# Microsoft Fabric Data Pipeline Deployment

This project demonstrates how to trigger a Microsoft Fabric Data Pipeline using GitHub Actions.

## Setup

1. Configure GitHub secrets:
   - AZURE_CLIENT_ID
   - AZURE_TENANT_ID
   - AZURE_CLIENT_SECRET
   - FABRIC_WORKSPACE_ID
   - PIPELINE_ID

2. Commit to the `main` branch to trigger the deployment.