import os
import requests
from msal import ConfidentialClientApplication

# Environment variables
client_id = os.getenv("AZURE_CLIENT_ID")
client_secret = os.getenv("AZURE_CLIENT_SECRET")
tenant_id = os.getenv("AZURE_TENANT_ID")
workspace_id = os.getenv("FABRIC_WORKSPACE_ID")
pipeline_id = os.getenv("PIPELINE_ID")

# Authentication
app = ConfidentialClientApplication(
    client_id=client_id,
    authority=f"https://login.microsoftonline.com/{tenant_id}",
    client_credential=client_secret
)

token_response = app.acquire_token_for_client(scopes=["https://api.fabric.microsoft.com/.default"])
access_token = token_response.get("access_token")

headers = {
    "Authorization": f"Bearer {access_token}",
    "Content-Type": "application/json"
}

# Trigger the pipeline run
url = f"https://api.fabric.microsoft.com/v1/workspaces/{workspace_id}/pipelines/{pipeline_id}/run"
response = requests.post(url, headers=headers)

if response.status_code == 202:
    print("✅ Pipeline triggered successfully.")
else:
    print(f"❌ Failed to trigger pipeline: {response.status_code}")
    print(response.text)