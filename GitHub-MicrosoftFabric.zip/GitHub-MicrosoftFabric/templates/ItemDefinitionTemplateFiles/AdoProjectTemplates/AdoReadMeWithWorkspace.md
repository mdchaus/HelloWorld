﻿# ADO Project used to demonstrate workspace export/import with Fabric REST API 

This ADO project provides exports from this Fabric workspace:
 - Workspace Name: **{WORKSPACE_NAME}**
 - Workspace Id: **{WORKSPACE_ID}**
 - Workspace URL: **[{WORKSPACE_URL}]({WORKSPACE_URL})**
