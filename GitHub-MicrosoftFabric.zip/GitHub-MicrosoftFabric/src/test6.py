
from fabric_devops import AdoProjectManager, AppLogger

project_name = "Diggler"


