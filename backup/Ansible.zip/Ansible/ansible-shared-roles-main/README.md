# Ansible Implementation and Best Practices

## Introduction

Ansible is a software tool that enables cross-platform automation and orchestration at scale and has become over the years the standard choice among enterprise automation solutions.

## USBank Use Cases

- Automate application deployment on VMs.

- Automate Enterprise Agent istallation on VMs ( e.g. App Dynamics , Autosys , Forgerock etc )


## Basic Terms

`Host`: A remote machine managed by Ansible.

`Group`: Several hosts grouped together that share a common attribute.

`Inventory`: A collection of all the hosts and groups that Ansible manages. Could be a static file in the simple cases or we can pull the inventory from remote sources, such as cloud providers.

`Modules`: Units of code that Ansible sends to the remote nodes for execution.

`Tasks`: Units of action that combine a module and its arguments along with some other parameters.

`Playbooks`: An ordered list of tasks along with its necessary parameters that define a recipe to configure a system.

`Roles`: Redistributable units of organization that allow users to share automation code easier.



## Best Practices

`Modular Playbooks:` Break down playbooks into small, reusable roles for better organization and maintainability.

`Idempotency:` Ensure tasks can be run multiple times without causing unintended changes, promoting stability and predictability.

`Variable Management:` Use variables to make playbooks flexible and reusable across different environments.

`Documentation:` Document playbooks, roles, and variables comprehensively for easier understanding and future updates.

`Error Handling:` Implement proper error handling mechanisms to handle failures gracefully and provide informative error messages.

`Playbook Execution:` Run playbooks with appropriate options, such as specifying the inventory file and limiting tasks to specific hosts or groups.

`Utilize Handlers:` Define handlers to trigger actions based on changes made by tasks, such as restarting services after configuration updates.

# Implementation

## Directory Layout

```
inventories/
   production/
      hosts               # inventory file for production servers
      group_vars/
         appserver.yml       # here we assign variables to particular groups e.g appserver
         dbserver.yml
      host_vars/
         hostname1.yml    # here we assign variables to particular systems
         hostname2.yml

   uat/
      hosts               # inventory file for uat environment
      group_vars/
         appserver.yml       # here we assign variables to particular groups
         dbserver.yml
      host_vars/
         uathost1.yml   # here we assign variables to particular systems
         uathost2.yml
group_vars             # here we can store global variables which are common across the environment
   all.yml
library/
module_utils/
filter_plugins/

site.yml     # Master Playbook
webservers.yml # App server playbook
dbservers.yml    # DB server playbook

roles/      # Reusbale Roles
    common/
    webtier/
    monitoring/
    fooapp/

```

## How to execute Ansible using Gitlab Pipelines

Dconf provides the capability to run ansible using the null resource module.
 
```shell
nullResource:
      instance01:
        provisioners:
        - command: "export ANSIBLE_TIMEOUT=120 && export no_proxy=$no_proxy,*.azr.bank-dns.com && ansible-playbook -i  ${path.cwd}/ansible/inventories/dev ${path.cwd}/ansible/site.yml -vvv"
          type: local
        serviceVersion: main
        triggers: {
          changes: "${timestamp()}"
        }
```
In above example , ansible will execute the master playbook site.yml. Child playbook can be imported in site.yml to distinguish/differentiate between different set of installation.  


```
- import_playbook: appserver.yml
- import_playbook: reportingserver.yml


```

## Inventory files

Maintain inventory files based on environments and proper groupings.

### Host File

```ini
[webservers]
<AppVMName1>.AZR.BANK-DNS.COM
<AppVMName2>.AZR.BANK-DNS.COM

[dbservers]
<DBVMName1>.AZR.BANK-DNS.COM
<DBVMName2>.AZR.BANK-DNS.COM
<DBVMName3>.AZR.BANK-DNS.COM

# Example to add range of hosts
[dbservers]  
<DBVMName>[01:50].AZR.BANK-DNS.COM

```

### Group Variable File


```
key: "value"

```

## Shared Roles

Cloud Migration Team is continuously working on creating reusable roles and sample playbooks.\
Gitlab Repository  :-  https://gitlab.us.bank-dns.com/AZURECLOUDMIGRATION/ansible-shared-roles

## How to use shared roles in application repository

![Shared_Role](../docs/images/shared_role.png)


- ### Create Role Requirements File

    Create a Role requirement.tmpl file either in the ansible directory or roles directory. \
    Below will be the content of  `requirements.tmpl` file. 

    This step is mandatory to add as it is, so the pipeline refers to the shared roles to retrieve the required roles

```
- name: shared_roles
  src: https://gitlab-ci-token:${CI_JOB_TOKEN}@gitlab.us.bank-dns.com/AZURECLOUDMIGRATION/ansible-shared-roles.git
  scm: git
  version: stable
```


- ### Install Shared Roles using `ansible-galaxy`

    Ansible Dconf needs to be modified as below to include `ansible-galaxy install` with two arguments.\
      1. Location of the requirements file.\
      2. Location where shared roles will be installed. 

    In the below example , `CI_JOB_TOKEN` in `requirements.tmpl` is substituted from env variables to create `requiremnts.yml` file. 
```yaml
nullResource:
      instance01:
        provisioners:
        - command: "apt-get install gettext-base && 
                    envsubst < ${path.cwd}/ansible/roles/requirements.tmpl > ${path.cwd}/ansible/roles/requirements.yml && 
                    export ANSIBLE_TIMEOUT=120 && apt-get install -y sshpass && export no_proxy=$no_proxy,.azr.bank-dns.com && 
                    ansible-galaxy install --roles-path ${path.cwd}/ansible/roles -r ${path.cwd}/ansible/roles/requirements.yml && 
                    ansible-playbook -i  ${path.cwd}/ansible/inventories/dev ${path.cwd}/ansible/site.yml -v|| exit 1"
          type: local
        serviceVersion: main
        triggers: { changes: "${timestamp()}"}



```

- ### Use shared roles in playbook 

    In Ansible playbook , reference the roles from the installed location or use relative paths to point to the roles within the repository. For example.

```ansible
- hosts: appserver
  gather_facts: true
  become: yes
  strategy: free
  roles:
    - shared_roles/linux/yum_installations_linux_rhel
    - shared_roles/linux/install_tomcat_linux_rhel
    - shared_roles/linux/copy_files_from_artifactory_linux_rhel
```

- ### Version control
    Ensure proper version is specified in the `requirements.tmpl` file. `version: stable` is recommended but can be changed to use tags as needed. 


### Shared Roles Linux RHEL 

Reusable Role Name     | Role Location  |  Role Readme Files    | Installer Version |
|---|---|----|----|
appdynamics_java_agent_linux_rhel     | [Github location](https://gitlab.us.bank-dns.com/AZURECLOUDMIGRATION/ansible-shared-roles/-/tree/main/roles/linux/appdynamics_java_agent_linux_rhel?ref_type=heads) | [README.md](https://gitlab.us.bank-dns.com/AZURECLOUDMIGRATION/ansible-shared-roles/-/blob/main/roles/linux/appdynamics_java_agent_linux_rhel/README.md?ref_type=heads)
appdynamics_machine_agent_linux_rhel  | [Github location](https://gitlab.us.bank-dns.com/AZURECLOUDMIGRATION/ansible-shared-roles/-/tree/main/roles/linux/appdynamics_machine_agent_linux_rhel?ref_type=heads) | [README.md](https://gitlab.us.bank-dns.com/AZURECLOUDMIGRATION/ansible-shared-roles/-/blob/main/roles/linux/appdynamics_machine_agent_linux_rhel/README.md?ref_type=heads)
copy_files_from_artifactory_linux_rhel | [Github location](https://gitlab.us.bank-dns.com/AZURECLOUDMIGRATION/ansible-shared-roles/-/tree/main/roles/linux/copy_files_from_artifactory_linux_rhel?ref_type=heads) | [README.md](https://gitlab.us.bank-dns.com/AZURECLOUDMIGRATION/ansible-shared-roles/-/blob/main/roles/linux/copy_files_from_artifactory_linux_rhel/README.md?ref_type=heads)
create_directories_linux_rhel | [Github location](https://gitlab.us.bank-dns.com/AZURECLOUDMIGRATION/ansible-shared-roles/-/tree/main/roles/linux/create_directories_linux_rhel?ref_type=heads) | [README.md](https://gitlab.us.bank-dns.com/AZURECLOUDMIGRATION/ansible-shared-roles/-/blob/main/roles/linux/create_directories_linux_rhel/README.md?ref_type=heads)
delete_directories_linux_rhel | [Github location](https://gitlab.us.bank-dns.com/AZURECLOUDMIGRATION/ansible-shared-roles/-/tree/main/roles/linux/delete_directories_linux_rhel?ref_type=heads) | [README.md](https://gitlab.us.bank-dns.com/AZURECLOUDMIGRATION/ansible-shared-roles/-/blob/main/roles/linux/delete_directories_linux_rhel/README.md?ref_type=heads)
file_line_appender_linux_rhel | [Github location](https://gitlab.us.bank-dns.com/AZURECLOUDMIGRATION/ansible-shared-roles/-/tree/main/roles/linux/file_line_appender_linux_rhel?ref_type=heads) | [README.md](https://gitlab.us.bank-dns.com/AZURECLOUDMIGRATION/ansible-shared-roles/-/blob/main/roles/linux/file_line_appender_linux_rhel/README.md?ref_type=heads)
install_jre_linux | [Github location](https://gitlab.us.bank-dns.com/AZURECLOUDMIGRATION/ansible-shared-roles/-/tree/main/roles/linux/install_jre_linux?ref_type=heads) | [README.md](https://gitlab.us.bank-dns.com/AZURECLOUDMIGRATION/ansible-shared-roles/-/blob/main/roles/linux/install_jre_linux/README.md?ref_type=heads)
install_tomcat_linux_rhel | [Github location](https://gitlab.us.bank-dns.com/AZURECLOUDMIGRATION/ansible-shared-roles/-/tree/main/roles/linux/install_tomcat_linux_rhel?ref_type=heads) | [README.md](https://gitlab.us.bank-dns.com/AZURECLOUDMIGRATION/ansible-shared-roles/-/blob/main/roles/linux/install_tomcat_linux_rhel/README.md?ref_type=heads)
run_shellscripts_linux_rhel | [Github location](https://gitlab.us.bank-dns.com/AZURECLOUDMIGRATION/ansible-shared-roles/-/tree/main/roles/linux/run_shellscripts_linux_rhel?ref_type=heads) | [README.md](https://gitlab.us.bank-dns.com/AZURECLOUDMIGRATION/ansible-shared-roles/-/blob/main/roles/linux/run_shellscripts_linux_rhel/README.md?ref_type=heads)
setup_path_variables_linux_rhel | [Github location](https://gitlab.us.bank-dns.com/AZURECLOUDMIGRATION/ansible-shared-roles/-/tree/main/roles/linux/setup_path_variables_linux_rhel?ref_type=heads) | [README.md](https://gitlab.us.bank-dns.com/AZURECLOUDMIGRATION/ansible-shared-roles/-/blob/main/roles/linux/setup_path_variables_linux_rhel/README.md?ref_type=heads)
unarchive_files_linux_rhel | [Github location](https://gitlab.us.bank-dns.com/AZURECLOUDMIGRATION/ansible-shared-roles/-/tree/main/roles/linux/unarchive_files_linux_rhel?ref_type=heads) | [README.md](https://gitlab.us.bank-dns.com/AZURECLOUDMIGRATION/ansible-shared-roles/-/blob/main/roles/linux/unarchive_files_linux_rhel/README.md?ref_type=heads)
yum_installations_linux_rhel | [Github location](https://gitlab.us.bank-dns.com/AZURECLOUDMIGRATION/ansible-shared-roles/-/tree/main/roles/linux/yum_installations_linux_rhel?ref_type=heads) | [README.md](https://gitlab.us.bank-dns.com/AZURECLOUDMIGRATION/ansible-shared-roles/-/blob/main/roles/linux/yum_installations_linux_rhel/README.md?ref_type=heads)
nessus_install_linux_rhel | [Github location](https://gitlab.us.bank-dns.com/AZURECLOUDMIGRATION/ansible-shared-roles/-/tree/main/roles/linux/nessus_install_linux_rhel?ref_type=heads) | [README.md](https://gitlab.us.bank-dns.com/AZURECLOUDMIGRATION/ansible-shared-roles/-/blob/main/roles/linux/nessus_install_linux_rhel/README.md?ref_type=heads)
create_usersandgroups_linux_rhel | [Github location](https://gitlab.us.bank-dns.com/AZURECLOUDMIGRATION/ansible-shared-roles/-/tree/main/roles/linux/create_usersandgroups_linux_rhel?ref_type=heads) | [README.md](https://gitlab.us.bank-dns.com/AZURECLOUDMIGRATION/ansible-shared-roles/-/blob/main/roles/linux/create_usersandgroups_linux_rhel/README.md?ref_type=heads)
copy_ad_secrets_from_akv_to_vm_linux_rhel | [Github location](https://gitlab.us.bank-dns.com/AZURECLOUDMIGRATION/ansible-shared-roles/-/tree/main/roles/linux/copy_ad_secrets_from_akv_to_vm_linux_rhel?ref_type=heads) | [README.md](https://gitlab.us.bank-dns.com/AZURECLOUDMIGRATION/ansible-shared-roles/-/blob/main/roles/linux/copy_ad_secrets_from_akv_to_vm_linux_rhel/README.md?ref_type=heads)
modify_file_permission_linux_rhel | [Github location](https://gitlab.us.bank-dns.com/AZURECLOUDMIGRATION/ansible-shared-roles/-/tree/main/roles/linux/modify_file_permission_linux_rhel?ref_type=heads) | [README.md](https://gitlab.us.bank-dns.com/AZURECLOUDMIGRATION/ansible-shared-roles/-/blob/main/roles/linux/modify_file_permission_linux_rhel/README.md?ref_type=heads)
add_startup_scripts_linux_rhel | [Github location](https://gitlab.us.bank-dns.com/AZURECLOUDMIGRATION/ansible-shared-roles/-/tree/main/roles/linux/add_startup_scripts_linux_rhel?ref_type=heads) | [README.md](https://gitlab.us.bank-dns.com/AZURECLOUDMIGRATION/ansible-shared-roles/-/blob/main/roles/linux/add_startup_scripts_linux_rhel/README.md?ref_type=heads)
dnf_install_linux_rhel | [Github location](https://gitlab.us.bank-dns.com/AZURECLOUDMIGRATION/ansible-shared-roles/-/tree/main/roles/linux/dnf_install_linux_rhel?ref_type=heads) | [README.md](https://gitlab.us.bank-dns.com/AZURECLOUDMIGRATION/ansible-shared-roles/-/blob/main/roles/linux/dnf_install_linux_rhel/README.md?ref_type=heads)
mount_onprem_nas_drive_linux_vm | [Github location](https://gitlab.us.bank-dns.com/AZURECLOUDMIGRATION/ansible-shared-roles/-/tree/main/roles/linux/copy_files_from_artifactory_linux_rhel?ref_type=heads) | [README.md](https://gitlab.us.bank-dns.com/AZURECLOUDMIGRATION/ansible-shared-roles/-/blob/main/roles/linux/copy_files_from_artifactory_linux_rhel/README.md?ref_type=heads)





### Shared Roles -  Windows  
Reusable Role Name     | Role Location                                                                                                                                                                      |  Role Readme Files | Installer Version |
|---|------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|----| ---- |
add_appid_to_vm_env_var_win | [Github location](https://gitlab.us.bank-dns.com/AZURECLOUDMIGRATION/ansible-shared-roles/-/tree/main/roles/windows/add_appid_to_vm_env_var_win?ref_type=heads)                    |[README.md](https://gitlab.us.bank-dns.com/AZURECLOUDMIGRATION/ansible-shared-roles/-/blob/main/roles/windows/add_appid_to_vm_env_var_win/README.md?ref_type=heads)
add_user_admingroup_win | [Github location](https://gitlab.us.bank-dns.com/AZURECLOUDMIGRATION/ansible-shared-roles/-/tree/main/roles/windows/add_user_admingroup_win?ref_type=heads)                        |[README.md](https://gitlab.us.bank-dns.com/AZURECLOUDMIGRATION/ansible-shared-roles/-/blob/main/roles/windows/add_user_admingroup_win/README.md?ref_type=heads)
create_directory_win | [Github location](https://gitlab.us.bank-dns.com/AZURECLOUDMIGRATION/ansible-shared-roles/-/tree/main/roles/windows/create_directories_win?ref_type=heads)                         | [README.md](https://gitlab.us.bank-dns.com/AZURECLOUDMIGRATION/ansible-shared-roles/-/blob/main/roles/windows/create_directories_win/README.md?ref_type=heads)
copy_files_from_artifactory_win | [Github location](https://gitlab.us.bank-dns.com/AZURECLOUDMIGRATION/ansible-shared-roles/-/tree/main/roles/windows/copy_files_from_artifactory_win?ref_type=heads)                | [README.md](https://gitlab.us.bank-dns.com/AZURECLOUDMIGRATION/ansible-shared-roles/-/blob/main/roles/windows/copy_files_from_artifactory_win/README.md?ref_type=heads)
download_latest_artifacts_from_artficatory_win | [Github location](https://gitlab.us.bank-dns.com/AZURECLOUDMIGRATION/ansible-shared-roles/-/tree/main/roles/windows/download_latest_artifacts_from_artficatory_win?ref_type=heads) |[README.md](https://gitlab.us.bank-dns.com/AZURECLOUDMIGRATION/ansible-shared-roles/-/blob/main/roles/windows/download_latest_artifacts_from_artficatory_win/README.md?ref_type=heads)
install_vcplus_win | [Github location](https://gitlab.us.bank-dns.com/AZURECLOUDMIGRATION/ansible-shared-roles/-/tree/main/roles/windows/install_vcplus_win?ref_type=heads) |[README.md](https://gitlab.us.bank-dns.com/AZURECLOUDMIGRATION/ansible-shared-roles/-/blob/main/roles/windows/install_vcplus_win/README.md?ref_type=heads)
nessus_agent_win | [Github location](https://gitlab.us.bank-dns.com/AZURECLOUDMIGRATION/ansible-shared-roles/-/tree/main/roles/windows/nessus_agent_win?ref_type=heads) | [README.md](https://gitlab.us.bank-dns.com/AZURECLOUDMIGRATION/ansible-shared-roles/-/blob/main/roles/windows/nessus_agent_win/README.md?ref_type=heads)
unzip_packages_win | [Github location](https://gitlab.us.bank-dns.com/AZURECLOUDMIGRATION/ansible-shared-roles/-/tree/main/roles/windows/unzip_packages_win?ref_type=heads) | [README.md](https://gitlab.us.bank-dns.com/AZURECLOUDMIGRATION/ansible-shared-roles/-/blob/main/roles/windows/unzip_packages_win/README.md?ref_type=heads)
install_iis_win | [Github location](https://gitlab.us.bank-dns.com/AZURECLOUDMIGRATION/ansible-shared-roles/-/tree/main/roles/windows/install_iis_win?ref_type=heads) | [README.md](https://gitlab.us.bank-dns.com/AZURECLOUDMIGRATION/ansible-shared-roles/-/blob/main/roles/windows/install_iis_win/Readme.md?ref_type=heads)
install_SSRS_win | [Github location](https://gitlab.us.bank-dns.com/AZURECLOUDMIGRATION/ansible-shared-roles/-/tree/main/roles/windows/install_SSRS_win?ref_type=heads) | [README.md](https://gitlab.us.bank-dns.com/AZURECLOUDMIGRATION/ansible-shared-roles/-/blob/main/roles/windows/install_SSRS_win/Readme.md?ref_type=heads)
install_tomcat_win | [Github location](https://gitlab.us.bank-dns.com/AZURECLOUDMIGRATION/ansible-shared-roles/-/tree/main/roles/windows/install_tomcat_win?ref_type=heads) | [README.md](https://gitlab.us.bank-dns.com/AZURECLOUDMIGRATION/ansible-shared-roles/-/blob/main/roles/windows/install_tomcat_win/README.md?ref_type=heads)
install_forgerock_dotnet_win | [Github location](https://gitlab.us.bank-dns.com/AZURECLOUDMIGRATION/ansible-shared-roles/-/tree/main/roles/windows/install_forgerock_dotnet_win?ref_type=heads) | [README.md](https://gitlab.us.bank-dns.com/AZURECLOUDMIGRATION/ansible-shared-roles/-/blob/main/roles/windows/install_forgerock_dotnet_win/readme.md?ref_type=heads)
run_powershell_win | [Github location](https://gitlab.us.bank-dns.com/AZURECLOUDMIGRATION/ansible-shared-roles/-/tree/main/roles/windows/run_powershell_win?ref_type=heads) | [README.md](https://gitlab.us.bank-dns.com/AZURECLOUDMIGRATION/ansible-shared-roles/-/blob/main/roles/windows/run_powershell_win/README.md?ref_type=heads)
install_edge_win | [Github location](https://gitlab.us.bank-dns.com/AZURECLOUDMIGRATION/ansible-shared-roles/-/tree/main/roles/windows/install_edge_win?ref_type=heads) | [README.md](https://gitlab.us.bank-dns.com/AZURECLOUDMIGRATION/ansible-shared-roles/-/blob/main/roles/windows/install_edge_win/README.md?ref_type=heads)
install_packages_win | [Github location](https://gitlab.us.bank-dns.com/AZURECLOUDMIGRATION/ansible-shared-roles/-/tree/main/roles/windows/install_packages_win?ref_type=heads) | [README.md](https://gitlab.us.bank-dns.com/AZURECLOUDMIGRATION/ansible-shared-roles/-/blob/main/roles/windows/install_packages_win/README.md?ref_type=heads)
create_task_scheduler_win | [Github location](https://gitlab.us.bank-dns.com/AZURECLOUDMIGRATION/ansible-shared-roles/-/tree/main/roles/windows/create_task_scheduler_win?ref_type=heads) | [README.md](https://gitlab.us.bank-dns.com/AZURECLOUDMIGRATION/ansible-shared-roles/-/blob/main/roles/windows/create_task_scheduler_win/README.md?ref_type=heads)
nessus_agent_win | [Github location](https://gitlab.us.bank-dns.com/AZURECLOUDMIGRATION/ansible-shared-roles/-/tree/main/roles/windows/nessus_agent_win?ref_type=heads) | [README.md](https://gitlab.us.bank-dns.com/AZURECLOUDMIGRATION/ansible-shared-roles/-/blob/main/roles/windows/nessus_agent_win/README.md?ref_type=heads)
install_iis_win | [Github location](https://gitlab.us.bank-dns.com/AZURECLOUDMIGRATION/ansible-shared-roles/-/tree/main/roles/windows/install_iis_win?ref_type=heads) | [README.md](https://gitlab.us.bank-dns.com/AZURECLOUDMIGRATION/ansible-shared-roles/-/blob/main/roles/windows/install_iis_win/Readme.md?ref_type=heads)
install_vcplus_win | [Github location](https://gitlab.us.bank-dns.com/AZURECLOUDMIGRATION/ansible-shared-roles/-/tree/main/roles/windows/install_vcplus_win?ref_type=heads) | [README.md](https://gitlab.us.bank-dns.com/AZURECLOUDMIGRATION/ansible-shared-roles/-/blob/main/roles/windows/install_vcplus_win/README.md?ref_type=heads)
install_odbc_driver_win | [Github location](https://gitlab.us.bank-dns.com/AZURECLOUDMIGRATION/ansible-shared-roles/-/tree/main/roles/windows/install_odbc_driver_win?ref_type=heads) | [README.md](https://gitlab.us.bank-dns.com/AZURECLOUDMIGRATION/ansible-shared-roles/-/blob/main/roles/windows/install_odbc_driver_win/README.md?ref_type=heads) | Supports 17 & 18
mount_azure_fileshare_win | [Github location](https://gitlab.us.bank-dns.com/AZURECLOUDMIGRATION/ansible-shared-roles/-/tree/main/roles/windows/mount_azure_fileshare_win?ref_type=heads) | [README.md](https://gitlab.us.bank-dns.com/AZURECLOUDMIGRATION/ansible-shared-roles/-/blob/main/roles/windows/mount_azure_fileshare_win/README.md?ref_type=heads)
java_agent_win | [Github location](https://gitlab.us.bank-dns.com/AZURECLOUDMIGRATION/ansible-shared-roles/-/tree/main/roles/windows/java_agent_win?ref_type=heads) | [README.md](https://gitlab.us.bank-dns.com/AZURECLOUDMIGRATION/ansible-shared-roles/-/blob/main/roles/windows/java_agent_win/%20README.md?ref_type=heads) | ver 8
install_dotnetcore_win | [Github location](https://gitlab.us.bank-dns.com/AZURECLOUDMIGRATION/ansible-shared-roles/-/tree/main/roles/windows/install_dotnetcore_win?ref_type=heads) | [README.md](https://gitlab.us.bank-dns.com/AZURECLOUDMIGRATION/ansible-shared-roles/-/blob/main/roles/windows/install_dotnetcore_win/README.md?ref_type=heads) | Supports 6.0.10 , 6.0.25 , 6.0.29 , 6.0.31
install_SSIS_win | [Github location](https://gitlab.us.bank-dns.com/AZURECLOUDMIGRATION/ansible-shared-roles/-/tree/main/roles/windows/install_SSIS_win?ref_type=heads) | [README.md](https://gitlab.us.bank-dns.com/AZURECLOUDMIGRATION/ansible-shared-roles/-/blob/main/roles/windows/install_SSIS_win/README.md?ref_type=heads)
copy_files_from_gitlab_to_vm_win | [Github location](https://gitlab.us.bank-dns.com/AZURECLOUDMIGRATION/ansible-shared-roles/-/tree/main/roles/windows/copy_files_from_gitlab_to_vm_win?ref_type=heads) | [README.md](https://gitlab.us.bank-dns.com/AZURECLOUDMIGRATION/ansible-shared-roles/-/blob/main/roles/windows/copy_files_from_gitlab_to_vm_win/README.md?ref_type=heads)
install_python_win | [Github location](https://gitlab.us.bank-dns.com/AZURECLOUDMIGRATION/ansible-shared-roles/-/tree/main/roles/windows/install_python_win?ref_type=heads) | [README.md](https://gitlab.us.bank-dns.com/AZURECLOUDMIGRATION/ansible-shared-roles/-/blob/main/roles/windows/install_python_win/README.md?ref_type=heads)
copy_credentials_from_akv_to_tibco_encrypted_config_win | [Github location](https://gitlab.us.bank-dns.com/AZURECLOUDMIGRATION/ansible-shared-roles/-/tree/main/roles/windows/copy_credentials_from_akv_to_tibco_encrypted_config_win?ref_type=heads) | [README.md](https://gitlab.us.bank-dns.com/AZURECLOUDMIGRATION/ansible-shared-roles/-/blob/main/roles/windows/copy_credentials_from_akv_to_tibco_encrypted_config_win/README.md?ref_type=heads)
stop_restart_shir_win | [Github location](https://gitlab.us.bank-dns.com/AZURECLOUDMIGRATION/ansible-shared-roles/-/tree/main/roles/windows/stop_restart_shir_win?ref_type=heads) | [README.md](https://gitlab.us.bank-dns.com/AZURECLOUDMIGRATION/ansible-shared-roles/-/blob/main/roles/windows/stop_restart_shir_win/README.md?ref_type=heads)
install_shir_win | [Github location](https://gitlab.us.bank-dns.com/AZURECLOUDMIGRATION/ansible-shared-roles/-/tree/main/roles/windows/install_shir_win?ref_type=heads) | [README.md](https://gitlab.us.bank-dns.com/AZURECLOUDMIGRATION/ansible-shared-roles/-/blob/main/roles/windows/install_shir_win/README.md?ref_type=heads) | Support 5.33.8649.1 , 5.44.8993.1
install_R_win | [Github location](https://gitlab.us.bank-dns.com/AZURECLOUDMIGRATION/ansible-shared-roles/-/tree/main/roles/windows/install_R_win?ref_type=heads) | [README.md](https://gitlab.us.bank-dns.com/AZURECLOUDMIGRATION/ansible-shared-roles/-/blob/main/roles/windows/install_R_win/README.md?ref_type=heads) | Supports 4.2.2, 4.4.1
install_perl_win | [Github location](https://gitlab.us.bank-dns.com/AZURECLOUDMIGRATION/ansible-shared-roles/-/tree/main/roles/windows/install_perl_win?ref_type=heads) | [README.md](https://gitlab.us.bank-dns.com/AZURECLOUDMIGRATION/ansible-shared-roles/-/blob/main/roles/windows/install_perl_win/README.md?ref_type=heads) | Support 5.32.1.1, 5.38.2.2 
install_IIS_URL_Rewrite_win | [Github location](https://gitlab.us.bank-dns.com/AZURECLOUDMIGRATION/ansible-shared-roles/-/tree/main/roles/windows/install_IIS_URL_Rewrite_win?ref_type=heads) | [README.md](https://gitlab.us.bank-dns.com/AZURECLOUDMIGRATION/ansible-shared-roles/-/blob/main/roles/windows/install_IIS_URL_Rewrite_win/Readme.md?ref_type=heads)





### Release Cadence 

Cloud Migration Engineering team strives for a bi-weekly release cadence for implementing new roles. This involves creating release tags with proper documentation , piloting changes with select applications and subsequently merging it to `stable` branch for broader implementation.

If your application has specific requirement, please submit a Jira backlog story on this board. [Jira Board](https://jira.us.bank-dns.com/secure/RapidBoard.jspa?rapidView=16790&view=planning&selectedIssue=CLOUDME-23641&epics=visible&issueLimit=-1&selectedEpic=CLOUDME-23637).

### Release Strategy
- Feature Branch to be created for every role development and should contain the JIRA ticket Number
- Merge Request is required to move the changes to the main branch. It should contain successful job link from the test ansible repo.  
- On the release day , a new tag will be created by incrementing the previous tag version. 
- The changes from the tag will be merged to stable branch after piloting the changes with select applications. 

Also, this repository is open for contribution. Please fork this project and create a merge request to contribute.

### Intake Strategy 

Engage with the application team during the TSA to pose relevant inquiries and determine all necessary software components.
 - Compile a comprehensive list detailing all software prerequisites for application installation, including examples such as Python, Java.
 - If Commercial Off-The-Shelf (COTS) software is involved, provide related vendor and software particulars.

Compare all available ansible role list and create a JIRA task to ansible team if required software component role currently unavailable.

![Intake Strategy](/docs/images/IntakeTSA.PNG)

### POD Teams Responsibilities

- Review all required software items identified during the TSA.
- Verify the availability of each software item within the shared repository.
- If any software is missing, create a Jira task for the Ansible team to request its inclusion.
- Develop the necessary Ansible role if it is not readily available, ensuring compliance with established standards.
- Integrate the developed Ansible role into the ansible framework.
- Contribute the developed assets back to the central shared repository for future use.

![POD](/docs/images/POD.PNG)

## Helpful Links

- [Ansible Best Practices](https://docs.ansible.com/ansible/2.8/user_guide/playbooks_best_practices.html#id15)

## Splunk Dashboard for Role utilization analysis

- [Splunk Dashboard](https://elosusbaws.splunkcloud.com/en-US/app/ABP_9672/abp_azure_ansible_automation?form.global_time.earliest=-7d%40h&form.global_time.latest=now&form.metta_component=*&form.selected_os=*&form.selected_roles=*&form.metta-app-name=*&form.text_Y4ENIvLF=*)

