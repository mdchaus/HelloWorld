### Intake Strategy 

Engage with the application team during the TSA to pose relevant inquiries and determine all necessary software components.
 - Compile a comprehensive list detailing all software prerequisites for application installation, including examples such as Python, Java.
 - If Commercial Off-The-Shelf (COTS) software is involved, provide related vendor and software particulars.

Compare all available ansible role list and create a JIRA task to ansible team if required software component role currently unavailable.

![Intake Strategy](../images/IntakeTSA.PNG)

### POD Teams Responsibilities

- Review all required software items identified during the TSA.
- Verify the availability of each software item within the shared repository.
- If any software is missing, create a Jira task for the Ansible team to request its inclusion.
- Develop the necessary Ansible role if it is not readily available, ensuring compliance with established standards.
- Integrate the developed Ansible role into the ansible framework.
- Contribute the developed assets back to the central shared repository for future use.

![POD](../images/POD.PNG)

## Helpful Links

- [Ansible Best Practices](https://docs.ansible.com/ansible/2.8/user_guide/playbooks_best_practices.html#id15)