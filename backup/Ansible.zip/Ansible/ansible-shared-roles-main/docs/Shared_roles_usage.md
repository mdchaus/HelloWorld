
## Shared Roles

Cloud Migration Team is continuously working on creating reusable roles and sample playbooks.\
Gitlab Repository  :-  https://gitlab.us.bank-dns.com/AZURECLOUDMIGRATION/ansible-shared-roles

## How to use shared roles in application repository

![Shared_Role](../images/shared_role.png)


- ### Create Role Requirements File

    Create a Role requirement.tmpl file either in the ansible directory or roles directory. \
    Below will be the content of  `requirements.tmpl` file. 

    This step is mandatory to add as it is, so the pipeline refers to the shared roles to retrieve the required roles

```
- name: shared_roles
  src: https://gitlab-ci-token:${CI_JOB_TOKEN}@gitlab.us.bank-dns.com/AZURECLOUDMIGRATION/ansible-shared-roles.git
  scm: git
  version: stable
```


- ### Install Shared Roles using `ansible-galaxy`

    Ansible Dconf needs to be modified as below to include `ansible-galaxy install` with two arguments.\
      1. Location of the requirements file.\
      2. Location where shared roles will be installed. 

    In the below example , `CI_JOB_TOKEN` in `requirements.tmpl` is substituted from env variables to create `requiremnts.yml` file. 
```shell
nullResource:
instance01:
provisioners:
- command: "apt-get install gettext-base && 
            envsubst < ${path.cwd}/ansible/roles/requirements.tmpl > ${path.cwd}/ansible/roles/requirements.yml && 
            export ANSIBLE_TIMEOUT=120 && apt-get install -y sshpass && export no_proxy=$no_proxy,*.azr.bank-dns.com &&
            ansible-galaxy install --roles-path ${path.cwd}/ansible/roles -r ${path.cwd}/ansible/roles/requirements.yml &&
            ls -ltr ${path.cwd}/ansible/roles/shared_roles/ &&
            ansible-playbook -i  ${path.cwd}/ansible/inventories/prod ${path.cwd}/ansible/site.yml"
type: local
serviceVersion: main
triggers: {
changes: "${timestamp()}"
}

```

- ### Use shared roles in playbook 

    In Ansible playbook , reference the roles from the installed location or use relative paths to point to the roles within the repository. For example.

```ansible
- hosts: appserver
  gather_facts: true
  become: yes
  strategy: free
  roles:
    - shared_roles/linux/yum_installations_linux_rhel
    - shared_roles/linux/install_tomcat_linux_rhel
    - shared_roles/linux/copy_files_from_artifactory_linux_rhel
```

- ### Version control
    Ensure proper version is specified in the `requirements.tmpl` file. `version: stable` is recommended but can be changed to use tags as needed. 

