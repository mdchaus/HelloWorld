### Splunk Dashboard to monitor Shared Roles utilization

-> [Splunk Dashboard](https://elosusbaws.splunkcloud.com/en-US/app/ABP_9672/abp_azure_ansible_automation?form.global_time.earliest=-7d%40h&form.global_time.latest=now&form.metta_component=*&form.selected_os=*&form.selected_roles=*&form.metta-app-name=*&form.text_Y4ENIvLF=*)
