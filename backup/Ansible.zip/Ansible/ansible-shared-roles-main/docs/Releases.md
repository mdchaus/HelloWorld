### Release Cadence 

Cloud Migration Engineering team strives for a bi-weekly release cadence for implementing new roles. This involves creating release tags with proper documentation , piloting changes with select applications and subsequently merging it to `stable` branch for broader implementation.

If your application has specific requirement, please submit a Jira backlog story on this board. [Jira Board](https://jira.us.bank-dns.com/secure/RapidBoard.jspa?rapidView=16790&view=planning&selectedIssue=CLOUDME-23641&epics=visible&issueLimit=-1&selectedEpic=CLOUDME-23637).

### Release Strategy
- Feature Branch to be created for every role development and should contain the JIRA ticket Number
- Merge Request is required to move the changes to the main branch. It should contain successful job link from the test ansible repo.  
- On the release day , a new tag will be created by incrementing the previous tag version. 
- The changes from the tag will be merged to stable branch after piloting the changes with select applications. 

Also, this repository is open for contribution. Please fork this project and create a merge request to contribute.
