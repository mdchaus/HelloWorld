# Ansible Implementation and Best Practices

## Introduction

Ansible is a software tool that enables cross-platform automation and orchestration at scale and has become over the years the standard choice among enterprise automation solutions.

## USBank Use Cases

- Automate application deployment on VMs.

- Automate Enterprise Agent istallation on VMs ( e.g. App Dynamics , Autosys , Forgerock etc )


## Basic Terms

`Host`: A remote machine managed by Ansible.

`Group`: Several hosts grouped together that share a common attribute.

`Inventory`: A collection of all the hosts and groups that Ansible manages. Could be a static file in the simple cases or we can pull the inventory from remote sources, such as cloud providers.

`Modules`: Units of code that Ansible sends to the remote nodes for execution.

`Tasks`: Units of action that combine a module and its arguments along with some other parameters.

`Playbooks`: An ordered list of tasks along with its necessary parameters that define a recipe to configure a system.

`Roles`: Redistributable units of organization that allow users to share automation code easier.



## Best Practices

`Modular Playbooks:` Break down playbooks into small, reusable roles for better organization and maintainability.

`Idempotency:` Ensure tasks can be run multiple times without causing unintended changes, promoting stability and predictability.

`Variable Management:` Use variables to make playbooks flexible and reusable across different environments.

`Documentation:` Document playbooks, roles, and variables comprehensively for easier understanding and future updates.

`Error Handling:` Implement proper error handling mechanisms to handle failures gracefully and provide informative error messages.

`Playbook Execution:` Run playbooks with appropriate options, such as specifying the inventory file and limiting tasks to specific hosts or groups.

`Utilize Handlers:` Define handlers to trigger actions based on changes made by tasks, such as restarting services after configuration updates.

# Implementation

## Directory Layout

```
inventories/
   production/
      hosts               # inventory file for production servers
      group_vars/
         appserver.yml       # here we assign variables to particular groups e.g appserver
         dbserver.yml
      host_vars/
         hostname1.yml    # here we assign variables to particular systems
         hostname2.yml

   uat/
      hosts               # inventory file for uat environment
      group_vars/
         appserver.yml       # here we assign variables to particular groups
         dbserver.yml
      host_vars/
         uathost1.yml   # here we assign variables to particular systems
         uathost2.yml
group_vars             # here we can store global variables which are common across the environment
   all.yml
library/
module_utils/
filter_plugins/

site.yml     # Master Playbook
webservers.yml # App server playbook
dbservers.yml    # DB server playbook

roles/      # Reusbale Roles
    common/
    webtier/
    monitoring/
    fooapp/

```

## How to execute Ansible using Gitlab Pipelines

Dconf provides the capability to run ansible using the null resource module.
 
```shell
nullResource:
      instance01:
        provisioners:
        - command: "export ANSIBLE_TIMEOUT=120 && export no_proxy=$no_proxy,*.azr.bank-dns.com && ansible-playbook -i  ${path.cwd}/ansible/inventories/dev ${path.cwd}/ansible/site.yml -vvv"
          type: local
        serviceVersion: main
        triggers: {
          changes: "${timestamp()}"
        }
```
In above example , ansible will execute the master playbook site.yml. Child playbook can be imported in site.yml to distinguish/differentiate between different set of installation.  


```
- import_playbook: appserver.yml
- import_playbook: reportingserver.yml


```

## Inventory files

Maintain inventory files based on environments and proper groupings.

### Host File

```ini
[webservers]
<AppVMName1>.AZR.BANK-DNS.COM
<AppVMName2>.AZR.BANK-DNS.COM

[dbservers]
<DBVMName1>.AZR.BANK-DNS.COM
<DBVMName2>.AZR.BANK-DNS.COM
<DBVMName3>.AZR.BANK-DNS.COM

# Example to add range of hosts
[dbservers]  
<DBVMName>[01:50].AZR.BANK-DNS.COM

```

### Group Variable File


```
key: "value"

```

