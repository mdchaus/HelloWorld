# Copy HashiCorp Vault Replicated Credentials from Azure Key Vault to an Encrypted File on a Windows VM

## Description

This role pulls credentials from Azure Key Vault (AKV) to an xml config file and encrypts the credentials with [aspnet_regiis.exe](https://learn.microsoft.com/en-us/previous-versions/aspnet/zhhddkxy(v=vs.100))  The credentials are replicated from HashiCorp Vault (HCV) KV engine.

## Prerequisites

1. Your required credentials should replicated from HashiCorp Vault to AKV. Read more [here](https://confluence.us.bank-dns.com/pages/viewpage.action?pageId=312642762)

2. `aspnet_regiis.exe` installed on the system. 

## Variables

| Variable                    | Type       | Required | Description                                                                                                                         | Default                                            |
|-----------------------------|--------------|----------|-----------------------------------------------------------------------------------------------------------------------------------|----------------------------------------------------|
| akv_vault_name              | string       | Yes      | ID of your AKV                                                                                                                    | --                                                 |
| replicated_app_id           | string       | Yes      | Your app ID (this is the same as the TARGET identifier used in the replication process)                                           | --                                                 |
| metta_component_name        | string       | Yes      | Component name in metta ([Shield Console](https://shield-console.us.bank-dns.com/dashboard)) [this is probably `secretreplicate`] | --                                                 |
| metta_app_name              | string       | Yes      | App name in metta ([Shield Console](https://shield-console.us.bank-dns.com/dashboard))                                            | --                                                 |
| tibco_config_file_path      | string       | Yes      | Target path of your config file                                                                                                   | --                                                 |
| tibco_ids                   | list(dict()) | Yes      | A list of dictionaries with required credentials                                                                                  | --                                                 |
| microsoft_dotnet_version    | string       | Yes      | Version of Microsoft.NET Framework                                                                                                | `v4.0.30319`                                       |
| aspnet_regiss_exe           | string       | Yes      | Path to `aspnet_regiss.exe`                                                                                                       | `C:\\Windows\\Microsoft.NET\\Framework\\{{ microsoft_dotnet_version }}\\aspnet_regiss.exe` |

`tibco_ids` item dictionary keys:
  - `username`: Username
  - `password_id`: Key of secret in HCV KV engine
  - `name`: Value of XML element's `name` attribute.

NOTE: if `aspnet_regiss.exe` is in a different location, make sure to update `aspnet_regiis_exe_path` and/or `microsoft_dotnet_version` accordingly

### Reference

Behind the scenes, the role is using the `community.windows.win_xml` module. [Docs here](https://docs.ansible.com/ansible/latest/collections/community/windows/win_xml_module.html).

Learn about xpath [here](https://www.w3schools.com/xml/xml_xpath.asp)

## Usage

Simply include this role with the required variables populated. Example below.

Make sure your config file is similar to the one below:

<u>momCore.config</u>
```xml
<?xml version="1.0" encoding="utf-8"?>
<configuration>
  <configSections>
    <section 
      name="AIDMOMConfiguration" 
      type="USBAM.Core.Tibco.MOM.MOMSettings, USBAM.Core.Tibco, Version=1.2.0.0, Culture=neutral"
    />
  </configSections>
  <connectionStrings>
  </connectionStrings>
  <AIDMOMConfiguration>
    <MOMProviders>
      <add 
        EMSServerURL="tcp://emsas1t.us.bank-dns.com:27229" 
        UserId="tibco-user1" 
        Password="<password_from_akv>"
        SendRequestTimeOut="0" 
        momProviderDataType="USBAM.Core.Tibco.MOM.EMSProviderData, USBAM.Core.Tibco, Version=1.2.0.0, Culture=neutral"
        type="USBank.AID.ApplicationBlocks.MOM.TibcoEMS.TibcoEMS, USBAM.Common, Version=1.2.0.0, Culture=neutral"
        name="TibcoEMS" 
      />
      <add 
        EMSServerURL="tcp://emsas1t.us.bank-dns.com:27229" 
        UserId="tibco-admin-user"
        Password="<password_from_akv>"
        SendRequestTimeOut="0"
        momProviderDataType="USBAM.Core.Tibco.MOM.EMSProviderData, USBAM.Core.Tibco, Version=1.2.0.0, Culture=neutral"
        type="USBank.AID.ApplicationBlocks.MOM.TibcoEMS.TibcoEMS, USBAM.Common, Version=1.2.0.0.0, Culture=neutral" 
        name="TibcoEMS_Server" 
      />
    </MOMProviders>
  </AIDMOMConfiguration>
</configuration>
```

## Example

This example playbook will pull secrets HCV KV replicated secrets from AKV and add them to the `momCore.config` XML config file shown above.

<u>your_playbook.yml</u>
```yaml
---
- hosts: windows
  gather_facts: true
  become_method: runas
  strategy: free

  tasks:
    - name: Create encrypted config file with values from Azure Key vault
      ansible.builtin.include_role:
        name: shared_roles/windows/copy_credentials_from_akv_to_tibco_encrypted_config_win
      vars:
        akv_vault_name: kv-cus-abp03-dev-01
        replicated_app_id: appabp03appiddev
        metta_component_name: secretreplicate
        metta_app_name: azabp
        tibco_config_file_path: "D:\\tmp\\momCore.config"
        tibco_ids:
            - username: tibco-user1
              passphrase_akv_id: tibco-user1-pw
              name: "TibcoEMS"
            - username: tibco-admin-user
              passphrase_akv_id: tibco-admin-secret   
              name: "TibcoEMS_Server"
```

## Validation Steps

1. Verify that there is a config file at the target path
1. Verify that the elements under the `credentials_base_xpath` section are replaced with an encrypted element