## Description

This role is for enabling and configuration of IIS on Windows server.

## Variables

Below are the variables that has to be provided by the application team. For port_no variable, the default port is 443 , we suggest the port number not to be overriden.

```

- `app_pool_name`: The name of the application pool.
- `website_name`: The name of the website.
- `website_directory`: The physical path of the website.
- `key_vault_uri`: The URI of the Azure Key Vault.
- `protocol`: The protocol for the website binding.
- `port_no`: The port number for the website binding.
- `iis_auth_scripts`: The scripts for changing the IIS site authentication.
- `iis_enable_32_app`: true / false -  Optional - set as false by default
- `host_header`:  The server name
- `iis_website_folder_rights`: The permission for website folder, for reference use the link (https://msdn.microsoft.com/en-us/library/system.security.accesscontrol.filesystemrights.aspx)

```

Below are default variables and are defined in role itself. Application team don't have to pass these in the variable files.

```

feature_list: ["Web-Server", "Web-Common-Http", "Web-Http-Logging", "Web-Log-Libraries", "Web-Request-Monitor", "Web-Http-Tracing", "Web-Stat-Compression", "Web-Filtering", "Web-Basic-Auth", "Web-CertProvider", "Web-Client-Auth", "Web-Digest-Auth", "Web-Cert-Auth", "Web-IP-Security", "Web-Url-Auth", "Web-Windows-Auth", "Web-Net-Ext45", "Web-ASP", "Web-Asp-Net45", "Web-CGI", "Web-ISAPI-Ext", "Web-ISAPI-Filter", "Web-Includes", "Web-Mgmt-Tools"]
protocol:  "Https"
port_no: "443"


```

### Sample Playbook

```ansible
- hosts: windows
  gather_facts: true
  become_method: runas
  strategy: free
  roles:
    - shared_roles/windows/install_iis_win
  vars:
    iis_auth_scripts:
      - "$site = Get-IISSite -Name \"{{ website_name }}\""
      - "$site | Set-IISSite -AuthenticationMethods Anonymous"
    
```


### Validation Steps


To check whether if IIS is enabled and configured or not in the windows server. Search IIS in the Start menu and click on it. Now check the hostname , application pool name and your website name.

![image1.PNG](image1.PNG)
![image2.PNG](image2.PNG)
![image3.PNG](image3.PNG)



