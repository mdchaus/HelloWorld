## Description

This role is for Installation of Tomcat 9.0.85 on Windows server.

## Variables

Below are the variables that has to be provided by the application team.

```

tomcat_tmp_dest_path: "C:\\temp1"
tomcat_directory: "C:\\tomcat"
tomcat_installer_path: "C:\\tomcat\\apache-tomcat-9.0.85\\"

```

Below are default variables and are defined in role itself. Application team don't have to pass these in the variable files.

```

tomcat_version_number: "9.0.85"
tomcat_artifactory_url: "https://artifactory.us.bank-dns.com/artifactory/cloud-migration-softwares-generic-virtual/tomcat/Tomcat_9/apache-tomcat-9.0.85-windows-x64.zip"
tomcat_version_zip_name: "apache-tomcat-9.0.85-windows-x64.zip"

```

### Sample Playbook

```ansible
- hosts: windows
  gather_facts: true
  become_method: runas
  become_user: "ciabp03appiddev"
  strategy: free
  roles:
    - shared_roles/windows/install_tomcat_win



```

### Validation Steps


To check whether tomcat 9.0.85 is installed or not. Follow the below steps

   - Open a web browser.
   - Navigate to `http://localhost:8080`.
   - You should see the Apache Tomcat welcome page if the installation was successful on browser page
   ![img.png](img.png)
