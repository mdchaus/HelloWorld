# Ansible Role: install_packages_win

This role installs specified packages on Windows hosts. It also includes the `copy_files_from_artifactory_win` role to download the packages from Artifactory before installation.

## Requirements

- Ansible 2.9 or higher
- Windows hosts

## Role Variables

This role uses the following variables:

- `windows_packages`: A list of packages to install. Each package should be a dictionary with the following keys:
  - `path`: The path to the package installer.
  - `artifactory_url`: The URL to download the package from Artifactory.
  - `product_id` (optional): The product id of the package.
  - `arguments` (optional): Any additional arguments to pass to the installer.

## Dependencies

None

## Example Playbook 

This is playbook was used to install ODBC driver
```yaml
- hosts: windows
  gather_facts: true
  become_method: runas
  strategy: free
  roles:
    - shared_roles/windows/install_packages_win
  vars:
    windows_packages:
     - name: "msodbcsql18"
       path: "C:\\Users\\{{ ansible_user_id}}\\temp"
       artifactory_url: "https://artifactory.us.bank-dns.com/artifactory/list/cloud-migration-softwares-generic-virtual/windows/drivers/ODBC/msodbcsql18.msi"
       arguments: /quiet IACCEPTMSODBCSQLLICENSETERMS=yes /norestart
        
```
## Validation Steps

After running the playbook, you can validate that the packages were installed correctly by following these steps:

1. Log in to the Windows host.
2. Open the Control Panel.
3. Click on "Programs and Features".
4. Check the list of installed programs for the packages you specified in the `windows_packages` variable.

You can also validate the installation from the command line:

```cmd
wmic product get name
```
