## Description

This role is for downloading single/multiple software from provided URL and place it on the provided destination path on Windows server.    

## Variables

This variable is defined as a global variable. Multiple 'src' and 'dest' could be added under 'artifactory_files' as per the requirement.

```
artifactory_files:
  - src: "https://artifactory.us.bank-dns.com/artifactory/list/cloud-migration-softwares-generic-virtual/windows/drivers/ODBC/msodbcsql18.msi"      #URL of ODBC software msi
    dest: "D:\\packages"     #local directory on server
  - src: "https://artifactory.us.bank-dns.com/artifactory/list/cloud-migration-softwares-generic-virtual/windows/RedistributeVisualC++/VC_redist.x64.exe"  #URL of VC++ software exe
    dest: "D:\\packages"     #local directory on server

```
