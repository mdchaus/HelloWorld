# Description
This role is for copying files from GitLab to a Windows VM.

# Variables
Below are variables that need to be provided by the user:

- `copy_file_gitlab_folder`: The file or folder in GitLab that needs to be copied.
- `copy_file_vm_destination_folder`: The destination folder on the VM where the files will be copied to.

# Sample Playbook
To use this role, use Ansible Galaxy to install shared_roles during runtime and create a playbook as below.

```yaml
- hosts: windows
  gather_facts: true
  become_method: runas
  strategy: free
  roles:
    - shared_roles/windows/copy_files_from_gitlab_to_vm_win
  vars:
    copy_file_gitlab_folder: "/dev/ansible/usbcloud-deploy.yaml"
    copy_file_vm_destination_folder: "C://Temp//"
```

# Validation Steps
After the copying process, you can validate if the files have been copied correctly by following these steps:

1. Log in to the VM.
2. Navigate to the `copy_file_vm_destination_folder`.
3. Check if the files from `copy_file_gitlab_folder` are present.

If the files are present, then the copying process was successful. If not, please check the Ansible logs for any errors.