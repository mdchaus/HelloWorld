## Description

This role is for installing the Nessus agent on Windows VM. 

## Variables

Below are default variables and are defined in role itself. Application team don't have to pass these in the variable files.  
```
nessus-artifactory-url: 
destination-path:
nessus-version-number:
nessus-agent-group-name:
nessus-server-port:
nessus-agent-key:

```

## Sample Playbook

To use this role ,  Use ansible galaxy to installed shared_roles during runtime and create a playbook as below. 

```ansible
- hosts: nessus
  gather_facts: true
  become_method: runas
  strategy: free
  roles:
    - shared_roles/windows/nessus_agent_win
```

