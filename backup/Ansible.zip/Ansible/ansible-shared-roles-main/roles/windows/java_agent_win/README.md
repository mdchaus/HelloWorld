## Description

This role is for Installation of Java 1.8.0_362 on Windows server.

## Variables

```

Below are default variables and are defined in role itself. Application team don't have to pass these in the variable files.
- java_tmp_dest_path: "{{ java_directory }}"
- java_directory: "C:\\Program Files\\Java\\"
- java_folder_name: "{{ java_directory }}\\{{ java_installer_name | regex_replace('_x64.msi','') }}"
- java_artifactory_url: "https://artifactory.us.bank-dns.com/artifactory/cloud-migration-softwares-generic-virtual/java/OpenJDK_v8_x64"
- java_installer_name: "openjdk-1.8.0.362_x64.msi"

```

### Sample Playbook

```ansible
- hosts: windows
  gather_facts: true
  become_method: runas
  strategy: free
  roles:
    - shared_roles/windows/java_agent_win



```

### Validation Steps


To check whether java -version is installed or not. 

   (![Alt text](img.png))

   
