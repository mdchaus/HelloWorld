## Description

This role is for installing IIS Rewrite Module on Windows server.

## Variables

Below are default variables and are defined in role itself. Application team don't have to pass these in the variable files.

```
destination_filepath: "C:\\Users\\{{ ansible_user_id }}\\temp"
iis_rewrite_installer_url: "https://artifactory.us.bank-dns.com/artifactory/usbam-4908-generic-snapshot-local/installers/"
iis_rewrite_installer: "rewrite_amd64_en-US.msi"
no_of_retries:      'Provide the no of retries for ping'
no_of_delay:        'Provide the no of delay in retrying in sec'

```

### Sample Playbook

```ansible
- hosts: windows
  gather_facts: true
  become_method: runas
  strategy: free

  roles:
    - shared_roles/windows/install_IIS_URL_Rewrite_win


```

### Validation Steps


To check whether IIS URL Rewrite Module is installed or not open Control Panel and check. 

![img1.png](img1.png)