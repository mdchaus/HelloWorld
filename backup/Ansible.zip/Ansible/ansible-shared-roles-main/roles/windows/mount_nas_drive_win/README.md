## Description

This role is to mount Nas file share on Windows VM, this role will import "copy_ad_secrets_from_akv_to_vm_win" in to current role and processes to get the secrets

If your app ID is `appabp03appiddev`, 3 secrets will be accessible if you include this role:
1. `appabp03appiddev_USERNAME`
1. `appabp03appiddev_PASSWORD`
1. `appabp03appiddev_UPN`

## Prerequisites for "copy_ad_secrets_from_akv_to_vm_win" role

- Setup secret replication from HashiCorp Vault to Azure Key Vault by following [this process](https://confluence.us.bank-dns.com/pages/viewpage.action?pageId=312642762)

## Variables

Below variables must be defined by the end user


- mount_drive_letter:           Unique drive letter
- akv_vault_name:           ID of your Azure Key Vault
- replicated_app_id:            your app ID (this is the same as the TARGET identifier used in the replication process)
- metta_component_name:         component name in metta ([Shield Console](https://shield-console.us.bank-dns.com/dashboard)) [this is probably secretreplicate]
- metta_app_name:           app name in metta ([Shield Console](https://shield-console.us.bank-dns.com/dashboard))
- unc_nas_path:                     Define your Nasu nc path here

 

## Sample Playbook

```
- hosts: windows
  gather_facts: true
  become_method: runas
  become_user: "appabp03appiddev"
  strategy: free
  vars:
    akv_vault_name: kv-cus-abp03-dev-01
    replicated_app_id: appabp03appiddev
    metta_component_name: secretreplicate
    metta_app_name: azabp
    mount_drive_letter: "M"
    unc_nas_path: \\o1-app-pr11-02.us.bank-dns.com\ABP_dev$
      
  roles:
    - shared_roles/windows/mount_nas_drive_win



```

## Validation Step


Once the playbook run is successful, restart the VM and open file explorer click on "This PC" the file mount should be visible as below:


![Nas_fileshare.png](Nas_fileshare.png)
![Nas_fileshare1.png](Nas_fileshare1.png)
