## Description

This role creates a Windows share and sets appropriate permissions on the share folder

## Variables

These variables must be defined by the end user.

- `share_name:` Name of the share to be created
- `share_path:` The local Path of the folder on windows machine that will be shared
- `share_users:` List of users and their access levels (read, change, or full). Each entry includes:
    - `name:` The name of the user for access permissions
    - `access:` The level of access ( eg: read, modify )



## Example Playbook

```
- hosts: windows
  roles:
    - shared_roles/windows/permissions_shared_folders_win
  vars:
    metta_app_name: abp03
    share_name: abp03
    share_path: D:\project
    share_users:
      - name: Everyone
        access: read
      - name: "US\\ciabp03appiddev"
        access: modify

```

## Validation Steps

To Validate the share has been created got the specified Drive and right click on folder mentioend in vars as "share_path" and click on Properties

![image1.PNG](permissions4.PNG)

Verify the share name by clicking on "sharing" tab

![image1.PNG](permissions1.PNG)

Verify the permissions to a particular user, click on "permissions" tab

![image1.PNG](permissions3.PNG)



