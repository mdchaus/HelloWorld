# Ansible Role: install_dotnetcore_win

This role is responsible for installing .NET Core on Windows machines.

## Requirements

- Ansible 2.9 or higher
- Windows Server 2012 R2 or higher

## Variables

### User-Defined Variables

- `dotnetcore_version`: The version of .NET Core to be installed.Defaults to 6.0.32.This variable can be provided by the user. 
    #### Supported Versions  : 6.0.10 , 6.0.25 , 6.0.29 , 6.0.31 , 6.0.32
### Default Variables

- `dotnetcore_destination_filepath`: The path where the .NET Core installer will be downloaded. Default is "C:\\Users\\{{ ansible_user_id }}\\temp".
- `dotnetcore_installer_url`: The URL of the .NET Core installer. Default is "https://artifactory.us.bank-dns.com/artifactory/cloud-migration-softwares-generic-virtual/netruntime".
- `dotnetcore_versions`: A list of .NET Core versions and their corresponding installer filenames. This is a default variable and need not be provided by the user.

## Dependencies

None.

## Example Playbook

```yaml
- hosts: windows
  gather_facts: true
  become_method: runas
  strategy: free
  roles:
    - shared_roles/windows/install_netcore_win
```

## Validation Steps

After running the playbook, you can validate the installation of .NET Core by running the following command in the command prompt:

```bash
dotnet --list-runtimes
```
### Example Output 

![img.png](img.png)

Alternatively,it can be validated by opening Program and Features.

![img_1.png](img_1.png)





