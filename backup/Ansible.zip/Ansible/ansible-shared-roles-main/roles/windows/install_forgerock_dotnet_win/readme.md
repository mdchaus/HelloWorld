## Description

This role is for configuring forgerock agent for dotnet application on Windows server

## Variables

Below are the variables that has to be provided by the application team.
```
fr_agent_url: " "
installation_directory: " "
fr_directory: "C:\\install"
working_directory: "D:"
AM_Console: " "
Agent_URL: " "
Realm: " "
Agent_Name: " "

```

Below are default variables and are defined in role itself. Application team don't have to pass these in the variable files.

```

fr_directory: "C:\\install"
working_directory: "D:"
AM_SYSTEM_LOG_SIZE_VALUE: "52428800"
pass: "Frock86doam!4g00d"  
site_id: "2.1.1"

```

### Sample Playbook

```ansible
- hosts: windows
  gather_facts: true
  become_method: runas
  strategy: free
  roles:
    - shared_roles/windows/Install_forgerock_dotnet


```

### Validation Steps


Check the footer at the bottom of the AM admin UI. The footer shows the version number once you are logged in as amAdmin (This is not the accurate validation as we were unable to test it as it required a policy update)
For example:

![Image.PNG](Image.PNG)




