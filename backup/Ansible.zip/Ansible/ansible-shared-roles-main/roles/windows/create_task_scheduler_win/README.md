## Description

This role is for scheduling task in Task Scheduler on Windows server.

## Variables

Below are the variables that has to be provided by the application team. For task_path variable, the default path for powershell is as defined in below , we suggest the task_path not to be overriden.

```
task_name: ""    #provide your task name
task_path: C:\Windows\System32\WindowsPowerShell\v1.0\powershell.exe   
task_days_of_weeks: ''             #['monday','tuesday','wednesday','thursday','friday'] 
task_trigger_start_time: ''      #provide the time in yy-mm-ddThh:mm:ss format for the task
task_interval:''   #1            #provide the value for which it will recur in terms of days/weeks
task_user: 'Administrator'
task_schdeule: ''                   #you can override the list of for your required schdeule from 'daily','weekly', 'boot', 'logon
task_script_path: ''   #provide your own script path here

```

Below are default variables and are defined in role itself. Application team don't have to pass these in the variable files.

```
task_path: C:\Windows\System32\WindowsPowerShell\v1.0\powershell.exe   
task_win_user: 'Administrator'

```

### Sample Playbook

```ansible
- hosts: windows
  gather_facts: true
  become_method: runas
  strategy: free
  roles:
    - shared_roles/windows/create_task_scheduler_win


```

### Validation Steps


To check whether task is scheduled in Task scheduler or not. Navigate to Task Scheduler and check. 

![img.png](img.png)