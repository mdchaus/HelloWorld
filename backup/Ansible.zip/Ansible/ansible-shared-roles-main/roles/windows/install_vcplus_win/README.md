## Description

This role is for installing Visual C++ Redistributable 2015 on Windows server.

## Variables

Below are default variables and are defined in role itself. Application team don't have to pass these in the variable files.

```
vcplus_exe_name: "VC_redist.x64.exe"
vcplus_artifactory_url: "https://artifactory.us.bank-dns.com/artifactory/list/cloud-migration-softwares-generic-virtual/windows/RedistributeVisualC++/"
tmp_dest_path: "C:\\Users\\{{ ansible_user_id }}\\temp"

```

### Sample Playbook

```ansible
- hosts: windows
  gather_facts: true
  become_method: runas
  strategy: free
  roles:
    - shared_roles/windows/install_vcplus_win

```

### Validation Steps


To check whether Visual C++ Redistrinutable is installed or not. Navigate to Apps and Features and check. 

![img.png](img.png)