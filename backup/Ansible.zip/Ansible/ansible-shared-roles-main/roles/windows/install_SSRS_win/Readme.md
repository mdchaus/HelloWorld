## Description

This role is for installing SQL Server Reporting Service on Windows server.

## Variables

Below are default variables and are defined in role itself. Application team don't have to pass these in the variable files.

```
ssrs_dest_path: "C:\\Users\\{{ ansible_user_id }}\\temp"
ssrs_artifactory_url: "https://artifactory.us.bank-dns.com/artifactory/list/cloud-migration-softwares-generic-virtual/SSRS/"
ssrs_exe_file_name: "SQLServerReportingServices.exe"
ssrs_reg_path: HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server

```

### Sample Playbook

```ansible
- hosts: windows
  gather_facts: true
  become_method: runas
  strategy: free
  roles:
    - shared_roles/windows/install_SSRS_win

```

### Validation Steps


To check whether SSRS is installed or not open Control Panel and check. 

![img1.png](img1.png)