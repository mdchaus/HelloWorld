
## Overview

This role is for installing JRE on Windows VMS.
This role is required for appdynamics machine agent installation in your project.

## Variables

#### Below  variables needs to be added to  role specific variable files
#### As these values will be common across the env , it can be placed in global group vars or as role local vars

```
# Shared
dest_temp_folder: d:\AppDynamics\AppDynamics-Installers\
dest_app_folder: d:\AppDynamics\

# Path to install JRE
jre_path: d:\AppDynamics\jre\

# Filename for the JRE on the target host
# Using a set filename prevents files building up in
# target download directory. 
dest_jre_file: agent-jre.zip

```

## Dependencies

This role has a dependency on
### Role :  copy_files_from_artifactory_win


For Prod:
```
artifactory_files:
  - src: "https://artifactory.us.bank-dns.com/artifactory/appdynamicsagents-generic-virtual/cloud-agent/prod/openjre-windows.zip" ## Add artifactory source URL
    dest: "d:\AppDynamics\AppDynamics-Installers\agent-jre.zip"

```

For Non-Prod:
```
artifactory_files:
  - src: "https://artifactory.us.bank-dns.com/artifactory/appdynamicsagents-generic-virtual/cloud-agent/non-prod/openjre-windows.zip" ## Add artifactory source URL
    dest: "d:\AppDynamics\AppDynamics-Installers\agent-jre.zip"

```
