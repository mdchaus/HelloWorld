## Description

This role is for installing R on Windows server.

## Variables

### Default Variables

Below are default variables and are defined in role itself. Application team don't have to pass these in the variable files.

```
R_dest_path: "C:\\Users\\{{ ansible_user_id }}\\temp"
R_artifactory_url: "https://artifactory.us.bank-dns.com/artifactory/list/cloud-migration-softwares-generic-virtual/R/"
R_versions: A list of R versions and their corresponding installer filenames. This is a default variable and need not be provided by the user.

R_versions:

version: 4.2.2
filename: R-4.2.2-win.exe
version: 4.4.1
filename: R-4.4.1-win.exe
```

## User Defined Variables

```
R_version: The version of R driver to be installed. This variable must be provided by the user

no_of_retries: 60
no_of_delay: 5


```
### Sample Playbook

```ansible
- hosts: windows
  gather_facts: true
  become_method: runas
  strategy: free
  roles:
   - shared_roles/windows/install_R_win

```

### Validation Steps


To check whether R is installed or not open Control Panel, also a Desktop icon will be created. 

![img1.png](img1.png)