# Ansible Role: run_powershell_win

This role runs a list of specified shell commands on a Windows host using the `win_shell` module.

## Requirements

- Ansible 2.9 or higher
- Windows hosts

## Role Variables

This role uses the following variables:

- `shell_commands`: A list of shell commands to run.
- `working_directory` (optional): The directory to run the commands in.

## Example Playbook

In this example, the dir and ipconfig commands are run in the C:\\path\\to\\directory directory on the Windows hosts.

```yaml
- hosts: windows
  gather_facts: true
  become_method: runas
  strategy: free
  roles:
    - shared_roles/windows/run_powershell_win
  vars:
    shell_commands:
      - 'dir'
      - 'ipconfig'


```

