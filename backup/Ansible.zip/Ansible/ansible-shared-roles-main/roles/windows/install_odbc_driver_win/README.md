## Description

This role is for installing ODBC Driver 17 and 18 on Windows server.

## Variables

Below are default variables and are defined in role itself. Application team don't have to pass these in the variable files.


## Default Variables
- odbc_tmp_dest_path: The path where the odbc driver will be downloaded. Default is "C:\Users\{{ ansible_user_id }}\temp
- odbc_artifactory_url: The URL of the odbc driver installer "https://artifactory.us.bank-dns.com/artifactory/list/cloud-migration-softwares-generic-virtual/windows/drivers/ODBC/"
- odbc_versions`: A list of odbc versions and their corresponding installer filenames. This is a default variable and need not be provided by the user.

- odbc_versions:
    - version: 17
      filename: msodbcsql17.msi
    - version: 18
      filename: msodbcsql18.msi 
  
## User-Defined Variables
- odbc_version: The version of odbc driver to be installed. This variable must be provided by the user.    



### Sample Playbook

```ansible
- hosts: windows
  gather_facts: true
  become_method: runas
  strategy: free
  roles:
    - shared_roles/windows/install_odbc_driver_win

```
 

### Validation Steps 

To check the ODBC SQL Server driver version.
In the ODBC Data Source Administrator, click the Drivers tab and check if you can see ODBC driver 18 for SQL Server

![img_1.png](img_1.png)
