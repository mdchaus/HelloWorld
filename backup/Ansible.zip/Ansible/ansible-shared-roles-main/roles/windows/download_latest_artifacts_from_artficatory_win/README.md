## Description

This role is for downloading latest package from artifactory repository and placing it in the destination directory on Windows server. This role imports 'unzip_package' role to unzip the downloded package.

## Variables

#### Below  variables needs to be added as global group level


src_artifactory: This is an Indexed variable, having 2 variables #global variable
  url: source artifactory url for downloading the artifacts 
  dest: directory path on server where artifacts are downloaded
 
```

src_artifactory:
  - url: "https://artifactory.us.bank-dns.com/artifactory/api/storage/...-generic-snapshot-local/.../"   
    dest: "{directory path}:\\pe_autosys\\Projects"

```