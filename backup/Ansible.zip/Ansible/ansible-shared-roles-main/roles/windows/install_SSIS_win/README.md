## Description

This role is for installing SQL Server Integration Services on Windows server.

## Variables

Below are default variables and are defined in role itself. Application team don't have to pass these in the variable files. If there is any change in installer version or the artifactory url.

```
destination_filepath: "C:\\Users\\{{ ansible_user_id }}\\temp"
ssis_server_installer_url: "https://artifactory.us.bank-dns.com/artifactory/cloud-migration-softwares-generic-virtual/SSIS/"
ssis_server_installer: "SQL2022-SSEI-Dev.exe"
ssis_server_conf: "ConfigurationFile.ini.j2"

```

Below are the variables that has to be provided by the application team.

```
destination_filepath: "C:\\Users\\{{ ansible_user_id }}\\temp"
ssis_server_installer_url: "https://artifactory.us.bank-dns.com/artifactory/cloud-migration-softwares-generic-virtual/SSIS/"
ssis_server_installer: "SQL2022-SSEI-Dev.exe"
ssis_server_conf: "ConfigurationFile.ini.j2"
key_vault_uri:        #Provide your Keyvault Url


```

### Sample Playbook

```ansible
- hosts: windows
  gather_facts: true
  become_method: runas
  strategy: free

  roles:
    - shared_roles/windows/install_SSIS_win

```

### Validation Steps


To check whether SSIS is installed or not open Control Panel and check. 

![img2.PNG](img2.PNG)