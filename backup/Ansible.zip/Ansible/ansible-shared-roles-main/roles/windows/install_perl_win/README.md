## Description
This role is for installing Perl on Windows server.

## Variables

## Default Variables
Below are default variables and are defined in role itself. Application team don't have to pass these in the variable files.

```
Perl_dest_path: "C:\\Users\\{{ ansible_user_id }}\\temp"
Perl_pkg_dir: "C:\\Program Files\\perlpkg"
Perl_bin_dir: "{{ Perl_pkg_dir }}\\perl\\bin\\"
Perl_artifactory_url: "https://artifactory.us.bank-dns.com/artifactory/cloud-migration-softwares-generic-virtual/Perl/"


Perl_versions: A list of Perl versions and their corresponding installer filenames. This is a default variable and need not be provided by the user.


Perl_versions:
  - version: 5.32.1.1
    filename: strawberry-perl-5.32.1.1-64bit-portable
  - version: 5.38.2.2 
    filename: strawberry-perl-5.38.2.2-64bit-portable

```

## User Defined Variables

```
Perl_version: The version of Perl driver to be installed. This variable must be provided by the user.

no_of_retries: 60  #The server will be rebooted once Perl is installed as such the ping task in the role will try to reach out to the server on the basis of no of retries.
no_of_delay: 5 

```

## Sample Playbook

- hosts: windows
  gather_facts: true
  become_method: runas
  strategy: free
  roles:
   - shared_roles/windows/install_perl_win


## Validation Steps

To check whether Perl is installed or not open CMD and type perl --version.

![img2.PNG](img2.PNG)