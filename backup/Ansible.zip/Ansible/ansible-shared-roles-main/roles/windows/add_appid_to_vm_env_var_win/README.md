## Description

This role is for getting the credentials using JWT from hashi_vault and mapping the same to environment variables on Windows server.  
This is deprecated role. Please use copy base58 secrets and Copy ad secrets from AKV. 

## Variables

#### Below variables needs to be added as global group level and env specific  

```
# Get AD details
hc_vault_uri: 'https://hcvault.us.bank-dns.com' #global variable
shield_namespace:	 # This is the shiled namespace from hashi vault. #global variable
engine_mount_point:	 # This variable specifies which environment you are using to pull the data. #environment varaible
hc_vault_appid:		 # This variable specifies application id name based on the environment. #environment varaible


```