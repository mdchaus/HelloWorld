## Description

This role is for creating single/multiple directories on Windows server.

## Variables

This variable is defined as a global variable. Multiple directory paths could be added under folderdir variable.

```
create_dirs: 
 - C:\\Temp\\EXCEPTIONREPORT        #Path of the directory to be created
 - C:\\Temp\\MSP_UPDATE_REPORT      #Path of the directory to be created

```
