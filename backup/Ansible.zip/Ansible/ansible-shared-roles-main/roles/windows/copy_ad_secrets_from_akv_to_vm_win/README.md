# Copy HCV Replicated AD Secrets from AKV to a Windows VM

## Description

This role provides access to app ID secrets that are stored in Azure Key Vault.

If your app ID is `appabp03appiddev`, 3 secrets will be accessible if you include this role:
1. `appabp03appiddev_USERNAME`
1. `appabp03appiddev_PASSWORD`
1. `appabp03appiddev_UPN`

## Prerequisites

- Setup secret replication from HashiCorp Vault to Azure Key Vault by following [this process](https://confluence.us.bank-dns.com/pages/viewpage.action?pageId=312642762)

## Variables

These variables must be defined by the end user.
- `akv_vault_name`: ID of your Azure Key Vault
- `replicated_app_id`: your app ID (this is the same as the TARGET identifier used in the replication process)
- `metta_component_name`: component name in metta ([Shield Console](https://shield-console.us.bank-dns.com/dashboard)) [this is probably `secretreplicate`]
- `metta_app_name`: app name in metta ([Shield Console](https://shield-console.us.bank-dns.com/dashboard))

## Usage

Secrets are stored in the `secrets` dictionary for usage during playbook runtime.

Secrets are also added system-wide environment variables.

## Example

Below is an example of how you can use the `secrets` dictionary in a playbook.

<u>your_playbook.yml</u>
```
---
- hosts: windows
  gather_facts: true
  become_method: runas
  strategy: free
  vars:
    akv_vault_name: kv-cus-abp03-dev-01
    replicated_app_id: appabp03appiddev
    metta_component_name: secretreplicate
    metta_app_name: azabp
  roles:
    - shared_roles/windows/copy_secrets_from_akv_to_vm_win

  tasks:
    - name: EXAMPLE - using secrets
      debug: msg="username={{ secrets.appabp03appiddev_USERNAME}}, password={{ secrets.appabp03appiddev_PASSWORD}}, upn={{ secrets.appabp03appiddev_UPN }}"
```

## Validation Steps

Use the following PowerShell script to validate that the environment variables are set.


<u>your_powershell_script.ps1</u>
```
Write-Host "username=$Env:appabp03appiddev_USERNAME, $Env:appabp03appiddev_PASSWORD, $Env:appabp03appiddev_UPN"
```
