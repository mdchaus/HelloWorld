# Copy HCV Replicated KV Secrets from AKV to a Windows VM

## Description

This role copies HashiCorp Vault (HCV) replicated Key Vault (KV) secrets from Azure Key Vault (AKV) to a Windows VM. 
The secrets are converted to HCV format and set as environment variables system-wide.

## Prerequisites

- Setup secret replication from HashiCorp Vault to Azure Key Vault by following [this process](https://confluence.us.bank-dns.com/pages/viewpage.action?pageId=312642762)

## Variables

These variables must be defined by the end user.
- `akv_vault_name`: ID of your Azure Key Vault
- `secret_ids`: list of custom keys stored in Hashicorp which were replicated
- `metta_component_name`: component name in metta ([Shield Console](https://shield-console.us.bank-dns.com/dashboard)) [this is probably `secretreplicate`]
- `metta_app_name`: app name in metta ([Shield Console](https://shield-console.us.bank-dns.com/dashboard))

## Usage

Secrets are stored in the `secrets` dictionary for usage during playbook runtime.

Secrets are also added system-wide environment variables.

## Example

Below is an example of how you can use the `secrets` dictionary in a playbook.

<u>your_playbook.yml</u>
```
---
- hosts: windows
  gather_facts: true
  become_method: runas
  strategy: free
  roles:
    - shared_roles/windows/copy_base58_kv_secrets_from_akv_to_vm_win
  vars:
    akv_vault_name: kv-cus-<appcontextname>-dev-01
    secret_ids: 
      - test
    metta_component_name: secretreplicate
    metta_app_name: <metta-app-name>    

  ```

## Validation Steps

Please validate environment variables on the target VM. 

```
