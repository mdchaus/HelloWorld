Description
This role is for installing the Microsoftedge on Windows VM.

Variables
Below are default variables and are defined in role itself. Application team don't have to pass these in the variable files.

artifactory_base_url: 
destination_path: 
edge_installer: 


Sample Playbook
To use this role ,  Use ansible galaxy to installed shared_roles during runtime and create a playbook as below.

- hosts: windows
  gather_facts: true
  become_method: runas
  strategy: free
  roles:
    - shared_roles/windows/Install_edge_win

### Validation Steps


To check whether if microsoft edge is installed and configured or not in the windows server. Search Microsoftedge in the Start menu and click on it. Now check the details, by right clicking on edge select properties. In properties select details tab.
![image1.png](image1.png)
![image2.png](image2.png)

