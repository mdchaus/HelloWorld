## Description

This role is for Installation of SHIR by ADF 5.33.8649.1 on Windows server.

## Variables

Below are the variables that has to be provided by the application team.

```yaml

akv_vault_name: "https://kv-cus-abp03-dev-01.vault.azure.net/"
shir_akv_key_name: "adf03-cus-ansitest-dev-01-shir-secret"

```

Below are default variables and are defined in role itself. Application team don't have to pass these in the variable files.

```yaml
shir_msi_name: "IntegrationRuntime_5.33.8649.1.msi"
shir_gateway_installer_name: "InstallGatewayOnLocalMachine.ps1"
shir_artifactory_url: "https://artifactory.us.bank-dns.com/artifactory/cloud-migration-softwares-generic-virtual/SHIR/"
shir_dest_path: "C:\\SHIR"
#download_gateway_install
shir_gateway_artifactory_url: "https://artifactory.us.bank-dns.com/artifactory/cloud-migration-softwares-generic-virtual/SHIR/InstallGatewayOnLocalMachine.ps1"
shir_remote_access_port: 8050

```

## Sample Playbook

```ansible
- hosts: windows
  gather_facts: true
  become_method: runas
  strategy: free
  roles:
    - shared_roles/windows/install_shir_win
```

## Validation Steps

To check whether SHIR in ADF is Running or not. Follow the below steps

- Open a web browser and open Azure Portal.
- Navigate to Data Factories in your resource group
- CLick On Launch Studio option

- Navigate to Integration Runtime
- You should see the Integration Runtime Page if the SHIR in ADF is Running or not

![img.png](image.png)

![img.png](image-1.png)

