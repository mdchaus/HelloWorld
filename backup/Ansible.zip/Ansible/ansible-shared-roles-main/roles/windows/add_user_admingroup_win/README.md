## Description

This role is for adding the any user to local user and group under Administrator.


## Variables

This variable is defined under envionment specific folder for each env under inventories. 
```
userid:  #user id

```