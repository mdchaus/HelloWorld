
## Overview

This role is for installing the .NET APM agent on Windows VMS.
This role is required for appdynamics machine agent installation in your project.

## Variables

#### Below  variables needs to be added to  role specific variable files
#### As these values will be common across the env , it can be placed in global group vars or as role local vars

```
# Shared
win_dest_dl_folder: d:\AppDynamics\AppDynamics-Installers\
win_dest_app_folder: d:\AppDynamics\

win_dest_dn_folder: d:\AppDynamics\DotNetAgent\
win_dest_dn_file: dotNetAgent.msi

# The service name is set by the .msi and is included here
# for the purposes of stopping and starting the service in
# response to changes in the agent. 
win_dn_agent_service_name: AppDynamics.Agent.Coordinator

# This is the key used to install the Agent into Windows
# This key can be obtained from the AppDynamics-Installers
# 
win_product_id: {2F9F3F93-3321-4680-BD4C-BFB077C50FE5}
```



## Overview 

This role is for installing app dynamics java agent on Windows VMS. 
Refer appdynamics-agent.yml playbook to orchestrate app dynamics installation in your project. 

## Variables

Below  variables needs to be added to  role specific variable files 

```
# Shared
win_dest_dl_folder: d:\AppDynamics\AppDynamics-Installers\
win_dest_app_folder: d:\AppDynamics\

win_dest_dn_folder: d:\AppDynamics\DotNetAgent\
win_dest_dn_file: dotNetAgent.msi

# The service name is set by the .msi and is included here
# for the purposes of stopping and starting the service in
# response to changes in the agent. 
win_dn_agent_service_name: AppDynamics.Agent.Coordinator

# This is the key used to install the Agent into Windows
# This key can be obtained from the AppDynamics-Installers
# 
win_product_id: {2F9F3F93-3321-4680-BD4C-BFB077C50FE5}

```

Below variables are environment specific and needs to be added in environment specific group variables

```
"accountAccessKey": "XXXXX"   # Please reach out to AppDynamics team to get this detail 
"application_name": "Personetics-6904-UAT"   # Please reach out to AppDynamics team to get this detail 
"tier_name": "Personetics"
"proxy_enable": "true"   # if no proxy is being used then, false
"proxy_host": "web-proxyapp.us.bank-dns.com"   # JVM Proxy Host Address
"proxy_port": "3128"   # JVM Proxy Port Value

# This setting will enable or disable the .NET agents ability to
# automatically detect, classify, and monitor IIS app pools from
# the IIS server processes.
# Accepted values: 
# true   #  enable auto-detection or
# false    # disable auto-detection
# IF false then see CUSTOM-MONITOR-VARS.txt for additional requirements
"iis_automatic": "true"

```

For Prod:
```
"controller_hostName": "us-bank.saas.appdynamics.com"   # hostname will change as the per the env
"controller_port": 443
"ssl_enabled": true
"accountName": "usbank"  # This value will change based on env
"analytics_endpoint:" "https://analytics.api.appdynamics.com:443"   # Analytics Delivery Endpoint
"global_accountName:" "USBANK_351d091f-c3a8-4779-a0da-4a53785ebec3"  # Analytics Delivery Key

```

For Non-Prod:
```
"controller_hostName": "us-bank-testdev.saas.appdynamics.com"   # hostname will change as the per the env
"controller_port": 443
"ssl_enabled": true
"accountName": "us-bank-testdev"  # This value will change based on env
"analytics_endpoint": "https://analytics.api.appdynamics.com:443"   # Analytics Delivery Endpoint
"global_accountName": "us-bank-testdev_0ca51855-0e84-4e7f-8ba5-87dab5c8e48f"  # Analytics Delivery Key

```

## Dependencies

This role has a dependency on  
### Role :  copy_files_from_artifactory_win.
Below variables are required in group global variables. 

For Prod:
```
artifactory_files:
  - src: "https://artifactory.us.bank-dns.com/artifactory/appdynamicsagents-generic-virtual/cloud-agent/non-prod/dotNetAgent.msi" ## Add artifactory source URL
    dest: "d:\AppDynamics\AppDynamics-Installers\dotNetAgent.msi"

```

For Non-Prod:
```
artifactory_files:
  - src: "https://artifactory.us.bank-dns.com/artifactory/appdynamicsagents-generic-virtual/cloud-agent/prod/dotNetAgent.msi" ## Add artifactory source URL
    dest: "d:\AppDynamics\AppDynamics-Installers\dotNetAgent.msi"

```
