## Description

This role is for copying contents from one folder to another on a windows machine.
This task will copy all the contents from source directory to destination directory specified. 
## Variables

Below are default variables and are defined in role itself. Application team Should change the source and destination paths according to their requirement.

```

copy_file_source_folder ''  ## Update the source path from where the files copied 
copy_file_destination_folder: ''  ## Update The destination path where the files copied to

```

| Variable                          | Details                                             |
| ------                            | ------                                              |
| copy_file_destination_folder      |  specify path where the content need to copied      |
| copy_file_source_folder           |   specify path from where contents need to be copied|

## Sample Playbook

```
- hosts: windows
   gather_facts: true
   become_method: runas
   strategy: free

   roles:
     - shared_roles/windows/copy_file_operation_win

```

### Validation Steps

We can validate the copy operation by login to the windows server, and manually validating the contents.

![image.png](./image.png)
![image.png](./image1.png)






