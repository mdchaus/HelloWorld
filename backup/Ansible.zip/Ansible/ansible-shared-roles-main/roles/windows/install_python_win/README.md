# Description
This role is for installing Python on a Windows VM.

# Variables
Below are default variables and are defined in the role itself. The application team doesn't have to pass these in the variable files.

- artifactory_python_url: The URL to download the Python installer.
- destination_path: The path where the Python installer will be downloaded.
- python_installer: The name of the Python installer file.

# Sample Playbook
To use this role, use Ansible Galaxy to install shared_roles during runtime and create a playbook as below.

```yaml
- hosts: windows
  gather_facts: true
  become_method: runas
  strategy: free
  roles:
    - shared_roles/windows/install_python_win
```

# Validation Steps
After the installation, you can validate if Python has been installed correctly by following these steps:

1. Open a command prompt.
2. Type `python --version` and press Enter.
3. The installed Python version should be displayed.

If Python is installed correctly, the version of Python that you installed should be displayed. If Python is not installed correctly, the command prompt will not recognize the `python` command.

![img.png](img.png)