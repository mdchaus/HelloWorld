## Overview

This role is for updating the connection string and file path in configuration file of the application on Windows server.\
This role imports 'setup_env_var_approle' role to get the credential details

## Variables

#### Below variables needs to be added in 

```
# File path and text to update in config file
appsetting_path: Path of config file of the application (eg: {Drive_Path}\\appsettings.json) #environment variable
app_configs:
    - { regexp: "", line: "" } 
    - { regexp: "", line: "" }
# eg:
# app_configs: regexp to match and change the value in config file #environment variable
#    - { regexp: '    "CDF_ROOT_FILE_LOCATION"', line: "{{ root_file_location }}" } 
#    - { regexp: '    "Create-Notes-Memo-Api"', line: "{{ notes_memo_api }}" }


```
