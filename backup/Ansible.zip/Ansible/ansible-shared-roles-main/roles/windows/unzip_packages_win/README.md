## Description

This role is for unzipping the zipped package on Windows server. 
This package has dependency of download artifacts role, Please use "download_artifacts.yml" to download the artifacts from .

## Variables

#### Below variables needs to be added as global group level  

```
# Unzip folder
unzip_packages:
   - src: PThe source path of zip package.  (eg: {Drive_Path}\\appsettings.json) #global variable
     dest:The destination backup path where unzipped package will be placed. #global variable

```
