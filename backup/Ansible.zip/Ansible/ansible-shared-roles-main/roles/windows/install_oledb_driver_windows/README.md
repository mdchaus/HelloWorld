## Description

This role is for installing OLEDB Driver 18 and 19 on Windows server.

## Variables

Below are default variables and are defined in role itself. Application team don't have to pass these in the variable files.


## Default Variables
- oledb_download_path: The path where the oledb driver will be downloaded. Default is "C:\Users{{ ansible_user_id }}\temp"
- oledb_driver_installer_url: The URL of the oledb driver installer "https://artifactory.us.bank-dns.com/artifactory/cloud-migration-softwares-generic-virtual/windows/drivers/OLEDB/"
- oledb_versions: A list of oledb versions and their corresponding installer filenames. This is a default variable and need not be provided by the user.

- oledb_versions:
    - version: 18
      filename: msoledbsql18.msi
    - version: 19
      filename: msoledbsql19.msi 
  
## User-Defined Variables
- oledb_version: The version of oledb driver to be installed. This variable must be provided by the user. 

## Sample Playbook: 
```
- hosts: <windows hosts>
  gather_facts: true
  become_method: runas
  strategy: free
  roles:
    - shared_roles/windows/install_oledb_driver_windows
```



## Validation Steps:
```
To validate OLEDB driver installation, in Windows server,please follow below steps
1. Login to server and click on Start and then go to settings. 
2. In settings choose Apps. 
3. In Apps,you will be able to view the OLEDB driver in the list of the installed software.
Please find the below picture, that shows OLEDB 19 installed on the server.
```
![img2.png](img2.png)
