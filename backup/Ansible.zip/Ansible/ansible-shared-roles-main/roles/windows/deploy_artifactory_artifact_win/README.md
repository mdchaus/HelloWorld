# Deploy Artifact from Artifactory to a Windows VM

## Description

This role pulls an artifact from Artifactory and deploys it to a target directory. It optionally performs a local backup of the previous deployment, and optionally performs an upload of a copy to a release directory.

## Variables

| Variable            | Type    | Required | Description                                                                                                                                       | Default                                        |
|---------------------|---------|----------|------------------------------------------------------------------------------------------------------------------------------------------------|------------------------------------------------|
| `deployment_path`   | string  | Yes      | Path to target deployment directory.                                                                                                           | --                                             |
| `artifact_dir_url`  | string  | Yes      | Fully qualified path to the directory of your Artifactory namespace (starts with `https://artifactory.us.bank-dns.com/artifactory`)                                  | --                                             |
| `unarchive`         | boolean | Yes      | Set this to a truthy value for compressed artifacts (`.zip`, `.tar.gz` extensions). Leave undefined or set to a falsy value for uncompressed artifacts.                              | `no`                                                       |
| `artifact_id`       | string  | No       | Specific artifact to pull from Artifactory. If undefined, the __last modified__ artifact is pulled.                                                | Last modified artifact ID                      |
| `release_dir_url`   | string  | No       | URL path to the release directory in Artifactory (starts with `https://artifactory.us.bank-dns.com/artifactory`). If defined, the role will upload a copy of the directory at `deployment_path` | --                                                          |
| `backup_path`       | string  | No       | Path to store backup when `perform_backup` is truthy. Ignored if `perform_backup` is falsy or undefined.                                       | `%Temp%\ansible_automation_code_deploy\backup` |
| `perform_backup`    | boolean | No       | If truthy and `first_time` is falsy, a backup of the previous deployment will be copied to `backup_path`. If falsy or undefined, the previous deployment is overwritten. | `no`                                          |
| `first_time`        | boolean | No       | Set this to a truthy value for first time deployments. It's important to set this accurately.                                                  | `no`                                           |

__NOTE__: last modified is not equivalent to latest

## Usage

Simply include the role in your playbook and populate the required variables.

## Examples

### Routine deployment of specific artifact with backup and copy uploaded to release directory 

<u>your_playbook.yml</u>

```yaml
- hosts: windows
  gather_facts: true
  become_method: runas
  strategy: free
  vars:
    deployment_path: "D:\\tmp\\test-deployment"
    artifact_dir_url: "https://artifactory.us.bank-dns.com/artifactory/cloud-migration-softwares-generic-virtual/"
    artifact_id: "IBMDB2SSH.zip"
    release_dir_url: "https://artifactory.us.bank-dns.com/artifactory/cloud-migration-softwares-generic-virtual/releases/"
    perform_backup: yes
    first_time: no
  roles:
    - shared_roles/windows/deploy_artifactory_artifact_win
```

### First time deployment of last modified artifact

<u>your_playbook.yml</u>

```yaml
- hosts: windows
  gather_facts: true
  become_method: runas
  strategy: free
  vars:
    deployment_path: "D:\\tmp\\test-deployment"
    artifact_dir_url: "https://artifactory.us.bank-dns.com/artifactory/cloud-migration-softwares-generic-virtual/"
    first_time: no
  roles:
    - shared_roles/windows/deploy_artifactory_artifact_win
```

## Validation Steps

1. Log into the target machine
2. Verify that the artifact exists in the `deployment_path` directory
3. If you populated `release_dir_url`, log in to Artifactory and verify that the artifact was uploaded to the directory