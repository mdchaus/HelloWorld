## Description

Thsi role is useful when host entries are to be added to hosts file

## Variables

Below are the variables that has to be provided by the application team as per their requirement

```
add_host_file_entries:
    -"<IP Address>  <Full DNS name>"
    -"<IP Address>  <Full DNS name>"

```

## Sample Playbook


```
- hosts: windows
  gather_facts: true
  become_method: runas
  strategy: free
  roles:
    - shared_roles/windows/add_host_entry_win
  vars:
    add_host_file_entries:
        - "100.65.66.88     vcausc117dev0bm.us.bank-dns.com"
        - "100.65.66.87     vcausc117dev05l.us.bank-dns.com"

```

## Validation

To Validate if hosts are added as required, crosscheck the hosts file at the path "C:\Windows\System32\drivers\etc\hosts "


![image1.PNG](add_hosts.PNG)
