# start_stop_restart_shir_win

## Description

This role is for stopping, and restarting the Self-hosted Integration Runtime (SHIR) on Windows servers.

## Prerequisites

- Ansible 2.9 or higher
- Windows Server 2012 R2 or higher

## Usage

This role is used to control the state of SHIR on Windows servers. It is part of a larger project and should be used in conjunction with other roles as needed.

## Variables


### Default  Variables
- `shir_runtime_path`: The path to the SHIR runtime on the Windows server.

### User Defined Variables

- `shir_action`: The action to perform on the SHIR. Can be 'stop', or 'restart'.


## Sample Playbook

```ansible
- hosts: windows
  gather_facts: true
  become_method: runas
  strategy: free
  roles:
    - shared_roles/windows/stop_restart_shir_win
  vars:
    shir_action: 'stop'
```

## Validation Steps


To check whether SHIR in ADF is Running or not. Follow the below steps

- Open a web browser and open Azure Portal.
- Navigate to Data Factories in your resource group
- CLick On Launch Studio option

- Navigate to Integration Runtime
- You should see the Integration Runtime Page if the SHIR in ADF is Running or not

![img.png](image.png)

![img.png](image-1.png)
