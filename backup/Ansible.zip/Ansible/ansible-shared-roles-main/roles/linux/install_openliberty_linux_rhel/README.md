### Description:

This role is for installing openliberty-runtime-21.0.0.10 software and adding the admin feature to the openliberty software on linux servers.

### Variables:

Below are the default variables and can be overriden. The default ports of openliberty are
http: 9080 and https: 9443. We can customize the ports as per our requirements.

```
openliberty_artifactory_url:
openliberty_target_directory:
openliberty_version:
openliberty_instance_name:
openliberty_https_port:
openliberty_http_port:
```

### Sample Playbook:
```
- hosts: <Linux hosts>
  gather_facts: true
  become: yes
  strategy: free
  roles:
    - shared_roles/linux/install_openliberty_linux_rhel
```
### Validation Steps:

```
To check the status of the openliberty instance,enter the below URL in the browser and check.
http://servername:9080
We should get the below output, when we enter the above link in the browser.
```

![img1.png](img1.png)
```
To access openliberty adminCenter,please enter the below URL in browser and enter admin userid and password.
https://servername:9443/adminCenter
We should get the below output, when we enter the above link in the browser.
```
![img3.png](img3.png)

### Note: 
```
To secure the openliberty adminCenter, please contact Ansibe team.
```
