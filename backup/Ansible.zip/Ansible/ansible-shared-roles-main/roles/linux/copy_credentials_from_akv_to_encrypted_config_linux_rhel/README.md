# Copy HashiCorp Vault Replicated Credentials from Azure Key Vault to an Encrypted File on a RHEL VM

## Description

This role pulls credentials from Azure Key Vault (AKV) to a config file, then symmetrically encrypts the file with `gpg`. The credentials are replicated from HashiCorp Vault (HCV) AD engine and or KV engine.

The plaintext format of the config file is like so:
```
key1=value1
key2=value2
...
keyN=valueN
```

## Prerequisites

The following secrets should be in AKV:
- Desired credentials
- Symmetric encryption passphrase (a Base64 256 bit key is recommended)

## Variables

These variables must be defined by the end user.
- `akv_vault_name`: ID of your AKV
- `config_file_path`: target path of your config file
- `encryption_passphrase_secret_id`: the AKV ID of your symmetric encryption passphrase
- `config_ids`: a list of required credentials, including your `encryption_passphrase_secret_id`
- `replicated_app_id`: your app ID (this is the same as the TARGET identifier used in the replication process)
- `metta_component_name`: component name in metta ([Shield Console](https://shield-console.us.bank-dns.com/dashboard)) [this is probably `secretreplicate`]
- `metta_app_name`: app name in metta ([Shield Console](https://shield-console.us.bank-dns.com/dashboard))
- `hcv_engine_type`: either `KV`, or `BOTH`; this is the type of HashiCorp Vault secrets engine that secrets are replicated from
    - `KV`: Use this if your required credentials are stored only in a KV engine of HCV
    - `BOTH`: `KV` and `AD` - Use this if you require app id AD credentials in addition to custom KV credentials 

## Usage

Simply include this role with the required variables populated. Example below.

## Examples

This example playbook will pull both `AD` engine replicated secrets and the specified `KV` engine replicated secrets from AKV to the config file.

<u>your_playbook1.yml</u>
```yaml
---
- hosts: linux
  gather_facts: true
  become: yes
  strategy: free

  tasks:
    - name: Create encrypted config file with values from Azure Key vault
    vars:
        akv_vault_name: kv-cus-abp03-dev-01
        config_file_path: '/tmp/config'
        encryption_passphrase_secret_id: test-encryption-passphrase # AKV ID of base64 encoded symmetric encryption key
        config_ids: # required credentials, encryption key, encryption IV
          - test-encryption-iv
          - test-encryption-key
          - sasgnc1lpoc01dabp0301-name
        replicated_app_id: appabp03appiddev
        metta_component_name: secretreplicate
        metta_app_name: azabp
        hcv_engine_type: BOTH
    ansible.builtin.include_role:
        - shared_roles/linux/copy_credentials_from_akv_to_encrypted_config_linux_rhel
```

## Validation Steps

1. Verify that the data was copied properly by viewing the config file after decrypting. 

    Use this command: `gpg --decrypt <config_file_path>`

    You will be prompted to enter the encryption passphrase, then the file contents will be displayed
