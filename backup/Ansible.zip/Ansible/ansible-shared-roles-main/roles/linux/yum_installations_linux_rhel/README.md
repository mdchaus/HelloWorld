## Description

This role is for installation of any package by using yum module


## Variables
```
packages:
  - java-1.8.0-openjdk

```