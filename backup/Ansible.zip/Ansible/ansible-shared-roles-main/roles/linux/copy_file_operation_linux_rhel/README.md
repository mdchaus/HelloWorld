## Description

This role is for copying contents from one folder to another on a linux machine.

This task will copy all the contents from source directory to destination directory specified. If no contents available it will skip the task.

## Variables
```
copy_file_destination_folder: <absolute path to destination folder>
copy_file_source_folder: <absolute path to source folder>   
```
Absolute path can be found by `pwd` command on RHEL.

|Variable|Details|Scope|
|---|---|---|
| copy_file_destination_folder | specify path of where directory to be created | env |
| copy_file_source_folder | specify path from where contents need to be copied | env |

## Validation Step
We can validate the copy operation by login as root user with `sudo su -`, and manually validating the contents.

![image.png](./image.png)
