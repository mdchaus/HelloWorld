## Description

This role is for creating groups ,users and adding users to groups on Linux (RHEL) VMs. 

## Variables

Below are default variables and are defined in role itself. 

groups_uid:
  - name: 
    gid: 

users:
  - name: 
    uid: 
    group: 
    groups: []

## Sample Playbook

To use this role ,  Use ansible galaxy to installed shared_roles during runtime and create a playbook as below. "hosts" need to be changes.

ansible
- hosts: <Linux hosts>
  gather_facts: true
  become_method: runas
  strategy: free
  roles:
    - shared_roles/linux/usersandgrop_linux_rhel

Validation Steps

To check whether users and groups are created simply type id username or groups username as shown in below image. Alternative we can check in /etc/passwd and /etc/group
![image1.PNG](image1.PNG)


