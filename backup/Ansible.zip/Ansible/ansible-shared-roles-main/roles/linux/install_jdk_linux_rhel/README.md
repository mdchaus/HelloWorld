### Description:

This role is for installing Jdk17.0.10 software on linux server.

### Variables:

Below are the default variables.

```
java_rpm_version:
java_artifactory_url:
java_download_path:
```



### Sample Playbook:
```
- hosts: <Linux hosts>
  gather_facts: true
  become: yes
  strategy: free
  roles:
    - shared_roles/linux/install_jdk_linux_rhel
```


### Validation Steps:
To check whether the java is installed, please run the  command "Java -version" on the termainal of the server.
We should get the below output, when we run "java -version" command.
![img2.png](img2.png)



