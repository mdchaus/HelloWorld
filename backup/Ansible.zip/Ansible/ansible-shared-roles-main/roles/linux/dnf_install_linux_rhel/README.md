## Description

The current role is for installation softwares/packages using "dnf", has the capability to either download from artifactory and install or to install linux inbuilt packages on Linux (RHEL) VMs

## Variables

Below are the variables that has to be provided by the application team

```
- dnf_installer_version:      Full name of the downloaded artifact that needs to be installed
- dnf_installer_artifactory_url:      Artifactory URL to be provided along with repo path
- dnf_installer_download_path:      The path/folder where artifact to be downloaded on target machine
- dnf_use_artifactory: true     This needs to be true if installation is required after downloading from artifactory, else false for Rhel internal packages
- dnf_packages:     List of all Linux inbuilt packages names
    - git                        
- dnf_installer_run_shell_script: true        This needs to true if any depandency commands to be executed after downloading and installing from artifactory, if not false
- dnf_shell_scripts:    list of all commands to be executed after installation
    - /bin/systemctl start nessusagent.service

```

## Sample Playbook


```ansible
- hosts: <Linux hosts>
  gather_facts: true
  become_method: runas
  strategy: free
  roles:
    - shared_roles/linux/dnf_install_linux_rhel
  vars:
    ansible_become_user: root
    ansible_become_method: sudo
    "ansible_ssh_user": "{{ lookup('ansible.builtin.env', 'SERVICE_ID') }}"
    "ansible_ssh_pass": "{{ lookup('ansible.builtin.env', 'SERVICE_PW') }}"
    "ansible_sudo_pass": "{{ lookup('ansible.builtin.env', 'SERVICE_PW') }}"
    "ansible_ssh_common_args": "-o StrictHostKeyChecking=no"
    dnf_installer_version: "NessusAgent-10.6.4-el8.x86_64.rpm"
    dnf_installer_artifactory_url: "https://artifactory.us.bank-dns.com/artifactory/cloud-migration-softwares-generic-virtual/nessus"
    dnf_installer_download_path: "/tmp"
    dnf_use_artifactory: true
    dnf_packages:
      - git
    dnf_installer_run_shell_script: true
    dnf_shell_scripts:
      - /bin/systemctl start nessusagent.service

