## Description

This role is to mount Azure file share on Linux VM, this role will import "copy_ad_secrets_from_akv_to_vm_linux_rhel" in to current role and processes to get the secrets

If your app ID is `appabp03appiddev`, 3 secrets will be accessible if you include this role:
1. `appabp03appiddev_USERNAME`
1. `appabp03appiddev_PASSWORD`
1. `appabp03appiddev_UPN`

## Prerequisites for "copy_ad_secrets_from_akv_to_vm_linux_rhel" role

- Setup secret replication from HashiCorp Vault to Azure Key Vault by following [this process](https://confluence.us.bank-dns.com/pages/viewpage.action?pageId=312642762)

## Variables

Below are default variables and are defined in role itself. Application team don't have to pass these in the variable files

- keytab: /var/kerberos/krb5/user/appuser.keytab

Below variables must be defined by the end user

- key_vault_uri:  Provide key vault url
- mount_drive:     Provide app specific mount point name for fileshre
- azure_storage_account_fqdn:       Provide Azure Storage account fully qualified domain name
- azure_file_share_name:            Provide your Azure file share name
- replicated_app_id:            your app ID (this is the same as the TARGET identifier used in the replication process)
- metta_component_name:         component name in metta ([Shield Console](https://shield-console.us.bank-dns.com/dashboard)) [this is probably secretreplicate]
- metta_app_name:           app name in metta ([Shield Console](https://shield-console.us.bank-dns.com/dashboard)) 

## Sample Playbook

```
- hosts: linux
  gather_facts: true
  become: true
  strategy: free
  vars:
    replicated_app_id: appabp03appiddev
    metta_component_name: secretreplicate
    metta_app_name: azabp

  roles:
    - shared_roles/linux/mount_azure_fileshare_linux

```

## Validation Step

Type "df -h" in the linux server your azure fileshare mount should be visible as below:


![image1.PNG](image1.PNG)
