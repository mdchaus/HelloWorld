
## Overview

This role is for installing JRE on linux VMS.
This role is required for appdynamics machine agent installation in your project.

## Variables

#### Below  variables needs to be added to  role specific variable files
#### As these values will be common across the env , it can be placed in global group vars or as role local vars

```


# Shared
dest_temp_folder: /opt/appdynamics/appdynamics-installers/
dest_app_folder: /opt/appdynamics/

# Path to install  JRE
jre_path: /opt/appdynamics/jre/

# Filename for the JRE on the target host
# Using a set filename prevents files building up in
# target download directory. 
dest_jre_file: agent-jre.zip
```



## Dependencies

This role has a dependency on
### Role :  copy_files_from_artifactory_linux_rhel

Below variables are required in group global variables.

```
"app_user": "app****"   # appiduser for the application
"admin_group": "root"

```

For Prod:
```
artifactory_files:
  - src: "https://artifactory.us.bank-dns.com/artifactory/appdynamicsagents-generic-virtual/cloud-agent/prod/openjre-linux.zip" ## Add artifactory source URL
    dest: "/opt/appdynamics/appdynamics-installers/agent-jre.zip"

```

For Non-Prod:
```
artifactory_files:
  - src: "https://artifactory.us.bank-dns.com/artifactory/appdynamicsagents-generic-virtual/cloud-agent/non-prod/openjre-linux.zip" ## Add artifactory source URL
    dest: "/opt/appdynamics/appdynamics-installers/agent-jre.zip"

```