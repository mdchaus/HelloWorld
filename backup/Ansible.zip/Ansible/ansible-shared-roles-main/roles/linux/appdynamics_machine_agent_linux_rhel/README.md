
## Overview

This role is for installing app dynamics java agent on linux VMS.
Refer appdynamics-agent.yml playbook to orchestrate app dynamics installation in your project.

## Variables

Below  variables needs to be added to role specific variable files.

```
# Shared
nix_dest_dl_folder: /opt/appdynamics/appdynamics-installers/
nix_dest_app_folder: /opt/appdynamics/

# Path to install Agent JRE
nix_appd_jre_path: /opt/appdynamics/jre/

# Machine Agent
nix_dest_ma_folder: /opt/appdynamics/machineagent/
nix_dest_ma_file: MachineAgent.zip

# SIM Monitoring Settings Adjustments
nix_sampling_interval: 60000
nix_script_timeout: 90
nix_max_volumes: 9

# Custom Max Metrics Default Value
# This default value is taken from Appdynamics documentation
max_metric_param: "-Dappdynamics.agent.maxMetrics="

# Custom Metrics for Configuration file templates

# SIM is enabled on every server with a machine agent as part of Observability policy.
# Valid entry values are: true | false
sim_enabled: true

# Unique host ID for use in the controller info.xml. If this value is not set it will
# default to a blank value. This blank value will cause the machine agent to request
# the hostname from the avaiable java JRE. This value should remain the default value
# unless that hostname being discovered by the machine agent is not matching with the
# corresponding APM agent installed on the target server. 
#  unique_host_id: vmiksa69901cvf.us.bank-dns.com
# This variable is used by the Machine Agent automation. This string will be used
# as the 'Hierarchy' Value displayed in the contorller. This variable defaults to a
# blank value (or ''). This string, if being set, must
# end in a pipe or '|' character i.e. OBC|UAT|APPD|
#  machine_path:
# This vaiable is used by the Machine Agent automation. This string will be used
# to determine the state of analytics collection as part of the machine agent.
# This variable only accepts two values: 'true' or 'false'
# and is set to 'false' by default.
#  analytics_enabled: false
# Custom Max Metrics Limit defines the number of custom metrics that can be defined by
# this machine agent and all of it's extentions. If an agent has extension installed it
# is highly likely that this value will need to be increased. This variable must be a
# a whole number. The defualt value for this variable is '1000'
#  max_metric_limit: 1000

```
Below variables are environment specific and needs to be added in environment specific group variables.

```
"accountAccessKey": "XXXXX"   # Please reach out to AppDynamics team to get this detail 
"application_name": "Personetics-6904-UAT"   # Please reach out to AppDynamics team to get this detail 
"tier_name": "Personetics"
"proxy_host_param": "-Dappdynamics.http.proxyHost="  # JVM Proxy Port Parameter
"proxy_port_param": "-Dappdynamics.http.proxyPort="  # JVM Proxy Host Value
"proxy_host": "web-proxyapp.us.bank-dns.com"   # JVM Proxy Port Value"proxy_port": "3128"
"app_uer" : appuser
"admin_group" : root

```

For Prod:
```
"controller_hostName": "us-bank.saas.appdynamics.com"   # hostname will change as the per the env
"controller_port": 443
"ssl_enabled": true
"accountName": "usbank"  # This value will change based on env
"analytics_endpoint:" "https://analytics.api.appdynamics.com:443"   # Analytics Delivery Endpoint
"global_accountName:" "USBANK_351d091f-c3a8-4779-a0da-4a53785ebec3"  # Analytics Delivery Key

```

For Non-Prod:
```
"controller_hostName": "us-bank-testdev.saas.appdynamics.com"   # hostname will change as the per the env
"controller_port": 443
"ssl_enabled": true
"accountName": "us-bank-testdev"  # This value will change based on env
"analytics_endpoint": "https://analytics.api.appdynamics.com:443"   # Analytics Delivery Endpoint
"global_accountName": "us-bank-testdev_0ca51855-0e84-4e7f-8ba5-87dab5c8e48f"  # Analytics Delivery Key

```

## Dependencies

This role has a dependency on  
### Role :  copy_files_from_artifactory_linux_rhel. 
Below variables are required in group global variables. 

For Prod:
```
artifactory_files:
  - src: "https://artifactory.us.bank-dns.com/artifactory/appdynamicsagents-generic-virtual/cloud-agent/prod/machineagent-linux.zip" ## Add artifactory source URL
    dest: "/opt/appdynamics/appdynamics-installers/MachineAgent.zip"

```

For Non-Prod:
```
artifactory_files:
  - src: "https://artifactory.us.bank-dns.com/artifactory/appdynamicsagents-generic-virtual/cloud-agent/non-prod/machineagent-linux.zip" ## Add artifactory source URL
    dest: "/opt/appdynamics/appdynamics-installers/MachineAgent.zip"

```

### Role:  install_jre_linux

Below variable is required for this role to work. 

```
# Shared
dest_temp_folder: /opt/appdynamics/appdynamics-installers/
dest_app_folder: /opt/appdynamics/

# Path to install JRE
jre_path: /opt/appdynamics/jre/
dest_jre_file: agent-jre.zip

```

For Prod:
```
artifactory_files:
  - src: "https://artifactory.us.bank-dns.com/artifactory/appdynamicsagents-generic-virtual/cloud-agent/prod/agent-jre.zip" ## Add artifactory source URL
    dest: "/opt/appdynamics/appdynamics-installers/agent-jre.zip"

```

For Non-Prod:
```
artifactory_files:
  - src: "https://artifactory.us.bank-dns.com/artifactory/appdynamicsagents-generic-virtual/cloud-agent/non-prod/agent-jre.zip" ## Add artifactory source URL
    dest: "/opt/appdynamics/appdynamics-installers/agent-jre.zip"

```