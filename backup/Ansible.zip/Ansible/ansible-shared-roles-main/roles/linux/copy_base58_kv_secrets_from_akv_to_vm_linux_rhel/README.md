# Copy HCV Replicated KV Secrets from AKV to a Linux VM

## Description
This role is responsible for copying Base58 Key Vault secrets from Azure Key Vault (AKV) to a Linux VM. It converts secret keys to HashiCorp Vault (HCV) format and sets them as environment variables system-wide.

## Prerequisites
- Azure Key Vault 
- Linux VM where the secrets will be copied.
- Setup secret replication from HashiCorp Vault to Azure Key Vault by following [this process](https://confluence.us.bank-dns.com/pages/viewpage.action?pageId=312642762)

## Variables
These variables must be defined by the end user.
- `metta_app_name`: The application name in metta.
- `metta_component_name`: The component name in metta used for replicating secrets.
- `secret_ids`: Secrets IDS that were replicated from HCV 

## Default Variables 

- `hcv_engine_type`: The type of secret engine in HashiCorp Vault for replicated secrets, set to `KV`.
## Usage
Include this role in your playbook to copy the secrets from AKV to your Windows VM. The secrets will be available as environment variables.

## Example
Here is an example of how to include this role in a playbook:

```yaml
---
- hosts: linux
  gather_facts: true
  become: yes
  strategy: free
  vars:
    metta_app_name: your_app_name
    metta_component_name: your_component_name
    secret_ids:
      - test
  roles:
    - roles/windows/copy_base58_kv_secrets_from_akv_to_vm_win

`
