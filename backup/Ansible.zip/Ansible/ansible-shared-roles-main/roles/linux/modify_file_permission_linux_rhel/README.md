# Ansible Role: Modify File Permissions

This role modifies the owner, group, and permissions of certain files. It is particularly useful in scenarios where you need to ensure that specific files have the correct owner, group, and permissions.

## Requirements

None.

## Role Variables

This role uses the following variables:

- `app_user`: The default user that should own the files. This should be a string representing the username.
- `admin_group`: The default group that should own the files. This should be a string representing the group name.
- `modify_file_paths`: A list of dictionaries. Each dictionary should have four keys: `path`, `user`, `group`, and `permission`. `path` should be a string representing the path to the file, `user` and `group` should be strings representing the user and group that should own the file, and `permission` should be a string representing the file permissions to be applied. If `user` and `group` are not provided, `app_user` and `admin_group` will be used as defaults.

## Dependencies

None.

## Example Playbook

Here's an example playbook that uses this role:

```yaml
- hosts: servers
  vars:
    app_user: 'myuser'
    admin_group: 'mygroup'
    modify_file_paths:
      - path: '/path/to/my/file'
        user: 'anotheruser'
        group: 'anothergroup'
        permission: '0755'
  roles:
    - { role: modify_file_permissions }

```

