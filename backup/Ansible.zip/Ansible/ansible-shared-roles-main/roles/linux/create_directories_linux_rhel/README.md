## Description

This role is for creating single or multiple directories.

This task will create directories. If the directories already exist, it will be skipped.

## Variables
```
create_dirs:  
  - /tmp/software/python   ## add variables in this path inventories/dev/group_vars/all.yml
```

|Variable|Details|Scope|
|---|---|---|
| create_dirs | specify path of where directory to be created | env |