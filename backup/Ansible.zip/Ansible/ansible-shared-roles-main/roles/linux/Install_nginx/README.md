## Description

This role is for installing NGINX on linux machine.

This task will install NGINX on RHEL, copy the vm default cert and key from `/etc/ssl/certs/` to a newly created folder i.e. `nginx_path` for configuration. You have to configure your application specific requirements and port on the `nginx.conf.j2` which can be found in templates folder.


## Variables
```
nginx_cert_alias: <DNS alias created for application>
nginx_path: <absolute path to nginx directory>   
app_user: <specific user>
admin_group: <specific user group>
```
Absolute path can be found by `pwd` command on RHEL.

|Variable|Details|Scope|
|---|---|---|
| nginx_cert_alias | specify the DNS alias created for application | env |
| admin_group | specific user group | global |
| nginx_path | specify path where nginx configiration will be kept | global |
| app_user | specific user | env |

Below variables are environment specific and needs to be added in environment specific group variables.

```
app_user:  service account from app context
nginx_cert_alias: env specific DNS alias

```

```Recommened value for `admin_group` is `root`.```


## Validation Step
We can validate the copy operation by login as root user with `sudo su -`, running command `systemctl status nginx`. Verify the copied certs in the specified folder as well as your `nginx.conf` file.


![nginx](nginx.png) ![cert](cert.png)