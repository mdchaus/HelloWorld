## Description

This role is to mount Nas file share on Linux VM, this role will import "copy_ad_secrets_from_akv_to_vm_linux_rhel" in to current role and processes to get the secrets

If your app ID is `appabp03appiddev`, 3 secrets will be accessible if you include this role:
1. `appabp03appiddev_USERNAME`
1. `appabp03appiddev_PASSWORD`
1. `appabp03appiddev_UPN`

## Prerequisites for "copy_ad_secrets_from_akv_to_vm_linux_rhel" role

- Setup secret replication from HashiCorp Vault to Azure Key Vault by following [this process](https://confluence.us.bank-dns.com/pages/viewpage.action?pageId=312642762)

## Default Variables

- mount_permission: permission to the mount directory
- cred_permission: permission to the credentials File
- credential_path: path for crendential to store
  

## Variables

Below variables must be defined by the end user


- mount_path:           Directory path to mount unc
- akv_vault_name:           ID of your Azure Key Vault
- replicated_app_id:            your app ID (this is the same as the TARGET identifier used in the replication process)
- metta_component_name:         component name in metta ([Shield Console](https://shield-console.us.bank-dns.com/dashboard)) [this is probably secretreplicate]
- metta_app_name:           app name in metta ([Shield Console](https://shield-console.us.bank-dns.com/dashboard))
- unc_nas_path:                     Define your Nas unc path here

 

## Sample Playbook

```
- hosts: linux
  gather_facts: true
  become: yes
  strategy: free
  vars:
    akv_vault_name: kv-cus-abp03-dev-01
    replicated_app_id: appabp03appiddev
    metta_component_name: secretreplicate
    metta_app_name: azabp
    mount_path: /tmp/nas
    unc_nas_path: //o1-app-pr11-02.us.bank-dns.com/ABP_dev$
    
  roles:
    - shared_roles/linux/mount_onprem_nas_drive_linux_vm


```

## Validation Step


Once the playbook run is successful, restart the VM and open file explorer click on "This PC" the file mount should be visible as below:


![Nas_fileshare.png](image.png)
![Nas_fileshare1.png](image__1_.png)
