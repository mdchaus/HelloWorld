## Description

This role is for running shellscripts

This task will run shellscripts

## Variables
```
shell_scripts: 
  - cmd: /opt/python-3.7.12/install.sh    ## add variables in this path inventories/dev/group_vars/all.yml
    dir: /opt/
```

|Variable|Details|Scope|
|---|---|---|
| shell_scripts | specify path of shell script to be run | env |