## Description

This role is for installing the Nessus agent on Linux (RHEL) VMs. 

## Variables

Below are default variables and are defined in role itself. Application team don't have to pass these in the variable files. "files_to_delete" files will be default for all installations.
```
nessus_rpm_version:
nessus_installer_path:
nessus_artifactory_url:
nessus_download_path:
nessus_linking_key:
device_group:
nessus_service:
nessus_host:
port:
files_to_delete:
    - /etc/machine_id
    - /etc/tenable_tag


```

## Sample Playbook

To use this role ,  Use ansible galaxy to installed shared_roles during runtime and create a playbook as below. "hosts" need to be changes.

```ansible
- hosts: <Linux hosts>
  gather_facts: true
  become_method: runas
  strategy: free
  roles:
    - shared_roles/linux/nessus_install_linux_rhel
```

