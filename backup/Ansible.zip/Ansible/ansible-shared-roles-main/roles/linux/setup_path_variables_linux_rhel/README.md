## Description

This role is for setup path variables

This task will setup the path variables

## Variables
```
path_parameters:
  - line: add PATH line to be added into destination
    ## add variables in this path inventories/dev/group_vars/all.yml
```

|Variable|Details|Scope|
|---|---|---|
| path_parameters | Specify value of line  | env |