## Description

This role is for unzip zipped files

This task will unzip the zipped files

## Variables
```
unarchive_files: 
  - src:  ## zip file path 
    dest:      ## destination for extract package
app_user :
admin_group :

```

|Variable|Details| Scope  |
|---|---|--------|
| unarchive_files | specify source and destination where files to be extract  | global |