## Description

This role is for downloading tomcat binaries and unarchiving that binaries

we achieve this task by creating a directory and downloading tomcat file by using
get_url module and unarchiving tomcat binaries 

## Variables
```

base_target_directory: '/opt'
tomcat_target_directory: /opt/tomcat
tomcat_download_path: '/var/tmp'
tomcat_artifactory_url: "https://artifactory.us.bank-dns.com/artifactory/cloud-migration-softwares-generic-virtual/tomcat/Tomcat_9/apache-tomcat-9.0.85.tar.gz"
tomcat_version_tar_gz_name: apache-tomcat-9.0.85.tar.gz
```
