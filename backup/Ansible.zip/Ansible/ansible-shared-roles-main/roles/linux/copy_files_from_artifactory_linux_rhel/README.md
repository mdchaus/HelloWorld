# Ansible Role: copy_files_from_artifactory_linux_rhel

This Ansible role is designed to copy files from Artifactory to specified directories on Red Hat Enterprise Linux (RHEL) hosts. It ensures the destination directory exists before copying and can unarchive files if required.

## Requirements

- Ansible 2.9 or higher
- RHEL hosts

## Role Variables

This role uses the following variables:

- `artifactory_files`: A list of files to copy from Artifactory. Each file should be a dictionary with the following keys:
  - `src`: The URL to download the file from Artifactory.
  - `dest`: The destination directory to copy the file to.
  - `file_name`: The name of the file.
  - `file_permission`: The file permission to apply to the copied files (optional, defaults to '0755').
  - `extract_files`: A boolean value indicating whether to extract the file after copying.
  - `unarchive_file_dest`: The destination directory to unarchive the file to (only required if `extract_files` is set to `true`).
  - `unarchive_file_permission`: The file permission to apply to the unarchived files (optional, defaults to '0755').
  - `user`: The owner of the copied files (optional, defaults to the value of `app_user`  variable).
  - `group`: The group owner of the copied files (optional, defaults to the value of `admin_group` variable).

## Dependencies

None.

## Example Playbook

```yaml
- hosts: rhel
  roles:
    - role: copy_files_from_artifactory_linux_rhel
  vars:
    artifactory_files:
      - src: https://artifactory.example.com/path/to/file1
        dest: /path/to/destination1
        file_name: file1
        file_permission: '0755'
        user: appuser1
        group: admingroup1
        extract_files: true
        unarchive_file_permission: '0755'
      - src: https://artifactory.example.com/path/to/file2
        dest: /path/to/destination2
        file_name: file2
        file_permission: '0644'
        user: appuser2
        group: admingroup2
        extract_files: false
```

## Validation Steps

After running the playbook, you can validate that the files were copied correctly by following these steps:

1. Log in to the RHEL host.
2. Navigate to the destination directory.
3. Check the list of files in the directory.
4. If `extract_files` was set to `true`, check that the file was unarchived correctly.

You can also validate the file permissions and ownership:

```bash

ls -l /path/to/destination
```

This command will display the file permissions, owner, and group for each file in the directory.


