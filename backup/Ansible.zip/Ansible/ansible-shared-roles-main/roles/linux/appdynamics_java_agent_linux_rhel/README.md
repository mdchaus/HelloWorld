## Overview 

This role is for installing app dynamics java agent on linux VMS. 
Refer appdynamics-agent.yml playbook to orchestrate app dynamics installation in your project. 

## Variables

Below  variables needs to be added to  role specific variable files 

```

# Shared
nix_dest_dl_folder: /opt/appdynamics/appdynamics-installers/
nix_dest_app_folder: /opt/appdynamics/

# Java Agent
nix_dest_jv_folder: /opt/appdynamics/javaagent/
nix_dest_jv_file: JavaAgent.zip
```

Below variables are environment specific and needs to be added in environment specific group variables

```

"accountAccessKey": "XXXXX"   # Please reach out to AppDynamics team to get this detail 
"app_user": "app****"   # appiduser for the application
"admin_group": "root"

```

For Prod:
```
"controller_hostName": "us-bank.saas.appdynamics.com"   # hostname will change as the per the env
"controller_port": 443
"ssl_enabled": true
"accountName": "usbank"  # This value will change based on env
"analytics_endpoint:" "https://analytics.api.appdynamics.com:443"   # Analytics Delivery Endpoint
"global_accountName:" "USBANK_351d091f-c3a8-4779-a0da-4a53785ebec3"  # Analytics Delivery Key

```

For Non-Prod:
```
"controller_hostName": "us-bank-testdev.saas.appdynamics.com"   # hostname will change as the per the env
"controller_port": 443
"ssl_enabled": true
"accountName": "us-bank-testdev"  # This value will change based on env
"analytics_endpoint": "https://analytics.api.appdynamics.com:443"   # Analytics Delivery Endpoint
"global_accountName": "us-bank-testdev_0ca51855-0e84-4e7f-8ba5-87dab5c8e48f"  # Analytics Delivery Key

```

The following parameters must be added to the java process additional parameters. The parameters are the same for both Windows and Linux operating systems.
```

-Dappdynamics.agent.applicationName=Personetics-6904-UAT   # Please reach out to AppDynamics team to get this detail
-Dappdynamics.agent.tierName=content-services-api   # This is used to group JVMs and can not contain any spaces
-Dappdynamics.agent.nodeName=VMIKSA699B1TA0-Branch-banking   # This is used to identify specific JVMs and can not contain any spaces
-Dappdynamics.http.proxyHost=web-proxyapp.us.bank-dns.com   # JVM Proxy Host Parameter
-Dappdynamics.http.proxyPort=3128   # JVM Proxy Port Parameter
```

## Dependencies

This role has a dependency on  
### Role :  copy_files_from_artifactory_linux_rhel. 
Below variables are required in group global variables. 

For Prod:
```
artifactory_files:
  - src: "https://artifactory.us.bank-dns.com/artifactory/appdynamicsagents-generic-virtual/cloud-agent/prod/JavaAgent.zip" ## Add artifactory source URL
    dest: "/opt/appdynamics/appdynamics-installers/JavaAgent.zip"

```

For Non-Prod:
```
artifactory_files:
  - src: "https://artifactory.us.bank-dns.com/artifactory/appdynamicsagents-generic-virtual/cloud-agent/non-prod/JavaAgent.zip" ## Add artifactory source URL
    dest: "/opt/appdynamics/appdynamics-installers/JavaAgent.zip"

```



