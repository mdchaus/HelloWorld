## Description

This role is for deleting single or multiple directories.

This task will delete directories.

## Variables
```
cleanup_dirs:
   - /tmp/software/python  ## add variables in this path inventories/dev/group_vars/all.yml
```

|Variable|Details|Scope|
|---|---|---|
| cleanup_dirs | specify the path which directory should be delete | env |