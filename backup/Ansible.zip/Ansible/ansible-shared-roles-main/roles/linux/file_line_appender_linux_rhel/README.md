## Description

This role is for adding lines to the files

This task will add lines only when the lines are not present in that file. if the lines are already present in that file the task will skip

## Variables : 

```
file_line:
  - file: "/etc/security/limits.conf"
    line: "apptriadappiddev soft    nofile          65536"
```