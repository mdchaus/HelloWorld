#!/bin/bash
set -e

# Note above that we run dumb-init as PID 1 in order to reap zombie processes
# as well as forward signals to all processes in its session. Normally, sh
# wouldn't do either of these functions so we'd leak zombies as well as do
# unclean termination of all our sub-processes.

# configure java environment
JAVA_OPTS="${JAVA_OPTS:-}";
JAVA_OPTS="$JAVA_OPTS -Dfile.encoding=UTF-8";

# enabling the filebeat on server
if [[ "$ENABLE_FILE_BEAT" == "yes" ]]; then
  # start the filebeat and run this as a background process
  cd /etc/filebeat
  filebeat run -c /etc/filebeat/filebeat.yml &
fi

# enabling the filebeat on server
if [[ "$ENABLE_HASHI_VAULT" == "yes" ]]; then
  # run the hashi to generate the creds
  hashi -environment ${ENV} -roleid ${ROLE_ID} -secretid ${SECRET_ID} -secretpath ${SECRET_PATH} -namespace ${HASHI_NAMESPACE}
  if [[ "$?" == 1 ]]; then
    echo "unable to find the secrets in the vault"
    cat "/var/log/hashi/hashi.log"
    exit 1
  fi

  echo "source /tmp/hashikeys.sh" >> ~/.bashrc
  source ~/.bashrc
fi

# enabling appd monitoring for the applications
if [[ "$ENABLE_APPD" == "yes" ]]; then
  #cd ${APP_HOME}
  java ${JAVA_MEM_OPTS} ${JAVA_APPD_OPTS} -jar /usr/${APPLICATION_NAME:-}.jar ${JAVA_OPTS:-}
else
  #cd ${APP_HOME}
  java ${JAVA_MEM_OPTS} -jar /usr/${APPLICATION_NAME:-}.jar ${JAVA_OPTS:-}
fi
