package com.usbank.poslp.merchant.details.model.request;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@AllArgsConstructor
@NoArgsConstructor
@Data
public class CustomerRequestContext {
	private Boolean isPilotUser;
	private Boolean isApplicationEnabled;
}
