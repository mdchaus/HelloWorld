package com.usbank.poslp.merchant.details.model.response;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;
import org.apache.commons.lang3.StringUtils;

@Data
public class MerchantDetailsBody {

    @JsonProperty("PrincipalType")
    private String principalType = StringUtils.EMPTY;

    @JsonProperty("LastName")
    private String lastName = StringUtils.EMPTY;

    @JsonProperty("FirstName")
    private String firstName = StringUtils.EMPTY;

    @JsonProperty("ContactID")
    private String contactID = StringUtils.EMPTY;

}
