package com.usbank.poslp.merchant.details.validator;

import com.usbank.api.core.component.requestcontext.IRequestContext;
import com.usbank.api.core.component.validator.BaseValidator;
import com.usbank.api.core.component.validator.IValidator;
import com.usbank.api.core.exception.BadRequestException;
import com.usbank.poslp.merchant.details.constants.CustomErrorCodes;
import com.usbank.poslp.merchant.details.constants.MerchantDetailsConstants;
import com.usbank.poslp.merchant.details.enums.ErrorCodes;
import com.usbank.poslp.merchant.details.model.request.MerchantDetailsInput;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
@Component
public class MerchantRequestValidator extends BaseValidator implements IValidator<MerchantDetailsInput> {

    private final Logger logger = LoggerFactory.getLogger(this.getClass());
    private static final String INPUT = "input";

    @Autowired
    IRequestContext requestContext;

    @Autowired
    MerchantHeaderValidator httpHeaderValidation;

    /**
     * This method validates the request
     *
     * @param request
     * @throws BadRequestException
     */

    @Override
    public void validate(MerchantDetailsInput request) {

        List<String> errors = new ArrayList<>();
        httpHeaderValidation.validate(errors);

        if (Objects.isNull(request.getMerchantID())) {
            logger.error("Request can't be empty");
            throw new BadRequestException(ErrorCodes.BAD_REQUEST.getErrorCode(),
                    ErrorCodes.BAD_REQUEST.getErrorDescription(), null, INPUT);
        } else {
        	validateMerchantId(request);
        }
    }

        private void validateMerchantId(MerchantDetailsInput request) {
            if (StringUtils.isBlank(request.getMerchantID().toString())
                    || request.getMerchantID().toString().length() > 22) {
                logger.error("error while processing request field MerchantId can't be empty");
                throw new BadRequestException(CustomErrorCodes.INVALID_MERCHANT_INPUT.getErrorCode(),
                        CustomErrorCodes.INVALID_MERCHANT_INPUT.getErrorDescription(), null,
                        MerchantDetailsConstants.INVALID_MERCHANTID);
            }

        }

}
