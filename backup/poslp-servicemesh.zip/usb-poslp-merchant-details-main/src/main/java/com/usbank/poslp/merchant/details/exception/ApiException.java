package com.usbank.poslp.merchant.details.exception;

import com.usbank.poslp.graphql.core.exceptions.GraphQLAPIException;
import com.usbank.poslp.merchant.details.model.response.PartialError;
import jakarta.annotation.Generated;
import lombok.Getter;

@Generated(value = "io.swagger.codegen.v3.generators.java.SpringCodegen", date = "2021-04-10T20:30:06.416-05:00[America/Chicago]")
@Getter
public class ApiException extends GraphQLAPIException {
	private String code;
	private String description;
	private String attribute;
	private String apiId;

	public ApiException(String code, String description, String attribute, String apiId) {
		super(code, description, attribute, apiId);
		this.code = code;
		this.description = description;
		this.attribute = attribute;
		this.apiId = apiId;

	}

	public ApiException(PartialError error) {
		super(error.getErrorCode(), error.getErrorDescription(), error.getErrorKeyAttribute(), error.getApiId());
		code = error.getErrorCode();
		description = error.getErrorDescription();
		attribute = error.getErrorKeyAttribute();
		apiId = error.getApiId();

	}

}