package com.usbank.poslp.merchant.details.model.request;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.usbank.poslp.commons.entities.MerchantProduct;
import com.usbank.poslp.merchant.details.utils.MappingUtils;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.UUID;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class MerchantProducts {

    @JsonProperty("merchantProductGuid")
    private UUID merchantProductGuid;

    @JsonProperty("productGuid")
    private UUID productGuid;

    @JsonProperty("productCode")
    private String productCode;

    @JsonProperty("termCount")
    private BigDecimal termCount;

    @JsonProperty("termType")
    private String termType;

    @JsonProperty("merchantProductEffectiveDate")
    private LocalDateTime merchantProductEffectiveDate;
    @JsonProperty("merchantProductExpirationDate")
    private LocalDateTime merchantProductExpirationDate;



    public static MerchantProducts ofEntity(MerchantProduct entity) {
        MappingUtils mappingUtils=new MappingUtils();
        return MerchantProducts.builder()
                .merchantProductGuid(entity.getMerchantProductGuid())
                .productGuid(entity.getProduct() .getProductGuid())
                .productCode(entity.getProduct().getProductCode())
                .termCount(entity.getProduct().getTermCount())
                .merchantProductEffectiveDate(entity.getEffectiveDate()!=null?mappingUtils.convertDateToLocalDateTime(entity.getEffectiveDate()):null)
                .merchantProductExpirationDate(entity.getExpirationDate()!=null?mappingUtils.convertDateToLocalDateTime(entity.getExpirationDate()):null)
                .termType(entity.getProduct().getTermType()).build();
    }

}
