package com.usbank.poslp.merchant.details.model.errorResponse;

import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.annotations.ApiModelProperty;
import jakarta.validation.Valid;
import org.springframework.validation.annotation.Validated;

@Validated
public class BaseResponse {

	@JsonProperty("error")
	private Error error = null;

	@JsonProperty("timestamp")
	private String timestamp = null;


	/**
	 * Get error
	 * 
	 * @return error
	 **/
	@ApiModelProperty(value = "")
	@Valid
	public Error getError() {
		return error;
	}
	public void setError(Error error) {
		this.error = error;
	}


	/**
	 * Get timestamp
	 * 
	 * @return timestamp
	 **/
	@ApiModelProperty(example = "yyyy-MM-dd hh:mm:ss", value = "")
	public String getTimestamp() {
		return timestamp;
	}
	
	public void setTimestamp(String timestamp) {
		this.timestamp = timestamp;
	}

}
