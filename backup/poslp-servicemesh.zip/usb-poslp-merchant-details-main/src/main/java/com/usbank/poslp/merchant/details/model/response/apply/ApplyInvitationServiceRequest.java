package com.usbank.poslp.merchant.details.model.response.apply;

import lombok.Data;

@Data
public class ApplyInvitationServiceRequest {
    private String correlationId;
    private String productCode;
    private String subProductCode;
    private String offerId;
    private String shoppingCartGUID;
    private String merchantID;
    private String sourceCode;
    private int locationCode;
    private String firstName;
    private String middleName;
    private String lastName;
    private String billingStreet1;
    private String billingStreet2;
    private String billingCity;
    private String state;
    private String postalCode;
    private String countryCode;
    private String applicantEmail;
    private String mobilePhone;
    private String returnUrl;
    private String consumerSource;
    private BnplCategory bnplCategory = BnplCategory.INVOICE;
}
