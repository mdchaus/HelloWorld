package com.usbank.poslp.merchant.details.model.response.apply;

import lombok.Data;

@Data
public class AttemptsItem{
	private String date;
	private String step;
}
