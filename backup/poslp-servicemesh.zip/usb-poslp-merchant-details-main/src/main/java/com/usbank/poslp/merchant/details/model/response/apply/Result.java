package com.usbank.poslp.merchant.details.model.response.apply;

import lombok.Data;

@Data
public class Result{
	private boolean async;
	private Execution execution;
	private boolean complete;
	private boolean errors;
}
