package com.usbank.poslp.merchant.details.model.response.apply;

public enum BnplCategory {
    PREAPPROVAL,
    INVOICE;
}
