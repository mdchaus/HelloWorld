package com.usbank.poslp.merchant.details.service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.usbank.api.core.aspect.LogExecutionTime;
import com.usbank.api.core.exception.PoslpAPIException;
import com.usbank.api.core.exception.SubsystemDataException;
import com.usbank.api.core.exception.SubsystemUnavailableException;
import com.usbank.api.core.model.BaseResponse;
import com.usbank.api.core.modelservice.IModelService;
import com.usbank.poslp.commons.entities.*;
import com.usbank.poslp.merchant.details.advice.MerchantExceptionHandler;
import com.usbank.poslp.merchant.details.constants.CustomErrorCodes;
import com.usbank.poslp.merchant.details.model.request.MerchantPreApprovalLinkRequest;
import com.usbank.poslp.merchant.details.model.response.MerchantPreApprovalLinkResponse;
import com.usbank.poslp.merchant.details.repository.MerchantDetailsRepository;
import org.hibernate.exception.JDBCConnectionException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.dao.DataAccessResourceFailureException;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.CannotCreateTransactionException;

import java.util.*;

@Service
public class MerchantPreApprovalLinkService  implements IModelService<MerchantPreApprovalLinkRequest, MerchantPreApprovalLinkResponse> {

    private static final Logger logger = LoggerFactory.getLogger(MerchantPreApprovalLinkService.class);

    @Value("${pre.approval.link}")
    private String preApprovalLink;

    @Autowired
    private MerchantDetailsRepository merchantRepository;

    @Autowired
    private ObjectMapper mapper;

    @LogExecutionTime
    @Override
    public MerchantPreApprovalLinkResponse process(MerchantPreApprovalLinkRequest request) throws Exception
    {
        logger.debug("MerchantPreApprovalLinkService call started");
        MerchantPreApprovalLinkResponse response=new MerchantPreApprovalLinkResponse();

        try {
            logger.info("MerchantPreApprovalLink - Get details for merchantID - {} from DB", request.getMerchantID());
            Optional<Merchant> merchantDetail = merchantRepository.findById(request.getMerchantID());
            if (merchantDetail.isPresent()) {
                logger.info("MerchantPreApprovalLink - Link : {} and Hashed Merchant Id : {}", preApprovalLink , merchantDetail.get().getHashedMerchantId());
                response.setPreApprovalLink(preApprovalLink+merchantDetail.get().getHashedMerchantId());
            } else {
                logger.error("[EXCEPTION] --> Merchant details NOT available for merchantID while building Pre Approval link- " + request.getMerchantID());
                throw new PoslpAPIException(CustomErrorCodes.NO_MERCHANT_FOUND.getErrorCode(), CustomErrorCodes.NO_MERCHANT_FOUND.getErrorDescription());
            }
        } catch (JDBCConnectionException | DataAccessResourceFailureException |
                 CannotCreateTransactionException ex) {
            throw new SubsystemUnavailableException(CustomErrorCodes.DB_CONNECTION_ERROR.getErrorCode(), CustomErrorCodes.DB_CONNECTION_ERROR.getErrorDescription(), ex.getMessage());
        } catch(Exception ex){
            logger.error("[EXCEPTION] --> Exception : {}",ex);
            throw ex;
        }
        logger.debug("MerchantPreApprovalLinkService response: "+ response);
        return response;
    }
}

