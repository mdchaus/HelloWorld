package com.usbank.poslp.merchant.details.handler;


import com.usbank.api.core.aspect.LogExecutionTime;
import com.usbank.api.core.component.validator.BaseValidator;
import com.usbank.api.core.exception.BadRequestException;
import com.usbank.api.core.requesthandler.IRequestHandler;
import com.usbank.poslp.merchant.details.advice.MerchantExceptionHandler;
import com.usbank.poslp.merchant.details.constants.CustomErrorCodes;
import com.usbank.poslp.merchant.details.constants.MerchantDetailsConstants;
import com.usbank.poslp.merchant.details.model.request.MerchantPreApprovalLinkRequest;
import com.usbank.poslp.merchant.details.model.response.MerchantPreApprovalLinkResponse;
import com.usbank.poslp.merchant.details.service.MerchantPreApprovalLinkService;
import com.usbank.poslp.merchant.details.utils.MerchantConfigurationUtils;
import com.usbank.poslp.merchant.details.validator.MerchantHeaderValidator;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.Objects;


@Component
public class MerchantPreApprovalLinkHandler extends BaseValidator implements IRequestHandler<MerchantPreApprovalLinkRequest, MerchantPreApprovalLinkResponse> {

    private static final Logger logger = LoggerFactory.getLogger(MerchantPreApprovalLinkHandler.class);
    @Autowired
    MerchantPreApprovalLinkService merchantPreApprovalLinkService;

    @Autowired
    MerchantExceptionHandler exceptionHandler;

    @Autowired
    private MerchantConfigurationUtils merchantConfigurationUtils;

    @Autowired
    private MerchantHeaderValidator merchantHeaderValidator;

    @Override
    @LogExecutionTime
    public MerchantPreApprovalLinkResponse handle(MerchantPreApprovalLinkRequest request) throws Exception {
        try {
            validateRequest(request);
            return merchantPreApprovalLinkService.process(request);
        } catch (Exception e) {
            logger.error("[EXCEPTION] Exception in Merchant Details: ", e);
            throw exceptionHandler.commonAPIException(e);
        }
    }

    public void validateRequest(MerchantPreApprovalLinkRequest request) {

        logger.info("Merchant PreApproval link validating request for PartnerId: {} and Merchant ID: {} ", Objects.nonNull(request)?request.getPartnerId():"[]", Objects.nonNull(request)?request.getMerchantID():"[]");
        if (Objects.isNull(request)) {
            logger.error("Request is empty");
            throw new BadRequestException(CustomErrorCodes.INVALID_REQUEST.getErrorCode(),
                    CustomErrorCodes.INVALID_REQUEST.getErrorDescription(),
                    MerchantDetailsConstants.MERCHANT_DETAIL_DOMAIN);
        }else{
            try {
                merchantHeaderValidator.validate(new ArrayList<>());
                merchantConfigurationUtils.validateMerchantId(request.getMerchantID());
                merchantConfigurationUtils.validatePartnerAndMerchantID(request.getPartnerId(), request.getMerchantID());
            } catch (Exception ex) {
                logger.error("[EXCEPTION] -->", ex);
                throw exceptionHandler.commonAPIException(ex);
            }
            logger.debug("Finished Merchant PreApproval link validating request for PartnerId: {} and Merchant ID: {} ", request.getPartnerId(), request.getMerchantID());
        }
    }

}
