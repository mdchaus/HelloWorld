package com.usbank.poslp.merchant.details.exception;

import com.usbank.api.core.exception.BadRequestException;
import com.usbank.api.core.exception.PoslpAPIException;
import com.usbank.api.core.exception.SubsystemDataException;
import com.usbank.api.core.exception.SubsystemUnavailableException;
import com.usbank.poslp.merchant.details.constants.CustomErrorCodes;
import io.github.resilience4j.circuitbreaker.CallNotPermittedException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import java.text.ParseException;
import java.util.concurrent.ExecutionException;

@Component
public class MerchantPreApprovalExceptionHandler {

    private final Logger log = LoggerFactory.getLogger(this.getClass());

    String code = null;
    String message = null;

    public RuntimeException commonAPIException(Exception ex) {

        if (ex instanceof PoslpAPIException) {
            log.error("[EXCEPTION] --> Process Loan Transaction API POSLP Exception");
            throw new PoslpAPIException(((PoslpAPIException) ex).getErrorCode(),((PoslpAPIException) ex).getErrorMessage());
        }
        if (ex instanceof SubsystemDataException) {
            log.error("[EXCEPTION] --> Process Loan Transaction API POSLP Subsystem Data Unavailable Exception");
            code = CustomErrorCodes.SUBSYSTEM_DATA_EXCEPTION.getErrorCode();
            message = ((SubsystemDataException) ex).getHostResultDescription();
            throw new PoslpAPIException(code, message);
        }
        if (ex instanceof SubsystemUnavailableException) {
            log.error("[EXCEPTION] --> Process Loan Transaction API POSLP Subsystem Unavailable Exception");
            code = CustomErrorCodes.SUBSYSTEM_UNAVAILABLE.getErrorCode();
            message = ((SubsystemUnavailableException) ex).getResponseBody();
            throw new PoslpAPIException(code, message);
        }
        if (ex instanceof ExecutionException) {
            log.error("[EXCEPTION] --> Process Loan Transaction API POSLP Subsystem Data Unavailable Exception");
            if ( ex.getCause() instanceof SubsystemUnavailableException ){
                code = CustomErrorCodes.SUBSYSTEM_UNAVAILABLE.getErrorCode();
                message = ((SubsystemUnavailableException) ex.getCause()).getResponseBody();
            } else {
                code = CustomErrorCodes.SUBSYSTEM_DATA_EXCEPTION.getErrorCode();
                message = ((SubsystemDataException) ex.getCause()).getHostResultDescription();
            }
            throw new PoslpAPIException(code, message);
        }


        if (ex instanceof BadRequestException) {
            code = ((BadRequestException) ex).getErrorCode();
            message = ((BadRequestException) ex).getErrorMessage();
            log.error("[EXCEPTION] --> Process Loan Transaction API POSLP BadRequest Exception");
            throw new BadRequestException(code, message);
        }
        if (ex instanceof ParseException) {
            message = ex.getMessage();
            log.error("[EXCEPTION] --> Process Loan Transaction API POSLP ParseException Exception");
            throw new BadRequestException(code, message);
        }
        if (ex instanceof NullPointerException) {
            code = CustomErrorCodes.INTERNAL_ERROR.getErrorCode();
            message = CustomErrorCodes.INTERNAL_ERROR.getErrorDescription();
            log.error("[EXCEPTION] --> Process Loan Transaction API POSLP Null Pointer Exception");
            throw new PoslpAPIException(code, message);
        }

        if (ex instanceof CallNotPermittedException) {
            code = CustomErrorCodes.CIRCUIT_BREAKER_OPEN.getErrorCode();
            message = CustomErrorCodes.CIRCUIT_BREAKER_OPEN.getErrorDescription();
            log.error("[EXCEPTION] --> Process Loan Transaction API POSLP Call Not Permitted Exception");
            throw new PoslpAPIException(code, message);
        }
        else{
            log.error("[EXCEPTION] --> Process Loan Transaction Unhandled Exception",ex.getMessage());
            throw new RuntimeException(ex);
        }

    }

}

