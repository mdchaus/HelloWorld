package com.usbank.poslp.merchant.details.handler;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.usbank.api.core.aspect.LogExecutionTime;
import com.usbank.api.core.component.requestcontext.IRequestContext;
import com.usbank.api.core.constant.USBConstants;
import com.usbank.api.core.requesthandler.IRequestHandler;
import com.usbank.poslp.merchant.details.advice.MerchantExceptionHandler;
import com.usbank.poslp.merchant.details.constants.MerchantDetailsConstants;
import com.usbank.poslp.merchant.details.model.request.MerchantDetailsInput;
import com.usbank.poslp.merchant.details.model.response.FeatureConfigurationResponse;
import com.usbank.poslp.merchant.details.service.MerchantDetailsFeatureService;
import com.usbank.poslp.merchant.details.validator.MerchantDetailsRequestValidator;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.Optional;

@Service
@Slf4j
public class MerchantDetailsFeatureHandler implements IRequestHandler<MerchantDetailsInput, List<FeatureConfigurationResponse>> {

    @Autowired
    private MerchantDetailsFeatureService merchantDetailsFeatureService;

    @Autowired
    MerchantDetailsRequestValidator merchantRequestValidator;

    @Autowired
    private MerchantExceptionHandler exceptionHandler;

    @Autowired
    ObjectMapper objectMapper;

    @Autowired
    private IRequestContext requestContext;

    @Override
    @LogExecutionTime
    public List<FeatureConfigurationResponse> handle(MerchantDetailsInput request) throws Exception {
        log.debug("MerchantDetailsFeatureHandler call started: ");
        log.debug("MerchantDetailsFeature Request: "+request);
        Optional<MerchantDetailsInput> optionalMerchantDetailsInput = Optional.ofNullable(request);
        List<FeatureConfigurationResponse> featureConfigurationResponseList = new ArrayList<>();
        try
        {
            /**
             * If request for Merchant Details comes from APIGEE,
             * then get the MID from the Identifier in the request header
             *
             * Else
             * Use the MID available in the request
             */
            String clientId=requestContext.getHttpHeaders().get(USBConstants.CLIENT_ID.toLowerCase());
            if(optionalMerchantDetailsInput.isPresent() && (Objects.nonNull(clientId) && clientId.equalsIgnoreCase(MerchantDetailsConstants.APIGEE))) {
                //Only when MID is available in Identifier in Request Header, override the Request. Else do not overwrite the request.
                String midFromHeader = merchantRequestValidator.getIdentifier();
                if(Objects.nonNull(midFromHeader) && StringUtils.isNotEmpty(midFromHeader)){
                    request = new MerchantDetailsInput();
                    request.setMerchantID(midFromHeader);
                }
                merchantRequestValidator.validate(request);
            } else {
                merchantRequestValidator.validate(request);
            }
            featureConfigurationResponseList = merchantDetailsFeatureService.process(request);
            log.debug("MerchantDetailsFeature response: "+ featureConfigurationResponseList);
        }catch (Exception ex) {
            log.error("[ERROR] --> Merchant details Feature Request Handler :{}", ex);
            throw exceptionHandler.commonAPIException(ex);
        }
        return featureConfigurationResponseList;

    }

}