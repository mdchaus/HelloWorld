package com.usbank.poslp.merchant.details.validator;

import com.usbank.api.core.component.validator.BaseValidator;
import com.usbank.api.core.component.validator.IValidator;
import com.usbank.api.core.exception.BadRequestException;
import com.usbank.api.core.exception.PoslpAPIException;
import com.usbank.poslp.merchant.details.constants.CustomErrorCodes;
import com.usbank.poslp.merchant.details.constants.MerchantDetailsConstants;
import com.usbank.poslp.merchant.details.model.request.ValidateMerchantDetails;
import com.usbank.poslp.merchant.details.model.response.MerchantDetailsResponse;
import com.usbank.poslp.merchant.details.model.response.SRSApiToken;
import com.usbank.poslp.merchant.details.utils.ApiUtils;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;

import lombok.extern.slf4j.Slf4j;
import java.util.*;

@Component
@Slf4j
public class MerchantDetailsValidator extends BaseValidator implements IValidator<ValidateMerchantDetails> {

    @Value("${bnpl.merchant.api.source}")
    private String bnplPartner;

    @Autowired
    private ApiUtils apiUtils;

    @Override
    public void validate(ValidateMerchantDetails validateMerchantDetails) {
        final boolean inputsAreValid = mandatoryFieldValuesPresent(validateMerchantDetails);
        if(inputsAreValid) throw new BadRequestException(CustomErrorCodes.VALIDATE_MERCHANT_DETAILS_ERROR.getErrorCode(),
                CustomErrorCodes.VALIDATE_MERCHANT_DETAILS_ERROR.getErrorDescription());
    }

    /**
     * Validate the merchant details mandatory field values
     * @param validateMerchantDetails
     * @throws BadRequestException
     */
    private boolean mandatoryFieldValuesPresent(ValidateMerchantDetails validateMerchantDetails) throws BadRequestException {

        if(Objects.isNull(validateMerchantDetails)) {
            log.error("Merchant details input object is null");
            return true;
        }

        if(StringUtils.isBlank(validateMerchantDetails.getAccountMid())
                || StringUtils.isBlank(validateMerchantDetails.getApiSource())
                || StringUtils.isBlank(validateMerchantDetails.getContactFirstName())
                || StringUtils.isBlank(validateMerchantDetails.getContactLastName())
                || StringUtils.isBlank(validateMerchantDetails.getDDANumber())
                || StringUtils.isBlank(validateMerchantDetails.getProcessingCenterID())
                || StringUtils.isBlank(validateMerchantDetails.getSSNorTaxId())) {
            log.error("SRS Api input mandatory field values are missing");
            return true;
        }

        if(!validateMerchantDetails.getApiSource().equalsIgnoreCase(bnplPartner)) {
            log.error("Invalid Api Source");
            return true;
        }

        if(validateMerchantDetails.getDDANumber().length() != MerchantDetailsConstants.DDA_NUMBER_LENGTH) {
            log.error("Invalid DDA Number");
            return true;
        }
        return false;
    }
}
