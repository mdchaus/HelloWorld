package com.usbank.poslp.merchant.details.model.request;

import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class MerchantPreApprovalLinkRequest {
    @Schema(name = "merchantID", type = "string", description = "", example = "8025000002", required = true, maximum = "22", nullable = false)
    String merchantID;
    @Schema(name = "partnerId", type = "string", description = "", example = "Rectangle", required = true, maximum = "120", nullable = false)
    String partnerId;
}
