package com.usbank.poslp.merchant.details.config;

import lombok.Data;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;

@Data
@Configuration
public class MerchantDetailsApiConfig {

	@Value("${api.id}")
	private String apiId;
}
