package com.usbank.poslp.merchant.details.scalars;
import com.netflix.graphql.dgs.DgsScalar;
import graphql.language.StringValue;
import graphql.schema.Coercing;
import graphql.schema.CoercingParseLiteralException;
import graphql.schema.CoercingParseValueException;
import graphql.schema.CoercingSerializeException;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.format.DateTimeFormatter;
import java.util.Date;

/**
 * graphql-java provides optional com.usbank.dss.servicing.account.details.scalars in the graphql-java-extended-com.usbank.dss.servicing.account.details.scalars
 * library. We can wire a scalar from this library by adding the scalar to the
 * RuntimeWiring.
 */
@DgsScalar(name = "Date")
public class DateScalar implements Coercing<Date, String> {

	private DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");

	private SimpleDateFormat originalFormat = new SimpleDateFormat("yyyy-MM-dd");

	@Override
	public String serialize(Object input) throws CoercingSerializeException {
		if (input instanceof Date) {
			return originalFormat.format(input);
		} else {
			throw new CoercingSerializeException("Not a valid Date");
		}
	}

	@Override
	public Date parseValue(Object input) throws CoercingParseValueException {
		try {
			return originalFormat.parse(input.toString());
		} catch (ParseException e) {
			throw new CoercingSerializeException("Not a valid Date");
		}
	}

	@Override
	public Date parseLiteral(Object input) throws CoercingParseLiteralException {
		if (input instanceof StringValue) {
			try {
				return originalFormat.parse(((StringValue) input).getValue());
			} catch (ParseException e) {
				throw new CoercingSerializeException("Not a valid Date");
			}

			// return LocalDate.parse(( (StringValue) input).getValue(), formatter);
		} else {
			throw new CoercingSerializeException("Not a valid DateTi");
		}
	}

}
