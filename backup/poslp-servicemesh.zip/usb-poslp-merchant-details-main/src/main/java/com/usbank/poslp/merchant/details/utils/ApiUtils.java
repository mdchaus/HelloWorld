package com.usbank.poslp.merchant.details.utils;

import com.usbank.api.core.component.requestcontext.RequestContext;
import com.usbank.api.core.exception.SubsystemDataException;
import com.usbank.api.core.exception.SubsystemUnavailableException;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.apache.http.entity.ContentType;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Map;
import java.util.HashMap;

import static com.usbank.poslp.core.clients.constant.HeaderConstant.CLIENT_APPLICATION;
import static com.usbank.poslp.merchant.details.constants.MerchantDetailsConstants.*;

@Component
@Slf4j
public class ApiUtils {

    @Value("${bnpl.srs.api.token.grant.type}")
    private String grantType;

    @Value("${bnpl.srs.api.token.client.id}")
    private String clientId;

    @Value("${bnpl.srs.api.token.client.secret}")
    private String clientSecret;

    @Value("${bnpl.srs.api.token.username}")
    private String username;

    @Value("${bnpl.srs.api.token.password}")
    private String password;

    @Value("${bnpl.aps.invitetoapply.url}")
    private String apsInviteToApplyUrl;

    @Value("${bnpl.aps.invitetoapply.service.uri}")
    private String apsInviteToApplyServiceUri;

    @Autowired
    private RequestContext requestContext;

    public Map<String, String> prepareQueryParameter() {
        Map<String, String> params = new HashMap<>();
        params.put(GRANT_TYPE, grantType);
        params.put(CLIENT_ID, clientId);
        params.put(CLIENT_SECRET, clientSecret);
        params.put(USERNAME, username);
        params.put(PASSWORD, password);
        return params;
    }

    public Map<String, String> inviteToApplyHeaders() {
        Map<String, String> headers = new HashMap<>();
        headers.put(CONTENT_TYPE, String.valueOf(ContentType.APPLICATION_JSON));
        headers.put(ACCEPT, String.valueOf(ContentType.APPLICATION_JSON));
        headers.put(ACCEPT_ENCODING, String.valueOf(ContentType.APPLICATION_JSON));
        headers.put(CLIENT_APPLICATION, USBWEB);
        headers.put(CORRELATION_ID,requestContext.getHttpHeaders().get(CORRELATION_ID.toLowerCase()));
        return headers;
    }

    public void handleSubsystemDataException(SubsystemDataException exception) {
        final String inviteToApplyUrl = apsInviteToApplyUrl + apsInviteToApplyServiceUri;
        HttpStatus httpCode = exception.getHttpStatus();
        if (HttpStatus.FAILED_DEPENDENCY.equals(httpCode)) {
            //We got 424 response.
            throw new SubsystemUnavailableException(inviteToApplyUrl, httpCode, exception.getResponseBody());
        } else if (HttpStatus.REQUEST_TIMEOUT.equals(httpCode)) {
            throw new SubsystemUnavailableException(inviteToApplyUrl,
                    HttpStatus.INTERNAL_SERVER_ERROR,
                    StringUtils.EMPTY);
        } else {
            throw new SubsystemDataException(inviteToApplyUrl,
                    httpCode,
                    exception.getResponseBody());
        }
    }

    public void handleSubsystemUnavailableException(SubsystemUnavailableException exception) {
        HttpStatus httpCode = exception.getHttpStatus();
        throw new SubsystemUnavailableException(apsInviteToApplyUrl + apsInviteToApplyServiceUri,
                httpCode,
                exception.getResponseBody());
    }

    public boolean validate(Date expirationDate) {
        SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
        Date date = new Date();
        int result = formatter.format(date).compareTo(String.valueOf(expirationDate));
        log.debug("current date={}"+formatter.format(date));
        log.debug("expriation date={}"+expirationDate);
        if ((result == 0)||(result < 0)) {
            log.debug("product is not expired");
            return true;
        }else {
            log.debug("product is exprired");
            return false;
        }
    }
}

