package com.usbank.poslp.merchant.details.handler;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.usbank.api.core.aspect.LogExecutionTime;
import com.usbank.api.core.component.requestcontext.IRequestContext;
import com.usbank.api.core.exception.SubsystemDataException;
import com.usbank.api.core.requesthandler.IRequestHandler;
import com.usbank.poslp.merchant.details.advice.MerchantExceptionHandler;
import com.usbank.poslp.merchant.details.model.request.ValidateMerchantDetails;
import com.usbank.poslp.merchant.details.model.response.ValidateMerchantResponse;
import com.usbank.poslp.merchant.details.service.MerchantDetailsService;
import com.usbank.poslp.merchant.details.service.ValidateMerchantDetailsService;
import com.usbank.poslp.merchant.details.utils.MerchantConfigurationUtils;
import com.usbank.poslp.merchant.details.validator.MerchantDetailsRequestValidator;
import com.usbank.poslp.merchant.details.validator.MerchantDetailsValidator;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import static com.usbank.poslp.merchant.details.constants.CustomErrorCodes.API_EXCEPTION;
import static com.usbank.poslp.merchant.details.constants.CustomErrorCodes.VALIDATE_API_EXCEPTION;
import static com.usbank.poslp.merchant.details.constants.MerchantDetailsConstants.MERCHANT_DETAIL_DOMAIN;

@Service
@Slf4j
public class MerchantDetailsValidationHandler implements IRequestHandler<ValidateMerchantDetails, ValidateMerchantResponse>{


	@Autowired
	private MerchantDetailsService merchantDetailsService;

	@Autowired
	MerchantDetailsRequestValidator merchantRequestValidator;

	@Autowired
	private MerchantExceptionHandler exceptionHandler;

	@Autowired
	ObjectMapper objectMapper;

	@Autowired
	private IRequestContext requestContext;

	@Autowired
	private MerchantConfigurationUtils merchantConfigurationUtils;

	@Autowired
	private ValidateMerchantDetailsService validateMerchantDetailsService;

	@Autowired
	private MerchantDetailsValidator merchantDetailsValidator;

	@LogExecutionTime
	public ValidateMerchantResponse handle(ValidateMerchantDetails request) throws Exception {
		log.debug("MerchantDetailsHandler call started: ");
		log.debug("MerchantDetails Request: "+request);
		log.debug("ValidateMerchantDetailsHandler call started.");
		ValidateMerchantResponse validateMerchantResponse;


		try {
			/** First validate the inputs. */
			merchantDetailsValidator.validate(request);

			/** Call the SRS Api and find whether the merchant is valid or not. */
			validateMerchantResponse = validateMerchantDetailsService.process(request);

			/** If the merchant is not valid then throw the exception*/
			if(!validateMerchantResponse.isMerchantValid()) {
				log.error(API_EXCEPTION.getErrorDescription());
				throw new SubsystemDataException(VALIDATE_API_EXCEPTION.getErrorCode(), VALIDATE_API_EXCEPTION.getErrorDescription(), MERCHANT_DETAIL_DOMAIN);
			}

			/** Process the response */

		}catch (Exception ex) {
			log.error("Exception occurred in ValidateMerchantDetailsHandler and cause is {}", ex.getLocalizedMessage());
			throw exceptionHandler.commonAPIException(ex);
		}

		return validateMerchantResponse;
	}

}
