package com.usbank.poslp.merchant.details.model.request;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.apache.commons.lang3.StringUtils;

/**
 * Used for the validateMerchant input type.
 * All the variables are declared in Snake case to make it sync with
 * the input parameters which are in Snake case.
 */

@Data
@NoArgsConstructor
@AllArgsConstructor
public class ValidateMerchantDetails {

    @JsonProperty("AccountMid")
    private String AccountMid;

    @JsonProperty("ApiSource")
    private String ApiSource;

    @JsonProperty("ContactFirstName")
    private String ContactFirstName;

    @JsonProperty("ContactLastName")
    private String ContactLastName;

    @JsonProperty("DDANumber")
    private String DDANumber;

    @JsonProperty("ProcessingCenterID")
    private String ProcessingCenterID;

    @JsonProperty("SSNorTaxId")
    private String SSNorTaxId;

    @JsonProperty("token")
    private String token;

    @JsonProperty("ApplicantEmail")
    private String ApplicantEmail = StringUtils.EMPTY;

}
