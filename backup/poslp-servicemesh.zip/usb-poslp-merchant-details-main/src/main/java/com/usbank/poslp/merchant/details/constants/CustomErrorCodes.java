package com.usbank.poslp.merchant.details.constants;

import jakarta.annotation.PostConstruct;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import static com.usbank.poslp.merchant.details.constants.APIErrorCode.*;

public enum CustomErrorCodes {

	DEPOSIT_ACCOUNT_PROVIDER_INTERNAL_ERROR("500.%s.50000", "Internal server error, unable to process request"),
	DEPOSIT_ACCOUNT_PROVIDER_NO_RESPONSE("500.%s.60020", "Internal Server error"),
	DEPOSIT_ACCOUNT_PROVIDER_TIMEOUT("500.%s.60040", "Internal Server error "),
	CIRCUIT_BREAKER_OPEN("500.%s.62000", "Internal Server error"),
	UNAUTHORIZED_ERROR("401.%s.2303", "Unauthorized to use the service"),
	INTERNAL_ERROR("500.%s.40003", "Internal System Error Occured"),
	BAD_REQUEST_ERROR("400.%s.40004", "Request cannot be processed due to Invalid Request"),
	METHOD_NOT_SUPPORTED_ERROR("405.%s.2306", "The Requested Url does not supports this Http Method"),
	CACHE_MISS_ERROR("500.%s.50001","Internal server error, unable to map input request"),
	
	INVALID_REQUEST("400.%s.41000", "The request cannot be fulfilled due to bad syntax or an invalid parameter"),
	INVALID_HEADER("400.%s.41000", "The request cannot be fulfilled due to bad syntax or an invalid header parameter"),
	BAD_HEADER_CORRELATION("400.%s.42040", "Correlation-ID header is mandatory"),
	//BAD_HEADER_CLIENTDATA("400.%s.42020", "ClientData header is mandatory"),
	BAD_HEADER_CONTENT("400.%s.42010", "Content-Type header is mandatory"),
	BAD_HEADER_APPLICATION("400.%s.42030", "Application-ID header is mandatory"),
	BAD_HEADER_SESSION("400.%s.42050", "Session-ID header is mandatory"),
	BAD_HEADER_CHANNEL("400.%s.42020", "Channel-ID header is mandatory"),
	INVALID_IDENTIFIER_TYPE("400.%s.41010", "Identifier Type is mandatory"),
	INVALID_ACCOUNT_TOKEN("400.%s.41020", "Account Token cannot be empty"),
	INVALID_ACCOUNT_NUMBER("400.%s.41030", "Account Number is mandatory"),
	INVALID_PRODUCT_CODE("400.%s.41040", "Product Code is mandatory"),
	INVALID_COMPANYID("400.%s.41050", "Company ID is mandatory"),
	INVALID_IDENTIFIERS("400.%s.41000", "Account Identifiers cannot be empty"),
	INVALID_IDENTIFIER("400.%s.41000", "Account Identifier cannot be empty"),
	INVALID_TOKENS("400.%s.41000", "Account Tokens cannot be empty"),
	INVALID_LIMIT("400.%s.41060", "Requests size exceeds allowed limit"),
	
	INVALID_LPID_IDENTIFIER("400.%s.41100", "Identifier is mandatory"),
	INVALID_FILTER("400.%s.41101", "Filter is mandatory"),
	INVALID_VIEW_TYPE("400.%s.41102", "View Type is mandatory"),
	INVALID_EXCLUDE_ACCOUNT_FLAG("400.%s.41103", "Exclude account flag is invalid"),
	INVALID_CHANNEL("400.%s.41104", "Channel invalid"),
	INVALID_AVAILABLE_BALANCE_FLAG("400.%s.41105", "Exclude Available balance flag is invalid"),
	INVALID_NAME_SPLIT_INDICATOR("400.%s.41106", "Name spplit indicator is invalid"),
	
	INVALID_MERCHANT_INPUT("400.%s.41010", "Merchant input is empty"),
	NO_MERCHANT_FOUND("500.45382.51110", "Invalid Merchant"),
	MERCHANT_ID_EXPIRED("500.45382.51120", "Merchant is INACTIVE"),
	MERCHANT_ID_MISSING(BAD_INPUT_PARAM+"10", "MerchantId is mandatory"),
	VALIDATE_MERCHANT_DETAILS_ERROR(BAD_INPUT_PARAM+"11", "Error in validating Merchant details input."),
	SRS_API_EXCEPTION(SYSTEM_ERROR+"1", "Internal Server Error occurred"),
	API_EXCEPTION(SYSTEM_ERROR+"2", "Api internal Server Error."),
	VALIDATE_API_EXCEPTION(BAD_INPUT_PARAM+"12", "Api Input errors."),
	SUBSYSTEM_DATA_EXCEPTION("500.%s.50010", "Subsystem Data unavailable"),
	MERCHANT_VALIDATION_FAILED("400.%s.41155", "Invalid merchant"),
	PARTNER_VALIDATION_EXPIRED("400.%s.41157", "Partner Expired"),
	PARTNER_MID_VALIDATION_FAILED("400.%s.41158", "Merchant is not enrolled for this service or MerchantID does not belongs to Partner"),
	SUBSYSTEM_UNAVAILABLE("500.%s.50020", "Subsystem unavailable"),
	BAD_HEADER_PARTNER_ID("400.%s.42060", "Partner-ID header is mandatory"),
	BAD_HEADER_MERCHANT_ID("400.%s.41110", "Merchant-ID header is mandatory"),
	PARTNER_VALIDATION_FAILED("400.%s.41156", "Invalid Partner"),
	INTERNAL_SERVER_ERROR("500.%s.50000", "Oops, Something went wrong!"),
	DB_CONNECTION_ERROR("500.%s.4004", "Database connectivity issue"),

	CLIENT_APPLICATION_INVALID("400.%s.41143", "Client Application is invalid or out of range"),
	BAD_HEADER_AUTHORIZATION("400.%s.42070", "Authorization header is mandatory"),
	;





	/**
	 * @param errorCode
	 * @param errorDescription
	 */
	private CustomErrorCodes(String errorCode, String errorDescription) {
		setErrorCode(errorCode);
		this.errorDescription = errorDescription;
	}

	private String errorCode;
	private String errorDescription;
	private String statusCode;

	/**
	 * @return the errorCode
	 */
	public String getErrorCode() {
		return errorCode;
	}

	public String getStatusCode() {
		return statusCode;
	}

	/**
	 * @return the errorDescription
	 */
	public String getErrorDescription() {
		return errorDescription;
	}

	protected void setErrorCode(String errorCode) {
		this.errorCode = errorCode;
	}

	/**
	 * The Class ErrorCodeInjector.
	 */
	@Component
	public static class ErrorCodeInjector {

		/** The apigee code. code specific for API */
		@Value("${accountdetails.apigee.code:45382}")
		private String apigeeCode;

		/**
		 * Post construct. Injects the common API based code in to enum
		 */
		@PostConstruct
		public void postConstruct() {
			for (CustomErrorCodes errorCode : CustomErrorCodes.values()) {
				errorCode.setErrorCode(String.format(errorCode.getErrorCode(), apigeeCode));
			}
		}
	}
}
