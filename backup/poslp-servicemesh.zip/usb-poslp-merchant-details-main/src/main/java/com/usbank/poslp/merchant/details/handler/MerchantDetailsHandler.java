package com.usbank.poslp.merchant.details.handler;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.usbank.api.core.aspect.LogExecutionTime;
import com.usbank.api.core.component.requestcontext.IRequestContext;
import com.usbank.api.core.constant.USBConstants;
import com.usbank.api.core.requesthandler.IRequestHandler;
import com.usbank.poslp.merchant.details.advice.MerchantExceptionHandler;
import com.usbank.poslp.merchant.details.constants.MerchantDetailsConstants;
import com.usbank.poslp.merchant.details.model.request.MerchantDetailsInput;
import com.usbank.poslp.merchant.details.model.response.MerchantDetails;
import com.usbank.poslp.merchant.details.service.MerchantDetailsService;
import com.usbank.poslp.merchant.details.utils.MerchantConfigurationUtils;
import com.usbank.poslp.merchant.details.validator.MerchantDetailsRequestValidator;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Objects;
import java.util.Optional;

@Service
@Slf4j
public class MerchantDetailsHandler implements IRequestHandler<MerchantDetailsInput, MerchantDetails>{


	@Autowired
	private MerchantDetailsService merchantDetailsService;

	@Autowired
	MerchantDetailsRequestValidator merchantRequestValidator;

	@Autowired
	private MerchantExceptionHandler exceptionHandler;

	@Autowired
	ObjectMapper objectMapper;

	@Autowired
	private IRequestContext requestContext;

	@Autowired
	private MerchantConfigurationUtils merchantConfigurationUtils;

	@Override
	@LogExecutionTime
	public MerchantDetails handle(MerchantDetailsInput request) throws Exception {
		log.debug("MerchantDetailsHandler call started: ");
		log.debug("MerchantDetails Request: "+request);
		Optional<MerchantDetailsInput> optionalMerchantDetailsInput = Optional.ofNullable(request);
		MerchantDetails merchantDetails=null;
		try
		{
			/**
			 * If request for Merchant Details comes from APIGEE,
			 * then get the MID from the Identifier in the request header
			 *
			 * Else
			 * Use the MID available in the request
			 */
			String clientId=requestContext.getHttpHeaders().get(USBConstants.CLIENT_ID.toLowerCase());
			if(optionalMerchantDetailsInput.isPresent() && (Objects.nonNull(clientId) && clientId.equalsIgnoreCase(MerchantDetailsConstants.APIGEE))) {
				//Only when MID is available in Identifier in Request Header, override the Request. Else do not overwrite the request.
				String midFromHeader = merchantRequestValidator.getIdentifier();
				if(Objects.nonNull(midFromHeader) && StringUtils.isNotEmpty(midFromHeader)){
					request = new MerchantDetailsInput();
					request.setMerchantID(midFromHeader);
				}
				merchantRequestValidator.validate(request);
			} else {
                merchantRequestValidator.validate(request);
			}

			/**
			 * If Partner-ID is available in Header, perform Partner-ID to MID validation
			 */
			if(Objects.nonNull(requestContext.getHttpHeaders().get(USBConstants.PARTNER_ID.toLowerCase())) && Objects.nonNull(request)) {
				merchantConfigurationUtils.validatePartnerAndMerchantID(requestContext.getHttpHeaders().get(USBConstants.PARTNER_ID.toLowerCase()), request.getMerchantID());
			}

			merchantDetails = merchantDetailsService.process(request);
			log.debug("MerchantDetails response: "+ merchantDetails);
		}catch (Exception ex) {
			log.error("[ERROR] --> Merchant details Request Handler :{}", ex);
			throw exceptionHandler.commonAPIException(ex);
		}
		return merchantDetails;
	}

}
