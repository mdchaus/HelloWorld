package com.usbank.poslp.merchant.details.model.response;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.util.Date;
import java.util.UUID;

@Data
@JsonIgnoreProperties
public class ShoppingCartResponse {

    @ApiModelProperty(value = "applicationGUID.  Unique Id created")
    @JsonProperty("applicationGUID")
    private UUID applicationGUID;

    @JsonProperty("merchantID")
    private String merchantID;

    @JsonProperty("invoiceID")
    private String invoiceID;

    @JsonProperty("invoiceAmount")
    private Double invoiceAmount;

    @ApiModelProperty(value = "partner Return Success URL")
    @JsonProperty("partnerReturnSuccessURL")
    private String partnerReturnSuccessURL;

    @ApiModelProperty(value = "partner Return Error URL")
    @JsonProperty("partnerReturnErrorURL")
    private String partnerReturnErrorURL;

    @ApiModelProperty(value = "Currency Type")
    @JsonProperty("currency Type")
    private String currencyType;

    @ApiModelProperty(value = "partner Return Error URL")
    @JsonProperty("partnerSessionID")
    private String partnerSessionID;

    @ApiModelProperty(value = "Merchant Transaction ID")
    @JsonProperty("merchantTransactionID")
    private String merchantTransactionID;

    @ApiModelProperty(value = "purchase Desc")
    @JsonProperty("purchaseDesc")
    private String purchaseDesc;

    @ApiModelProperty(value = "Terminal ID")
    @JsonProperty("terminalID")
    private String terminalID;

    @ApiModelProperty(value = "client Application")
    @JsonProperty("clientApplication")
    private String clientApplication;

    @ApiModelProperty(value = "cart Origination Channel")
    @JsonProperty("cartOriginationChannel")
    private String cartOriginationChannel;

    @ApiModelProperty(value = "Consumer IP Address")
    @JsonProperty("consumer IP Address")
    private String consumerIPAddress;

    @ApiModelProperty(value = "consumer Language")
    @JsonProperty("consumerLanguage")
    private String consumerLanguage;

    @ApiModelProperty(value = "consumer Email")
    @JsonProperty("consumerEmail")
    private String consumerEmail;


    @ApiModelProperty(value = "first Name")
    @JsonProperty("firstName")
    private String firstName;

    @ApiModelProperty(value = "middle Name")
    @JsonProperty("middleName")
    private String middleName;

    @ApiModelProperty(value = "Last Name")
    @JsonProperty("lastName")
    private String lastName;

    @ApiModelProperty(value = "mobile Phone")
    @JsonProperty("mobilePhone")
    private String mobilePhone;

    @ApiModelProperty(value = "Billing Street1")
    @JsonProperty("billingStreet1")
    private String billingStreet1;

    @ApiModelProperty(value = "Billing Street2")
    @JsonProperty("billingStreet2")
    private String billingStreet2;

    @ApiModelProperty(value = "Billing Street3")
    @JsonProperty("billingStreet3")
    private String billingStreet3;

    @ApiModelProperty(value = "Billing City")
    @JsonProperty("billingCity")
    private String billingCity;

    @ApiModelProperty(value = "Billing State")
    @JsonProperty("billingState")
    private String billingState;

    @ApiModelProperty(value = "billing Country Code")
    @JsonProperty("billingCountryCode")
    private String billingCountryCode;

    @ApiModelProperty(value = "billingPostalCode")
    @JsonProperty("billingPostalCode")
    private String billingPostalCode;

    @ApiModelProperty(value = "")
    @JsonProperty("effectiveDate")
    private Date effectiveDate;

    @ApiModelProperty(value = "")
    @JsonProperty("expirationDate")
    private Date expirationDate;

    @ApiModelProperty(value = "Last Modified User")
    @JsonProperty("lastModUser")
    private String lastModUser;

    @ApiModelProperty(value = "Last Modified Timestamp")
    @JsonProperty("lastModTMS")
    private String lastModTMS;

    private PartialError error;

}
