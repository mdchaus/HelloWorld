package com.usbank.poslp.merchant.details.model.response;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;
import org.apache.commons.lang3.StringUtils;

/**
 * SRS Api token response details.
 */
@Data
public class SRSApiToken {

    @JsonProperty("access_token")
    private String accessToken = StringUtils.EMPTY;

    @JsonProperty("instance_url")
    private String instanceUrl = StringUtils.EMPTY;

    @JsonProperty("id")
    private String id = StringUtils.EMPTY;

    @JsonProperty("token_type")
    private String tokenType = StringUtils.EMPTY;

    @JsonProperty("issued_at")
    private String issueAt = StringUtils.EMPTY;

    @JsonProperty("signature")
    private String signature = StringUtils.EMPTY;
}
