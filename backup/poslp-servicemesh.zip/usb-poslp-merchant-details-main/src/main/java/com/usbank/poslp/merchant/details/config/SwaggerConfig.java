package com.usbank.poslp.merchant.details.config;

import io.swagger.v3.oas.models.OpenAPI;
import io.swagger.v3.oas.models.info.Contact;
import io.swagger.v3.oas.models.info.Info;
import io.swagger.v3.oas.models.info.License;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class SwaggerConfig {
    @Value("${app.name}")
    private String appName;

    @Bean
    public OpenAPI usersMicroserviceOpenAPI() {
        return new OpenAPI()


                .info(new Info().title("Avvance Merchant Details API")
                        .description("Merchant Details")
                        .license(getLicense())
                        .contact(getContact())
                        .termsOfService("https://avvance.com/terms/")
                        .version("1.0.0"));

    }

    public License getLicense() {
        License license = new License();
        license.setName("US Bank / Avvance / Elavon - Internal");
        license.setUrl("http://www.usbank.com/");
        return license;

    }

    public Contact getContact() {
        Contact contact = new Contact();
        contact.setEmail("BNPL-PlatformTeam@usbank.com");
        return contact;

    }


}