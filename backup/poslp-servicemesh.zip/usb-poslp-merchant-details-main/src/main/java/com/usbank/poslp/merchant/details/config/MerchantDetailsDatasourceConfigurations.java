package com.usbank.poslp.merchant.details.config;

import com.zaxxer.hikari.HikariConfig;
import com.zaxxer.hikari.HikariDataSource;
import jakarta.persistence.EntityManagerFactory;
import lombok.Data;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.dao.annotation.PersistenceExceptionTranslationPostProcessor;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.orm.jpa.JpaTransactionManager;
import org.springframework.orm.jpa.LocalContainerEntityManagerFactoryBean;
import org.springframework.orm.jpa.vendor.Database;
import org.springframework.orm.jpa.vendor.HibernateJpaVendorAdapter;
import org.springframework.transaction.PlatformTransactionManager;

import javax.sql.DataSource;
import java.util.Properties;

@Data
@Configuration
@EnableJpaRepositories("com.usbank.poslp.merchant.details.repository")
public class MerchantDetailsDatasourceConfigurations {
	private final Logger logger = LoggerFactory.getLogger(this.getClass());

	@Value("${spring.datasource.url}")
	private String poslpDatabaseUrl;

	@Value("${spring.datasource.username}")
	private String poslpDBUserName;

	@Value("${spring.datasource.password}")
	private String poslpDBPassword;

	@Value("${spring.datasource.hikari.connectionTimeout}")
	private int connectionTimeout;

	@Value("${spring.datasource.hikari.idleTimeout}")
	private int idleTimeout;

	@Value("${spring.datasource.hikari.maxLifetime}")
	private int maxLifetime;

	@Value("${spring.datasource.hikari.minimumIdle}")
	private int minimumIdle;

	@Value("${spring.datasource.hikari.initializationFailTimeout}")
	private int initializationFailTimeout;

	@Value("${spring.datasource.hikari.maximumPoolSize}")
	private int maximumPoolSize;


    @Bean
    public LocalContainerEntityManagerFactoryBean entityManagerFactory() {
        HibernateJpaVendorAdapter vendorAdapter = new HibernateJpaVendorAdapter();
        vendorAdapter.setDatabase(Database.POSTGRESQL);
        LocalContainerEntityManagerFactoryBean em = new LocalContainerEntityManagerFactoryBean();
        em.setDataSource(dataSource());
        em.setPackagesToScan("com.usbank.poslp.commons.entities");
        em.setJpaVendorAdapter(vendorAdapter);
        em.setJpaProperties(additionalProperties());

        return em;
    }

    @Bean
    public DataSource dataSource() {
        HikariConfig hikariConfig = new HikariConfig();
        hikariConfig.setJdbcUrl(poslpDatabaseUrl);
        hikariConfig.setDriverClassName("org.postgresql.Driver");
        //Connection pooling details
        hikariConfig.setConnectionTestQuery("SELECT 1;");
        if (maximumPoolSize > 0) {
            hikariConfig.setMaximumPoolSize(maximumPoolSize);
        }
        hikariConfig.setConnectionTimeout(connectionTimeout);
        hikariConfig.setIdleTimeout(idleTimeout);
        hikariConfig.setMaxLifetime(maxLifetime);
        hikariConfig.setMinimumIdle(minimumIdle);
        hikariConfig.setInitializationFailTimeout(initializationFailTimeout);
        hikariConfig.getDataSourceProperties().put("user", poslpDBUserName);
        hikariConfig.getDataSourceProperties().put("password", poslpDBPassword);
        HikariDataSource hds = new HikariDataSource(hikariConfig);
        return hds;
    }

    @Bean
    public PlatformTransactionManager transactionManager(EntityManagerFactory emf) {
        JpaTransactionManager transactionManager = new JpaTransactionManager();
        transactionManager.setEntityManagerFactory(emf);
        return transactionManager;
    }

    @Bean
    public PersistenceExceptionTranslationPostProcessor exceptionTranslation() {
        return new PersistenceExceptionTranslationPostProcessor();
    }

    private Properties additionalProperties() {
        Properties properties = new Properties();
        properties.setProperty("spring.datasource.hikari.connectionTimeout",String.valueOf(connectionTimeout));
        properties.setProperty("spring.datasource.hikari.idleTimeout",String.valueOf(idleTimeout));
        properties.setProperty("spring.datasource.hikari.maxLifetime",String.valueOf(maxLifetime));
        properties.setProperty("spring.datasource.hikari.minimumIdle",String.valueOf(minimumIdle));
        properties.setProperty("spring.datasource.hikari.initializationFailTimeout",String.valueOf(initializationFailTimeout));
        properties.setProperty("spring.datasource.hikari.maximumPoolSize",String.valueOf(maximumPoolSize));
        return properties;
    }
}