package com.usbank.poslp.merchant.details.service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.usbank.api.core.aspect.LogExecutionTime;
import com.usbank.api.core.exception.PoslpAPIException;
import com.usbank.api.core.exception.SubsystemDataException;
import com.usbank.api.core.exception.SubsystemUnavailableException;
import com.usbank.api.core.model.BaseResponse;
import com.usbank.api.core.modelservice.IModelService;
import com.usbank.poslp.commons.entities.*;
import com.usbank.poslp.merchant.details.advice.MerchantExceptionHandler;
import com.usbank.poslp.merchant.details.constants.CustomErrorCodes;
import com.usbank.poslp.merchant.details.model.request.MerchantDetailsInput;
import com.usbank.poslp.merchant.details.model.response.FeatureConfigurationResponse;
import com.usbank.poslp.merchant.details.model.response.MerchantDetails;
import com.usbank.poslp.merchant.details.repository.FeatureConfigurationRepository;
import com.usbank.poslp.merchant.details.repository.MerchantDetailsRepository;
import io.github.resilience4j.circuitbreaker.annotation.CircuitBreaker;
import org.hibernate.exception.JDBCConnectionException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessResourceFailureException;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.CannotCreateTransactionException;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.Optional;

@Service
@Transactional
public class MerchantDetailsFeatureService implements IModelService<MerchantDetailsInput, List<FeatureConfigurationResponse>> {

    private static final Logger log = LoggerFactory.getLogger(MerchantDetailsFeatureService.class);
    @Autowired
    private MerchantDetailsRepository merchantRepository;

    @Autowired
    private ObjectMapper mapper;

    @Autowired
    private MerchantExceptionHandler exceptionHandler;

    @Autowired
    FeatureConfigurationRepository featureConfigurationRepository;

    public static final String CIRCUIT_BREAKER_NAME = "merchantDetailsProviderDB";

    @Override
    @CircuitBreaker(name = CIRCUIT_BREAKER_NAME)
    @LogExecutionTime
    public List<FeatureConfigurationResponse> process(MerchantDetailsInput request) throws Exception
    {
        log.debug("MerchantDetailsFeatureService call started");
        List<FeatureConfiguration> featureConfigurationList=new ArrayList<>();
        List<FeatureConfigurationResponse> featureConfigurationResponseList = new ArrayList<>();

        try {
            log.info("[TRACE] - Get Merchant Feature Details for merchantID - {} from DB", request.getMerchantID());
            if (null != request.getMerchantID()) {

                featureConfigurationList = featureConfigurationRepository.findByFeatureConfig(request.getMerchantID());
                log.debug("Feature Conf List : "+ featureConfigurationList);
                featureConfigurationList.stream().forEach(e ->
                        featureConfigurationResponseList.add(FeatureConfigurationResponse.ofEntity(e))
                );
                log.info("[TRACE] - featureConfigurationResponseList - {} from DB", featureConfigurationResponseList);
            } else {
                log.error("[EXCEPTION] --> Merchant details NOT available for merchantID - " + request.getMerchantID());
                throw new PoslpAPIException(CustomErrorCodes.NO_MERCHANT_FOUND.getErrorCode(), CustomErrorCodes.NO_MERCHANT_FOUND.getErrorDescription());
            }
        }catch(JDBCConnectionException | DataAccessResourceFailureException | CannotCreateTransactionException ex){
            throw new SubsystemUnavailableException(CustomErrorCodes.DB_CONNECTION_ERROR.getErrorCode(), CustomErrorCodes.DB_CONNECTION_ERROR.getErrorDescription(), ex.getMessage());
        }
        catch(Exception ex){
            log.error("[EXCEPTION] --> Exception : {}",ex);
            exceptionHandler.commonAPIException(ex);
        }

        log.debug("MerchantDetailsFeatureService response: "+ featureConfigurationResponseList);
        return featureConfigurationResponseList;
    }

}