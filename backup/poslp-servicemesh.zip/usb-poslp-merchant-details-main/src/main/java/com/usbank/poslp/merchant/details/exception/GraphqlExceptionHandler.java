package com.usbank.poslp.merchant.details.exception;

import com.usbank.api.core.exception.BadRequestException;
import com.usbank.api.core.exception.PoslpAPIException;
import com.usbank.api.core.exception.SubsystemDataException;
import com.usbank.api.core.exception.SubsystemUnavailableException;
import com.usbank.poslp.common.authorization.exception.AuthorizationException;
import com.usbank.poslp.graphql.core.exceptions.GraphQLAPIException;
import com.usbank.poslp.graphql.core.exceptions.GraphQLValidationException;
import com.usbank.poslp.merchant.details.config.MerchantDetailsApiConfig;
import com.usbank.poslp.merchant.details.constants.APIErrorCode;
import com.usbank.poslp.merchant.details.constants.CustomErrorCodes;
import com.usbank.poslp.merchant.details.constants.MerchantDetailsConstants;
import io.github.resilience4j.circuitbreaker.CallNotPermittedException;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.Objects;
import java.util.concurrent.CompletionException;
import java.util.concurrent.ExecutionException;

@Component
public class GraphqlExceptionHandler {

	private final Logger logger = LoggerFactory.getLogger(this.getClass());

	@Autowired
	private MerchantDetailsApiConfig config;

	public RuntimeException handleException(Throwable ex) {
		if (ex instanceof CompletionException || ex instanceof ExecutionException) {
			ex = ex.getCause();

		}
		if (ex instanceof PoslpAPIException) {
			logger.error(ex.getLocalizedMessage());
			PoslpAPIException e = (PoslpAPIException) ex;
			return buildGraphQLAPIException(e.getErrorCode(), e.getErrorMessage(), e.getErrorKey());
		} else if (ex instanceof BadRequestException) {
			logger.error(ex.getLocalizedMessage());
			BadRequestException e = (BadRequestException) ex;
			return buildGraphQLValidationException(e.getErrorCode(), e.getErrorMessage(), e.getErrorKey());
		} else if (ex instanceof ApiException) {
			logger.error(ex.getLocalizedMessage());
			ApiException e = (ApiException) ex;
			return buildGraphQLAPIException(e.getCode(), e.getDescription(), e.getAttribute());
		} else if (ex instanceof CallNotPermittedException) {
			logger.error(ex.getLocalizedMessage());
			return buildGraphQLAPIException(CustomErrorCodes.CIRCUIT_BREAKER_OPEN.getErrorCode(),
					CustomErrorCodes.CIRCUIT_BREAKER_OPEN.getErrorDescription(),
					((CallNotPermittedException) ex).getCausingCircuitBreakerName());
		} else if (ex instanceof AuthorizationException) {
			logger.error(ex.getLocalizedMessage());
			AuthorizationException e = (AuthorizationException) ex;
			return buildGraphQLAPIException(CustomErrorCodes.UNAUTHORIZED_ERROR.getErrorCode(), e.getMessage(),
					MerchantDetailsConstants.MERCHANT_DETAIL_DOMAIN);
		} else if (ex instanceof GraphQLValidationException) {
			logger.error(ex.getLocalizedMessage());
			return (GraphQLValidationException) ex;
		} else if (ex instanceof SubsystemDataException) {
			logger.error(ex.getLocalizedMessage());
			SubsystemDataException e = (SubsystemDataException) ex;
			String message = e.getUrl() +APIErrorCode.ERROR_CODE+ e.getHostResultCode() +APIErrorCode.ERROR_MESSAGE
					+ e.getHostResultDescription();
			return buildGraphQLAPIException(CustomErrorCodes.SUBSYSTEM_DATA_EXCEPTION.getErrorCode(), message,
					MerchantDetailsConstants.MERCHANT_DETAIL_DOMAIN);
		} else if (ex instanceof SubsystemUnavailableException) {
			logger.error(ex.getLocalizedMessage());
			SubsystemUnavailableException e = (SubsystemUnavailableException) ex;
			String message = e.getUrl() + APIErrorCode.ERROR_CODE + e.getHttpStatus();
			return buildGraphQLAPIException(CustomErrorCodes.SUBSYSTEM_UNAVAILABLE.getErrorCode(), message,
					MerchantDetailsConstants.MERCHANT_DETAIL_DOMAIN);
		} else {
			logger.error(ex.getMessage());
			return buildGraphQLAPIException(CustomErrorCodes.INTERNAL_ERROR.getErrorCode(),
					CustomErrorCodes.INTERNAL_ERROR.getErrorDescription(),
					MerchantDetailsConstants.MERCHANT_DETAIL_DOMAIN);
		}
	}

	private RuntimeException buildGraphQLAPIException(String errorCode, String errorMessage, String attribute) {
		errorCode = Objects.isNull(errorCode) ? StringUtils.EMPTY : errorCode;
		errorMessage = Objects.isNull(errorMessage) ? StringUtils.EMPTY : errorMessage;
		attribute = Objects.isNull(attribute) ? StringUtils.EMPTY : attribute;
		return new GraphQLAPIException(errorCode, errorMessage, attribute, config.getApiId());
	}

	private RuntimeException buildGraphQLValidationException(String errorCode, String errorMessage, String attribute) {
		errorCode = Objects.isNull(errorCode) ? StringUtils.EMPTY : errorCode;
		errorMessage = Objects.isNull(errorMessage) ? StringUtils.EMPTY : errorMessage.trim();
		attribute = Objects.isNull(attribute) ? StringUtils.EMPTY : attribute;
		return new GraphQLValidationException(errorCode, errorMessage, attribute, config.getApiId());
	}

}
