package com.usbank.poslp.merchant.details.scalars;

import com.netflix.graphql.dgs.DgsScalar;
import graphql.language.StringValue;
import graphql.schema.Coercing;
import graphql.schema.CoercingParseLiteralException;
import graphql.schema.CoercingParseValueException;
import graphql.schema.CoercingSerializeException;

import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;

/**
 * graphql-java provides optional com.usbank.dss.servicing.account.details.scalars in the graphql-java-extended-com.usbank.dss.servicing.account.details.scalars
 * library. We can wire a scalar from this library by adding the scalar to the
 * RuntimeWiring.
 */
@DgsScalar(name = "LocalDate")
public class LocalDateScalar implements Coercing<java.time.LocalDate, String> {

	private DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");

	@Override
	public String serialize(Object o) throws CoercingSerializeException {
		if (o instanceof java.time.LocalDate) {
			return ((java.time.LocalDate) o).format(formatter);
		} else {
			throw new CoercingSerializeException("Not a valid Date");
		}
	}

	@Override
	public java.time.LocalDate parseValue(Object input) throws CoercingParseValueException, DateTimeParseException {
		return java.time.LocalDate.parse(input.toString(), formatter);
	}

	@Override
	public java.time.LocalDate parseLiteral(Object input) throws CoercingParseLiteralException {
		if (input instanceof StringValue) {
			return java.time.LocalDate.parse(((StringValue) input).getValue(), formatter);
		} else {
			throw new CoercingSerializeException("Not a valid DateTime");
		}
	}

}
