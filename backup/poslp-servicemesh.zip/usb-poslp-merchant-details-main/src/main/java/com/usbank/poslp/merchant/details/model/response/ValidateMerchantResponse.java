package com.usbank.poslp.merchant.details.model.response;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;
import org.apache.commons.lang3.StringUtils;

@Data
public class ValidateMerchantResponse {

    @JsonProperty("merchantValid")
    private boolean merchantValid = false;

    @JsonProperty("token")
    private String token = StringUtils.EMPTY;

}
