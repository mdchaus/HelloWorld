package com.usbank.poslp.merchant.details.model.response.apply;

import lombok.Data;

import java.util.List;

@Data
public class StepExecutionAttempts{
	private Object history;
	private List<AttemptsItem> attempts;
}