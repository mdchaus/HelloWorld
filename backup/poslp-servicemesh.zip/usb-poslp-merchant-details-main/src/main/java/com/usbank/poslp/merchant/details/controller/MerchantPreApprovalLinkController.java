package com.usbank.poslp.merchant.details.controller;

import com.usbank.api.core.controller.BaseController;
import com.usbank.api.core.model.BaseResponse;
import com.usbank.api.core.requesthandler.IRequestHandler;
import com.usbank.poslp.merchant.details.model.request.MerchantPreApprovalLinkRequest;
import com.usbank.poslp.merchant.details.model.response.MerchantPreApprovalLinkResponse;
import io.swagger.annotations.Api;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;


@RestController
@Slf4j
@Validated
@Api(value = "Merchant pre-approval link controller")
@javax.annotation.Generated(value = "io.swagger.codegen.languages.SpringCodegen")

@RequestMapping("/v1")
public class MerchantPreApprovalLinkController extends BaseController {
    @Autowired
    private IRequestHandler<MerchantPreApprovalLinkRequest, MerchantPreApprovalLinkResponse> merchantTransactionResponseIRequestHandler;

    @GetMapping(value = "/preApproval/link")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Successful operation", content = {@Content(mediaType = "application/json", schema = @Schema(implementation = MerchantPreApprovalLinkResponse.class))}),
            @ApiResponse(responseCode = "400", description = "Invalid Request", content = {@Content(mediaType = "application/json", schema = @Schema(implementation = BaseResponse.class))}),
            @ApiResponse(responseCode = "401", description = "Authentication Failure", content = {@Content(mediaType = "application/json", schema = @Schema(implementation = String.class))}),
            @ApiResponse(responseCode = "405", description = "Method not allowed", content = {@Content(mediaType = "application/json", schema = @Schema(implementation = BaseResponse.class))}),
            @ApiResponse(responseCode = "500", description = "Internal Server Error", content = {@Content(mediaType = "application/json", schema = @Schema(implementation = BaseResponse.class))})
    })

    @Operation(summary = "Pre Approval Link", description = "Pre Approval Link")
    public ResponseEntity<MerchantPreApprovalLinkResponse> preApprovalLink
            (@RequestHeader(value = "Channel-ID", required = true) String channelId,
             @RequestHeader(value = "Correlation-ID", required = true) String correlationId,
             @RequestHeader(value = "Application-ID", required = true) String applicationId,
             @RequestHeader(value = "Session-ID", required = true) String sessionId,
             @RequestHeader(value = "Authorization", required = true) String authorization,
             @RequestHeader(value = "Partner-ID", required = true) String partnerId,
             @RequestHeader(value = "Merchant-ID", required = true) String merchantId)
            throws Exception {
        MerchantPreApprovalLinkRequest request = new MerchantPreApprovalLinkRequest();
        request.setMerchantID(merchantId);
        request.setPartnerId(partnerId);
        MerchantPreApprovalLinkResponse response = merchantTransactionResponseIRequestHandler.handle(request);
        return ResponseEntity.ok(response);
    }
}

