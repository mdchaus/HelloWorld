package com.usbank.poslp.merchant.details.config;

import lombok.extern.slf4j.Slf4j;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.client.SimpleClientHttpRequestFactory;
import org.springframework.web.client.RestTemplate;
import java.net.InetSocketAddress;
import java.net.Proxy;

/**
 * Created a proxy rest template
 */
@Configuration
@Slf4j
public class MerchantDetailsTemplateConfig {

    @Value("${PROXY_HOST}")
    private String bnplWebProxy;

    @Value("${PROXY_PORT}")
    private String bnplProxyPort;

    @Bean(name = "POSLPRestTemplate")
    public RestTemplate restTemplate() {
        SimpleClientHttpRequestFactory simpleClientHttpRequestFactory = new SimpleClientHttpRequestFactory();
        InetSocketAddress address = new InetSocketAddress(bnplWebProxy, Integer.parseInt(bnplProxyPort));
        Proxy proxy = new Proxy(Proxy.Type.HTTP, address);
        simpleClientHttpRequestFactory.setProxy(proxy);
        log.info("POSLPRestTemplate created successfully.");
        return new RestTemplate(simpleClientHttpRequestFactory);
    }
}