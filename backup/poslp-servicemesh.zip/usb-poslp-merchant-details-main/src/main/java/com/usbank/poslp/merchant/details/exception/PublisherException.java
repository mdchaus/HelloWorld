package com.usbank.poslp.merchant.details.exception;

import com.usbank.poslp.merchant.details.constants.CustomErrorCodes;

public class PublisherException extends RuntimeException {

    private static final long serialVersionUID = -5017899898718555386L;

    private final String errorCode;
    private final String errorMessage;
    private final String statusCode;


    public PublisherException(String message) {
        super(message);
        this.errorMessage = message;
        this.errorCode = CustomErrorCodes.INTERNAL_SERVER_ERROR.getErrorCode();
        this.statusCode = CustomErrorCodes.INTERNAL_SERVER_ERROR.getStatusCode();
    }

    public PublisherException(Throwable ex, String message) {
        super(ex);
        this.errorMessage = message;
        this.errorCode = CustomErrorCodes.INTERNAL_SERVER_ERROR.getErrorCode();
        this.statusCode = CustomErrorCodes.INTERNAL_SERVER_ERROR.getStatusCode();
    }

    public String getErrorCode() {
        return errorCode;
    }

    public String getErrorMessage() {
        return errorMessage;
    }

    public String getStatusCode() {
        return statusCode;
    }
}
