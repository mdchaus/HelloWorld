package com.usbank.poslp.merchant.details.model.response;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

@Data
@JsonIgnoreProperties
public class ShoppingCart {

    @JsonProperty("merchantDetails")
    private MerchantDetails merchantDetails;

    @JsonProperty("merchantID")
    private String merchantID;



}
