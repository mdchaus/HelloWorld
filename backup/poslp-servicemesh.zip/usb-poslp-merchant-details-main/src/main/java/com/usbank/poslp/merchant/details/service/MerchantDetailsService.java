
package com.usbank.poslp.merchant.details.service;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.usbank.api.core.aspect.LogExecutionTime;
import com.usbank.api.core.component.requestcontext.IRequestContext;
import com.usbank.api.core.exception.PoslpAPIException;
import com.usbank.api.core.exception.SubsystemUnavailableException;
import com.usbank.api.core.modelservice.IModelService;
import com.usbank.poslp.commons.entities.Merchant;
import com.usbank.poslp.commons.entities.Partner;
import com.usbank.poslp.merchant.details.advice.MerchantExceptionHandler;
import com.usbank.poslp.merchant.details.constants.CustomErrorCodes;
import com.usbank.poslp.merchant.details.mapper.response.MerchantResponseMapper;
import com.usbank.poslp.merchant.details.model.request.MerchantDetailsInput;
import com.usbank.poslp.merchant.details.model.response.MerchantDetails;
import com.usbank.poslp.merchant.details.repository.MerchantDetailsRepository;
import com.usbank.poslp.merchant.details.repository.PartnerRepository;
import io.github.resilience4j.circuitbreaker.annotation.CircuitBreaker;
import org.hibernate.exception.JDBCConnectionException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessResourceFailureException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.CannotCreateTransactionException;
import org.springframework.transaction.annotation.Transactional;

import java.util.Optional;


@Service
@Transactional
public class MerchantDetailsService implements IModelService<MerchantDetailsInput, MerchantDetails>{

	private static final Logger log = LoggerFactory.getLogger(MerchantDetailsService.class);
	@Autowired private MerchantDetailsRepository merchantRepository;

	@Autowired
	private PartnerRepository partnerRepository;

	@Autowired
	private ObjectMapper mapper;
	@Autowired
	private MerchantResponseMapper merchantResponseMapper;
	@Autowired
	private MerchantExceptionHandler exceptionHandler;

	@Autowired
	IRequestContext requestContext;
	public static final String CIRCUIT_BREAKER_NAME = "merchantDetailsProviderDB";
	@Override
	@CircuitBreaker(name = CIRCUIT_BREAKER_NAME)
	@LogExecutionTime
	public MerchantDetails process(MerchantDetailsInput request) throws Exception
	{
        log.debug("MerchantDetailsService call started");
        MerchantDetails merchantDetails = null;


		try {
        	log.info("[TRACE] - Get details for merchantID - {} from DB", request.getMerchantID());
			Optional<Merchant> merchantDetail = merchantRepository.findById(request.getMerchantID());
			if (merchantDetail.isPresent()) {
				if (!merchantDetail.get().getBnplStatus().equalsIgnoreCase("ACTIVE")) {
					log.error("[EXCEPTION] --> Merchant is NOT Active. Status - {} " + merchantDetail.get().getBnplStatus());
					throw new PoslpAPIException(CustomErrorCodes.MERCHANT_ID_EXPIRED.getErrorCode(), CustomErrorCodes.MERCHANT_ID_EXPIRED.getErrorDescription());
				}
				merchantDetails = MerchantDetails.ofEntity(merchantDetail.get());
				Partner partner = partnerRepository.findByMerchantId(merchantDetails.getMerchantID());
				if (partner != null) {
						merchantDetails.setPartnerGuid(partner.getPartnerGuid().toString());
						merchantDetails.setPartnerId(partner.getPartnerId());
				}
			} else {
				log.error("[EXCEPTION] --> Merchant details NOT available for merchantID - " + request.getMerchantID());
				throw new PoslpAPIException(CustomErrorCodes.NO_MERCHANT_FOUND.getErrorCode(), CustomErrorCodes.NO_MERCHANT_FOUND.getErrorDescription());
			}
		}catch(JDBCConnectionException | DataAccessResourceFailureException | CannotCreateTransactionException ex){
			throw new SubsystemUnavailableException(CustomErrorCodes.DB_CONNECTION_ERROR.getErrorCode(), CustomErrorCodes.DB_CONNECTION_ERROR.getErrorDescription(), ex.getMessage());
		}catch(Exception ex){
            log.error("[EXCEPTION] --> Exception : {}",ex);
			exceptionHandler.commonAPIException(ex);
        }
        log.debug("MerchantDetailsService response: "+ merchantDetails);
        return merchantDetails;    
	}


}
