package com.usbank.poslp.merchant.details.model.request;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;
import lombok.Getter;
import lombok.Setter;

@Data
public class MerchantDetailsInput {
	@JsonProperty("merchantID")
	private String merchantID;

}

