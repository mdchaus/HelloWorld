package com.usbank.poslp.merchant.details.utils;

import com.usbank.api.core.exception.BadRequestException;
import com.usbank.poslp.commons.entities.MerchantPartnerConfiguration;
import com.usbank.poslp.commons.entities.Partner;
import com.usbank.poslp.merchant.details.constants.CustomErrorCodes;
import com.usbank.poslp.merchant.details.constants.MerchantDetailsConstants;
import com.usbank.poslp.merchant.details.repository.MerchantPartnerConfigurationRepository;
import com.usbank.poslp.merchant.details.repository.MerchantRepository;
import com.usbank.poslp.merchant.details.repository.PartnerRepository;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Objects;

@Service
public class MerchantConfigurationUtils {

    private static final Logger logger = LoggerFactory.getLogger(MerchantConfigurationUtils.class);

    @Autowired
    private MerchantPartnerConfigurationRepository merchantPartnerConfigurationRepository;

    @Autowired
    private PartnerRepository partnerRepository;

    @Autowired
    private MerchantRepository merchantRepository;

    public void validatePartnerAndMerchantID(String partnerID, String merchantID) {
        logger.info("Validating relation between Merchant ID: {} and PartnerId: {}", merchantID, partnerID);
        if (StringUtils.isNotEmpty(partnerID)) {
            Partner partner = partnerRepository.findByPartnerId(partnerID);
            if (partner != null) {
                validatePartnerId(partner);
                List<MerchantPartnerConfiguration> configurations = merchantPartnerConfigurationRepository.findByMerchantIdAndPartnerGuid(merchantID, partner.getPartnerGuid());
                if (configurations == null || configurations.isEmpty()) {
                    logger.info("Merchant {} is not enrolled for this service or MerchantID does not belong to Partner {}", merchantID, partner.getPartnerId());
                    throw new BadRequestException(CustomErrorCodes.PARTNER_MID_VALIDATION_FAILED.getErrorCode(),
                            CustomErrorCodes.PARTNER_MID_VALIDATION_FAILED.getErrorDescription(),
                            MerchantDetailsConstants.MERCHANT_DETAIL_DOMAIN);
                }
            } else {
                logger.info("Partner ID: {} is invalid", partnerID);
                throw new BadRequestException(CustomErrorCodes.PARTNER_VALIDATION_FAILED.getErrorCode(),
                        CustomErrorCodes.PARTNER_VALIDATION_FAILED.getErrorDescription(),
                        MerchantDetailsConstants.MERCHANT_DETAIL_DOMAIN);
            }
        }
    }

    public void validateMerchantId(String merchantID) {
        if (merchantRepository.findAll(merchantID) == null) {
            logger.info("Merchant ID : {} is invalid", merchantID);
            throw new BadRequestException(CustomErrorCodes.MERCHANT_VALIDATION_FAILED.getErrorCode(),
                    CustomErrorCodes.MERCHANT_VALIDATION_FAILED.getErrorDescription(),
                    MerchantDetailsConstants.MERCHANT_DETAIL_DOMAIN);
        }
    }

    private void validatePartnerId(Partner partner) {
        java.util.Date expirationDate = partner.getExpirationDate();
        logger.info("Partner Obtained with id [{}] and name [{}]", partner.getPartnerId(), partner.getPartnerName());
        logger.debug("expirationDate={}", expirationDate);
        if (Objects.nonNull(expirationDate) && new java.util.Date().compareTo(expirationDate) > 0) {
            throw new BadRequestException(CustomErrorCodes.PARTNER_VALIDATION_EXPIRED.getErrorCode(),
                    CustomErrorCodes.PARTNER_VALIDATION_EXPIRED.getErrorDescription(),
                    MerchantDetailsConstants.MERCHANT_DETAIL_DOMAIN);
        }
    }
}
