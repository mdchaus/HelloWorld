package com.usbank.poslp.merchant.details.constants;

import static com.usbank.poslp.merchant.details.constants.MerchantDetailsConstants.API_ID;

public class APIErrorCode {

	private APIErrorCode() {

	}

	private static final String BASE_400 = "400." + API_ID;
	private static final String BASE_401 = "401." + API_ID;
	private static final String BASE_422 = "422." + API_ID;
	private static final String BASE_404 = "404." + API_ID;
	private static final String BASE_500 = "500." + API_ID;
	public static final String UNAUTHORISED = BASE_401 + ".5999";
	public static final String BAD_INPUT_PARAM = BASE_400 + ".411";
	public static final String INVALID_HEADER_CUSTOM = BASE_400 + ".421";
	/**
	 * Client send bad request
	 */
	public static final String BAD_REQUEST = BASE_400 + ".4000";
	public static final String BAD_REQUEST_MSG = "Request cannot be processed due to Invalid Request";

	public static final String INVALID_HEADER = BASE_422 + ".4200";
	public static final String INVALID_HEADER_MSG = "Invalid Headers Provided";

	/**
	 * Error related to UID/SignOnID. E.g: Account not found. Bad format
	 */
	public static final String UID = BASE_404 + ".4100";

	public static final String FAN_API = BASE_404 + ".4700";
	public static final String FAN_API_MSG = "FANS Dependency failure: Unable to get response.";

	public static final String FAN_API_BAD_RESPONSE = BASE_400 + ".6800";
	public static final String FAN_API_BAD_RESPONSE_MSG = "Fan Api Returned Invalid Response";
	/**
	 * Circuit breaker is open
	 */
	public static final String CIRCUIT_BREAKER_OPEN = BASE_500 + ".5999";
	public static final String CIRCUIT_BREAKER_OPEN_MSG = "Circuit Breaker is open. Unable to make requests to backend.";

	/**
	 * Didn't receive Data Provider response
	 */
	public static final String PROVIDER_NO_RESPONSE = BASE_404 + ".4500";
	public static final String PROVIDER_NO_RESPONSE_MSG = "Did not receive response from DDA-Details Data Provider";

	/**
	 * Didn't receive Data Provider success response code 00
	 */
	public static final String PROVIDER_FAILED_RESPONSE = BASE_500 + ".5200";
	public static final String PROVIDER_FAILED_RESPONSE_MSG = "Unable to connect with provider and fetch response.";

	public static final String SYSTEM_ERROR = BASE_500 + ".9000";
	public static final String SYSTEM_ERROR_MSG = "Internal System Error Occured";

	public static final String METHOD_NOT_SUPPORTED_MSG = "The Requested Url does not supports this Http Method";
	public static final String METHOD_NOT_SUPPORTED = BASE_500 + ".5900";
	public static final String ERROR_CODE = " : Error Code : ";
	public static final String ERROR_MESSAGE = " : Error Message : ";

}
