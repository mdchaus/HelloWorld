package com.usbank.poslp.merchant.details.model.errorResponse;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

import java.util.List;

public class Error {


	@JsonInclude(Include.NON_NULL)
	private String code;

	@JsonInclude(Include.NON_NULL)
	private String message;

	private List<ErrorDetail> details;

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public List<ErrorDetail> getDetails() {
		return details;
	}

	public void setDetails(List<ErrorDetail> details) {
		this.details = details;
	}

}
