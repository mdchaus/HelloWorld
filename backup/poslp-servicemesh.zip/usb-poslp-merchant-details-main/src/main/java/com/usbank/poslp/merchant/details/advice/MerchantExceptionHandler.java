package com.usbank.poslp.merchant.details.advice;

import com.usbank.api.core.component.connector.ConnectorException;
import com.usbank.api.core.exception.BadRequestException;
import com.usbank.api.core.exception.PoslpAPIException;
import com.usbank.api.core.exception.SubsystemDataException;
import com.usbank.api.core.exception.SubsystemUnavailableException;
import com.usbank.poslp.merchant.details.constants.MerchantDetailsConstants;
import com.usbank.poslp.merchant.details.enums.ErrorCodes;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.CannotGetJdbcConnectionException;
import org.springframework.stereotype.Component;
import org.springframework.transaction.CannotCreateTransactionException;

import java.net.SocketTimeoutException;
import java.sql.SQLException;
import java.text.ParseException;

@Component
public class MerchantExceptionHandler {
    private final Logger log = LoggerFactory.getLogger(this.getClass());

    String code = null;
    String message = null;
    String key = null;

    public RuntimeException commonAPIException(Exception ex) {

        if (ex instanceof CannotCreateTransactionException) {

            code = ErrorCodes.DATABASE_EXCEPTION.getErrorCode();
            message = ex.getMessage();
            log.error("[EXCEPTION] --> Merchant Details API Database  Exception");
            throw new PoslpAPIException(code, message);
        }
        if (ex instanceof CannotGetJdbcConnectionException) {

            code = ErrorCodes.DATABASE_EXCEPTION.getErrorCode();
            message = ex.getMessage();
            log.error("[EXCEPTION] --> Merchant Details API Database  Exceptio");
            throw new PoslpAPIException(code, message);
        }
        if (ex instanceof SQLException) {

            code = ErrorCodes.DATABASE_EXCEPTION.getErrorCode();
            message = ex.getMessage();
            log.error("[EXCEPTION] --> Merchant Details API POSLP Subsystem Unavailable Exception");
            throw new PoslpAPIException(code, message);
        }
        if (ex instanceof PoslpAPIException) {
            code = ((PoslpAPIException) ex).getErrorCode();
            message = ((PoslpAPIException) ex).getMessage();
            log.error("[EXCEPTION] --> Merchant Details API POSLP Exception");
            throw new PoslpAPIException(code, message);
        }
        if (ex instanceof SubsystemDataException) {
            code = ErrorCodes.SUBSYSTEM_DATA_EXCEPTION.getErrorCode();
            message = ErrorCodes.SUBSYSTEM_DATA_EXCEPTION.getErrorDescription();
            log.error("[EXCEPTION] --> Merchant Details API POSLP Subsystem Data Unavailable Exception");
            throw new PoslpAPIException(code, message);
        }
        if (ex instanceof SubsystemUnavailableException) {
            code = ErrorCodes.SUBSYSTEM_UNAVAILABLE.getErrorCode();
            message = ErrorCodes.SUBSYSTEM_UNAVAILABLE.getErrorDescription();
            log.error("[EXCEPTION] --> Merchant Details API POSLP Subsystem Unavailable Exception");
            throw new PoslpAPIException(code, message);
        }
        if (ex instanceof SocketTimeoutException) {
            code = ErrorCodes.READ_TIMEOUT_ERROR.getErrorCode();
            message = ErrorCodes.READ_TIMEOUT_ERROR.getErrorDescription();
            log.error("[EXCEPTION] --> Merchant Details API POSLP Read Timeout Exception");
            throw new PoslpAPIException(code, message);
        }
        if (ex instanceof ConnectorException) {
            code = ErrorCodes.DOWN_STREAM_CONNECTION_FAILURE.getErrorCode();
            message = ((ConnectorException) ex).getMessage();
            log.error("[EXCEPTION] --> Merchant Details API POSLP Connection Exception");
            throw new PoslpAPIException(code, message);
        }
        if (ex instanceof BadRequestException) {
            code = ((BadRequestException) ex).getErrorCode();
            message = ((BadRequestException) ex).getErrorMessage();
            key = MerchantDetailsConstants.MERCHANT_DETAIL_DOMAIN;
            log.error("[EXCEPTION] --> Merchant Details API POSLP BadRequest Exception");
            throw new BadRequestException(code, message);
        }
        if (ex instanceof ParseException) {
            message = ((ParseException) ex).getMessage();
            log.error("[EXCEPTION] --> Merchant Details API POSLP ParseException Exception");
            throw new BadRequestException(code, message);
        }
        if (ex instanceof NullPointerException) {
            code = ErrorCodes.INTERNAL_SERVER_ERROR.getErrorCode();
            message = ErrorCodes.INTERNAL_SERVER_ERROR.getErrorDescription();
            log.error("[EXCEPTION] --> Merchant Details API POSLP Null Pointer Exception");
            throw new PoslpAPIException(code, message);
        }

        if (ex instanceof DataAccessException) {
            code = ErrorCodes.DATA_NOT_FOUND.getErrorCode();
            message = ErrorCodes.DATA_NOT_FOUND.getErrorDescription();
            log.error("[EXCEPTION] --> Merchant Details API POSLP Data Access Exception");
            throw new PoslpAPIException(code, message);
        }
        return null;
    }

}
