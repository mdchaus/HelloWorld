package com.usbank.poslp.merchant.details.model.response.apply;

import com.google.gson.annotations.SerializedName;
import lombok.Data;

@Data
public class ApplyInvitationServiceResponse {

	@SerializedName("result")
	private Result result;

	@SerializedName("applyUrl")
	private String applyUrl;

	@SerializedName("invitationId")
	private String invitationId;

	@SerializedName("status")
	private String status;
}