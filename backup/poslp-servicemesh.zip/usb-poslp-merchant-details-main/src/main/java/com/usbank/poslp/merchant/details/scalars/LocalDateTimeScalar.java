package com.usbank.poslp.merchant.details.scalars;

import com.netflix.graphql.dgs.DgsScalar;
import graphql.language.StringValue;
import graphql.schema.Coercing;
import graphql.schema.CoercingParseLiteralException;
import graphql.schema.CoercingParseValueException;
import graphql.schema.CoercingSerializeException;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

/**
 * graphql-java provides optional com.usbank.dss.servicing.account.details.scalars in the graphql-java-extended-com.usbank.dss.servicing.account.details.scalars
 * library. We can wire a scalar from this library by adding the scalar to the
 * RuntimeWiring.
 */
@DgsScalar(name = "LocalDateTime")
public class LocalDateTimeScalar implements Coercing<LocalDateTime, String> {
	
	private DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");

	@Override
	public String serialize(Object o) throws CoercingSerializeException {
		if (o instanceof LocalDateTime) {
			return ((LocalDateTime) o).format(formatter);
		} else {
			throw new CoercingSerializeException("Not a valid DateTime");
		}
	}

	@Override
	public LocalDateTime parseValue(Object input) throws CoercingParseValueException {
		return LocalDateTime.parse(input.toString(), formatter);
	}

	@Override
	public LocalDateTime parseLiteral(Object input) throws CoercingParseLiteralException {
		if (input instanceof StringValue) {
			return LocalDateTime.parse(((StringValue) input).getValue(), formatter);
		} else {
			throw new CoercingSerializeException("Not a valid DateTime");
		}
	}
}
