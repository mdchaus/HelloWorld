
package com.usbank.poslp.merchant.details.service;


import com.fasterxml.jackson.databind.ObjectMapper;
import com.usbank.api.core.aspect.LogExecutionTime;
import com.usbank.api.core.exception.PoslpAPIException;
import com.usbank.api.core.exception.SubsystemUnavailableException;
import com.usbank.api.core.modelservice.IModelService;
import com.usbank.poslp.commons.entities.Merchant;
import com.usbank.poslp.commons.entities.MerchantProduct;
import com.usbank.poslp.merchant.details.advice.MerchantExceptionHandler;
import com.usbank.poslp.merchant.details.constants.CustomErrorCodes;
import com.usbank.poslp.merchant.details.mapper.response.MerchantProductsResponseMapper;
import com.usbank.poslp.merchant.details.model.request.MerchantDetailsInput;
import com.usbank.poslp.merchant.details.model.request.MerchantProducts;
import com.usbank.poslp.merchant.details.repository.MerchantDetailsRepository;
import io.github.resilience4j.circuitbreaker.annotation.CircuitBreaker;
import org.hibernate.exception.JDBCConnectionException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessResourceFailureException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.CannotCreateTransactionException;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;


@Service
@Transactional
public class MerchantProductsService implements IModelService<MerchantDetailsInput, List<MerchantProducts>>{

	private static final Logger log = LoggerFactory.getLogger(MerchantProductsService.class);
	@Autowired
	private MerchantDetailsRepository merchantRepository;
	@Autowired
	private ObjectMapper mapper;

	@Autowired
	private MerchantProductsResponseMapper productsResponseMapper;

	@Autowired
	private MerchantExceptionHandler exceptionHandler;


	public static final String CIRCUIT_BREAKER_NAME = "merchantDetailsProviderDB";
	@Override
	@CircuitBreaker(name = CIRCUIT_BREAKER_NAME)
	@LogExecutionTime
	public List<MerchantProducts> process(MerchantDetailsInput request) throws Exception
	{
		log.debug("Merchant Products Service call started");
		List<MerchantProducts> merchantProductsList = new ArrayList<>();

		try {

			log.info("[TRACE] - Get Merchant Product Details for merchantID - {} from DB", request.getMerchantID());
			Optional<Merchant> merchantDetail = merchantRepository.findByIdWithProducts(request.getMerchantID());
			if (merchantDetail.isPresent()) {
				Merchant merchant = merchantDetail.get();
				if (!"ACTIVE".equalsIgnoreCase(merchant.getBnplStatus())) {
					log.error("[EXCEPTION] --> Merchant is NOT Active. Status - {}", merchant.getBnplStatus());
					throw new PoslpAPIException(CustomErrorCodes.MERCHANT_ID_EXPIRED.getErrorCode(), CustomErrorCodes.MERCHANT_ID_EXPIRED.getErrorDescription());
				}
				List<MerchantProduct> productList = merchant.getMerchantProducts();
				if(Optional.ofNullable(productList).isPresent())
				{
					log.info("[TRACE] -  Merchant Product Details size "+ productList.size());

				}

				merchantProductsList = productsResponseMapper.map(productList);
			} else {
				log.error("[EXCEPTION] --> Merchant details NOT available for merchantID - {}", request.getMerchantID());
				throw new PoslpAPIException(CustomErrorCodes.NO_MERCHANT_FOUND.getErrorCode(), CustomErrorCodes.NO_MERCHANT_FOUND.getErrorDescription());
			}
		} catch (JDBCConnectionException | DataAccessResourceFailureException | CannotCreateTransactionException ex) {
			throw new SubsystemUnavailableException(CustomErrorCodes.DB_CONNECTION_ERROR.getErrorCode(), CustomErrorCodes.DB_CONNECTION_ERROR.getErrorDescription(), ex.getMessage());
		} catch (Exception ex) {
			log.error("[EXCEPTION] --> Exception : {}", ex);
			exceptionHandler.commonAPIException(ex);
		}

		log.debug("Merchant Product List: {}", merchantProductsList);
		return merchantProductsList;
        }


	


}
