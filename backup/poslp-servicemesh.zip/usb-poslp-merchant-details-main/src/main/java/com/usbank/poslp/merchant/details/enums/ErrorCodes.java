package com.usbank.poslp.merchant.details.enums;

public enum ErrorCodes {
	 //Generic Error Codes
    BAD_REQUEST("400", "Bad Request"),
    BAD_HEADER_REQUEST("400", "The request cannot be completed due to bad syntax or an invalid header parameter"),
    
    //Application Error Codes
    MERCHANTID_MISSING("400", "MerchantId is mandatory"),
    INTERNAL_SERVER_ERROR("500", "Internal Server Error"),
    DOWN_STREAM_CONNECTION_FAILURE("500", "Downstream Error"),
    READ_TIMEOUT_ERROR("500", "Read Timeout Error"),
    SUBSYSTEM_DATA_EXCEPTION("500", "Subsystem Data unavailable"),
    DATABASE_EXCEPTION("500", "Database Data unavailable"),
    SUBSYSTEM_UNAVAILABLE("500", "Subsystem unavailable"),
    IDENTIFIER_MISSING("400", "identifier is mandatory"),
    FIRST_NAME_MISSING("400", "first name is mandatory"),
    LAST_NAME_MISSING("400", "first name is mandatory"),
    ZIP_CODE_MISSING("400", "zip code is mandatory"),
    EMAIL_ID_MISSING("400", "Email ID is mandatory"),
    PHONE_NUMBER_MISSING("400", "Phone Number is mandatory"),
    IDENTIFIER_TYPE_MISSING("400", "identifierType is mandatory"),
    CORRELATION_ID_MISSING("400", "Missing Header - Correlation-ID"),
    CONTENT_TYPE_MISSING("400", "Missing Header - Content-Type"),
    CHANNEL_ID_MISSING("400", "Missing Header - ChannelID"),
    APPLICATION_ID_MISSING("400", "Missing Header - application-id"),
    DELEGATE_VALIDATION_SUCCESS("200", "Delegate Validation Success"),
    DATA_NOT_FOUND("404", "Internal server error, no data found"),
    DELEGATE_VALIDATION_FAILED("401", "Delegate Validation Failed"),
    INVALID_SUB_PRODUCT_CODE("400", "Invalid Sub Product Code"),
    ACTION_MISSING("400", "Missing field - Action"),
    DELEGATE_IS_ADMIN("400", "Delegate User ID cannot be same as Logged in User ID"),
    DATA_INSERT_ERROR("500", "Error inserting data into table"),
    PROCEDURE_EXECUTE_ERROR("500", "Error occurred while executing stored procedure DB"),
    NO_EVENTHISTDATAFOUND("204", "No Activity Event History Found for Given CustomerID"),
    MANAGE_ENTITLEMENT_ENROLLED("400", "User Already Enrolled"),
    MANAGE_ENTITLEMENT_UNENROLLED("400", "User Already UnEnrolled"),
    MISSING_DELEGATE_UID("400", "Missing Delegate UID"),
    MISSING_OWNER_UID("400", "Missing Owner UID"),
    MISSING_EVENT_NAME("400", "Missing Event Name");

    /**
     * @param errorCode
     * @param errorDescription
     */
    private ErrorCodes(String errorCode, String errorDescription) {
        this.errorCode = errorCode;
        this.errorDescription = errorDescription;
    }

    private String errorCode;
    private String errorDescription;

    public String getErrorCode() {
        return errorCode;
    }

    public void setErrorCode(String errorCode) {
        this.errorCode = errorCode;
    }

    public String getErrorDescription() {
        return errorDescription;
    }

    public void setErrorDescription(String errorDescription) {
        this.errorDescription = errorDescription;
    }

}
