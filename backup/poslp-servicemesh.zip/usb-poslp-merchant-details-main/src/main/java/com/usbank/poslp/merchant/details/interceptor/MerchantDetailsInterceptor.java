package com.usbank.poslp.merchant.details.interceptor;

import com.usbank.api.core.constant.USBConstants;
import com.usbank.api.core.exception.BadRequestException;
import com.usbank.poslp.merchant.details.constants.CustomErrorCodes;
import com.usbank.poslp.merchant.details.constants.MerchantDetailsConstants;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Component;
import org.springframework.web.servlet.HandlerInterceptor;
import org.springframework.web.servlet.ModelAndView;

@Component
@Slf4j
public class MerchantDetailsInterceptor implements HandlerInterceptor {

    @Override
    public void afterCompletion(HttpServletRequest request, HttpServletResponse response, Object object, Exception arg3) throws Exception {
        //nothing or to no logic to implement in afterCompletion method
    }

    @Override
    public void postHandle(HttpServletRequest request, HttpServletResponse response, Object object, ModelAndView model) throws Exception {
        //nothing or to no logic to implement in postHandle method
    }

    @Override
    public boolean preHandle(HttpServletRequest request,
                             HttpServletResponse response, Object handler) throws Exception {

        log.info("MerchantDetailsInterceptor preHandle method is calling");

        if (StringUtils.isEmpty(request.getHeader(MerchantDetailsConstants.CONTENT_TYPE.toLowerCase()))) {
            throw new BadRequestException(CustomErrorCodes.BAD_HEADER_CONTENT.getErrorCode(),
                    CustomErrorCodes.BAD_HEADER_CONTENT.getErrorDescription(),
                    MerchantDetailsConstants.MERCHANT_DETAIL_DOMAIN, "Content-Type");
        }

        if (StringUtils.isEmpty(request.getHeader(USBConstants.CORRELATION_ID.toLowerCase()))) {
            throw new BadRequestException(CustomErrorCodes.BAD_HEADER_CORRELATION.getErrorCode(),
                    CustomErrorCodes.BAD_HEADER_CORRELATION.getErrorDescription(),
                    MerchantDetailsConstants.MERCHANT_DETAIL_DOMAIN, "Correlation-ID");
        }

        if (StringUtils.isEmpty(request.getHeader(USBConstants.CHANNEL_ID.toLowerCase()))) {
            throw new BadRequestException(CustomErrorCodes.BAD_HEADER_CHANNEL.getErrorCode(),
                    CustomErrorCodes.BAD_HEADER_CHANNEL.getErrorDescription(),
                    MerchantDetailsConstants.MERCHANT_DETAIL_DOMAIN, "Channel-ID");
        }

        if (StringUtils.isEmpty(request.getHeader(USBConstants.APPLICATION_ID.toLowerCase()))) {
            throw new BadRequestException(CustomErrorCodes.BAD_HEADER_APPLICATION.getErrorCode(),
                    CustomErrorCodes.BAD_HEADER_APPLICATION.getErrorDescription(),
                    MerchantDetailsConstants.MERCHANT_DETAIL_DOMAIN, "Application-ID");
        }
        if (request.getHeader(USBConstants.APPLICATION_ID.toLowerCase()).length() > MerchantDetailsConstants.APPLICATION_ID_HEADER_LENGTH_MAX) {
            throw new BadRequestException(CustomErrorCodes.CLIENT_APPLICATION_INVALID.getErrorCode(),
                    CustomErrorCodes.CLIENT_APPLICATION_INVALID.getErrorDescription(),
                    MerchantDetailsConstants.MERCHANT_DETAIL_DOMAIN, "Application-ID");
        }
        if (StringUtils.isEmpty(request.getHeader(USBConstants.SESSION_ID.toLowerCase()))) {
            throw new BadRequestException(CustomErrorCodes.BAD_HEADER_SESSION.getErrorCode(),
                    CustomErrorCodes.BAD_HEADER_SESSION.getErrorDescription(),
                    MerchantDetailsConstants.MERCHANT_DETAIL_DOMAIN, "Session-ID");
        }

        String authKey = request.getHeader(MerchantDetailsConstants.AUTHORIZATION.toLowerCase());

        if (StringUtils.isEmpty(authKey)) {
            throw new BadRequestException(CustomErrorCodes.BAD_HEADER_AUTHORIZATION.getErrorCode(),
                    CustomErrorCodes.BAD_HEADER_AUTHORIZATION.getErrorDescription(),
                    MerchantDetailsConstants.MERCHANT_DETAIL_DOMAIN,
                    MerchantDetailsConstants.AUTHORIZATION);
        }
        //PartnerID cannot be empty or null.
        if (StringUtils.isEmpty(request.getHeader(MerchantDetailsConstants.PARTNERID))) {
            throw new BadRequestException(CustomErrorCodes.BAD_HEADER_PARTNER_ID.getErrorCode(),
                    CustomErrorCodes.BAD_HEADER_PARTNER_ID.getErrorDescription(),
                    MerchantDetailsConstants.MERCHANT_DETAIL_DOMAIN, MerchantDetailsConstants.PARTNERID);
        }
        //MerchantId cannot be empty or null.
        if (StringUtils.isEmpty(request.getHeader(MerchantDetailsConstants.MERCHANT_ID_HEADER))) {
            throw new BadRequestException(CustomErrorCodes.BAD_HEADER_MERCHANT_ID.getErrorCode(),
                    CustomErrorCodes.BAD_HEADER_MERCHANT_ID.getErrorDescription(),
                    MerchantDetailsConstants.MERCHANT_DETAIL_DOMAIN, MerchantDetailsConstants.MERCHANT_ID_HEADER);
        }
        return true;
    }
}
