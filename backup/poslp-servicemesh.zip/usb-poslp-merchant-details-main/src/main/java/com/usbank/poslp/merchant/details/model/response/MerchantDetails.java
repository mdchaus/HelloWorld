package com.usbank.poslp.merchant.details.model.response;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.usbank.poslp.commons.entities.Merchant;
import com.usbank.poslp.merchant.details.model.request.MerchantProducts;
import io.swagger.annotations.ApiModelProperty;
import lombok.Builder;
import lombok.Data;

import java.time.Instant;
import java.time.LocalDateTime;
import java.util.Date;
import java.util.List;

@Data
@Builder
@JsonIgnoreProperties
public class MerchantDetails {

    @ApiModelProperty(value = "Mandatory.merchantID")
    @JsonProperty("merchantID")
    private String merchantID;

    @ApiModelProperty(value = "Merchant running bussiness under a fictitious name")
    @JsonProperty("merchantDBAName")
    private String merchantDBAName;

    @JsonProperty("merchantLegalName")
    private String merchantLegalName;

    @JsonProperty("merchantChargeAfterId")
    private String merchantChargeAfterId;

    @JsonProperty("bnplStatus")
    private String bnplStatus;

    @ApiModelProperty(value = "Terminal ID Number")
    @JsonProperty("tid")
    private String tid;

    @JsonProperty("accountStatus")
    private String accountStatus;

    @JsonProperty("businessTimeZoneID")
    private String businessTimeZoneID;

    @JsonProperty("businessCountryCode")
    private String businessCountryCode;

    @JsonProperty("businessEmail")
    private String businessEmail;

    @JsonProperty("businessAddress1")
    private String businessAddress1;

    @JsonProperty("businessAddress2")
    private String businessAddress2;

    @JsonProperty("languageCode")
    private String languageCode;

    @JsonProperty("webURL")
    private String webURL;

    @JsonProperty("principalOwnerName")
    private String principalOwnerName;

    @JsonProperty("principalOwnerEmail")
    private String principalOwnerEmail;

    @JsonProperty("businessTaxId")
    private String businessTaxId;

    @JsonProperty("clientGroup")
    private Integer clientGroup;

    @JsonProperty("midGroup")
    private String midGroup;

    @JsonProperty("parentChain")
    private String parentChain;


    @JsonProperty("openDate")
    private Date openDate;


    @JsonProperty("businessAddressLineOne")
    private String businessAddressLineOne;

    @JsonProperty("businessAddressLineTwo")
    private String businessAddressLineTwo;
    @JsonProperty("businessAddressLineThree")
    private String businessAddressLineThree;


    @ApiModelProperty(value = "Merchant Category Code")
    @JsonProperty("mccCode")
    private String mccCode;
     /*
    @ApiModelProperty(value = "Merchant Category Classification Code")
    @JsonProperty("mccClassCode")
    private String mccClassCode;

    @JsonProperty("extendedMCCCode")
    private String extendedMCCCode;

    @JsonProperty("signatoryName")
    private String signatoryName;

    @JsonProperty("signatoryEmail")
    private String signatoryEmail;

    @JsonProperty("percentOnlineSales")
    private BigDecimal percentOnlineSales;

    @JsonProperty("percentCardPresentSales")
    private BigDecimal percentCardPresentSales;

    @JsonProperty("percentMOTOSales")
    private BigDecimal percentMOTOSales;

  @ApiModelProperty(value = "Dynamic Currency Conversion enabled")
    @JsonProperty("dccEnabled")
    private String dccEnabled;
*/  @JsonProperty("fundingCurrencyCode")
    private String fundingCurrencyCode;


    @ApiModelProperty(value = "phoneNumber")
    @JsonProperty("phoneNumber")
    private String phoneNumber;

    @ApiModelProperty(value = "Last Modified User")
    @JsonProperty("lastModUser")
    private String lastModUser;

    @ApiModelProperty(value = "Last Modified Timestamp")
    @JsonProperty("lastModTMS")
    private LocalDateTime lastModTMS;

    @ApiModelProperty(value = "Created Timestamp")
    @JsonProperty("created_timestamp")
    private LocalDateTime createdTimestamp;

    @JsonProperty("hashedMerchantId")
    private String hashedMerchantId;

    @JsonProperty("partnerId")
    private String partnerId;

    @JsonProperty("partnerGuid")
    private String partnerGuid;

    @JsonProperty("previousStatus")
    private String previousStatus;

    @JsonProperty("statusReason")
    private String statusReason;

    @JsonProperty("merchantCity")
    private String merchantCity;

    @JsonProperty("merchantState")
    private String merchantState;

    @JsonProperty("merchantZip")
    private String merchantZip;

    @JsonProperty("merchantCountry")
    private String merchantCountry;

    @JsonProperty("terminalBin")
    private String terminalBin;

    @JsonProperty("terminalId")
    private String terminalId;

    @JsonProperty("terminalVerificationValue")
    private String terminalVerificationValue;

    @JsonProperty("preapprovalStatus")
    private String preapprovalStatus;

    /*@JsonProperty("merchantContacts")
    private MerchantContacts merchantContacts;

    @JsonProperty("merchantAddresses")
    private MerchantAddresses merchantAddresses;*/

    @JsonProperty("merchantProducts")
    private List<MerchantProducts> merchantProducts;

    @JsonProperty("feature")
    private List<FeatureConfigurationResponse> feature;

    @JsonProperty("errorCode")
    private String errorCode;

    @JsonProperty("errorMessage")
    private String errorMessage;

    public static MerchantDetails ofEntity(Merchant entity) {
               Instant instant = Instant.ofEpochMilli(new Date().getTime());
               return MerchantDetails.builder()
                .merchantID(entity.getMerchantId())
                .merchantDBAName(entity.getMerchantDbaName())
                .merchantLegalName(entity.getMerchantLegaLname())
                .accountStatus(entity.getAccountStatus())
                .bnplStatus(entity.getBnplStatus())
                .businessTimeZoneID(entity.getBusinessTimeZoneId())
                .businessCountryCode(entity.getBusinessCountryCode())
                .businessCountryCode(entity.getBusinessCountryCode())
                .businessEmail(entity.getBusinessEmail())
                .languageCode(entity.getLanguageCode())
                .webURL(entity.getWebUrl())
                .principalOwnerEmail(entity.getPrincipalOwnerEmail())
                .principalOwnerName(entity.getPrincipalOwnerName())
                .businessTaxId(entity.getBusinessTaxId())
                .parentChain(entity.getParentChain())
                .mccCode(entity.getMccCode())
                .lastModUser(entity.getLastModifiedUser())
                .phoneNumber(entity.getPhoneNumber())
                .fundingCurrencyCode(entity.getFundingCurrencyCode())
                .openDate(entity.getOpenDate()).lastModTMS(entity.getLastModifiedTimestamp()!=null?entity.getLastModifiedTimestamp().toLocalDateTime():null)
                .midGroup(entity.getMidGroup())
                .businessAddressLineOne(entity.getBusinessAddressLineOne())
                .clientGroup(entity.getClientGroup())
                .businessAddressLineTwo(entity.getBusinessAddressLineTwo())
                       .createdTimestamp(entity.getCreatedTimestamp()!=null?entity.getCreatedTimestamp().toLocalDateTime():null)
                       .hashedMerchantId(entity.getHashedMerchantId())
                       .previousStatus(entity.getPreviousStatus())
                       .statusReason(entity.getStatusReason())
                       .merchantCity(entity.getMerchantCity())
                       .merchantState(entity.getMerchantState())
                       .merchantZip(entity.getMerchantZip())
                       .merchantCountry(entity.getMerchantCountry())
                       .terminalBin(entity.getTerminalBin())
                       .terminalId(entity.getTerminalId())
                       .terminalVerificationValue(entity.getTerminalVerificationValue())
                       .preapprovalStatus(entity.getPreApprovalStatus()).build();
    }
}















