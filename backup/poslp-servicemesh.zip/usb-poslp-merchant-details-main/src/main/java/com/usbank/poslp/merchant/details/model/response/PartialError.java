package com.usbank.poslp.merchant.details.model.response;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.apache.commons.lang3.StringUtils;

@Data
public class PartialError {

	@JsonProperty("accountToken")
	private String accountToken = StringUtils.EMPTY;

	@JsonProperty("errorCode")
	private String errorCode = StringUtils.EMPTY;

	@JsonProperty("errorDescription")
	private String errorDescription = StringUtils.EMPTY;

	@JsonProperty("errorKeyAttribute")
	private String errorKeyAttribute = StringUtils.EMPTY;

	@JsonProperty("apiId")
	private String apiId = StringUtils.EMPTY;


}
