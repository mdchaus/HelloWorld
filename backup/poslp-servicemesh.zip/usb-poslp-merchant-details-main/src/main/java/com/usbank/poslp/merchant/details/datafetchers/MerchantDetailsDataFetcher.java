package com.usbank.poslp.merchant.details.datafetchers;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import com.netflix.graphql.dgs.*;
import com.usbank.api.core.requesthandler.IRequestHandler;
import com.usbank.api.core.utils.LogUtils;
import com.usbank.poslp.graphql.core.exceptions.GraphQLAPIException;
import com.usbank.poslp.merchant.details.constants.MerchantDetailsConstants;
import com.usbank.poslp.merchant.details.exception.GraphqlExceptionHandler;
import com.usbank.poslp.merchant.details.handler.InviteToApplyHandler;
import com.usbank.poslp.merchant.details.handler.MerchantDetailsValidationHandler;
import com.usbank.poslp.merchant.details.model.request.MerchantDetailsInput;
import com.usbank.poslp.merchant.details.model.request.MerchantProducts;
import com.usbank.poslp.merchant.details.model.request.ValidateMerchantDetails;
import com.usbank.poslp.merchant.details.model.response.*;
import com.usbank.poslp.merchant.details.model.response.apply.InviteToApplyResponse;
import com.usbank.poslp.merchant.details.service.ValidateMerchantDetailsService;
import com.usbank.poslp.merchant.details.validator.MerchantDetailsValidator;
import graphql.schema.DataFetchingEnvironment;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.context.request.RequestAttributes;
import org.springframework.web.context.request.RequestContextHolder;

import java.util.*;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;


@DgsComponent
public class MerchantDetailsDataFetcher {


    private final Logger logger = LoggerFactory.getLogger(this.getClass());

    @Autowired
    private IRequestHandler<MerchantDetailsInput, MerchantDetails> merchantDetailsHandler;

    @Autowired
    private  IRequestHandler<MerchantDetailsInput, List<FeatureConfigurationResponse>> merchantDetailsFeatureHandler;

    @Autowired
    IRequestHandler<MerchantDetailsInput, List<MerchantProducts>> merchantProductsHandler;


    @Autowired
    private GraphqlExceptionHandler exceptionHandler;

    @Value("${log.masking.fields}")
    public List<String> maskingFields;

    @Autowired
    private ObjectMapper objectMapper;

    @Autowired
    private MerchantDetailsValidator merchantDetailsValidator;

    @Autowired
    private InviteToApplyHandler inviteToApplyHandler;

    @Autowired
    private MerchantDetailsValidationHandler merchantDetailsValidationHandler;

    @Autowired
    private ValidateMerchantDetailsService validateMerchantDetailsService;

    @Value("${bnpl.merchantdetails.api.feature.validateMerchant}")
    private String merchantDetailsDisabled;

    public static final String REQUEST_FOR_LOGGING = "[REQUEST] - {}";

    @DgsData(parentType = "Query", field = "inviteToApply")
    public CompletableFuture<InviteToApplyResponse> inviteToApply(@InputArgument ValidateMerchantDetails input) {
        logger.debug("Started invite to apply DataFetcher");
        if(merchantDetailsDisabled.equalsIgnoreCase("true")) {
            logger.error("Merchant details InviteToApply endpoint is disabled");
            throw new UnsupportedOperationException("Merchant details InviteToApply endpoint is disabled");
        }
        InviteToApplyResponse inviteToApplyResponse;
        try {
            /** Call the InviteToApplyService with the ValidateMerchantDetails bean*/
            inviteToApplyResponse = inviteToApplyHandler.handle(input);

            /** Return the InviteToApplyResponse bean with the applyUrl */
            logger.debug("Merchant details Invite to apply fetcher stitching: "+ inviteToApplyResponse);
            return CompletableFuture.completedFuture(inviteToApplyResponse);
        }catch (Exception ex) {
            logger.error("[EXCEPTION] --> Invite to apply fetcher - {}", ex);
            throw exceptionHandler.handleException(ex);
        }
    }

    /**
     * GraphQL api endpoint for validating the merchant
     * @param input
     * @return
     */
    @DgsData(parentType = "Query", field = "validateMerchant")
    public ValidateMerchantResponse validateMerchant(@InputArgument ValidateMerchantDetails input) {
        logger.debug("Started validating Merchant Details DataFetcher");
        if(merchantDetailsDisabled.equalsIgnoreCase("true")) {
            throw new UnsupportedOperationException("Validate Merchant endpoint is disabled");
        }

        try {
            merchantDetailsValidator.validate(input);
            return merchantDetailsValidationHandler.handle(input);
        }catch (Exception ex) {
            logger.error("[EXCEPTION] --> Verify Merchant Details fetcher - {}", ex);
            throw exceptionHandler.handleException(ex);
        }

    }

    @DgsData(parentType = "Query", field = "merchantDetails")
    public MerchantDetails getMerchantDetails(@InputArgument MerchantDetailsInput input) {
        logger.debug("Started get Merchant Details  DataFetcher");
        MerchantDetails merchantDetailsResponse;
        try {
            logger.info(REQUEST_FOR_LOGGING, input);
            merchantDetailsResponse = merchantDetailsHandler.handle(input);
            ObjectMapper mapper = new ObjectMapper();
            mapper.registerModule(new JavaTimeModule());
            Map<String, String> map = mapper.convertValue(merchantDetailsResponse, Map.class);

            logger.info("[RESPONSE] - {}", LogUtils.maskSensitiveValues(merchantDetailsResponse.toString(),maskingFields,map));
            logger.debug("Ended --> Merchant Details fetcher");
            return merchantDetailsResponse;
        } catch (Exception ex) {
            logger.error("[EXCEPTION] --> Merchant Details fetcher - {}", ex);
            throw exceptionHandler.handleException(ex);
        }
    }

    @DgsData(parentType = "MerchantDetails", field = "feature")
    public CompletableFuture<List<FeatureConfigurationResponse>> getMerchantDetailsFeature(DgsDataFetchingEnvironment environment) {
        logger.debug("Begin merchant details feature stitching query...");
        MerchantDetails merchantDetails = environment.getSource();
        List<FeatureConfigurationResponse> feature ;
        if (merchantDetails == null) {
            logger.error("MerchantDetails is null in getMerchantDetailsFeature");
            return CompletableFuture.completedFuture(Collections.emptyList());
        }
        try {
            logger.info(REQUEST_FOR_LOGGING, merchantDetails.getMerchantID());
            MerchantDetailsInput merchantDetailsInput = new MerchantDetailsInput();
            merchantDetailsInput.setMerchantID(merchantDetails.getMerchantID());
            feature = merchantDetailsFeatureHandler.handle(merchantDetailsInput);
            logger.debug("Ended --> Merchant details feature stitching: " + feature);
            return CompletableFuture.completedFuture(feature);
        } catch (Exception ex) {
            logger.error("[EXCEPTION] --> Merchant Details feature stitching - {}", ex);
            throw exceptionHandler.handleException(ex);
        }
    }



    @DgsData(parentType = "MerchantDetails", field = "merchantProducts")
    public CompletableFuture<List<MerchantProducts>> getMerchantProducts(DgsDataFetchingEnvironment environment) {
        logger.debug("Begin merchant products feature stitching query...");
        MerchantDetails merchantDetails = environment.getSource();
        List<MerchantProducts> merchantProducts = new ArrayList<>();
        if (merchantDetails == null) {
            logger.error("MerchantDetails is null in getMerchantProducts");
            return CompletableFuture.completedFuture(merchantProducts);
        }

        // Capture the current request attributes
        RequestAttributes requestAttributes = RequestContextHolder.currentRequestAttributes();

        ExecutorService executor = Executors.newSingleThreadExecutor();

        return CompletableFuture.supplyAsync(() -> {
            // Bind the request attributes to the new thread
            RequestContextHolder.setRequestAttributes(requestAttributes);
            try {
                logger.info(REQUEST_FOR_LOGGING, merchantDetails.getMerchantID());
                MerchantDetailsInput merchantDetailsInput = new MerchantDetailsInput();
                merchantDetailsInput.setMerchantID(merchantDetails.getMerchantID());
                return merchantProductsHandler.handle(merchantDetailsInput);
            } catch (Exception ex) {
                logger.error("[EXCEPTION] --> Merchant Details feature stitching - {}", ex);
                throw exceptionHandler.handleException(ex);
            } finally {
                // Clear the request attributes from the thread
                RequestContextHolder.resetRequestAttributes();
            }
        }, executor).thenApplyAsync(result -> {
            executor.shutdown();
            return result;
        });
    }



    @DgsData(parentType = MerchantDetailsConstants.SHOPPING_CART, field = "merchantDetails")
    public CompletableFuture<MerchantDetails>  getShoppingCartMerchantDetails(DataFetchingEnvironment dataFetchingEnvironment) {
        logger.debug("Begin Merchant details Stitching query ... ");
        ShoppingCartResponse shoppingCart = dataFetchingEnvironment.getSource();
        PartialError error = shoppingCart.getError();
        if (Objects.nonNull(error)) {
            throw new GraphQLAPIException(error.getErrorCode(), error.getErrorDescription(),
                    shoppingCart.getMerchantID(), error.getApiId());
        } else {
            try {
                MerchantDetailsInput merchantDetailsInput=new MerchantDetailsInput();
                merchantDetailsInput.setMerchantID(shoppingCart.getMerchantID());
                MerchantDetails merchantDetailsResponse=merchantDetailsHandler.handle(merchantDetailsInput);
                logger.debug("Ended --> Merchant details fetcher stitching: "+merchantDetailsResponse);
                return CompletableFuture.completedFuture(merchantDetailsResponse);
            }
            catch (Exception ex) {
                logger.error("[EXCEPTION] --> Merchant Details Stitching fetcher - {}", ex);
                throw exceptionHandler.handleException(ex);
            }
        } }

    @DgsTypeResolver(name =MerchantDetailsConstants.SHOPPING_CART)
    public String resolveShoppingCart(ShoppingCartResponse shoppingCart) {
        return MerchantDetailsConstants.SHOPPING_CART;
    }

    @DgsEntityFetcher(name = MerchantDetailsConstants.SHOPPING_CART)
    public CompletableFuture<ShoppingCartResponse> getShoppingCartMerchantDetail(Map<String, Object> values,
                                                                                 DgsDataFetchingEnvironment environment) {
        String merchantID = (String) values.get(MerchantDetailsConstants.MERCHANT_ID);
        ShoppingCartResponse shoppingCart=new ShoppingCartResponse();
        shoppingCart.setMerchantID(merchantID);
        return CompletableFuture.completedFuture(shoppingCart);

    }


}
