package com.usbank.poslp.merchant.details.model.response.apply;

import lombok.Data;

import java.util.List;

@Data
public class Execution{
	private boolean running;
	private int retries;
	private Variables variables;
	private Object errorState;
	private String firstAttempt;
	private Object module;
	private String lastAttempt;
	private String id;
	private String state;
	private List<String> history;
	private String machineType;
}