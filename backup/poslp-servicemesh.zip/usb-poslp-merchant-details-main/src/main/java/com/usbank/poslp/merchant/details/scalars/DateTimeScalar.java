package com.usbank.poslp.merchant.details.scalars;

import com.netflix.graphql.dgs.DgsComponent;
import com.netflix.graphql.dgs.DgsRuntimeWiring;
import graphql.scalars.ExtendedScalars;
import graphql.schema.idl.RuntimeWiring;

/**
 * graphql-java provides optional com.usbank.dss.servicing.account.details.scalars in the graphql-java-extended-com.usbank.dss.servicing.account.details.scalars
 * library. We can wire a scalar from this library by adding the scalar to the
 * RuntimeWiring.
 */
@DgsComponent
public class DateTimeScalar {

	@DgsRuntimeWiring
	public RuntimeWiring.Builder addScalar(RuntimeWiring.Builder builder) {
		return builder.scalar(ExtendedScalars.DateTime);
	}
}
