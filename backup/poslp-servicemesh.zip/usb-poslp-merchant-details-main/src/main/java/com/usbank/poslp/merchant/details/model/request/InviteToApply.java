package com.usbank.poslp.merchant.details.model.request;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.apache.commons.lang3.StringUtils;

import java.util.UUID;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class InviteToApply {

    @JsonProperty("merchantID")
    private String merchantID;

    @JsonProperty("firstName")
    private String firstName;

    @JsonProperty("lastName")
    private String lastName;

    @JsonProperty("applicantEmail")
    private String applicantEmail;

    @JsonProperty("productCode")
    private String productCode;

    @JsonProperty("subProductCode")
    private String subProductCode;

    @JsonProperty("subType")
    private String subType;

    @JsonProperty("correlationId")
    private String correlationId;

    @JsonProperty("isMerchant")
    private boolean isMerchant;

    @JsonProperty("apiSource")
    private String apiSource;

    @JsonProperty("merchantProcessingCenterId")
    private String merchantProcessingCenterId;

    @JsonProperty("apsProduct")
    private String apsProduct;

    @JsonProperty("dbaName")
    private String dbaName;

    public InviteToApply(ValidateMerchantDetails merchantDetails, String productCode, String subProductCode,
                         String subType, String isMerchant, String apsProduct, String dbaName) {
        this.apiSource = merchantDetails.getApiSource();
        this.merchantID = merchantDetails.getAccountMid();
        this.firstName = merchantDetails.getContactFirstName();
        this.lastName = merchantDetails.getContactLastName();
        this.merchantProcessingCenterId = merchantDetails.getProcessingCenterID();
        this.applicantEmail = merchantDetails.getApplicantEmail();

        this.productCode = productCode;
        this.subProductCode = subProductCode;
        this.subType = subType;
        this.isMerchant = (StringUtils.isNotBlank(isMerchant) && isMerchant.equalsIgnoreCase("YES")) ? true : false;
        this.apsProduct = StringUtils.isBlank(apsProduct) ? StringUtils.EMPTY : apsProduct;
        this.dbaName = dbaName;
        this.correlationId = UUID.randomUUID().toString();
    }

}
