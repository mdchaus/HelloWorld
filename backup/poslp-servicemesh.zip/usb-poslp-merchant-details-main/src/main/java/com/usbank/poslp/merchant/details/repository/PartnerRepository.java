package com.usbank.poslp.merchant.details.repository;

import com.usbank.api.core.jpa.repository.PoslpRepository;
import com.usbank.poslp.commons.entities.Partner;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import java.util.UUID;

@Repository
@Transactional
public interface PartnerRepository extends PoslpRepository<Partner, UUID> {
    Partner findByPartnerId(String partnerId);

    @Query(value = """
            select p from Partner p join MerchantPartnerConfiguration mpc
            on  p.partnerGuid = mpc.partnerGuid
            where mpc.merchantId = :merchantId
            """)
    Partner findByMerchantId(String merchantId);
}
