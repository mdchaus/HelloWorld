package com.usbank.poslp.merchant.details.exception;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.usbank.api.core.advice.BaseExceptionHandlerAdvice;
import com.usbank.api.core.exception.BadRequestException;
import com.usbank.api.core.model.rest.errors.Error;
import com.usbank.api.core.model.rest.errors.ErrorDetail;
import com.usbank.api.core.model.rest.model.BaseResponse;
import com.usbank.api.core.utils.ExceptionUtils;
import com.usbank.poslp.merchant.details.constants.MerchantDetailsConstants;
import com.usbank.poslp.merchant.details.model.request.MerchantPreApprovalLinkRequest;
import jakarta.servlet.http.HttpServletRequest;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.json.JSONException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;

import java.time.LocalDateTime;
import java.time.ZonedDateTime;
import java.util.ArrayList;
import java.util.List;

import static com.usbank.poslp.merchant.details.constants.CustomErrorCodes.BAD_REQUEST_ERROR;
import static com.usbank.poslp.merchant.details.constants.MerchantDetailsConstants.EMPTY_STRING;

@ControllerAdvice
@EnableWebMvc
@Slf4j
public class PublisherExceptionHandler extends BaseExceptionHandlerAdvice {
    @Autowired
    private HttpServletRequest httpServletRequest;

    @Value("${api.id}")
    private String apiId;
    @Value("${build.version}")
    private String buildVersion;

    @ExceptionHandler(BadRequestException.class)
    public ResponseEntity handleBadRequestException(BadRequestException ex) {
        log.info("BadRequestException : message={}", ex.getErrorMessage());
        Error error = new Error();
        handleErrorDetails(ex.getAttributeName(), updateIfBlank(ex.getErrorMessage()), error, getAttributeValue(ex));
        BaseResponse baseResponse = handleError(ex.getErrorMessage(), ex.getErrorCode(), null, error);
        return populateError(baseResponse, new HttpHeaders(), HttpStatus.BAD_REQUEST);
    }

    @ExceptionHandler(JsonProcessingException.class)
    public ResponseEntity handleJsonProcessingException(JsonProcessingException ex) {
        Error error = new Error();
        handleErrorDetails(ex.getMessage(), ex.getMessage(), error);
        BaseResponse baseResponse = handleError(ex.getMessage(), BAD_REQUEST_ERROR.getErrorCode(), "Please provide info as per schema", error);
        return populateError(baseResponse, new HttpHeaders(), HttpStatus.BAD_REQUEST);
    }

    @ExceptionHandler(JSONException.class)
    public ResponseEntity handleJsonException(JSONException ex) {
        Error error = new Error();
        handleErrorDetails(ex.getMessage(), ex.getMessage(), error);
        BaseResponse baseResponse = handleError(ex.getMessage(), BAD_REQUEST_ERROR.getErrorCode(), "Please provide info as per schema", error);
        return populateError(baseResponse, new HttpHeaders(), HttpStatus.BAD_REQUEST);
    }

    @ExceptionHandler(PublisherException.class)
    public ResponseEntity handlePublisherException(PublisherException ex) {
        Error error = new Error();
        handleErrorDetails(ex.getErrorMessage(), ex.getMessage(), error);
        BaseResponse baseResponse = handleError(ex.getMessage(), ex.getErrorCode(), "Please provide info as per schema", error);
        return populateError(baseResponse, new HttpHeaders(), HttpStatus.INTERNAL_SERVER_ERROR);
    }


    protected ResponseEntity<Object> populateError(BaseResponse baseResponse, HttpHeaders headers, final HttpStatus httpStatus) {
        headers.setDate(ZonedDateTime.now());
        headers.setContentType(MediaType.APPLICATION_JSON);
        headers.add("Correlation-ID", this.httpServletRequest.getHeader("Correlation-ID"));
        headers.add("Version", null != this.buildVersion ? this.buildVersion : "1.0.0");
        headers.add("Access-Control-Allow-Origin", "*");
        if (this.log != null) {
            this.log.error("[BaseExceptionHandlerAdvice] populateError " + baseResponse.toString());
        }

        return new ResponseEntity(baseResponse, headers, httpStatus);
    }

    protected BaseResponse handleError(String errorMessage, String errorCode, String help, Error error) {
        BaseResponse baseResponse = new BaseResponse();
        error.setCode(getCode(errorCode));
        error.setMessage(errorMessage);
        baseResponse.setError(error);
        baseResponse.setTimestamp(LocalDateTime.now().toString());
        return baseResponse;
    }

    protected Error handleErrorDetails(String attributeName, String reason, Error error) {
        List<ErrorDetail> errList = new ArrayList();
        ErrorDetail errorDetail = new ErrorDetail();
        errorDetail.setAttributeName(attributeName);
        errorDetail.setReason(reason);
        errList.add(errorDetail);
        error.setDetails(errList);
        return error;
    }

    public String getCode(String codeConstant) {
        try {
            return String.format(codeConstant, apiId);

        } catch (Exception ex) {
            log.error("[EXCEPTION] -- > ", ex);
        }
        return null;
    }

    private String updateIfBlank(String value) {
        return StringUtils.isNotBlank(value) ? value : EMPTY_STRING;

    }

    public String getAttributeValue(BadRequestException ex) {
        String attributeName = ex.getAttributeName();
        String attributeValue = ExceptionUtils.getFieldType(MerchantPreApprovalLinkRequest.class, attributeName);
        if (StringUtils.isEmpty(attributeValue)) {
            attributeValue = MerchantDetailsConstants.STRING;
        }
        if (StringUtils.isEmpty(attributeName)) {
            attributeValue = MerchantDetailsConstants.EMPTY_STRING;
        }
        return attributeValue;
    }

    public Error handleErrorDetails(String attributeName, String reason, Error error, String attributeValue) {
        List<ErrorDetail> errList = new ArrayList();
        ErrorDetail errorDetail = new ErrorDetail();
        errorDetail.setAttributeName(attributeName);
        errorDetail.setAttributeValue(attributeValue);
        errorDetail.setReason(reason);
        errList.add(errorDetail);
        error.setDetails(errList);
        return error;
    }
}