
package com.usbank.poslp.merchant.details.repository;

import com.usbank.api.core.jpa.repository.PoslpRepository;
import com.usbank.poslp.commons.entities.Merchant;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

@Repository
public interface MerchantRepository extends PoslpRepository<Merchant, String> {

    @Query(value = """
            select m.merchantid,m.bnplstatus,count(mp.*),m.merchantDbaName from merchants m
            join merchant_products mp on m.merchantid = mp.merchantid
            where m.merchantid =:merchantId and m.bnplstatus = 'ACTIVE' group by
            m.merchantid,m.bnplstatus having count(mp.*) > 0
            """, nativeQuery = true)
    public String findAll(String merchantId);
}
