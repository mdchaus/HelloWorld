package com.usbank.poslp.merchant.details.service;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.usbank.api.core.modelservice.IModelService;
import com.usbank.poslp.core.clients.http.InternalAPIClient;
import com.usbank.poslp.merchant.details.model.request.ValidateMerchantDetails;
import com.usbank.poslp.merchant.details.model.response.MerchantDetailsResponse;
import com.usbank.poslp.merchant.details.model.response.SRSApiResponse;
import com.usbank.poslp.merchant.details.model.response.SRSApiToken;
import com.usbank.poslp.merchant.details.model.response.ValidateMerchantResponse;
import com.usbank.poslp.merchant.details.utils.ApiUtils;
import com.usbank.poslp.merchant.details.validator.MerchantDetailsValidator;
import io.github.resilience4j.circuitbreaker.annotation.CircuitBreaker;
import jakarta.transaction.Transactional;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.*;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;

import java.util.HashMap;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;

import static com.usbank.poslp.merchant.details.constants.MerchantDetailsConstants.AUTHORIZATION;
import static com.usbank.poslp.merchant.details.constants.MerchantDetailsConstants.BEARER;
import static com.usbank.poslp.merchant.details.constants.MerchantDetailsConstants.PRODESSING_CENTER_ID;
import static com.usbank.poslp.merchant.details.constants.MerchantDetailsConstants.API_SOURCE;
import static com.usbank.poslp.merchant.details.constants.MerchantDetailsConstants.ACCOUNT_MID;
import static com.usbank.poslp.merchant.details.constants.MerchantDetailsConstants.CONTACT_ID;
import static com.usbank.poslp.merchant.details.constants.MerchantDetailsConstants.CIRCUIT_BREAKER_VALIDATE_MERCHANT_DETAILS;

@Service
@Transactional
@Slf4j
public class ValidateMerchantDetailsService implements IModelService<ValidateMerchantDetails, ValidateMerchantResponse>  {

    @Value("${bnpl.srs.merchant.validation.url}")
    private String srsValidateMerchantUrl;

    @Value("${bnpl.srs.api.token.url}")
    private String srsAccessTokenUrl;

    @Autowired
    private ObjectMapper objectMapper;

    @Autowired
    private MerchantDetailsValidator merchantDetailsValidator;

    @Autowired
    private ApiUtils apiUtils;

    @Autowired
    @Qualifier("POSLPRestTemplate")
    private RestTemplate restTemplate;

    @Autowired
    private InternalAPIClient dataProvider;

    @Override
    @CircuitBreaker(name = CIRCUIT_BREAKER_VALIDATE_MERCHANT_DETAILS)
    public ValidateMerchantResponse process(ValidateMerchantDetails validateMerchantDetails) throws Exception {
        log.info("Validate Merchant Details service started.");
        HttpHeaders httpHeaders;
        HttpEntity<?> httpEntity;
        ValidateMerchantResponse validateMerchantResponse;

        try {
            /** Prepare the input JSON String*/
            final String inputMerchant = this.objectMapper.writeValueAsString(validateMerchantDetails);
            log.info("Input merchant details : " + inputMerchant);

            /** Call the SRS Api for token */
            httpHeaders = new HttpHeaders();
            httpHeaders.setContentType(MediaType.APPLICATION_JSON);
            httpEntity = new HttpEntity<>(inputMerchant, httpHeaders);
            final ResponseEntity<SRSApiToken> responseToken = restTemplate.exchange(srsAccessTokenUrl, HttpMethod.POST, httpEntity, SRSApiToken.class, apiUtils.prepareQueryParameter());
            log.info("SRS Api token response for the merchant {}, {}", validateMerchantDetails.getAccountMid(), responseToken);

            /** Get the token */
            final String token = responseToken.getBody().getAccessToken();

            /** Call the SRS API to validate the merchant. */
            httpHeaders.add(AUTHORIZATION, BEARER + token);
            httpEntity = new HttpEntity<>(inputMerchant, httpHeaders);
            final ResponseEntity<MerchantDetailsResponse> responseValidMerchant = restTemplate.exchange(srsValidateMerchantUrl, HttpMethod.POST, httpEntity, MerchantDetailsResponse.class);
            log.info("SRS Api(Valid Merchant) response for the merchant {}, {}", validateMerchantDetails.getAccountMid(), responseValidMerchant);

            /** Get the Contact ID */
            final String contactId = Optional.ofNullable(responseValidMerchant.getBody())
                    .map(m -> m.getMerchantDetailsBody())
                    .map(p -> p.getContactID())
                    .orElse(StringUtils.EMPTY);

            validateMerchantResponse = new ValidateMerchantResponse();

            /** Call the SRS API to add authority package to validate the merchant. */
            if (Optional.ofNullable(contactId).isPresent() && !StringUtils.isBlank(contactId)) {
                Map<String, String> headersMap = new HashMap<>();
                headersMap.put(AUTHORIZATION, BEARER + token);

                UriComponentsBuilder builder = UriComponentsBuilder.fromUriString(srsValidateMerchantUrl)
                        .queryParam(PRODESSING_CENTER_ID, validateMerchantDetails.getProcessingCenterID())
                        .queryParam(API_SOURCE, validateMerchantDetails.getApiSource())
                        .queryParam(ACCOUNT_MID, validateMerchantDetails.getAccountMid())
                        .queryParam(CONTACT_ID, contactId);
                final ResponseEntity<SRSApiResponse> srsApiResponse = restTemplate.exchange(builder.buildAndExpand(srsValidateMerchantUrl).toUri(), HttpMethod.GET, httpEntity, SRSApiResponse.class);


                log.info("SRS Api(Add Authority package for Valid Merchant) response for the merchant {}, {}", validateMerchantDetails.getAccountMid(), srsApiResponse);

                final boolean merchantValid =(!Objects.isNull(srsApiResponse.getStatusCode())
                        && srsApiResponse.getStatusCode().is2xxSuccessful());

                validateMerchantResponse.setMerchantValid(merchantValid);
                validateMerchantResponse.setToken(token);
                log.info("Validate Merchant Response : " + validateMerchantResponse.toString());
            } else {
                validateMerchantResponse.setMerchantValid(false);
            }
            return validateMerchantResponse;
        } catch (Exception ex) {
            log.error("Error in processing the merchant details, {}", ex.getCause());
            throw ex;
        }
    }
}
