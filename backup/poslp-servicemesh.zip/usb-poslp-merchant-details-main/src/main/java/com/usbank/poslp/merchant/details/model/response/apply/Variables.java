package com.usbank.poslp.merchant.details.model.response.apply;

import com.google.gson.annotations.SerializedName;
import lombok.Data;

@Data
public class Variables{
	@SerializedName("REMOTE_CALLS_ID")
	private String remoteCallsID;
	private boolean searchShoppingCartDetailsFunctionSuccess;
	private StepExecutionAttempts stepExecutionAttempts;
	private boolean applicationExists;
	private String applyUrl;
	private String host;
	private Object event;
	private String applicationId;
	private String machineName;
}
