package com.usbank.poslp.merchant.details.model.response;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.usbank.poslp.commons.entities.FeatureConfiguration;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;

@Data
@Builder
@JsonIgnoreProperties
@AllArgsConstructor
public class FeatureConfigurationResponse {

    @JsonProperty("configurationName")
    private String configurationName;

    @JsonProperty("configurationValue")
    private String configurationValue;

    public FeatureConfigurationResponse(){}

    public static FeatureConfigurationResponse ofEntity(FeatureConfiguration entity) {
        return FeatureConfigurationResponse.builder()
                .configurationName(entity.getConfigurationName())
                .configurationValue(entity.getConfigurationValue()).build();
    }
}
