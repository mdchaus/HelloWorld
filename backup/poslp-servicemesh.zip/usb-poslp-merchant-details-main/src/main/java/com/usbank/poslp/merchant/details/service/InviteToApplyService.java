package com.usbank.poslp.merchant.details.service;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.usbank.api.core.exception.SubsystemDataException;
import com.usbank.api.core.exception.SubsystemUnavailableException;
import com.usbank.api.core.modelservice.IModelService;
import com.usbank.poslp.core.clients.http.InternalAPIClient;
import com.usbank.poslp.merchant.details.model.request.InviteToApply;
import com.usbank.poslp.merchant.details.model.request.ValidateMerchantDetails;
import com.usbank.poslp.merchant.details.model.response.apply.ApplyInvitationServiceResponse;
import com.usbank.poslp.merchant.details.model.response.apply.InviteToApplyResponse;
import com.usbank.poslp.merchant.details.utils.ApiUtils;
import io.github.resilience4j.circuitbreaker.CallNotPermittedException;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.*;
import org.springframework.stereotype.Service;
import java.util.Map;

@Service
@Slf4j
public class InviteToApplyService implements IModelService<ValidateMerchantDetails, InviteToApplyResponse> {

    @Value("${bnpl.aps.invitetoapply.url}")
    private String apsInviteToApplyUrl;

    @Value("${bnpl.aps.invitetoapply.service.uri}")
    private String apsInviteToApplyServiceUri;

    @Value("${bnpl.aps.invitetoapply.productcode}")
    private String productCode;

    @Value("${bnpl.aps.invitetoapply.subproductcode}")
    private String subProductCode;

    @Value("${bnpl.aps.invitetoapply.subtype}")
    private String subType;

    @Value("${bnpl.aps.invitetoapply.ismerchant}")
    private String isMerchant;

    @Value("${bnpl.aps.invitetoapply.apsproduct}")
    private String apsProduct;

    @Value("${bnpl.aps.invitetoapply.dbaname}")
    private String dbaName;

    @Autowired
    private ObjectMapper objectMapper;

    @Autowired
    private InternalAPIClient internalAPIClient;

    @Autowired
    private ApiUtils apiUtils;

    @Override
    public InviteToApplyResponse process(ValidateMerchantDetails validateMerchantDetails) throws Exception {
        log.debug("Validate Invites to apply service started.");
        InviteToApplyResponse inviteToApplyResponse;
        InviteToApply inviteToApply;
        Map<String, String> headers;
        String inviteToApplyUrl = null;
        ApplyInvitationServiceResponse response;

        try {
            /** Get the Invite to apply object */
            inviteToApply = new InviteToApply(validateMerchantDetails, productCode,
                    subProductCode, subType, isMerchant, apsProduct, dbaName);

            /** Prepare the input JSON String*/
            final String inviteToApplyJson = this.objectMapper.writeValueAsString(inviteToApply);
            log.info("Invite To Apply details : " + inviteToApplyJson);

            /** Set the header. */
            headers = apiUtils.inviteToApplyHeaders();

            /** Invoke the APS Api with the InviteToApply bean as the input. */
            response = internalAPIClient.post(apsInviteToApplyUrl + apsInviteToApplyServiceUri, inviteToApply, headers, ApplyInvitationServiceResponse.class);
            log.info("APS InviteToApply Api response for the merchant {}, {}", inviteToApply.getMerchantID(), response);

            /** Set the applyUrl. */
            inviteToApplyUrl = response.getApplyUrl();
            log.debug("Apply Url {}", inviteToApplyUrl);
        }catch (CallNotPermittedException ex) {
            log.error("Exception thrown by the Rest Client in Invite To Apply service: {}", ex);
            throw ex;
        } catch (SubsystemDataException ex) {
            log.error("SubSystemDataException thrown by the Rest Client in Invite To Apply service: {}", ex);
            apiUtils.handleSubsystemDataException(ex);
        } catch (SubsystemUnavailableException ex) {
            log.error("SubsystemUnavailableException thrown by the Rest Client in Invite To Apply service: {}", ex);
            apiUtils.handleSubsystemUnavailableException(ex);
        }
        catch(Exception ex) {
            log.error("Exception caught in posting the Aps invite to apply Api with error {}", ex.getLocalizedMessage());
            throw new SubsystemUnavailableException(apsInviteToApplyUrl,
                    HttpStatus.INTERNAL_SERVER_ERROR,
                    "Invitation Service: " + ex.getMessage());
        }
        inviteToApplyResponse = new InviteToApplyResponse();
        inviteToApplyResponse.setApplyUrl(inviteToApplyUrl);
        return inviteToApplyResponse;
    }
}
