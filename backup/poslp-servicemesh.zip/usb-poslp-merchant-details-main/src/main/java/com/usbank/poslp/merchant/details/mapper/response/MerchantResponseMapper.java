package com.usbank.poslp.merchant.details.mapper.response;

import com.usbank.poslp.commons.entities.MerchantProduct;
import com.usbank.poslp.merchant.details.model.request.MerchantProducts;
import com.usbank.poslp.merchant.details.model.response.MerchantDetails;
import com.usbank.poslp.merchant.details.utils.ApiUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;

@Component
public class MerchantResponseMapper {

	private static final Logger log = LoggerFactory.getLogger(MerchantResponseMapper.class);

	@Autowired
	private ApiUtils apiUtils;

	public MerchantDetails map(MerchantDetails merchantDetails,List<MerchantProduct> productList) {

				List<MerchantProducts> merchantProductsList = new ArrayList<>();
				productList.stream().forEach(product -> {
					MerchantProducts merchantProducts = null;
					if (apiUtils.validate((product.getExpirationDate()))) {
						merchantProducts = merchantProducts.ofEntity(product);
						merchantProductsList.add(merchantProducts);
					} else {
						log.info("[TRACE] - Excluding expired Product, merchantProductGuid - {}", product.getMerchantProductGuid());
					}
				});
				merchantDetails.setMerchantProducts(merchantProductsList);


		return merchantDetails;
	}

}
