package com.usbank.poslp.merchant.details.utils;

import com.usbank.api.core.component.requestcontext.IRequestContext;
import com.usbank.api.core.constant.USBConstants;
import com.usbank.poslp.merchant.details.config.MerchantDetailsApiConfig;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.Date;
import java.util.Map;
import java.util.Objects;
import java.util.UUID;

@Component
public class MappingUtils {
	@Autowired
	private MerchantDetailsApiConfig config;

	@Autowired
	private IRequestContext requestContext;

	private static final Logger logger = LoggerFactory.getLogger(MappingUtils.class);


	public static Date parseIntegerToDate(Integer value) throws ParseException {
		try {

			if (value > 0) {
				SimpleDateFormat originalFormat = new SimpleDateFormat("yyyyMMdd");
				return originalFormat.parse(value.toString());
			}
		} catch (Exception e) {
			logger.error("parseIntegerToDate has error " + e.getLocalizedMessage());

		}
		return null;
	}

	/**
	 * Method to get correlationId from headers
	 *
	 * @param httpHeaders
	 * @return String
	 */
	public static String getCorrelationId(Map<String, String> httpHeaders) {
		String retVal = StringUtils.EMPTY;
		try {
			if (httpHeaders != null) {
				String id = httpHeaders.get(USBConstants.CORRELATION_ID);

				if (StringUtils.isNotEmpty(id)) {
					try {
						UUID.fromString(id);
						retVal = id;
					} catch (Exception e) {
						retVal = UUID.randomUUID().toString();
						logger.warn("[MappingUtils] getCorrelationId parsed invalid UUID value: " + id + ". Return "
								+ retVal);
					}
					return retVal;
				}
			}

			logger.debug("[MappingUtils] getCorrelationId httpHeaders or correlation-id is null. Generate new");
			retVal = UUID.randomUUID().toString();
			return retVal;

		} finally {
			logger.debug("[MappingUtils] getCorrelationId return  {}", retVal);
		}
	}

	public static String getSecretAccountNumber(String accountNumber) {
		return StringUtils.leftPad(
				StringUtils.substring(accountNumber, accountNumber.length() - 4, accountNumber.length()), 16, '*');
	}



	public String getLastFourAccountNumber(String accountNumber) {
		return accountNumber.length() > 4 ? StringUtils.substring(accountNumber, accountNumber.length() - 4)
				: accountNumber;
	}

	public String modifyAccountNumber(String accountNumber) {
		if (accountNumber.length() < 22) {
			return StringUtils.leftPad(accountNumber, 22, "0");
		} else if (accountNumber.length() > 22) {
			return accountNumber.substring(accountNumber.length() - 22);
		} else {
			return accountNumber;
		}
	}



	/**
	 * This method formats the decimal values to 2 decimal places
	 *
	 * @param value
	 * @return
	 */
	public BigDecimal formatBigDecimal(BigDecimal value) {
		if (Objects.nonNull(value)) {
			try {
				return value.setScale(2, RoundingMode.HALF_UP);
			} catch (Exception ex) {
				logger.error("Exception while converting decimal value", ex);
			}
		}
		return null;
	}

	//This method converts java.util.Date to LocaleDateTime
	
	public LocalDateTime convertDateToLocalDateTime(Date date) {
		if (Objects.nonNull(date)) {
			try {
				Date dt = new Date(date.getTime());
			    return dt.toInstant().atZone(ZoneId.systemDefault()).toLocalDateTime();
			} catch (Exception ex) {
				logger.error("Exception while converting date to localdatetime", ex);
			}
		}
		return null;
	}

}
