package com.usbank.poslp.merchant.details.model.request;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@JsonIgnoreProperties(ignoreUnknown = true)
@Data
@AllArgsConstructor
@NoArgsConstructor
public class ClientData {

    @JsonProperty("ChannelID")
    private String channelID;

    @JsonProperty("UserId")
    private String userId;

    @JsonProperty("CompanyId")
    private String companyId;

    @JsonProperty("Identifier")
    private String identifier;

    @JsonProperty("IdentifierType")
    private String identifierType;

    @JsonProperty("SessionKey")
    private String sessionKey;

    @JsonProperty("OMA99")
    private boolean oma99;

    @JsonProperty("ANT99")
    private boolean ant99;

}

