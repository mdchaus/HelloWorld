package com.usbank.poslp.merchant.details.model.response;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;
import org.apache.commons.lang3.StringUtils;

@Data
public class SRSApiResponse {

    @JsonProperty("StatusCode")
    private String statusCode;

    @JsonProperty("Status")
    private String status = StringUtils.EMPTY;

    @JsonProperty("ErrorMessage")
    private String errorMessage = StringUtils.EMPTY;

}
