package com.usbank.poslp.merchant.details.scalars;

import com.netflix.graphql.dgs.DgsScalar;
import graphql.language.StringValue;
import graphql.schema.Coercing;
import graphql.schema.CoercingParseLiteralException;
import graphql.schema.CoercingParseValueException;
import graphql.schema.CoercingSerializeException;

import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;

/**
 * graphql-java provides optional scalars in the graphql-java-extended-scalars
 * library. We can wire a scalar from this library by adding the scalar to the
 * RuntimeWiring.
 */
@DgsScalar(name = "ZonedDateTime")
public class ZonedDateTimeScalar implements Coercing<ZonedDateTime, String> {
	private DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ssZZZZZ");
	@Override
	public String serialize(Object dataFetcherResult) throws CoercingSerializeException {
		if (dataFetcherResult instanceof ZonedDateTime) {
			return ((ZonedDateTime) dataFetcherResult).format(formatter);
		} else {
			throw new CoercingSerializeException("Not a valid DateTime");
		}
	}

	@Override
	public ZonedDateTime parseValue(Object input) throws CoercingParseValueException {
		return ZonedDateTime.parse(input.toString(), formatter);
	}

	@Override
	public ZonedDateTime parseLiteral(Object input) throws CoercingParseLiteralException {
		if (input instanceof StringValue) {
			return ZonedDateTime.parse(((StringValue) input).getValue(),formatter);
		}

		throw new CoercingParseLiteralException("Value is not a valid ISO date time");
	}
}
