package com.usbank.poslp.merchant.details.repository;

import com.usbank.api.core.jpa.repository.PoslpRepository;
import com.usbank.poslp.commons.entities.Merchant;
import jakarta.validation.constraints.NotNull;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;


import java.util.List;
import java.util.Optional;

@Repository
public interface MerchantDetailsRepository extends PoslpRepository<Merchant, String>{

	@NotNull
	@Cacheable("merchantDetails")
	Optional<Merchant> findById(String merchantid);

	Optional<List<Merchant>> findAllByMerchantId(String merchantid);

	@Query("SELECT m FROM Merchant m LEFT JOIN FETCH m.merchantProducts WHERE m.merchantId = :merchantId AND m.bnplStatus = 'ACTIVE'")
	Optional<Merchant> findByIdWithProducts(String merchantId);

}
