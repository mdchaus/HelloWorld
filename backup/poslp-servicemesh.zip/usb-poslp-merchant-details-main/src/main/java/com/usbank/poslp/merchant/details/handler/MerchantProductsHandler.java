package com.usbank.poslp.merchant.details.handler;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.usbank.api.core.aspect.LogExecutionTime;
import com.usbank.api.core.component.requestcontext.IRequestContext;
import com.usbank.api.core.constant.USBConstants;
import com.usbank.api.core.requesthandler.IRequestHandler;
import com.usbank.poslp.merchant.details.advice.MerchantExceptionHandler;
import com.usbank.poslp.merchant.details.constants.MerchantDetailsConstants;
import com.usbank.poslp.merchant.details.model.request.MerchantDetailsInput;
import com.usbank.poslp.merchant.details.model.request.MerchantProducts;
import com.usbank.poslp.merchant.details.service.MerchantProductsService;
import com.usbank.poslp.merchant.details.validator.MerchantDetailsRequestValidator;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.Optional;

@Service
@Slf4j
public class MerchantProductsHandler implements IRequestHandler<MerchantDetailsInput, List<MerchantProducts>> {

    @Autowired
    private MerchantProductsService merchantProductsService;

    @Autowired
    MerchantDetailsRequestValidator merchantRequestValidator;

    @Autowired
    private MerchantExceptionHandler exceptionHandler;

    @Autowired
    ObjectMapper objectMapper;

    @Autowired
    private IRequestContext requestContext;

    @Override
    @LogExecutionTime
    public List<MerchantProducts> handle(MerchantDetailsInput request) throws Exception {
        log.debug("MerchantProductsHandler call started: ");
        log.debug("MerchantProducts Request: "+request);
        Optional<MerchantDetailsInput> optionalMerchantDetailsInput = Optional.ofNullable(request);
        List<MerchantProducts> merchantProducts = new ArrayList<>();
        try
        {
            /**
             * If request for Merchant Details comes from APIGEE,
             * then get the MID from the Identifier in the request header
             *
             * Else
             * Use the MID available in the request
             */
            String clientId=requestContext.getHttpHeaders().get(USBConstants.CLIENT_ID.toLowerCase());
            if(optionalMerchantDetailsInput.isPresent() && (Objects.nonNull(clientId) && clientId.equalsIgnoreCase(MerchantDetailsConstants.APIGEE))) {
                //Only when MID is available in Identifier in Request Header, override the Request. Else do not overwrite the request.
                String midFromHeader = merchantRequestValidator.getIdentifier();
                if(Objects.nonNull(midFromHeader) && StringUtils.isNotEmpty(midFromHeader)){
                    request = new MerchantDetailsInput();
                    request.setMerchantID(midFromHeader);
                }
                merchantRequestValidator.validate(request);
            } else {
                merchantRequestValidator.validate(request);
            }
            merchantProducts = merchantProductsService.process(request);
            log.debug("MerchantProductsHandler response: "+ merchantProducts);
        }catch (Exception ex) {
            log.error("[ERROR] --> MerchantProducts Request Handler :{}", ex);
            throw exceptionHandler.commonAPIException(ex);
        }
        return merchantProducts;

    }

}