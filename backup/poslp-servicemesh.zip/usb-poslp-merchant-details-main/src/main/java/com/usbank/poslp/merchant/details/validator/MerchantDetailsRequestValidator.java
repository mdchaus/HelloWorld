
package com.usbank.poslp.merchant.details.validator;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.usbank.api.core.component.requestcontext.IRequestContext;
import com.usbank.api.core.component.validator.BaseValidator;
import com.usbank.api.core.component.validator.IValidator;
import com.usbank.api.core.constant.USBConstants;
import com.usbank.api.core.exception.BadRequestException;
import com.usbank.poslp.merchant.details.constants.CustomErrorCodes;
import com.usbank.poslp.merchant.details.constants.MerchantDetailsConstants;
import com.usbank.poslp.merchant.details.model.request.ClientData;
import com.usbank.poslp.merchant.details.model.request.MerchantDetailsInput;
import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

@Component
public class MerchantDetailsRequestValidator extends BaseValidator
		implements IValidator<MerchantDetailsInput> {

	private final Logger logger = LogManager.getLogger(this.getClass());
	List<String> errors = new ArrayList<>();

	@Autowired
	private IRequestContext requestContext;

	@Autowired
	ObjectMapper objectMapper;

	@Override
	public void validate(MerchantDetailsInput request) {
		logger.debug("Started MerchantDetails Validator");
		errors.clear();
		validateHeaders(errors);
		if (Objects.isNull(request)) {
			logger.error("Request is empty");
			errors.add(CustomErrorCodes.INVALID_REQUEST.getErrorDescription());
			buildErrorMessage(errors, CustomErrorCodes.BAD_REQUEST_ERROR.getErrorCode(),
					StringUtils.EMPTY);
		} else {
			validateMandatoryInputs(request);
			validateMerchantId(request);
			logger.debug("Finished MerchantDetails request validation");
		}
	}

   	  private void validateHeaders(List<String> errors) {
		  if (StringUtils
				.isEmpty(requestContext.getHttpHeaders().get(MerchantDetailsConstants.CONTENT_TYPE.toLowerCase()))) {
			logger.error(CustomErrorCodes.BAD_HEADER_CONTENT.getErrorDescription());
			errors.add(CustomErrorCodes.BAD_HEADER_CONTENT.getErrorDescription());
			buildErrorMessage(errors, CustomErrorCodes.BAD_HEADER_CONTENT.getErrorCode(),
					StringUtils.EMPTY);
		}
		if (StringUtils
				.isEmpty(requestContext.getHttpHeaders().get(USBConstants.CORRELATION_ID.toLowerCase()))) {
			logger.error(CustomErrorCodes.BAD_HEADER_CORRELATION.getErrorDescription());
			errors.add(CustomErrorCodes.BAD_HEADER_CORRELATION.getErrorDescription());
			buildErrorMessage(errors, CustomErrorCodes.BAD_HEADER_CORRELATION.getErrorCode(),
					StringUtils.EMPTY);
		}
		if (StringUtils.isEmpty(requestContext.getHttpHeaders().get(USBConstants.CHANNEL_ID.toLowerCase()))) {
			logger.error(CustomErrorCodes.BAD_HEADER_CHANNEL.getErrorDescription());
			errors.add(CustomErrorCodes.BAD_HEADER_CHANNEL.getErrorDescription());
			buildErrorMessage(errors, CustomErrorCodes.BAD_HEADER_CHANNEL.getErrorCode(),
					StringUtils.EMPTY);
		}
		  if (StringUtils
				  .isEmpty(requestContext.getHttpHeaders().get(USBConstants.SESSION_ID.toLowerCase()))) {
			  logger.error(CustomErrorCodes.BAD_HEADER_SESSION.getErrorDescription());
			  errors.add(CustomErrorCodes.BAD_HEADER_SESSION.getErrorDescription());
			  buildErrorMessage(errors, CustomErrorCodes.BAD_HEADER_SESSION.getErrorCode(),
					  StringUtils.EMPTY);
		  }

		  if (StringUtils
				.isEmpty(requestContext.getHttpHeaders().get(USBConstants.APPLICATION_ID.toLowerCase()))) {
			logger.error(CustomErrorCodes.BAD_HEADER_APPLICATION.getErrorDescription());
			errors.add(CustomErrorCodes.BAD_HEADER_APPLICATION.getErrorDescription());
			buildErrorMessage(errors, CustomErrorCodes.BAD_HEADER_APPLICATION.getErrorCode(),
					StringUtils.EMPTY);
		}
		if (requestContext.getHttpHeaders().get(USBConstants.APPLICATION_ID.toLowerCase()).length() >
				MerchantDetailsConstants.APPLICATION_ID_HEADER_LENGTH_MAX) {
			logger.error(CustomErrorCodes.BAD_HEADER_APPLICATION.getErrorDescription());
			errors.add(CustomErrorCodes.BAD_HEADER_APPLICATION.getErrorDescription());
			buildErrorMessage(errors, CustomErrorCodes.BAD_HEADER_APPLICATION.getErrorCode(),
					StringUtils.EMPTY);
		}

	}
	private void validateMandatoryInputs(MerchantDetailsInput request){
			//MerchantID cannot be empty or null. No min	 max length enforcement yet.
			if ((StringUtils.isEmpty(request.getMerchantID())) || Objects.isNull(request.getMerchantID())) {
				logger.error(CustomErrorCodes.MERCHANT_ID_MISSING.getErrorCode(), CustomErrorCodes.MERCHANT_ID_MISSING.getErrorDescription());
				errors.add(CustomErrorCodes.MERCHANT_ID_MISSING.getErrorDescription());
				buildErrorMessage(errors, CustomErrorCodes.MERCHANT_ID_MISSING.getErrorCode(), CustomErrorCodes.MERCHANT_ID_MISSING.getErrorDescription());
			}
		}

	private void validateMerchantId(MerchantDetailsInput request) {
		if (org.apache.commons.lang3.StringUtils.isBlank(request.getMerchantID().toString())
				|| request.getMerchantID().toString().length() > 22) {
			logger.error("error while processing request field MerchantId can't be empty");
			throw new BadRequestException(CustomErrorCodes.INVALID_MERCHANT_INPUT.getErrorCode(),
					CustomErrorCodes.INVALID_MERCHANT_INPUT.getErrorDescription(), null,
					MerchantDetailsConstants.INVALID_MERCHANTID);
		}

	}



	public String getIdentifier() throws JsonProcessingException {
		logger.debug("values..." + requestContext.getHttpHeaders());
		ClientData clientData = this.objectMapper.readValue(requestContext.getHttpHeaders().get("clientdata"), ClientData.class);
		return clientData.getIdentifier();
	}

}