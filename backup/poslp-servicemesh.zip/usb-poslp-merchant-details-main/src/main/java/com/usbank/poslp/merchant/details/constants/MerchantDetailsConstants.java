package com.usbank.poslp.merchant.details.constants;

public class MerchantDetailsConstants {

	private MerchantDetailsConstants() {
		
	}
	
	public static final String API_ID = "45382";
	public static final String EMPTY_STRING = "";
	public static final String CONTENT_TYPE = "Content-Type";
	public static final String USBWEB = "USBWEB";
	public static final String BASIC = "Basic ";
	public static final String AUTHORIZATION = "Authorization";
	public static final String CORRELATION_ID = "Correlation-ID";
	public static final String APPLICATION_ID = "Application-ID";
	public static final String CHANNEL_ID = "Channel-ID";
	public static final String ACCEPT = "Accept";
	public static final String ACCEPT_ENCODING = "Accept-Encoding";
	public static final String ACCOUNT_TOKEN = "accountToken";
	public static final String MERCHANT_DETAILS_INPUT = "input";
	public static final String SHOPPING_CART = "ShoppingCartResponse";
	public static final String MERCHANT_ID = "merchantID";
	public static final String MERCHANT_ID_HEADER = "Merchant-ID";
	public static final String PARTNERID = "Partner-ID";

	public static final String APIGEE ="APIGEE";
	public static final int APPLICATION_ID_HEADER_LENGTH_MAX = 10;


	public static final String VERSION_URL = "/v1";
	public static final String MSG_BALANCE_NOT_FOUND = "DEPOSIT BALANCES NOT FOUND.";
	public static final String MSG_FANS_NOT_FOUND = "FANS API did not return a response.";
 	public static final String MSG_FAILURE_FANS_CALL = "Error: FANS API call was unsuccessful. Exception - ";
	public static final String MERCHANT_DETAIL_DOMAIN = "Merchant Details Domain";
	public static final String CIRCUIT_BREAKER_NAME = "Shopping cart CB";
	public static final String FIELD1 = "field1";
	public static final String FIELD2 = "field2";
	public static final String MSG_FAILURE_PROV_CALL = "Error: Provider API call was unsuccessful. Exception - ";

	public static final String PROJECT_CODE = "20479";
	public static final String  ERROR_CODE_DEFAULT="55555";

	public static final String GRAPHQL_API_ERROR_CODE = "errorCode";
	public static final String GRAPHQL_API_ERROR_MSG = "errorMessage";
	public static final String GRAPHQL_API_ERROR_KEY = "errorKey";
	public static final String GRAPHQL_API_ERROR_APIID = "apiID";

	public static final String GRAPHQL_VALIDATION_ERROR_CODE = "errorCode";
	public static final String GRAPHQL_VALIDATION_ERROR_MSG = "errorMessage";
	public static final String GRAPHQL_VALIDATION_ERROR_KEY = "errorKey";
	public static final String GRAPHQL_VALIDATION_ERROR_APIID = "apiID";
	public static final String REFER_TO_HELP_ME_PAGE_HELP = "Refer to help me page :";

	public static final String MSG_INVALID_DATE = "Not a valid Date";

	public static final String FANS_API_ERROR_CODE = "2014";
	public static final String DATA_ERROR_CODE = "2015";
	public static final String DATE_FORMAT_YYYY_MM_DD = "yyyy-MM-dd HH:mm:ss";
	public static final String REPRESENTATIONS = "representations";
	public static final String IDENTIFIER_TYPE = "identifierType";
	public static final String UNDERSCORE = "_";
	public static final String UID ="UID";

	public static final String REQUEST_CONTEXT = "requestContext";
	public static final String DDA = "DDA";
	public static final String CDA = "CDA";
	public static final String REA = "REA";

	public static final String ACH = "ACH";
	public static final String ACCOUNT_IDENTIFIER = "ACCOUNT_IDENTIFIER";
	public static final String INVALID_MERCHANTID = "MerchantId";

	public static final String CLOUD_APPLY = "CloudApply";

	/** Constants for merchant on-boarding implementation */
	public static final String DEFAULT_PRINCIPAL_TYPE = "Authorized Signer";
	public static final String GRANT_TYPE = "grant_type";
	public static final String CLIENT_ID = "client_id";
	public static final String CLIENT_SECRET = "client_secret";
	public static final String USERNAME = "username";
	public static final String PASSWORD = "password";
	public static final String BEARER = "Bearer ";
	
	/** Constant for merchant details validation */
	public static final int DDA_NUMBER_LENGTH = 5;

	/** Constants for SRS Get API */
	public static final String PRODESSING_CENTER_ID = "ProcessingCenterID";
	public static final String API_SOURCE = "ApiSource";
	public static final String ACCOUNT_MID = "AccountMid";
	public static final String CONTACT_ID = "ContactId";

	/** Constants for Circuit Breaker */
	public static final String CIRCUIT_BREAKER_VALIDATE_MERCHANT_DETAILS= "validateMerchantDetailsServiceCB";
	public static final String CIRCUIT_BREAKER_INVITE_TO_APPLY = "inviteToApplyServiceCB";
	public static final String STRING = "String";

}
