package com.usbank.poslp.merchant.details.handler;

import com.usbank.api.core.aspect.LogExecutionTime;
import com.usbank.api.core.component.requestcontext.IRequestContext;
import com.usbank.api.core.exception.SubsystemDataException;
import com.usbank.api.core.requesthandler.IRequestHandler;
import com.usbank.poslp.merchant.details.advice.MerchantExceptionHandler;
import com.usbank.poslp.merchant.details.model.request.ValidateMerchantDetails;
import com.usbank.poslp.merchant.details.model.response.ValidateMerchantResponse;
import com.usbank.poslp.merchant.details.model.response.apply.InviteToApplyResponse;
import com.usbank.poslp.merchant.details.service.InviteToApplyService;
import com.usbank.poslp.merchant.details.service.ValidateMerchantDetailsService;
import com.usbank.poslp.merchant.details.validator.MerchantDetailsValidator;
import io.github.resilience4j.circuitbreaker.annotation.CircuitBreaker;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import static com.usbank.poslp.merchant.details.constants.CustomErrorCodes.API_EXCEPTION;
import static com.usbank.poslp.merchant.details.constants.CustomErrorCodes.VALIDATE_API_EXCEPTION;
import static com.usbank.poslp.merchant.details.constants.MerchantDetailsConstants.CIRCUIT_BREAKER_INVITE_TO_APPLY;
import static com.usbank.poslp.merchant.details.constants.MerchantDetailsConstants.MERCHANT_DETAIL_DOMAIN;

@Service
@Slf4j
public class InviteToApplyHandler implements IRequestHandler<ValidateMerchantDetails, InviteToApplyResponse>{
	 
	 @Autowired
	 private MerchantExceptionHandler exceptionHandler;

	@Autowired
	private IRequestContext requestContext;

	@Autowired
	private MerchantDetailsValidator merchantDetailsValidator;

	@Autowired
	private ValidateMerchantDetailsService validateMerchantDetailsService;

	@Autowired
	private InviteToApplyService inviteToApplyService;

	@Override
	@LogExecutionTime
	@CircuitBreaker(name = CIRCUIT_BREAKER_INVITE_TO_APPLY)
	public InviteToApplyResponse handle(ValidateMerchantDetails validateMerchantDetails) throws Exception {
		log.debug("ValidateMerchantDetailsHandler call started.");
		ValidateMerchantResponse validateMerchantResponse;
		InviteToApplyResponse inviteToApplyResponse;

		try {
			/** First validate the inputs. */
			merchantDetailsValidator.validate(validateMerchantDetails);

			/** Call the SRS Api and find whether the merchant is valid or not. */
			validateMerchantResponse = validateMerchantDetailsService.process(validateMerchantDetails);

			/** If the merchant is not valid then throw the exception*/
			if(!validateMerchantResponse.isMerchantValid()) {
				log.error(API_EXCEPTION.getErrorDescription());
				throw new SubsystemDataException(VALIDATE_API_EXCEPTION.getErrorCode(), VALIDATE_API_EXCEPTION.getErrorDescription(), MERCHANT_DETAIL_DOMAIN);
			}

			/** Process the response */
			validateMerchantDetails.setToken(validateMerchantResponse.getToken());
			inviteToApplyResponse = inviteToApplyService.process(validateMerchantDetails);
			return inviteToApplyResponse;
		}catch (Exception ex) {
			log.error("Exception occurred in ValidateMerchantDetailsHandler and cause is {}", ex.getLocalizedMessage());
			throw exceptionHandler.commonAPIException(ex);
		}
	}
}
