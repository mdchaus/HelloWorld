
package com.usbank.poslp.merchant.details.validator;

import com.usbank.api.core.component.requestcontext.IRequestContext;
import com.usbank.api.core.component.validator.BaseValidator;
import com.usbank.api.core.exception.BadRequestException;
import com.usbank.poslp.merchant.details.constants.MerchantDetailsConstants;
import com.usbank.poslp.merchant.details.enums.ErrorCodes;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Objects;

@Component
public class MerchantHeaderValidator extends BaseValidator {

	private final Logger log = LoggerFactory.getLogger(this.getClass());

	@Autowired
	IRequestContext requestContext;

	public void validate(List<String> errors) {
		log.debug("Started --> Merchant Details API Header Validation");
		if ((StringUtils
				.isEmpty(requestContext.getHttpHeaders().get(MerchantDetailsConstants.CORRELATION_ID.toLowerCase())))
				|| (Objects.isNull(
						requestContext.getHttpHeaders().get(MerchantDetailsConstants.CORRELATION_ID.toLowerCase())))) {
			log.error(ErrorCodes.CORRELATION_ID_MISSING.getErrorCode(),
					ErrorCodes.CORRELATION_ID_MISSING.getErrorDescription());
			errors.add(ErrorCodes.CORRELATION_ID_MISSING.getErrorDescription());
			throw new BadRequestException(ErrorCodes.CORRELATION_ID_MISSING.getErrorCode(),
					ErrorCodes.CORRELATION_ID_MISSING.getErrorDescription(), null,
                    MerchantDetailsConstants.CORRELATION_ID);			
		}
		if ((StringUtils
				.isEmpty(requestContext.getHttpHeaders().get(MerchantDetailsConstants.APPLICATION_ID.toLowerCase())))
				|| (Objects.isNull(
						requestContext.getHttpHeaders().get(MerchantDetailsConstants.APPLICATION_ID.toLowerCase())))) {
			log.error(ErrorCodes.APPLICATION_ID_MISSING.getErrorCode(),
					ErrorCodes.APPLICATION_ID_MISSING.getErrorDescription());
			errors.add(ErrorCodes.APPLICATION_ID_MISSING.getErrorDescription());
			throw new BadRequestException(ErrorCodes.APPLICATION_ID_MISSING.getErrorCode(),
					ErrorCodes.APPLICATION_ID_MISSING.getErrorDescription(), null,
                    MerchantDetailsConstants.CORRELATION_ID);			
		}
		if ((StringUtils
				.isEmpty(requestContext.getHttpHeaders().get(MerchantDetailsConstants.CONTENT_TYPE.toLowerCase())))
				|| (Objects.isNull(
						requestContext.getHttpHeaders().get(MerchantDetailsConstants.CONTENT_TYPE.toLowerCase())))) {
			log.error(ErrorCodes.CONTENT_TYPE_MISSING.getErrorCode(),
					ErrorCodes.CONTENT_TYPE_MISSING.getErrorDescription());
			errors.add(ErrorCodes.CONTENT_TYPE_MISSING.getErrorDescription());
			throw new BadRequestException(ErrorCodes.CONTENT_TYPE_MISSING.getErrorCode(),
					ErrorCodes.CONTENT_TYPE_MISSING.getErrorDescription(), null,
                    MerchantDetailsConstants.CONTENT_TYPE);			
		}
		if ((StringUtils.isEmpty(requestContext.getHttpHeaders().get(MerchantDetailsConstants.CHANNEL_ID.toLowerCase())))
				|| (Objects.isNull(requestContext.getHttpHeaders().get(MerchantDetailsConstants.CHANNEL_ID.toLowerCase())))) {
			log.error(ErrorCodes.CHANNEL_ID_MISSING.getErrorCode(), ErrorCodes.CHANNEL_ID_MISSING.getErrorDescription());
			errors.add(ErrorCodes.CHANNEL_ID_MISSING.getErrorDescription());
			throw new BadRequestException(ErrorCodes.CHANNEL_ID_MISSING.getErrorCode(),
					ErrorCodes.CHANNEL_ID_MISSING.getErrorDescription(), null,
                    MerchantDetailsConstants.CHANNEL_ID);			
		}

		log.debug("Ended --> Merchant Details API Header Validation");
	}

}
