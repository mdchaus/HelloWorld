package com.usbank.poslp.merchant.details.repository;

import com.usbank.api.core.jpa.repository.PoslpRepository;
import com.usbank.poslp.commons.entities.MerchantPartnerConfiguration;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.UUID;

@Repository
public interface MerchantPartnerConfigurationRepository extends PoslpRepository<MerchantPartnerConfiguration, UUID> {

    List<MerchantPartnerConfiguration> findByMerchantIdAndPartnerGuid(String merchantId, UUID partnerGuid);

}
