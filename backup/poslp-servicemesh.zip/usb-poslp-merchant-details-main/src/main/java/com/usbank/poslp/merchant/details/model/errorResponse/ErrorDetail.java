package com.usbank.poslp.merchant.details.model.errorResponse;


public class ErrorDetail {

	private String attributeName;
	private String reason;
	private String attributeValue;

	public String getAttributeName() {
		return attributeName;
	}

	public void setAttributeName(String attributeName) {
		this.attributeName = attributeName;
	}

	public String getReason() {
		return reason;
	}

	public void setReason(String reason) {
		this.reason = reason;
	}

	@Override
	public String toString() {
		return "ErrorDetail [attributeName=" + attributeName + ", reason=" + reason + "]";
	}

    public void setAttributeValue(String attributeValue) {
        this.attributeValue = attributeValue;
    }

    public String getAttributeValue() {
        return attributeValue;
    }
}
