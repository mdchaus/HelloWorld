package com.usbank.poslp.merchant.details.model.response.apply;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

@Data
public class InviteToApplyResponse {

    @JsonProperty("applyUrl")
    private String applyUrl;

}
