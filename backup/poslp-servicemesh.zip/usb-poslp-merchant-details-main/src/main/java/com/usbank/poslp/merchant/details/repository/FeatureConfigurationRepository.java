package com.usbank.poslp.merchant.details.repository;

import com.usbank.api.core.jpa.repository.PoslpRepository;
import com.usbank.poslp.commons.entities.FeatureConfiguration;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.UUID;

@Repository
public interface FeatureConfigurationRepository extends PoslpRepository<FeatureConfiguration, UUID> {
    @Query("SELECT fc FROM FeatureConfiguration fc " +
            "WHERE (upper(fc.featureCategoryType) = 'MID' AND fc.featureCategoryValue = :merchantId) " +
            "   OR (upper(fc.featureCategoryType) = 'MCC' AND fc.featureCategoryValue IN (SELECT CAST(m.mccCode AS string) FROM Merchant m WHERE m.merchantId = :merchantId) " +
            "   AND fc.partnerId in (SELECT mpc.partnerGuid FROM MerchantPartnerConfiguration mpc JOIN Merchant m ON mpc.merchantId = m.merchantId WHERE m.merchantId = :merchantId)" +
            "   AND fc.configurationName not in (select fc2.configurationName from FeatureConfiguration fc2 where fc.configurationName = fc2.configurationName and upper(fc2.featureCategoryType) = 'MID' and fc2.featureCategoryValue= :merchantId)) " +
            "   OR (upper(fc.featureCategoryType) = 'MCC' AND fc.featureCategoryValue IN (SELECT CAST(m.mccCode AS string) FROM Merchant m WHERE m.merchantId = :merchantId) " +
            "   AND fc.partnerId is null and fc.configurationName not in (select fc2.configurationName from FeatureConfiguration fc2 where fc.configurationName = fc2.configurationName " +
            "   AND ((upper(fc2.featureCategoryType) = 'MID' and fc2.featureCategoryValue= :merchantId) or (upper(fc2.featureCategoryType) = 'MCC' and fc2.partnerId in (SELECT mpc.partnerGuid FROM MerchantPartnerConfiguration mpc JOIN Merchant m ON mpc.merchantId = m.merchantId WHERE m.merchantId = :merchantId) and fc2.featureCategoryValue IN (SELECT CAST(m.mccCode AS string) FROM Merchant m WHERE m.merchantId = :merchantId and fc2.partnerId is not null and upper(fc2.featureCategoryType) = 'MCC'))))) " +
            "   OR (upper(fc.featureCategoryType) = 'PARTNER' AND fc.featureCategoryValue IN (SELECT CAST(mpc.partnerGuid AS string) FROM MerchantPartnerConfiguration mpc JOIN Merchant m ON mpc.merchantId = m.merchantId WHERE m.merchantId = :merchantId) " +
            "   AND fc.configurationName not in (select fc2.configurationName from FeatureConfiguration fc2 where fc.configurationName = fc2.configurationName AND (fc2.featureCategoryValue = :merchantId and upper(fc2.featureCategoryType) = 'MID') " +
            "   OR (fc2.featureCategoryValue IN (SELECT CAST(m.mccCode AS string) FROM Merchant m WHERE m.merchantId = :merchantId and fc2.partnerId is null and upper(fc2.featureCategoryType) = 'MCC')) OR (fc2.partnerId IN (SELECT mpc.partnerGuid FROM MerchantPartnerConfiguration mpc JOIN Merchant m ON mpc.merchantId = m.merchantId WHERE m.merchantId = :merchantId and upper(fc2.featureCategoryType) = 'MCC') and fc2.featureCategoryValue IN (SELECT CAST(m.mccCode AS string) FROM Merchant m WHERE m.merchantId = :merchantId and fc2.partnerId is not null and upper(fc2.featureCategoryType) = 'MCC')))) " +
            "   OR (upper(fc.featureCategoryType) = 'GLOBAL' AND fc.configurationName not in (select fc2.configurationName from FeatureConfiguration fc2 where fc.configurationName = fc2.configurationName AND ((fc2.featureCategoryValue = :merchantId and upper(fc2.featureCategoryType) = 'MID') " +
            "   OR (fc2.featureCategoryValue IN (SELECT CAST(m.mccCode AS string) FROM Merchant m WHERE m.merchantId = :merchantId and fc2.partnerId is null and upper(fc2.featureCategoryType) = 'MCC')) OR (fc2.partnerId IN (SELECT mpc.partnerGuid FROM MerchantPartnerConfiguration mpc JOIN Merchant m ON mpc.merchantId = m.merchantId WHERE m.merchantId = :merchantId and upper(fc2.featureCategoryType) = 'MCC') and fc2.featureCategoryValue IN (SELECT CAST(m.mccCode AS string) FROM Merchant m WHERE m.merchantId = :merchantId and fc2.partnerId is not null and upper(fc2.featureCategoryType) = 'MCC'))" +
            "   OR (fc2.featureCategoryValue IN (SELECT CAST(mpc.partnerGuid AS string) FROM MerchantPartnerConfiguration mpc JOIN Merchant m ON mpc.merchantId = m.merchantId WHERE m.merchantId = :merchantId and upper(fc2.featureCategoryType) = 'PARTNER'))))) ")
    public List<FeatureConfiguration> findByFeatureConfig(String merchantId);
}
