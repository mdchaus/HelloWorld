package com.usbank.poslp.merchant.details.handler;

import com.usbank.api.core.component.requestcontext.IRequestContext;
import com.usbank.api.core.constant.USBConstants;
import com.usbank.poslp.merchant.details.advice.MerchantExceptionHandler;
import com.usbank.poslp.merchant.details.constants.MerchantDetailsConstants;
import com.usbank.poslp.merchant.details.model.request.MerchantDetailsInput;
import com.usbank.poslp.merchant.details.model.response.MerchantDetails;
import com.usbank.poslp.merchant.details.service.MerchantDetailsService;
import com.usbank.poslp.merchant.details.validator.MerchantDetailsRequestValidator;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;

import java.util.HashMap;
import java.util.Map;

import static org.junit.Assert.assertNotNull;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class MerchantDetailsHandlerTest {
	
	@InjectMocks
	private MerchantDetailsHandler merchantDetailsHandler;

	@Mock
	private MerchantDetailsService merchantDetailsService;

	@Mock
	MerchantDetailsRequestValidator merchantRequestValidator;

	@Mock
	private MerchantExceptionHandler exceptionHandler;

	@Mock
	private IRequestContext requestContext;

	@Test
	public void handleTest() throws Exception {
		Map<String, String> map = new HashMap<>();
		map.put(USBConstants.CLIENT_ID, MerchantDetailsConstants.APIGEE);
	    MerchantDetails merchantDetails=MerchantDetails.builder().accountStatus("Active").build();
		when(requestContext.getHttpHeaders()).thenReturn(map);
		Mockito.when(merchantDetailsService.process(Mockito.any())).thenReturn(merchantDetails);
		assertNotNull(merchantDetailsHandler.handle(new MerchantDetailsInput()));

	}
	@Test
	public void handleTest1() throws Exception {
		Map<String, String> map = new HashMap<>();
		map.put(USBConstants.CLIENT_ID, MerchantDetailsConstants.USBWEB);
		MerchantDetails merchantDetails=MerchantDetails.builder().accountStatus("Active").build();
		when(requestContext.getHttpHeaders()).thenReturn(map);
		Mockito.when(merchantDetailsService.process(Mockito.any())).thenReturn(merchantDetails);
		assertNotNull(merchantDetailsHandler.handle(null));

	}

	@Test
	public void handleTestWithMidFromHeader() throws Exception {
		Map<String, String> map = new HashMap<>();
		Map<String, String> clientData = new HashMap<>();
		clientData.put("ChannelID","web");
		map.put(USBConstants.CLIENT_ID, MerchantDetailsConstants.APIGEE);
		map.put("clientdata", clientData.toString());
		when(requestContext.getHttpHeaders()).thenReturn(map);
		when(merchantRequestValidator.getIdentifier()).thenReturn("testMidFromHeader");

		MerchantDetails merchantDetails = MerchantDetails.builder().accountStatus("Active").build();
		when(merchantDetailsService.process(Mockito.any())).thenReturn(merchantDetails);

		MerchantDetailsInput input = new MerchantDetailsInput();
		input.setMerchantID("originalMid");

		MerchantDetails result = merchantDetailsHandler.handle(input);

		assertNotNull(result);
		Mockito.verify(merchantRequestValidator).validate(Mockito.argThat(argument -> "testMidFromHeader".equals(argument.getMerchantID())));
	}

	/**
	 * Commented this test as rest of all the tests are JUNIT5 Unit Test and this alone is JUNIT4 unit test.
	 * Unit Tests fail with this test.
	@org.junit.Test(expected = NullPointerException.class)
	public void handleTestException() throws	  Exception {
		Mockito.when(exceptionHandler.commonAPIException(Mockito.any())).thenThrow(new BadRequestException("400","Bad request"));
		merchantDetailsHandler.handle(null);

	}*/




}
