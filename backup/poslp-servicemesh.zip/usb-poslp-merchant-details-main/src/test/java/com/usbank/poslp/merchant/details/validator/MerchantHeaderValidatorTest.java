
package com.usbank.poslp.merchant.details.validator;

import com.usbank.api.core.component.requestcontext.IRequestContext;
import com.usbank.api.core.component.validator.BaseValidator;
import com.usbank.api.core.exception.BadRequestException;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class MerchantHeaderValidatorTest{

	@InjectMocks
	MerchantHeaderValidator merchantHeaderValidator;

	@Mock
	BaseValidator baseValidator;
	@Mock
	IRequestContext requestContext;

	@Test
	public void testExceptionWhenNoCorrelationIdHeader() {
		List<String> errors=new ArrayList<>();
		Map<String, String> headerMap = new HashMap<>();
		//headerMap.put("correlation-id", "9900887766556");
		headerMap.put("application-id", "WEB");
		headerMap.put("clientdata", "clientData");
		headerMap.put("channel-id", "owa");
		headerMap.put("session-id", "12345");
		when(requestContext.getHttpHeaders()).thenReturn(headerMap);
		assertThrows(BadRequestException.class, () -> merchantHeaderValidator.validate(errors));
	}

	@Test
	public void testExceptionWhenNoApplicationIdHeader() {
		List<String> errors=new ArrayList<>();
		Map<String, String> headerMap = new HashMap<>();
		headerMap.put("correlation-id", "9900887766556");
		headerMap.put("clientdata", "clientData");
		headerMap.put("channel-id", "owa");
		headerMap.put("session-id", "12345");
		when(requestContext.getHttpHeaders()).thenReturn(headerMap);
		assertThrows(BadRequestException.class, () -> merchantHeaderValidator.validate(errors));
	}

	@Test
	public void testExceptionWhenNoContentType() {
		List<String> errors=new ArrayList<>();
		Map<String, String> headerMap = new HashMap<>();
		headerMap.put("correlation-id", "9900887766556");
		headerMap.put("application-id", "WEB");
		headerMap.put("clientdata", "clientData");
		headerMap.put("channel-id", "owa");
		headerMap.put("session-id", "12345");
		when(requestContext.getHttpHeaders()).thenReturn(headerMap);
		assertThrows(BadRequestException.class, () -> merchantHeaderValidator.validate(errors));
	}

	@Test
	public void testExceptionWhenNoChannelId() {
		List<String> errors=new ArrayList<>();
		Map<String, String> headerMap = new HashMap<>();
		headerMap.put("correlation-id", "9900887766556");
		headerMap.put("application-id", "WEB");
		headerMap.put("clientdata", "clientData");
		headerMap.put("content-type", "application/json");
		headerMap.put("session-id", "12345");
		when(requestContext.getHttpHeaders()).thenReturn(headerMap);
		assertThrows(BadRequestException.class, () -> merchantHeaderValidator.validate(errors));
	}



}
