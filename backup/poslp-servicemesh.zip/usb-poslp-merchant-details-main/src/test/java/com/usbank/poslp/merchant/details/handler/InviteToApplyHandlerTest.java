package com.usbank.poslp.merchant.details.handler;

import com.usbank.api.core.exception.PoslpAPIException;
import com.usbank.api.core.exception.SubsystemDataException;
import com.usbank.api.core.exception.SubsystemUnavailableException;
import com.usbank.poslp.merchant.details.advice.MerchantExceptionHandler;
import com.usbank.poslp.merchant.details.model.request.ValidateMerchantDetails;
import com.usbank.poslp.merchant.details.model.response.ValidateMerchantResponse;
import com.usbank.poslp.merchant.details.model.response.apply.InviteToApplyResponse;
import com.usbank.poslp.merchant.details.service.InviteToApplyService;
import com.usbank.poslp.merchant.details.service.ValidateMerchantDetailsService;
import com.usbank.poslp.merchant.details.validator.MerchantDetailsValidator;
import org.junit.Test;
import org.junit.jupiter.api.Assertions;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;

@RunWith(MockitoJUnitRunner.class)
public class InviteToApplyHandlerTest {

    @Mock
    private MerchantExceptionHandler exceptionHandler;

    @Mock
    private MerchantDetailsValidator merchantDetailsValidator;

    @Mock
    private ValidateMerchantDetailsService validateMerchantDetailsService;

    @Mock
    private InviteToApplyService inviteToApplyService;

    @InjectMocks
    private InviteToApplyHandler inviteToApplyHandler;

    @Test
    public void testHandle() throws Exception {
        ValidateMerchantDetails validateMerchantDetails = getValidateMerchantDetails();

        ValidateMerchantResponse validateMerchantResponse = new ValidateMerchantResponse();
        validateMerchantResponse.setMerchantValid(true);
        validateMerchantResponse.setToken("test1234");
        InviteToApplyResponse inviteToApplyResponse = new InviteToApplyResponse();
        inviteToApplyResponse.setApplyUrl("dummyURL");

        Mockito.when(validateMerchantDetailsService.process(validateMerchantDetails))
                        .thenReturn(validateMerchantResponse);
        Mockito.when(inviteToApplyService.process(validateMerchantDetails))
                        .thenReturn(inviteToApplyResponse);

        InviteToApplyResponse inviteToApplyResponseActual = inviteToApplyHandler.handle(validateMerchantDetails);
        Assertions.assertEquals(inviteToApplyResponse.getApplyUrl(), inviteToApplyResponseActual.getApplyUrl());
    }

    @Test
    public void testHandle_WhenMerchantIsInvalid() throws Exception {
        ValidateMerchantDetails validateMerchantDetails = getValidateMerchantDetails();

        ValidateMerchantResponse validateMerchantResponse = new ValidateMerchantResponse();
        validateMerchantResponse.setMerchantValid(false);
        validateMerchantResponse.setToken("test1234");
        PoslpAPIException poslpAPIException = new PoslpAPIException("500", "Something went wrong");

        Mockito.when(validateMerchantDetailsService.process(validateMerchantDetails))
                .thenReturn(validateMerchantResponse);
        Mockito.when(exceptionHandler.commonAPIException(Mockito.any(SubsystemDataException.class)))
                .thenReturn(poslpAPIException);

        PoslpAPIException poslpAPIExceptionActual = Assertions.assertThrows(PoslpAPIException.class,
                () -> inviteToApplyHandler.handle(validateMerchantDetails));
        Assertions.assertNotNull(poslpAPIExceptionActual);
        Assertions.assertEquals(poslpAPIException.getErrorCode(), poslpAPIExceptionActual.getErrorCode());
        Assertions.assertEquals(poslpAPIException.getErrorMessage(), poslpAPIExceptionActual.getErrorMessage());
    }

    private ValidateMerchantDetails getValidateMerchantDetails() {
        ValidateMerchantDetails validateMerchantDetails = new ValidateMerchantDetails();
        validateMerchantDetails.setAccountMid("12345");
        validateMerchantDetails.setApiSource("Converge");
        validateMerchantDetails.setContactFirstName("Test");
        validateMerchantDetails.setContactLastName("Test");
        validateMerchantDetails.setDDANumber("test12345");
        validateMerchantDetails.setProcessingCenterID("testCenter");
        validateMerchantDetails.setSSNorTaxId("testTaxId");
        return validateMerchantDetails;
    }
}
