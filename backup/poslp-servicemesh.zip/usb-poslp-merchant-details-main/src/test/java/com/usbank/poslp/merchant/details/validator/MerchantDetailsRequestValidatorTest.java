package com.usbank.poslp.merchant.details.validator;

import com.usbank.api.core.component.auditlog.Audit;
import com.usbank.api.core.component.requestcontext.IRequestContext;
import com.usbank.api.core.exception.BadRequestException;
import com.usbank.api.core.model.Session;
import com.usbank.poslp.merchant.details.config.MerchantDetailsApiConfig;
import com.usbank.poslp.merchant.details.model.request.MerchantDetailsInput;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;

import java.util.HashMap;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.fail;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class MerchantDetailsRequestValidatorTest {

    @InjectMocks
    private MerchantDetailsRequestValidator validator;

    @Mock
    private IRequestContext requestContext;


    @Mock
    private MerchantDetailsApiConfig merchantDetailsApiConfig;

    @Before
    public void setup() {

        Map<String, String> headerMap = new HashMap<>();
        headerMap.put("Content-Type", "application/json");
        headerMap.put("correlation-id", "9900887766556");
        headerMap.put("application-id", "WEB");
        headerMap.put("clientdata", "clientData");
        headerMap.put("channel-id", "owa");
        headerMap.put("session-id", "12345");
        requestContext.setHttpHeaders(headerMap);
        // when(requestContext.getHttpHeaders()).thenReturn(headerMap);
    }


    @Test
    public void testExceptionWhenNoContentTypeHeader() {
        Map<String, String> headerMap = new HashMap<>();
        headerMap.put("correlation-id", "9900887766556");
        headerMap.put("application-id", "WEB");
        headerMap.put("clientdata", "clientData");
        headerMap.put("channel-id", "owa");
        headerMap.put("session-id", "12345");
        when(requestContext.getHttpHeaders()).thenReturn(headerMap);
        assertThrows(BadRequestException.class, () -> validator.validate(new MerchantDetailsInput()));
    }

    @Test
    public void testExceptionWhenNoCorrelationIdHeader() {
        Map<String, String> headerMap = new HashMap<>();
        headerMap.put("content-type", "application/json");
        headerMap.put("application-id", "WEB");
        headerMap.put("clientdata", "clientData");
        headerMap.put("channel-id", "owa");
        headerMap.put("session-id", "12345");
        when(requestContext.getHttpHeaders()).thenReturn(headerMap);
        assertThrows(BadRequestException.class, () -> validator.validate(new MerchantDetailsInput()));
    }

    @Test
    public void testExceptionWhenNoApplicationIdHeader() {
        Map<String, String> headerMap = new HashMap<>();
        headerMap.put("content-type", "application/json");
        headerMap.put("correlation-id", "9900887766556");
        headerMap.put("clientdata", "clientData");
        headerMap.put("channel-id", "owa");
        headerMap.put("session-id", "12345");
        when(requestContext.getHttpHeaders()).thenReturn(headerMap);
        assertThrows(BadRequestException.class, () -> validator.validate(new MerchantDetailsInput()));
    }

    @Test
    public void testExceptionWhenNoClientDataHeader() {
        Map<String, String> headerMap = new HashMap<>();
        headerMap.put("content-type", "application/json");
        headerMap.put("correlation-id", "9900887766556");
        headerMap.put("application-id", "WEB");
        headerMap.put("channel-id", "owa");
        headerMap.put("session-id", "12345");
        when(requestContext.getHttpHeaders()).thenReturn(headerMap);
        assertThrows(BadRequestException.class, () -> validator.validate(new MerchantDetailsInput()));
    }

    @Test
    public void testExceptionWhenNoChannelIdHeader() {
        Map<String, String> headerMap = new HashMap<>();
        headerMap.put("content-type", "application/json");
        headerMap.put("correlation-id", "9900887766556");
        headerMap.put("application-id", "WEB");
        headerMap.put("clientdata", "clientData");
        headerMap.put("session-id", "12345");
        when(requestContext.getHttpHeaders()).thenReturn(headerMap);
        assertThrows(BadRequestException.class, () -> validator.validate(new MerchantDetailsInput()));
    }

    @Test
    public void testExceptionWhenNoSessionIdHeader() {
        Map<String, String> headerMap = new HashMap<>();
        headerMap.put("content-type", "application/json");
        headerMap.put("correlation-id", "9900887766556");
        headerMap.put("application-id", "WEB");
        headerMap.put("clientdata", "clientData");
        headerMap.put("channel-id", "owa");
        when(requestContext.getHttpHeaders()).thenReturn(headerMap);
        assertThrows(BadRequestException.class, () -> validator.validate(new MerchantDetailsInput()));
    }

    @Test
    public void testExceptionWhenApplicationIdHeaderExceedsLength() {
        MerchantDetailsInput merchantDetailsInput = new MerchantDetailsInput();
        merchantDetailsInput.setMerchantID("902536814590253681459025368145234");
        Map<String, String> headerMap = new HashMap<>();
        headerMap.put("content-type", "application/json");
        headerMap.put("correlation-id", "9900887766556");
        headerMap.put("application-id", "123456789015544");
        headerMap.put("clientdata", "clientData");
        headerMap.put("channel-id", "owa");
        headerMap.put("session-id", "12345");
        when(requestContext.getHttpHeaders()).thenReturn(headerMap);
        assertThrows(BadRequestException.class, () -> validator.validate(merchantDetailsInput));
    }

    @Test
    public void testExceptionWhenMerhcantIdExceedsLength() {
        MerchantDetailsInput merchantDetailsInput = new MerchantDetailsInput();
        merchantDetailsInput.setMerchantID("902536814590253681459025368145234");
        Map<String, String> headerMap = new HashMap<>();
        headerMap.put("content-type", "application/json");
        headerMap.put("correlation-id", "9900887766556");
        headerMap.put("application-id", "1234567890");
        headerMap.put("clientdata", "clientData");
        headerMap.put("channel-id", "owa");
        headerMap.put("session-id", "12345");
        when(requestContext.getHttpHeaders()).thenReturn(headerMap);
        assertThrows(BadRequestException.class, () -> validator.validate(merchantDetailsInput));
    }


    @Test
    public void testExceptionWhenRequestObjectIsNull() {
        Map<String, String> headerMap = new HashMap<>();
        headerMap.put("content-type", "application/json");
        headerMap.put("correlation-id", "9900887766556");
        headerMap.put("application-id", "1234567890");
        headerMap.put("clientdata", "clientData");
        headerMap.put("channel-id", "owa");
        headerMap.put("session-id", "12345");
        when(requestContext.getHttpHeaders()).thenReturn(headerMap);
        assertThrows(BadRequestException.class, () -> validator.validate(null));
    }

    @Test
    public void testExceptionWhenMerchantIdIsMissing() {
        Map<String, String> headerMap = new HashMap<>();
        headerMap.put("content-type", "application/json");
        headerMap.put("correlation-id", "9900887766556");
        headerMap.put("application-id", "1234567890");
        headerMap.put("clientdata", "clientData");
        headerMap.put("channel-id", "owa");
        headerMap.put("session-id", "12345");
        MerchantDetailsInput ip = new MerchantDetailsInput();
//        ip.setMerchantID("123-234-6545-5645-45334-3434");
        assertThrows(BadRequestException.class, () -> validator.validate(ip));
    }

    @Test
    public void testExceptionWhenMerchantIdIsExceeds() {
        Map<String, String> headerMap = new HashMap<>();
        headerMap.put("content-type", "application/json");
        headerMap.put("correlation-id", "9900887766556");
        headerMap.put("application-id", "1234567890");
        headerMap.put("clientdata", "clientData");
        headerMap.put("channel-id", "owa");
        headerMap.put("session-id", "12345");
        MerchantDetailsInput ip = new MerchantDetailsInput();
        ip.setMerchantID("123-234-6545-5645-45334-3434");
        assertThrows(BadRequestException.class, () -> validator.validate(ip));
    }

    @Test
    public void testValidateMandatoryInputs() {
        Map<String, String> headerMap = new HashMap<>();
        headerMap.put("content-type", "application/json");
        headerMap.put("correlation-id", "9900887766556");
        headerMap.put("application-id", "1234567890");
        headerMap.put("clientdata", "clientData");
        headerMap.put("channel-id", "owa");
        headerMap.put("session-id", "12345");
        MerchantDetailsInput ip = new MerchantDetailsInput();
        assertThrows(BadRequestException.class, () -> validator.validate(ip));
    }

    @Test
    public void testSuccessfulValidationWithValidInput() {
        MerchantDetailsInput merchantDetailsInput = new MerchantDetailsInput();
        merchantDetailsInput.setMerchantID("212345");
        Map<String, String> headerMap = new HashMap<>();
        headerMap.put("content-type", "application/json");
        headerMap.put("correlation-id", "9900887766556");
        headerMap.put("application-id", "1234564");
        headerMap.put("clientdata", "clientData");
        headerMap.put("channel-id", "owa");
        headerMap.put("session-id", "12345");
        when(requestContext.getHttpHeaders()).thenReturn(headerMap);
        try {
            validator.validate(merchantDetailsInput);
        } catch (Exception ex) {
            fail("Test Case Failied..");
        }

    }


}