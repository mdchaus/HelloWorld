package com.usbank.poslp.merchant.details.handler;


import com.usbank.api.core.exception.BadRequestException;
import com.usbank.poslp.merchant.details.advice.MerchantExceptionHandler;
import com.usbank.poslp.merchant.details.constants.CustomErrorCodes;
import com.usbank.poslp.merchant.details.model.request.MerchantPreApprovalLinkRequest;
import com.usbank.poslp.merchant.details.service.MerchantPreApprovalLinkService;
import com.usbank.poslp.merchant.details.utils.MerchantConfigurationUtils;
import com.usbank.poslp.merchant.details.validator.MerchantHeaderValidator;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;

import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class MerchantPreApprovalLinkHandlerTest {

    @Mock
    private MerchantPreApprovalLinkService merchantPreApprovalLinkService;

    @Mock
    private MerchantExceptionHandler exceptionHandler;

    @InjectMocks
    private MerchantPreApprovalLinkHandler merchantPreApprovalLinkHandler;

    @Mock
    private MerchantConfigurationUtils merchantConfigurationUtils;

    @Mock
    private MerchantHeaderValidator merchantHeaderValidator;

    @Test
    public void validateRequest_WithEmptyRequest() {
        MerchantPreApprovalLinkRequest request=null;
        BadRequestException exe = new BadRequestException(CustomErrorCodes.INVALID_REQUEST.getErrorCode(),
                CustomErrorCodes.INVALID_REQUEST.getErrorDescription());

        Mockito.when(exceptionHandler.commonAPIException(any())).thenThrow(exe);
        assertThrows(BadRequestException.class, () ->merchantPreApprovalLinkHandler.handle(request));
    }



    @Test
    public void validateRequest_WithInvalidPartnerMerchantId() {
        MerchantPreApprovalLinkRequest request=new MerchantPreApprovalLinkRequest();
        request.setMerchantID("86466726752");
        request.setPartnerId("Rectangle");
        BadRequestException exe = new BadRequestException(CustomErrorCodes.PARTNER_MID_VALIDATION_FAILED.getErrorCode(),
                CustomErrorCodes.PARTNER_MID_VALIDATION_FAILED.getErrorDescription());
        doThrow(exe).when(merchantConfigurationUtils).validatePartnerAndMerchantID(any(), any());
        when(exceptionHandler.commonAPIException(any())).thenThrow(exe);
        assertThrows(BadRequestException.class, () ->merchantPreApprovalLinkHandler.handle(request));
    }

    @Test
    public void validateRequest_WithInvalidMerchantId() {
        MerchantPreApprovalLinkRequest request=new MerchantPreApprovalLinkRequest();
        request.setMerchantID("86466726752");
        request.setPartnerId("Rectangle");

        BadRequestException exe = new BadRequestException(CustomErrorCodes.MERCHANT_VALIDATION_FAILED.getErrorCode(),
                CustomErrorCodes.MERCHANT_VALIDATION_FAILED.getErrorDescription());
        doThrow(exe).when(merchantConfigurationUtils).validatePartnerAndMerchantID(any(), any());
        when(exceptionHandler.commonAPIException(any())).thenThrow(exe);
        assertThrows(BadRequestException.class, () ->merchantPreApprovalLinkHandler.handle(request));
    }

    @Test
    public void validateRequest_WithInvalidPartnerId() {
        MerchantPreApprovalLinkRequest request=new MerchantPreApprovalLinkRequest();
        request.setMerchantID("86466726752");
        request.setPartnerId("Rectangle");
        BadRequestException exe = new BadRequestException(CustomErrorCodes.PARTNER_VALIDATION_FAILED.getErrorCode(), CustomErrorCodes.PARTNER_VALIDATION_FAILED.getErrorDescription());
        doThrow(exe).when(merchantConfigurationUtils).validatePartnerAndMerchantID(any(), any());
        when(exceptionHandler.commonAPIException(any())).thenThrow(exe);
        assertThrows(BadRequestException.class, () ->merchantPreApprovalLinkHandler.handle(request));
    }


}
