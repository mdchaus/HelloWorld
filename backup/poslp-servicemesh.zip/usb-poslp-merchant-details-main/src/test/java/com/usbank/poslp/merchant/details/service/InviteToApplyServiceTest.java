package com.usbank.poslp.merchant.details.service;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.usbank.api.core.exception.SubsystemDataException;
import com.usbank.api.core.exception.SubsystemUnavailableException;
import com.usbank.poslp.core.clients.http.InternalAPIClient;
import com.usbank.poslp.merchant.details.model.request.ValidateMerchantDetails;
import com.usbank.poslp.merchant.details.model.response.apply.ApplyInvitationServiceResponse;
import com.usbank.poslp.merchant.details.model.response.apply.InviteToApplyResponse;
import com.usbank.poslp.merchant.details.utils.ApiUtils;
import io.github.resilience4j.circuitbreaker.CallNotPermittedException;
import org.junit.Test;
import org.junit.jupiter.api.Assertions;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.http.HttpStatus;
import org.springframework.test.util.ReflectionTestUtils;

import java.util.HashMap;

@RunWith(MockitoJUnitRunner.class)
public class InviteToApplyServiceTest {

    @Mock
    private ObjectMapper objectMapper;

    @Mock
    private InternalAPIClient internalAPIClient;

    @Mock
    private ApiUtils apiUtils;

    @InjectMocks
    private InviteToApplyService inviteToApplyService;

    @Test
    public void testPorcess() throws Exception {
        ValidateMerchantDetails validateMerchantDetails = new ValidateMerchantDetails();
        ApplyInvitationServiceResponse applyInvitationServiceResponse = new ApplyInvitationServiceResponse();
        applyInvitationServiceResponse.setApplyUrl("dummyURL");

        Mockito.when(internalAPIClient.post(Mockito.anyString(), Mockito.any(), Mockito.any(HashMap.class), Mockito.any()))
                        .thenReturn(applyInvitationServiceResponse);

        InviteToApplyResponse inviteToApplyResponse = inviteToApplyService.process(validateMerchantDetails);

        Assertions.assertEquals("dummyURL", inviteToApplyResponse.getApplyUrl());
    }

    @Test
    public void  testProcess_WhenCallNotPermittedException() throws Exception {
        ValidateMerchantDetails validateMerchantDetails = new ValidateMerchantDetails();

        Mockito.when(internalAPIClient.post(Mockito.anyString(), Mockito.any(), Mockito.any(HashMap.class), Mockito.any()))
                .thenThrow(CallNotPermittedException.class);

        CallNotPermittedException callNotPermittedException = Assertions.assertThrows(CallNotPermittedException.class,
                () -> inviteToApplyService.process(validateMerchantDetails));
        Assertions.assertNotNull(callNotPermittedException);
    }

    @Test
    public void  testProcess_WhenSubsystemDataException() throws Exception {
        ValidateMerchantDetails validateMerchantDetails = new ValidateMerchantDetails();
        SubsystemDataException subsystemDataException = new SubsystemDataException("dummyURL", HttpStatus.FAILED_DEPENDENCY, "dummyBody");

        Mockito.when(internalAPIClient.post(Mockito.anyString(), Mockito.any(), Mockito.any(HashMap.class), Mockito.any()))
                .thenThrow(subsystemDataException);
        Mockito.doThrow(new SubsystemUnavailableException("dummyURL",HttpStatus.FAILED_DEPENDENCY,"dummyBody")).when(apiUtils).handleSubsystemDataException(subsystemDataException);

        SubsystemUnavailableException subsystemUnavailableException = Assertions.assertThrows(SubsystemUnavailableException.class,
                () -> inviteToApplyService.process(validateMerchantDetails));
        Assertions.assertNotNull(subsystemUnavailableException);
        Assertions.assertEquals(HttpStatus.FAILED_DEPENDENCY, subsystemUnavailableException.getHttpStatus());
    }

    @Test
    public void  testProcess_WhenSubsystemUnavailableException() throws Exception {
        ValidateMerchantDetails validateMerchantDetails = new ValidateMerchantDetails();
        SubsystemUnavailableException subsystemUnavailableException = new SubsystemUnavailableException("dummyURL", HttpStatus.FAILED_DEPENDENCY, "dummyBody");

        Mockito.when(internalAPIClient.post(Mockito.anyString(), Mockito.any(), Mockito.any(HashMap.class), Mockito.any()))
                .thenThrow(subsystemUnavailableException);
        Mockito.doThrow(subsystemUnavailableException).when(apiUtils).handleSubsystemUnavailableException(subsystemUnavailableException);

        SubsystemUnavailableException subsystemUnavailableExceptionActual = Assertions.assertThrows(SubsystemUnavailableException.class,
                () -> inviteToApplyService.process(validateMerchantDetails));
        Assertions.assertNotNull(subsystemUnavailableExceptionActual);
        Assertions.assertEquals(subsystemUnavailableExceptionActual.getHttpStatus(), subsystemUnavailableException.getHttpStatus());
    }

    @Test
    public void  testProcess_WhenException() throws Exception {
        ReflectionTestUtils.setField(inviteToApplyService, "apsInviteToApplyUrl", "testInviteToApplyURL");
        ValidateMerchantDetails validateMerchantDetails = new ValidateMerchantDetails();

        Mockito.when(internalAPIClient.post(Mockito.anyString(), Mockito.any(), Mockito.any(HashMap.class), Mockito.any()))
                .thenThrow(Exception.class);

        SubsystemUnavailableException subsystemUnavailableException = Assertions.assertThrows(SubsystemUnavailableException.class,
                () -> inviteToApplyService.process(validateMerchantDetails));
        Assertions.assertNotNull(subsystemUnavailableException);
        Assertions.assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, subsystemUnavailableException.getHttpStatus());
    }
}
