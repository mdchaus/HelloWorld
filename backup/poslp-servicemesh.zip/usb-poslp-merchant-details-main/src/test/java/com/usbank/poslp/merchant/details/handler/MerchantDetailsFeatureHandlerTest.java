package com.usbank.poslp.merchant.details.handler;

import com.usbank.api.core.component.requestcontext.IRequestContext;
import com.usbank.api.core.component.requestcontext.RequestContext;
import com.usbank.api.core.constant.USBConstants;
import com.usbank.api.core.exception.PoslpAPIException;
import com.usbank.poslp.commons.entities.FeatureConfiguration;
import com.usbank.poslp.merchant.details.advice.MerchantExceptionHandler;
import com.usbank.poslp.merchant.details.constants.MerchantDetailsConstants;
import com.usbank.poslp.merchant.details.model.request.ClientData;
import com.usbank.poslp.merchant.details.model.request.MerchantDetailsInput;
import com.usbank.poslp.merchant.details.model.response.FeatureConfigurationResponse;
import com.usbank.poslp.merchant.details.service.MerchantDetailsFeatureService;
import com.usbank.poslp.merchant.details.validator.MerchantDetailsRequestValidator;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;
import static org.junit.Assert.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static org.junit.Assert.assertNotNull;

@RunWith(MockitoJUnitRunner.class)
public class MerchantDetailsFeatureHandlerTest {

    @InjectMocks
    private MerchantDetailsFeatureHandler merchantDetailsFeatureHandler;

    @Mock
    private MerchantDetailsFeatureService merchantDetailsFeatureService;

    @Mock
    MerchantDetailsRequestValidator merchantRequestValidator;

    @Mock
    private MerchantExceptionHandler exceptionHandler;

    @Mock
    private IRequestContext requestContext;


    @Test
    public void handleTest() throws Exception {
        FeatureConfigurationResponse feature = new FeatureConfigurationResponse();
        List<FeatureConfigurationResponse> featureConfigurationResponseList = new ArrayList<>();
        feature.setConfigurationName("PAGAYA");
        feature.setConfigurationValue("ENABLED");
        featureConfigurationResponseList.add(feature);
        Mockito.when(merchantDetailsFeatureService.process(Mockito.any())).thenReturn(featureConfigurationResponseList);
        assertNotNull(merchantDetailsFeatureHandler.handle(new MerchantDetailsInput()));

    }

    @Test
    public void handleTest1() throws Exception {
        FeatureConfigurationResponse feature = new FeatureConfigurationResponse();
        List<FeatureConfigurationResponse> featureConfigurationResponseList = new ArrayList<>();
        feature.setConfigurationName("PAGAYA");
        feature.setConfigurationValue("ENABLED");
        featureConfigurationResponseList.add(feature);
        Mockito.when(merchantDetailsFeatureService.process(Mockito.any())).thenReturn(featureConfigurationResponseList);
        assertNotNull(merchantDetailsFeatureHandler.handle(null));

    }

    @Test
    public void handlerTestForHeadersWithApigee() {
        Map<String, String> map = new HashMap<>();
        map.put(USBConstants.CLIENT_ID, MerchantDetailsConstants.APIGEE);
        MerchantDetailsInput request = new MerchantDetailsInput();
        String merchantId = "9025368145";
        try {
            request.setMerchantID(merchantId);
            FeatureConfigurationResponse feature = new FeatureConfigurationResponse();
            List<FeatureConfigurationResponse> featureConfigurationResponseList = new ArrayList<>();
            feature.setConfigurationName("PAGAYA");
            feature.setConfigurationValue("ENABLED");
            featureConfigurationResponseList.add(feature);
            when(requestContext.getHttpHeaders()).thenReturn(map);
            Mockito.when(merchantDetailsFeatureService.process(Mockito.any())).thenReturn(featureConfigurationResponseList);
            assertNotNull(merchantDetailsFeatureHandler.handle(new MerchantDetailsInput()));
        } catch (Exception ex) {
        }
    }

    @Test
    public void handlerTestForHeadersNonApigee() {
        Map<String, String> map = new HashMap<>();
        map.put(USBConstants.CLIENT_ID, MerchantDetailsConstants.USBWEB);

        MerchantDetailsInput request = new MerchantDetailsInput();
        request.setMerchantID("9025368145");
        try {
            FeatureConfigurationResponse feature = new FeatureConfigurationResponse();
            List<FeatureConfigurationResponse> featureConfigurationResponseList = new ArrayList<>();
            feature.setConfigurationName("PAGAYA");
            feature.setConfigurationValue("ENABLED");
            featureConfigurationResponseList.add(feature);
            when(requestContext.getHttpHeaders()).thenReturn(map);
            Mockito.when(merchantDetailsFeatureService.process(Mockito.any())).thenReturn(featureConfigurationResponseList);
            assertNotNull(merchantDetailsFeatureHandler.handle(new MerchantDetailsInput()));
        } catch (Exception ex) {
        }
    }

}
