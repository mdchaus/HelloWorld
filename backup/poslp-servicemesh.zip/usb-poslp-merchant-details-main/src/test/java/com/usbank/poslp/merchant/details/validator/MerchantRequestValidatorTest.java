package com.usbank.poslp.merchant.details.validator;

import com.usbank.api.core.component.requestcontext.IRequestContext;
import com.usbank.api.core.component.validator.BaseValidator;
import com.usbank.api.core.component.validator.IValidator;
import com.usbank.api.core.exception.BadRequestException;
import com.usbank.poslp.merchant.details.model.request.MerchantDetailsInput;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;

import java.util.ArrayList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertThrows;

@RunWith(MockitoJUnitRunner.Silent.class)
public class MerchantRequestValidatorTest  {

    @Mock
    BaseValidator baseValidator;

    @Mock
    MerchantHeaderValidator httpHeaderValidation;

    @Mock
    IValidator<MerchantDetailsInput> merchantDetailsInputIValidator;

    @Mock
    IRequestContext requestContext;

    @Mock
    MerchantHeaderValidator merchantHeaderValidator;

    @InjectMocks
    MerchantRequestValidator validator;


    @Test
    public void validateWhenRequestIsNoNull() {
        MerchantDetailsInput merchantDetailsInput=new MerchantDetailsInput();
        merchantDetailsInput.setMerchantID("2345876565444323245678889999877545");
       assertThrows(BadRequestException.class, () -> validator.validate(merchantDetailsInput));


    }
    @Test
    public void validateWhenRequestIsNull() {
        MerchantDetailsInput merchantDetailsInput=new MerchantDetailsInput();
        assertThrows(BadRequestException.class, () -> validator.validate(merchantDetailsInput));


    }
    @Test
    public void validateWhenRequestIsBlank() {
        MerchantDetailsInput merchantDetailsInput=new MerchantDetailsInput();
        merchantDetailsInput.setMerchantID(" ");
        assertThrows(BadRequestException.class, () -> validator.validate(merchantDetailsInput));

    }
}
