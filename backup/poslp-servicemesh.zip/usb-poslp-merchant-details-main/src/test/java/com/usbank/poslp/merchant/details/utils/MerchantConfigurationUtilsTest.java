package com.usbank.poslp.merchant.details.utils;

import com.usbank.api.core.exception.BadRequestException;
import com.usbank.poslp.commons.entities.MerchantPartnerConfiguration;
import com.usbank.poslp.commons.entities.Partner;
import com.usbank.poslp.merchant.details.constants.CustomErrorCodes;
import com.usbank.poslp.merchant.details.repository.MerchantPartnerConfigurationRepository;
import com.usbank.poslp.merchant.details.repository.MerchantRepository;
import com.usbank.poslp.merchant.details.repository.PartnerRepository;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.fail;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class MerchantConfigurationUtilsTest {

    @Mock
    MerchantRepository merchantRepository;

    @InjectMocks
    MerchantConfigurationUtils merchantConfigurationUtils;

    @Mock
    PartnerRepository partnerRepository;

    @Mock
    MerchantPartnerConfigurationRepository merchantPartnerConfigurationRepository;

    @Test
    public void testSuccessResponseValidateMerchantId() {
        String merchantResponseString = "12345678,ACTIVE,9,TestMerchant";
        when(merchantRepository.findAll("12345678")).thenReturn(merchantResponseString);
        merchantConfigurationUtils.validateMerchantId("12345678");
    }

    @Test
    public void testExceptionOnValidateMerchantId() {
        when(merchantRepository.findAll("12345678")).thenReturn(null);
        try {
            merchantConfigurationUtils.validateMerchantId("12345678");
            fail("Must throw BadRequestException");
        } catch (BadRequestException bre) {
            assertEquals(CustomErrorCodes.MERCHANT_VALIDATION_FAILED.getErrorCode(), bre.getErrorCode());
        } catch (Exception e) {
            fail("Must throw BadRequestException");
        }
    }

    @Test
    public void testSuccessMerchantPartnerRelation() {
        Partner partner = new Partner();
        partner.setPartnerGuid(UUID.randomUUID());
        when(partnerRepository.findByPartnerId(any())).thenReturn(partner);

        MerchantPartnerConfiguration merchantPartnerConfiguration = new MerchantPartnerConfiguration();
        merchantPartnerConfiguration.setMerchantId("98765432");
        merchantPartnerConfiguration.setPartnerGuid(UUID.randomUUID());

        List<MerchantPartnerConfiguration> merchantPartnerConfigurationList = new ArrayList<>();
        merchantPartnerConfigurationList.add(merchantPartnerConfiguration);

        when(merchantPartnerConfigurationRepository.findByMerchantIdAndPartnerGuid(any(), any())).thenReturn(merchantPartnerConfigurationList);
        merchantConfigurationUtils.validatePartnerAndMerchantID("MAGWITCH", "98765432");
    }

    @Test
    public void testInvalidPartnerOnMerchantPartnerRelation() {
        when(partnerRepository.findByPartnerId(any())).thenReturn(null);
        try {
            merchantConfigurationUtils.validatePartnerAndMerchantID("MAGWITCH", "98765432");
            fail("Must throw BadRequestException");
        } catch (BadRequestException bre) {
            assertEquals(CustomErrorCodes.PARTNER_VALIDATION_FAILED.getErrorCode(), bre.getErrorCode());
        } catch (Exception ex) {
            fail("Must throw BadRequestException");
        }
    }

    @Test
    public void testFailureOnPartnerOnMerchantPartnerRelation() {
        Partner partner = new Partner();
        partner.setPartnerGuid(UUID.randomUUID());
        when(partnerRepository.findByPartnerId(any())).thenReturn(partner);
        when(merchantPartnerConfigurationRepository.findByMerchantIdAndPartnerGuid(any(), any())).thenReturn(null);

        try {
            merchantConfigurationUtils.validatePartnerAndMerchantID("MAGWITCH", "98765432");
            fail("Must throw BadRequestException");
        } catch (BadRequestException bre) {
            assertEquals(CustomErrorCodes.PARTNER_MID_VALIDATION_FAILED.getErrorCode(), bre.getErrorCode());
        } catch (Exception ex) {
            fail("Must throw BadRequestException");
        }
    }

    @Test
    public void successWhenPartnerIdIsValidAndNotExpired() {
        Partner partner = new Partner();
        partner.setPartnerGuid(UUID.randomUUID());
        partner.setExpirationDate(new java.util.Date(System.currentTimeMillis() + 100000)); // Future date
        when(partnerRepository.findByPartnerId(any())).thenReturn(partner);

        MerchantPartnerConfiguration merchantPartnerConfiguration = new MerchantPartnerConfiguration();
        merchantPartnerConfiguration.setMerchantId("98765432");
        merchantPartnerConfiguration.setPartnerGuid(partner.getPartnerGuid());

        List<MerchantPartnerConfiguration> merchantPartnerConfigurationList = new ArrayList<>();
        merchantPartnerConfigurationList.add(merchantPartnerConfiguration);

        when(merchantPartnerConfigurationRepository.findByMerchantIdAndPartnerGuid(any(), any())).thenReturn(merchantPartnerConfigurationList);
        merchantConfigurationUtils.validatePartnerAndMerchantID("MAGWITCH", "98765432");
    }

    @Test
    public void exceptionWhenPartnerIdIsExpired() {
        Partner partner = new Partner();
        partner.setPartnerGuid(UUID.randomUUID());
        partner.setExpirationDate(new java.util.Date(System.currentTimeMillis() - 100000)); // Past date
        when(partnerRepository.findByPartnerId(any())).thenReturn(partner);

        try {
            merchantConfigurationUtils.validatePartnerAndMerchantID("MAGWITCH", "98765432");
            fail("Must throw BadRequestException");
        } catch (BadRequestException bre) {
            assertEquals(CustomErrorCodes.PARTNER_VALIDATION_EXPIRED.getErrorCode(), bre.getErrorCode());
        } catch (Exception ex) {
            fail("Must throw BadRequestException");
        }
    }

}
