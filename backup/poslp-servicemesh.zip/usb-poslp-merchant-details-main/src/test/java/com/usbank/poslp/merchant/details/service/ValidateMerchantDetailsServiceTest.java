package com.usbank.poslp.merchant.details.service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.usbank.poslp.core.clients.http.InternalAPIClient;
import com.usbank.poslp.merchant.details.model.request.ValidateMerchantDetails;
import com.usbank.poslp.merchant.details.model.response.MerchantDetailsResponse;
import com.usbank.poslp.merchant.details.model.response.SRSApiResponse;
import com.usbank.poslp.merchant.details.model.response.SRSApiToken;
import com.usbank.poslp.merchant.details.model.response.ValidateMerchantResponse;
import com.usbank.poslp.merchant.details.model.response.MerchantDetailsBody;
import com.usbank.poslp.merchant.details.utils.ApiUtils;
import com.usbank.poslp.merchant.details.validator.MerchantDetailsValidator;

import org.junit.Test;
import org.junit.jupiter.api.Assertions;
import org.junit.runner.RunWith;
import org.mockito.ArgumentMatchers;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.web.client.RestTemplate;

import java.net.URI;
import java.util.Map;

@RunWith(MockitoJUnitRunner.class)
public class ValidateMerchantDetailsServiceTest {

    @Mock
    private ObjectMapper objectMapper;

    @Mock
    private MerchantDetailsValidator merchantDetailsValidator;

    @Mock
    private ApiUtils apiUtils;

    @Mock
    private RestTemplate restTemplate;

    @Mock
    private InternalAPIClient dataProvider;

    @InjectMocks
    private ValidateMerchantDetailsService validateMerchantDetailsService;

    @Test
    public void testProcess() throws Exception {
        ReflectionTestUtils.setField(validateMerchantDetailsService,"srsValidateMerchantUrl","testURL");
        ValidateMerchantDetails validateMerchantDetails = new ValidateMerchantDetails();
        validateMerchantDetails.setAccountMid("12345");
        validateMerchantDetails.setApiSource("Converge");
        validateMerchantDetails.setContactFirstName("Test");
        validateMerchantDetails.setContactLastName("Test");
        validateMerchantDetails.setDDANumber("test12345");
        validateMerchantDetails.setProcessingCenterID("testCenter");
        validateMerchantDetails.setSSNorTaxId("testTaxId");

        SRSApiToken srsApiToken = new SRSApiToken();
        srsApiToken.setAccessToken("1234");
        ResponseEntity responseToken = new ResponseEntity<>(srsApiToken, HttpStatus.OK);
        Mockito.when(restTemplate.exchange(
                ArgumentMatchers.nullable(String.class),
                ArgumentMatchers.any(HttpMethod.class),
                ArgumentMatchers.any(HttpEntity.class),
                ArgumentMatchers.<Class<String>>any(),
                ArgumentMatchers.<Map<String, ?>>any())).thenReturn(responseToken);

        MerchantDetailsResponse merchantDetailsResponse = new MerchantDetailsResponse();
        MerchantDetailsBody merchantDetailsBody = new MerchantDetailsBody();
        merchantDetailsBody.setContactID("testContactID");
        merchantDetailsResponse.setMerchantDetailsBody(merchantDetailsBody);
        ResponseEntity responseValidMerchant = new ResponseEntity<>(merchantDetailsResponse, HttpStatus.OK);
        Mockito.when(restTemplate.exchange(
                ArgumentMatchers.nullable(String.class),
                ArgumentMatchers.any(HttpMethod.class),
                ArgumentMatchers.any(HttpEntity.class),
                ArgumentMatchers.<Class<String>>any())).thenReturn(responseValidMerchant);

        SRSApiResponse srsApiResponse = new SRSApiResponse();
        srsApiResponse.setStatusCode(HttpStatus.OK.toString());
        ResponseEntity srsApiResponseResponseEntity = new ResponseEntity<>(srsApiResponse, HttpStatus.OK);
        Mockito.when(restTemplate.exchange(
                ArgumentMatchers.nullable(URI.class),
                ArgumentMatchers.any(HttpMethod.class),
                ArgumentMatchers.any(HttpEntity.class),
                ArgumentMatchers.<Class<String>>any())).thenReturn(srsApiResponseResponseEntity);

        ValidateMerchantResponse validateMerchantResponse = validateMerchantDetailsService.process(validateMerchantDetails);
        Assertions.assertNotNull(validateMerchantResponse);
        Assertions.assertTrue(validateMerchantResponse.isMerchantValid());
    }

    @Test
    public void testProcess_WhenParsingError() throws Exception {
        ValidateMerchantDetails validateMerchantDetails = new ValidateMerchantDetails();
        Mockito.when(objectMapper.writeValueAsString(validateMerchantDetails)).thenThrow(JsonProcessingException.class);
        Exception ex= Assertions.assertThrows(Exception.class,
                () -> validateMerchantDetailsService.process(validateMerchantDetails));
        Assertions.assertNotNull(ex.getMessage());
    }
}
