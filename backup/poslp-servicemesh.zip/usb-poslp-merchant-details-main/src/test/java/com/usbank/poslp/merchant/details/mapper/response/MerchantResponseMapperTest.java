package com.usbank.poslp.merchant.details.mapper.response;

import com.usbank.poslp.commons.entities.Merchant;
import com.usbank.poslp.commons.entities.MerchantProduct;
import com.usbank.poslp.commons.entities.Product;
import com.usbank.poslp.commons.entities.ProductBand;
import com.usbank.poslp.commons.entities.ProductFicoBand;
import com.usbank.poslp.merchant.details.model.request.MerchantProducts;
import com.usbank.poslp.merchant.details.model.response.MerchantDetails;
import com.usbank.poslp.merchant.details.utils.ApiUtils;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

@RunWith(MockitoJUnitRunner.class)
public class MerchantResponseMapperTest {

    @InjectMocks
    MerchantResponseMapper merchantResponseMapper;

    @Mock
    private ApiUtils apiUtils;

    @Test
    public void mapTest() throws Exception {
        Product product=new Product();
        product.setProductCode("testproduct");
        List<MerchantProduct> productList=new ArrayList<>();
        MerchantProduct merchantProduct=new MerchantProduct();
        merchantProduct.setExpirationDate(new Date());
        merchantProduct.setEffectiveDate(new Date());
        merchantProduct.setProduct(product);
        merchantProduct.setEffectiveDate(new Date());
        merchantProduct.setExpirationDate(new Date());
        productList.add(merchantProduct);
        List<MerchantProducts> listProducts=new ArrayList<>();
        MerchantProducts merchantProductObj=MerchantProducts.builder().productCode("code1").build();
        listProducts.add(merchantProductObj);
        Merchant merchant=new Merchant();
        merchant.setMerchantDbaName("testDB");
        merchant.setMerchantProducts(productList);
        Optional<Merchant> checkMerchantResponseNull = Optional.ofNullable(merchant);
        MerchantDetails merchantDetails=MerchantDetails.builder().accountStatus("Active").merchantProducts(listProducts).build();


 }
    @Test
    public void mapTestWithConditions()  {
        Product product=new Product();
        product.setProductCode("testproduct");
        List<ProductBand> productBands=new ArrayList<ProductBand>();
        ProductBand productBand=new ProductBand();
        productBand.setBandGuid(UUID.fromString("82a93d7f-fc96-4b79-b3d6-43e290bc5bc6"));
        productBand.setApr(BigDecimal.ONE);
        productBands.add(productBand);

        product.setProductGuid( UUID.randomUUID());
//        product.setProductGuid(new  UUID("2394574838"));
        List<MerchantProduct> productList=new ArrayList<>();
        List<ProductBand>productBandList=new ArrayList<>();
        productBandList.add(productBand);
        List<ProductFicoBand>productFicoBandList=new ArrayList<>();
        ProductFicoBand fico=new ProductFicoBand();
        fico.setBandGuid(UUID.fromString("82a93d7f-fc96-4b79-b3d6-43e290bc5bc6"));
        productFicoBandList.add(fico);
        MerchantProduct merchantProduct=new MerchantProduct();
        merchantProduct.setExpirationDate(null);
        merchantProduct.setEffectiveDate(new Date());
        merchantProduct.setProduct(product);

        productList.add(merchantProduct);
        List<MerchantProducts> listProducts=new ArrayList<>();
        MerchantProducts merchantProductObj=MerchantProducts.builder().productCode("code1").build();
        MerchantDetails mm=  MerchantDetails.builder().merchantID("123").businessCountryCode("12334").build();
        listProducts.add(merchantProductObj);
        Merchant merchant=new Merchant();
        merchant.setMerchantDbaName("testDB");
        merchant.setMerchantProducts(productList);
        Optional<Merchant> checkMerchantResponseNull = Optional.ofNullable(merchant);
        MerchantDetails merchantDetails=MerchantDetails.builder().accountStatus("Active").merchantProducts(listProducts).build();
        merchantResponseMapper.map(merchantDetails,productList);
    }

    @Test
    public void mapTestWithConditionsCloudApply()  {
        Product product=new Product();
        product.setProductCode("testproduct");
        List<ProductBand> productBands=new ArrayList<ProductBand>();
        ProductBand productBand=new ProductBand();
        productBand.setBandGuid(UUID.randomUUID());
        productBand.setApr(BigDecimal.ONE);
        productBands.add(productBand);

        product.setProductGuid( UUID.randomUUID());
//        product.setProductGuid(new  UUID("2394574838"));
        List<MerchantProduct> productList=new ArrayList<>();
        MerchantProduct merchantProduct=new MerchantProduct();
        merchantProduct.setExpirationDate(new Date());
        merchantProduct.setEffectiveDate(new Date());
        merchantProduct.setProduct(product);
        merchantProduct.setEffectiveDate(new Date());
        merchantProduct.setExpirationDate(new Date());
        productList.add(merchantProduct);
        List<MerchantProducts> listProducts=new ArrayList<>();
        MerchantProducts merchantProductObj=MerchantProducts.builder().productCode("code1").build();
        MerchantDetails mm=  MerchantDetails.builder().merchantID("123").businessCountryCode("12334").build();
        listProducts.add(merchantProductObj);
        Merchant merchant=new Merchant();
        merchant.setMerchantDbaName("testDB");
        merchant.setMerchantProducts(productList);
        Optional<Merchant> checkMerchantResponseNull = Optional.ofNullable(merchant);
        MerchantDetails merchantDetails=MerchantDetails.builder().accountStatus("Active").merchantProducts(listProducts).build();

        merchantResponseMapper.map(merchantDetails,productList);

    }

    @Test
    public void mapForValidationOfExpiryDate(){

    }
}
