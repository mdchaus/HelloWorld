package com.usbank.poslp.merchant.details.service;

import com.usbank.api.core.exception.PoslpAPIException;
import com.usbank.api.core.exception.SubsystemUnavailableException;
import com.usbank.poslp.commons.entities.Merchant;
import com.usbank.poslp.merchant.details.constants.CustomErrorCodes;
import com.usbank.poslp.merchant.details.model.request.MerchantPreApprovalLinkRequest;
import com.usbank.poslp.merchant.details.model.response.MerchantPreApprovalLinkResponse;
import com.usbank.poslp.merchant.details.repository.MerchantDetailsRepository;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.dao.DataAccessResourceFailureException;
import org.springframework.test.util.ReflectionTestUtils;

import java.util.Optional;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.fail;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;



@RunWith(MockitoJUnitRunner.class)
public class MerchantPreApprovalLinkServiceTest {

    @InjectMocks
    private MerchantPreApprovalLinkService merchantPreApprovalLinkService;

    @Mock
    private MerchantDetailsRepository merchantRepository;

    @Test
public void process_ReturnsPreApprovalLink_WhenMerchantExists() throws Exception {
        ReflectionTestUtils.setField(merchantPreApprovalLinkService, "preApprovalLink", "https://it1.avvance.com/flexible-financing.html?id=");

        MerchantPreApprovalLinkRequest request = new MerchantPreApprovalLinkRequest();
    request.setMerchantID("123456789");
    Merchant merchant = new Merchant();
    merchant.setHashedMerchantId("1234");
    when(merchantRepository.findById("123456789")).thenReturn(Optional.of(merchant));
    MerchantPreApprovalLinkResponse response = merchantPreApprovalLinkService.process(request);
    assertEquals("https://it1.avvance.com/flexible-financing.html?id=1234", response.getPreApprovalLink());
}

    @Test
    public void process_ThrowsPoslpAPIException_WhenMerchantNotFound() {
        MerchantPreApprovalLinkRequest request=new MerchantPreApprovalLinkRequest();
        request.setMerchantID("86466726752");
        request.setPartnerId("Rectangle");
        when(merchantRepository.findById("86466726752")).thenReturn(Optional.empty());
        try{
            merchantPreApprovalLinkService.process(request);
            fail("Must throw PoslpAPIException");
        }catch (PoslpAPIException poslpAPIException){
            assertEquals(CustomErrorCodes.NO_MERCHANT_FOUND.getErrorCode(), poslpAPIException.getErrorCode());
            assertEquals(CustomErrorCodes.NO_MERCHANT_FOUND.getErrorDescription(), poslpAPIException.getMessage());
        }catch (Exception ex){
            fail("Must throw PoslpAPIException");
        }
    }

    @Test
    public void process_ThrowsSubsystemUnavailableException() {
        MerchantPreApprovalLinkRequest request=new MerchantPreApprovalLinkRequest();
        request.setMerchantID("86466726752");
        request.setPartnerId("Rectangle");
        when(merchantRepository.findById(any())).thenThrow(new DataAccessResourceFailureException("DB Connection Error"));
        try{
            merchantPreApprovalLinkService.process(request);
            fail("Must throw SubsystemUnavailableException");
        }catch (SubsystemUnavailableException subsystemUnavailableException){
            assertEquals(CustomErrorCodes.DB_CONNECTION_ERROR.getErrorCode(), subsystemUnavailableException.getErrorCode());
        }catch (Exception ex){
            fail("Must throw SubsystemUnavailableException");
        }
    }
}
