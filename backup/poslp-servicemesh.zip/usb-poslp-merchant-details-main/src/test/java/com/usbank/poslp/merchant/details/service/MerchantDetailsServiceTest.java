package com.usbank.poslp.merchant.details.service;

import com.usbank.api.core.exception.PoslpAPIException;
import com.usbank.api.core.exception.SubsystemUnavailableException;
import com.usbank.poslp.commons.entities.*;
import com.usbank.poslp.merchant.details.advice.MerchantExceptionHandler;
import com.usbank.poslp.merchant.details.constants.CustomErrorCodes;
import com.usbank.poslp.merchant.details.model.request.MerchantDetailsInput;
import com.usbank.poslp.merchant.details.model.response.MerchantDetails;
import com.usbank.poslp.merchant.details.repository.MerchantDetailsRepository;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.http.HttpStatus;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;

import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;

@RunWith(MockitoJUnitRunner.class)
public class MerchantDetailsServiceTest {

	@InjectMocks
	MerchantDetailsService mercahntDetailsService;
	@Mock
	MerchantExceptionHandler exceptionHandler;
	@Mock
	MerchantDetailsRepository merchantRepository;


	@Test
	public void processIfMerchantDetailsIsNotPresent() throws Exception {
		Merchant merchant=new Merchant();
		merchant.setAccountStatus("Active");
		merchant.setMerchantDbaName("testDb1");
		Optional<Merchant> merchantDetail = Optional.ofNullable(merchant);
		MerchantDetailsInput request=new MerchantDetailsInput();
		request.setMerchantID("887772227999");
        Optional<Merchant> emptyMerchantDetails = Optional.empty();
		Mockito.when(merchantRepository.findById(any())).thenReturn(emptyMerchantDetails);
		mercahntDetailsService.process(request);
	}

	@Test
	public void processTestWhenMerchantIsNotActive() throws Exception {
		Merchant merchant=new Merchant();
		MerchantDetails merchantDetails=MerchantDetails.builder().merchantID("12345677").accountStatus("Active").build();
		merchant.setAccountStatus("INACTIVE");
		merchant.setMerchantDbaName("testDb1");
		Optional<Merchant> merchantDetail = Optional.ofNullable(merchant);
		merchantDetail.get().setBnplStatus("INACTIVE");
		MerchantDetailsInput request=new MerchantDetailsInput();
		request.setMerchantID("887772227999");
		Mockito.when(merchantRepository.findById(any())).thenReturn(merchantDetail);

		PoslpAPIException exe = new PoslpAPIException(CustomErrorCodes.NO_MERCHANT_FOUND.getErrorCode(), CustomErrorCodes.NO_MERCHANT_FOUND.getErrorDescription());

		Mockito.when(exceptionHandler.commonAPIException(any())).thenThrow(exe);
		assertThrows(PoslpAPIException.class, () ->mercahntDetailsService.process(request));
	}

	@Test
	public void processTestWhenNoException() throws Exception {
		Merchant merchant=new Merchant();
		MerchantDetails merchantDetails=MerchantDetails.builder().merchantID("12345677").accountStatus("ACTIVE").build();
		merchant.setAccountStatus("ACTIVE");
		merchant.setBnplStatus("ACTIVE");
		merchant.setMerchantDbaName("testDb1");
		Optional<Merchant> merchantDetail = Optional.ofNullable(merchant);
		MerchantDetailsInput request=new MerchantDetailsInput();
		request.setMerchantID("887772227999");
		SubsystemUnavailableException ex=new SubsystemUnavailableException("usbank.com", HttpStatus.REQUEST_TIMEOUT,"errorkey");
		Mockito.when(merchantRepository.findById(any())).thenReturn(merchantDetail);
//		Mockito.when(merchantResponseMapper.map(Mockito.any(),Mockito.any())).thenReturn(merchantDetails);
		try {
			mercahntDetailsService.process(request).getAccountStatus();
		}catch (Exception e){
			System.out.println(e);
		}

//		assertThrows(SubsystemUnavailableException.class, () -> mercahntDetailsService.process(request));


	}
	@Test
	public void testgetErrorResponseWhenThrowsException()  {


		//Mockito.when(mapper.readValue(res.toString(),BaseResponse.class )).thenReturn(res);

	}


	@Test
	public void processTestWhenRequestHeaderCloudApply() throws Exception {
		Merchant merchant=new Merchant();
		List<MerchantProduct>productList=new ArrayList<>();
		MerchantProduct merchantProduct=new MerchantProduct();
		MerchantProduct merchantProduct1=new MerchantProduct();
		Product product=new Product();
		Product product1=new Product();
		product.setProductCode("BNPL");
		merchantProduct.setProduct(product);
		merchantProduct1.setProduct(product1);
		productList.add(merchantProduct);
		productList.add(merchantProduct1);
		MerchantDetails merchantDetails=MerchantDetails.builder().merchantID("12345677").accountStatus("Active").build();
		merchant.setAccountStatus("ACTIVE");
		merchant.setMerchantDbaName("testDb1");
		merchant.setMerchantProducts(productList);
		Optional<Merchant> merchantDetail = Optional.ofNullable(merchant);
		merchantDetail.get().setBnplStatus("ACTIVE");

		MerchantDetailsInput request=new MerchantDetailsInput();
		request.setMerchantID("887772227999");
		Mockito.when(merchantRepository.findById(any())).thenReturn(merchantDetail);
		Map<String,String> headers=new HashMap<>();
		headers.put("application-id","CloudApply");


		assertNotNull(mercahntDetailsService.process(request));
	}

}
