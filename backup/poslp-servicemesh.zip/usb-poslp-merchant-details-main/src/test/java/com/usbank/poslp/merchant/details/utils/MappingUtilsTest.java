package com.usbank.poslp.merchant.details.utils;

import com.usbank.api.core.constant.USBConstants;
import com.usbank.poslp.merchant.details.constants.MerchantDetailsConstants;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.http.MediaType;

import java.math.BigDecimal;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;

@RunWith(MockitoJUnitRunner.class)
public class MappingUtilsTest {

    @InjectMocks
    private MappingUtils mappingUtils;

    public Map<String, String> getMockHttpHeadersInMap() {
        Map<String, String> map = new HashMap<>();
        map.put(USBConstants.CORRELATION_ID, "test");
        map.put(MerchantDetailsConstants.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE);
        map.put(USBConstants.CLIENT_DATA, "test");
        map.put(USBConstants.APPLICATION_ID, "test");
        map.put(USBConstants.CHANNEL_ID, "test");
        return map;
    }

    @Test
    public void testGetSecretAccountNumber() {
        assertNotNull(mappingUtils.getSecretAccountNumber("90824059773497"));
    }

    @Test
    public void testParseIntegerToDate() throws Exception {
        assertNotNull(mappingUtils.parseIntegerToDate(20210422));
    }
    @Test
    public void testParseIntegerToDateException() throws Exception {
        assertNull(MappingUtils.parseIntegerToDate(20210-4221));
    }

    @Test
    public void testNullResponseParseIntegerToDate() throws Exception {
        assertNull(mappingUtils.parseIntegerToDate(-1));
    }

    @Test
    public void testExceptionFlowParseIntegerToDate() throws Exception {
        assertNull(mappingUtils.parseIntegerToDate(-1));
    }

    @Test
    public void testWhenCorrelationIDHeaderIsNull()  {
        assertNotNull(mappingUtils.getCorrelationId(null));
    }

    @Test
    public void testWhenCorrelationIDIsString()  {
        assertNotNull(mappingUtils.getCorrelationId(getMockHttpHeadersInMap()));
    }

    @Test
    public void testWhenCorrelationIDIsUUID() {
        Map<String, String> map = getMockHttpHeadersInMap();
        map.put(USBConstants.CORRELATION_ID, UUID.randomUUID().toString());
        assertNotNull(mappingUtils.getCorrelationId(map));
    }

    @Test
    public void testGetLastFourAccountNumber() {
        assertEquals("1234", mappingUtils.getLastFourAccountNumber("12547851234"));
    }

    @Test
    public void testGetLastFourAccountNumberLessThanFourLength() {
        assertEquals("123", mappingUtils.getLastFourAccountNumber("123"));
    }

    @Test
    public void testModifyAccountNumberLessLength() {
        assertEquals("0000000000000000001236", mappingUtils.modifyAccountNumber("00001236"));
    }

    @Test
    public void testModifyAccountNumberMoreLength() {
        assertEquals("0000000000000000001236", mappingUtils.modifyAccountNumber("000000000000000000000000000001236"));
    }

    @Test
    public void testModifyAccountNumberSameLength() {
        assertEquals("0000000000000000001236", mappingUtils.modifyAccountNumber("0000000000000000001236"));
    }

    @Test
    public void testFormatBigDecimalWhenNull() {

        mappingUtils.formatBigDecimal(null);
    }

    @Test
    public void testFormatBigDecimalWhenValidValue() {
        assertEquals("4.89", mappingUtils.formatBigDecimal(new BigDecimal("4.889")).toString());
    }

    @Test
    public void testFormatBigDecimalWhenNegativeValue() {
        assertEquals("-49.36", mappingUtils.formatBigDecimal(new BigDecimal("-49.359")).toString());
    }

    @Test
    public void testExceptionFlowFormatBigDecimal() {
        assertEquals("-49.36", mappingUtils.formatBigDecimal(new BigDecimal("-49.359")).toString());
    }
    @Test
    public void testConvertDateToLocalDateTime() {
        DateFormat formatter = new SimpleDateFormat("dd/MM/yyyy");
        Date today = new Date();
        try {
            Date todayWithZeroTime = formatter.parse(formatter.format(today));
            mappingUtils.convertDateToLocalDateTime(todayWithZeroTime);
        } catch (ParseException e) {
            throw new RuntimeException(e);
        }

    }

}