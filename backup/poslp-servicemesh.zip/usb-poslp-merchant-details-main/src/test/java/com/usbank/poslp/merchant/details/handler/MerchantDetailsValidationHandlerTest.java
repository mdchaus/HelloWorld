package com.usbank.poslp.merchant.details.handler;



import com.fasterxml.jackson.databind.ObjectMapper;
import com.usbank.api.core.aspect.LogExecutionTime;
import com.usbank.api.core.component.requestcontext.IRequestContext;
import com.usbank.api.core.exception.PoslpAPIException;
import com.usbank.api.core.exception.SubsystemDataException;
import com.usbank.api.core.requesthandler.IRequestHandler;
import com.usbank.poslp.merchant.details.advice.MerchantExceptionHandler;
import com.usbank.poslp.merchant.details.constants.CustomErrorCodes;
import com.usbank.poslp.merchant.details.model.request.ValidateMerchantDetails;
import com.usbank.poslp.merchant.details.model.response.ValidateMerchantResponse;
import com.usbank.poslp.merchant.details.service.MerchantDetailsService;
import com.usbank.poslp.merchant.details.service.ValidateMerchantDetailsService;
import com.usbank.poslp.merchant.details.utils.MerchantConfigurationUtils;
import com.usbank.poslp.merchant.details.validator.MerchantDetailsRequestValidator;
import com.usbank.poslp.merchant.details.validator.MerchantDetailsValidator;
import lombok.extern.slf4j.Slf4j;
import org.junit.Before;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import static com.usbank.poslp.merchant.details.constants.CustomErrorCodes.API_EXCEPTION;
import static com.usbank.poslp.merchant.details.constants.CustomErrorCodes.VALIDATE_API_EXCEPTION;
import static com.usbank.poslp.merchant.details.constants.MerchantDetailsConstants.MERCHANT_DETAIL_DOMAIN;

import org.junit.Test;

import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;

import java.util.HashMap;
import java.util.Map;

import static org.junit.Assert.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.when;
import static org.mockito.Mockito.verify;
import static org.mockito.ArgumentMatchers.any;


@RunWith(MockitoJUnitRunner.class)
public class MerchantDetailsValidationHandlerTest {

    @Mock
    private MerchantExceptionHandler exceptionHandler;

    @Mock
    private IRequestContext requestContext;

    @Mock
    private ValidateMerchantDetailsService validateMerchantDetailsService;

    @Mock
    private MerchantDetailsValidator merchantDetailsValidator;

    @InjectMocks
    private MerchantDetailsValidationHandler handler;

    private ValidateMerchantDetails request;
    private ValidateMerchantResponse response;

    @Before
    public void setUp() {
        request = new ValidateMerchantDetails();
        response = new ValidateMerchantResponse();
    }

    @Test
    public void testHandle_ValidMerchant() throws Exception {
        response.setMerchantValid(true);
        when(validateMerchantDetailsService.process(any())).thenReturn(response);

        handler.handle(request);

        verify(merchantDetailsValidator).validate(request);
        verify(validateMerchantDetailsService).process(request);
    }

    @Test
    public void testHandle_InvalidMerchant() throws Exception {
        response.setMerchantValid(false);
        when(validateMerchantDetailsService.process(any())).thenReturn(response);
        PoslpAPIException exe = new PoslpAPIException(CustomErrorCodes.NO_MERCHANT_FOUND.getErrorCode(),
                CustomErrorCodes.NO_MERCHANT_FOUND.getErrorDescription());
        Mockito.when(exceptionHandler.commonAPIException(any())).thenThrow(exe);
        assertThrows(PoslpAPIException.class, () -> handler.handle(request));
    }

    @Test
    public void testHandle_Exception() throws Exception {
        when(validateMerchantDetailsService.process(any())).thenThrow(new RuntimeException("Test Exception"));
        PoslpAPIException exe = new PoslpAPIException(CustomErrorCodes.NO_MERCHANT_FOUND.getErrorCode(),
                CustomErrorCodes.NO_MERCHANT_FOUND.getErrorDescription());
        Mockito.when(exceptionHandler.commonAPIException(any())).thenThrow(exe);
        assertThrows(PoslpAPIException.class, () -> handler.handle(request));
    }

}