package com.usbank.poslp.merchant.details.controller;

import com.usbank.api.core.requesthandler.IRequestHandler;
import com.usbank.poslp.merchant.details.model.request.MerchantPreApprovalLinkRequest;
import com.usbank.poslp.merchant.details.model.response.MerchantPreApprovalLinkResponse;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.MethodSorters;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestHeader;

import java.util.HashMap;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.when;


@RunWith(MockitoJUnitRunner.class)
@FixMethodOrder(value = MethodSorters.NAME_ASCENDING)
public class MerchantPreApprovalLinkControllerTest {

    @InjectMocks
    private MerchantPreApprovalLinkController merchantPreApprovalLinkController;


    @Mock
    private IRequestHandler<MerchantPreApprovalLinkRequest, MerchantPreApprovalLinkResponse> merchantTransactionResponseIRequestHandler;


    @Test
    public void preApprovalLink_ReturnsSuccessfulResponse() throws Exception {
        MerchantPreApprovalLinkRequest request=new MerchantPreApprovalLinkRequest();
        request.setMerchantID("123456789");
        request.setPartnerId("Rectangle");
        MerchantPreApprovalLinkResponse expectedResponse = new MerchantPreApprovalLinkResponse();
        when(merchantTransactionResponseIRequestHandler.handle(request)).thenReturn(expectedResponse);
        ResponseEntity<MerchantPreApprovalLinkResponse> response = merchantPreApprovalLinkController.preApprovalLink
                ("channelId",
                "correlationId",
                "applicationId",
                "sessionId",
                "authorization",
                "Rectangle",
                "123456789");
        assertEquals(ResponseEntity.ok(expectedResponse), response);
    }
}
