package com.usbank.poslp.merchant.details.service;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.usbank.api.core.component.requestcontext.IRequestContext;
import com.usbank.api.core.exception.PoslpAPIException;
import com.usbank.poslp.commons.entities.*;
import com.usbank.poslp.merchant.details.advice.MerchantExceptionHandler;
import com.usbank.poslp.merchant.details.constants.CustomErrorCodes;
import com.usbank.poslp.merchant.details.mapper.response.MerchantResponseMapper;
import com.usbank.poslp.merchant.details.model.request.MerchantDetailsInput;
import com.usbank.poslp.merchant.details.model.response.MerchantDetails;
import com.usbank.poslp.merchant.details.repository.FeatureConfigurationRepository;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;


import java.util.*;

import static org.junit.Assert.assertThrows;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;
import static org.junit.jupiter.api.Assertions.fail;

@RunWith(MockitoJUnitRunner.class)
public class MerchantDetailsFeatureServiceTest {

    @InjectMocks
    MerchantDetailsFeatureService merchantDetailsFeatureService;
    @Mock
    MerchantResponseMapper merchantResponseMapper;
    @Mock
    MerchantExceptionHandler exceptionHandler;
    @Mock
    ObjectMapper mapper;

    @Mock
    FeatureConfigurationRepository featureConfigurationRepository;

    @Mock
    IRequestContext requestContext;

    @Test
    public void processTestWhenRequestWithFeatureDetails() throws Exception {
        Merchant merchant = new Merchant();
        List<MerchantProduct> productList = new ArrayList<>();
        MerchantProduct merchantProduct = new MerchantProduct();
        MerchantProduct merchantProduct1 = new MerchantProduct();
        Product product = new Product();
        Product product1 = new Product();
        product.setProductCode("BNPL");
        merchantProduct.setProduct(product);
        merchantProduct1.setProduct(product1);
        productList.add(merchantProduct);
        productList.add(merchantProduct1);
        MerchantDetails merchantDetails = MerchantDetails.builder().merchantID("12345677").accountStatus("Active").build();
        merchant.setAccountStatus("ACTIVE");
        merchant.setMerchantDbaName("testDb1");
        merchant.setMerchantProducts(productList);
        Optional<Merchant> merchantDetail = Optional.ofNullable(merchant);
        merchantDetail.get().setBnplStatus("ACTIVE");

        MerchantDetailsInput request = new MerchantDetailsInput();
        request.setMerchantID("887772227999");
        List<ProductBand> productBandList = new ArrayList<ProductBand>();
        List<ProductFicoBand> productFicoBandList = new ArrayList<ProductFicoBand>();
        List<FeatureConfiguration> featureConfigurationList = new ArrayList<FeatureConfiguration>();
        when(featureConfigurationRepository.findByFeatureConfig(any())).thenReturn(featureConfigurationList);

        assertTrue(merchantDetailsFeatureService.process(request).isEmpty());
    }

    @Test
    public void processTestWhenMerchantIdNull(){
        MerchantDetailsInput request = new MerchantDetailsInput();
        try {
            merchantDetailsFeatureService.process(request);
        } catch (PoslpAPIException exception) {
            assertEquals(CustomErrorCodes.NO_MERCHANT_FOUND.getErrorDescription(), exception.getErrorMessage());
            assertEquals(CustomErrorCodes.NO_MERCHANT_FOUND.getErrorCode(), exception.getErrorCode());
        } catch (Exception e) {
            fail("Should throw PoslpAPIException");
        }

    }

}
