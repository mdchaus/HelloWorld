package com.usbank.poslp.merchant.details.interceptor;

import com.usbank.api.core.exception.BadRequestException;
import com.usbank.api.core.constant.USBConstants;
import com.usbank.poslp.merchant.details.constants.MerchantDetailsConstants;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;

import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.Silent.class)
public class MerchantDetailsInterceptorTest {

    @InjectMocks
    private MerchantDetailsInterceptor interceptor;

    @Mock
    private HttpServletRequest request;

    @Mock
    private HttpServletResponse response;

    @Before
    public void setUp() {
        // Initialize mocks
    }

    @Test
    public void testPreHandle_MissingContentTypeHeader() {
        when(request.getHeader(MerchantDetailsConstants.CONTENT_TYPE.toLowerCase())).thenReturn(null);
        assertThrows(BadRequestException.class, () -> interceptor.preHandle(request, response, new Object()));
    }

    @Test
    public void testPreHandle_MissingCorrelationIdHeader() {
        when(request.getHeader(MerchantDetailsConstants.CONTENT_TYPE.toLowerCase())).thenReturn("application/json");
        when(request.getHeader(USBConstants.CORRELATION_ID.toLowerCase())).thenReturn(null);
        assertThrows(BadRequestException.class, () -> interceptor.preHandle(request, response, new Object()));
    }

    @Test
    public void testPreHandle_MissingChannelIdHeader() {
        when(request.getHeader(MerchantDetailsConstants.CONTENT_TYPE.toLowerCase())).thenReturn("application/json");
        when(request.getHeader(USBConstants.CORRELATION_ID.toLowerCase())).thenReturn("correlation-id");
        when(request.getHeader(USBConstants.CHANNEL_ID.toLowerCase())).thenReturn(null);
        assertThrows(BadRequestException.class, () -> interceptor.preHandle(request, response, new Object()));
    }

    @Test
    public void testPreHandle_MissingApplicationIdHeader() {
        when(request.getHeader(MerchantDetailsConstants.CONTENT_TYPE.toLowerCase())).thenReturn("application/json");
        when(request.getHeader(USBConstants.CORRELATION_ID.toLowerCase())).thenReturn("correlation-id");
        when(request.getHeader(USBConstants.CHANNEL_ID.toLowerCase())).thenReturn("channel-id");
        when(request.getHeader(USBConstants.APPLICATION_ID.toLowerCase())).thenReturn(null);
        assertThrows(BadRequestException.class, () -> interceptor.preHandle(request, response, new Object()));
    }

    @Test
    public void testPreHandle_MissingSessionIdHeader() {
        when(request.getHeader(MerchantDetailsConstants.CONTENT_TYPE.toLowerCase())).thenReturn("application/json");
        when(request.getHeader(USBConstants.CORRELATION_ID.toLowerCase())).thenReturn("correlation-id");
        when(request.getHeader(USBConstants.CHANNEL_ID.toLowerCase())).thenReturn("channel-id");
        when(request.getHeader(USBConstants.APPLICATION_ID.toLowerCase())).thenReturn("application-id");
        when(request.getHeader(USBConstants.SESSION_ID.toLowerCase())).thenReturn(null);
        assertThrows(BadRequestException.class, () -> interceptor.preHandle(request, response, new Object()));
    }

    @Test
    public void testPreHandle_MissingAuthorizationHeader() {
        when(request.getHeader(MerchantDetailsConstants.CONTENT_TYPE.toLowerCase())).thenReturn("application/json");
        when(request.getHeader(USBConstants.CORRELATION_ID.toLowerCase())).thenReturn("correlation-id");
        when(request.getHeader(USBConstants.CHANNEL_ID.toLowerCase())).thenReturn("channel-id");
        when(request.getHeader(USBConstants.APPLICATION_ID.toLowerCase())).thenReturn("application-id");
        when(request.getHeader(USBConstants.SESSION_ID.toLowerCase())).thenReturn("session-id");
        when(request.getHeader(MerchantDetailsConstants.AUTHORIZATION.toLowerCase())).thenReturn(null);
        assertThrows(BadRequestException.class, () -> interceptor.preHandle(request, response, new Object()));
    }

    @Test
    public void testPreHandle_MissingPartnerIdHeader() {
        when(request.getHeader(MerchantDetailsConstants.CONTENT_TYPE.toLowerCase())).thenReturn("application/json");
        when(request.getHeader(USBConstants.CORRELATION_ID.toLowerCase())).thenReturn("correlation-id");
        when(request.getHeader(USBConstants.CHANNEL_ID.toLowerCase())).thenReturn("channel-id");
        when(request.getHeader(USBConstants.APPLICATION_ID.toLowerCase())).thenReturn("application-id");
        when(request.getHeader(USBConstants.SESSION_ID.toLowerCase())).thenReturn("session-id");
        when(request.getHeader(MerchantDetailsConstants.AUTHORIZATION.toLowerCase())).thenReturn("auth-key");
        when(request.getHeader(MerchantDetailsConstants.PARTNERID)).thenReturn(null);
        assertThrows(BadRequestException.class, () -> interceptor.preHandle(request, response, new Object()));
    }

    @Test
    public void testPreHandle_MissingMerchantIdHeader() {
        when(request.getHeader(MerchantDetailsConstants.CONTENT_TYPE.toLowerCase())).thenReturn("application/json");
        when(request.getHeader(USBConstants.CORRELATION_ID.toLowerCase())).thenReturn("correlation-id");
        when(request.getHeader(USBConstants.CHANNEL_ID.toLowerCase())).thenReturn("channel-id");
        when(request.getHeader(USBConstants.APPLICATION_ID.toLowerCase())).thenReturn("application-id");
        when(request.getHeader(USBConstants.SESSION_ID.toLowerCase())).thenReturn("session-id");
        when(request.getHeader(MerchantDetailsConstants.AUTHORIZATION.toLowerCase())).thenReturn("auth-key");
        when(request.getHeader(MerchantDetailsConstants.PARTNERID)).thenReturn("partner-id");
        when(request.getHeader(MerchantDetailsConstants.MERCHANT_ID_HEADER)).thenReturn(null);
        assertThrows(BadRequestException.class, () -> interceptor.preHandle(request, response, new Object()));
    }

    @Test
    public void testPreHandle_AllHeadersPresent() throws Exception {
        when(request.getHeader(MerchantDetailsConstants.CONTENT_TYPE.toLowerCase())).thenReturn("application/json");
        when(request.getHeader(USBConstants.CORRELATION_ID.toLowerCase())).thenReturn("correlation-id");
        when(request.getHeader(USBConstants.CHANNEL_ID.toLowerCase())).thenReturn("channel-id");
        when(request.getHeader(USBConstants.APPLICATION_ID.toLowerCase())).thenReturn("apply");
        when(request.getHeader(USBConstants.SESSION_ID.toLowerCase())).thenReturn("session-id");
        when(request.getHeader(MerchantDetailsConstants.AUTHORIZATION.toLowerCase())).thenReturn("auth-key");
        when(request.getHeader(MerchantDetailsConstants.PARTNERID)).thenReturn("partner-id");
        when(request.getHeader(MerchantDetailsConstants.MERCHANT_ID_HEADER)).thenReturn("merchant-id");

        boolean result = interceptor.preHandle(request, response, new Object());
        assert(result);
    }
}