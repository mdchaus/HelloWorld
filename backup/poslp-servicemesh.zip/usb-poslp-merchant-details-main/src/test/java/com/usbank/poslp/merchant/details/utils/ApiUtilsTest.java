package com.usbank.poslp.merchant.details.utils;

import com.usbank.api.core.component.requestcontext.RequestContext;
import com.usbank.api.core.exception.SubsystemDataException;
import com.usbank.api.core.exception.SubsystemUnavailableException;
import org.apache.http.entity.ContentType;
import org.junit.Assert;
import org.junit.Test;
import org.junit.jupiter.api.Assertions;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.http.HttpStatus;
import static org.junit.Assert.assertThrows;
import static org.junit.Assert.assertTrue;
import static org.mockito.Mockito.when;

import java.text.SimpleDateFormat;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import static com.usbank.poslp.core.clients.constant.HeaderConstant.CLIENT_APPLICATION;
import static com.usbank.poslp.merchant.details.constants.MerchantDetailsConstants.*;

@RunWith(MockitoJUnitRunner.class)
public class ApiUtilsTest {

    @InjectMocks
    private ApiUtils apiUtils;

    @Mock
    private SubsystemUnavailableException subsystemUnavailableException;

    @Mock
    private SubsystemDataException subsystemDataException;

    @Mock
    private RequestContext requestContext;

    @Test
    public  void testPrepareQueryParameter() {
        Map<String, String> queryParams = apiUtils.prepareQueryParameter();
        Assertions.assertNotNull(queryParams);
        Assertions.assertEquals(5, queryParams.size());
    }

    @Test
    public  void testInviteToApplyHeaders() {
        Map<String, String> map = new HashMap<>();
        map.put(CORRELATION_ID.toLowerCase(), "corelationid");
        requestContext.setHttpHeaders(map);
        Map<String, String> headerParams = apiUtils.inviteToApplyHeaders();
        Assertions.assertNotNull(headerParams);
        Assertions.assertEquals(5, headerParams.size());
        Assertions.assertEquals(headerParams.get(CONTENT_TYPE), String.valueOf(ContentType.APPLICATION_JSON));
        Assertions.assertEquals(headerParams.get(CLIENT_APPLICATION), USBWEB);
        Assertions.assertEquals(headerParams.get(CORRELATION_ID), requestContext.getHttpHeaders().get(CORRELATION_ID.toLowerCase()));
    }

    @Test
    public void testHandleSubsystemUnavailableException() {
        String inviteToApplyUrl = "https://localhost:8080/inviteToApply";
        subsystemUnavailableException = new SubsystemUnavailableException(inviteToApplyUrl, HttpStatus.INTERNAL_SERVER_ERROR, "Error");
        assertThrows(SubsystemUnavailableException.class, () -> apiUtils.handleSubsystemUnavailableException(subsystemUnavailableException));
    }

    @Test
    public void testHandleSubsystemDataException() {
        String inviteToApplyUrl = "https://localhost:8080/inviteToApply";
        subsystemDataException = new SubsystemDataException(inviteToApplyUrl, HttpStatus.FAILED_DEPENDENCY, "Failed dependency");
        assertThrows(SubsystemUnavailableException.class, () -> apiUtils.handleSubsystemDataException(subsystemDataException));
        Assert.assertNotNull(subsystemDataException.getResponseBody());

        subsystemDataException = new SubsystemDataException(inviteToApplyUrl, HttpStatus.REQUEST_TIMEOUT, "Request timeout");
        assertThrows(SubsystemUnavailableException.class, () -> apiUtils.handleSubsystemDataException(subsystemDataException));
        Assert.assertNotNull(subsystemDataException.getResponseBody());

        subsystemDataException = new SubsystemDataException(inviteToApplyUrl, HttpStatus.NO_CONTENT, "Other error");
        assertThrows(SubsystemDataException.class, () -> apiUtils.handleSubsystemDataException(subsystemDataException));
        Assert.assertNotNull(subsystemDataException.getResponseBody());
    }

    @Test
    public void testExpirationDateForTrue(){
        Date today = new Date();
        long ltime = today.getTime()+8*24*60*60*1000;
        Date futureDate = new Date(ltime);
        assertTrue(apiUtils.validate(futureDate));
    }

    @Test
    public void testExpirationDateForFalse(){
        Date today = new Date();
        long ltime = today.getTime()-8*24*60*60*1000;
        Date expiredDate = new Date(ltime);
        assertTrue(apiUtils.validate(expiredDate));
    }
}
