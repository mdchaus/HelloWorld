package com.usbank.poslp.merchant.details.datafetchers;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import com.netflix.graphql.dgs.DgsDataFetchingEnvironment;
import com.usbank.api.core.exception.BadRequestException;
import com.usbank.api.core.requesthandler.IRequestHandler;
import com.usbank.poslp.graphql.core.exceptions.GraphQLAPIException;
import com.usbank.poslp.merchant.details.constants.MerchantDetailsConstants;
import com.usbank.poslp.merchant.details.exception.GraphqlExceptionHandler;
import com.usbank.poslp.merchant.details.handler.InviteToApplyHandler;
import com.usbank.poslp.merchant.details.handler.MerchantDetailsValidationHandler;
import com.usbank.poslp.merchant.details.handler.MerchantDetailsHandler;
import com.usbank.poslp.merchant.details.model.request.MerchantDetailsInput;
import com.usbank.poslp.merchant.details.model.request.MerchantProducts;
import com.usbank.poslp.merchant.details.model.request.ValidateMerchantDetails;
import com.usbank.poslp.merchant.details.model.response.*;
import com.usbank.poslp.merchant.details.model.response.apply.InviteToApplyResponse;
import com.usbank.poslp.merchant.details.service.ValidateMerchantDetailsService;
import com.usbank.poslp.merchant.details.validator.MerchantDetailsValidator;
import graphql.GraphQLContext;
import graphql.cachecontrol.CacheControl;
import graphql.execution.ExecutionId;
import graphql.execution.ExecutionStepInfo;
import graphql.execution.MergedField;
import graphql.execution.directives.QueryDirectives;
import graphql.language.Document;
import graphql.language.Field;
import graphql.language.FragmentDefinition;
import graphql.language.OperationDefinition;
import graphql.schema.DataFetchingEnvironment;
import graphql.schema.DataFetchingFieldSelectionSet;
import graphql.schema.GraphQLFieldDefinition;
import graphql.schema.GraphQLOutputType;
import graphql.schema.GraphQLSchema;
import graphql.schema.GraphQLType;
import org.dataloader.DataLoader;
import org.dataloader.DataLoaderRegistry;
import org.junit.Assert;
import org.junit.jupiter.api.Assertions;
import org.junit.Test;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.runner.RunWith;
import org.mockito.ArgumentMatchers;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;

import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.Mockito.when;

import org.mockito.junit.MockitoJUnitRunner;
import org.mockito.junit.jupiter.MockitoExtension;
import org.mockito.junit.jupiter.MockitoSettings;
import org.mockito.quality.Strictness;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.context.request.RequestAttributes;
import org.springframework.web.context.request.RequestContextHolder;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.*;
import java.util.concurrent.CompletableFuture;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.springframework.test.util.ReflectionTestUtils.setField;

@RunWith(MockitoJUnitRunner.Silent.class)
@ExtendWith(MockitoExtension.class)
@MockitoSettings(strictness = Strictness.LENIENT)
public class MerchantDetailsDataFetcherTest {
    @InjectMocks
    MerchantDetailsDataFetcher merchantDetailsDataFetcher;


    @Mock
    DataFetchingEnvironment dataFetchingEnvironment;

    @Mock
    DgsDataFetchingEnvironment dgsDataFetchingEnvironment;

    @Mock
    private IRequestHandler<MerchantDetailsInput, MerchantDetails> merchantDetailsHandler;

    @Mock
    private IRequestHandler<MerchantDetailsInput, List<FeatureConfigurationResponse>> merchantDetailsFeatureHandler;

    @Mock
    private IRequestHandler<MerchantDetailsInput, List<MerchantProducts>> merchantProductsHandler;

    @Mock
    private GraphqlExceptionHandler exceptionHandler;

    @Mock
    private ValidateMerchantDetailsService validateMerchantDetailsService;

    @Mock
    private MerchantDetailsValidator merchantDetailsValidator;

    @Mock
    private InviteToApplyHandler inviteToApplyHandler;

    @Mock
    private MerchantDetailsValidationHandler merchantDetailsValidationHandlerHandlerHandler;


    @Value("${log.masking.fields}")
    public List<String> maskingFields;


//	@Test(=Exception.class)
//	public void getMerchantDetailsSuccess() throws Exception {
//		MerchantDetailsInput merchantDetailsInput = new MerchantDetailsInput();
//		MerchantDetails merchantDetails = MerchantDetails.builder().businessCountryCode("Test1").build();
//		merchantDetailsInput.setMerchantID("187366DB");
//		Mockito.when(merchantDetailsHandler.handle(merchantDetailsInput)).thenReturn(merchantDetails);
//		Mockito.when(merchantDetailsDataFetcher.getMerchantDetails(merchantDetailsInput)).thenReturn(ArgumentMatchers.any());
//		MerchantDetails response = merchantDetailsDataFetcher.getMerchantDetails(merchantDetailsInput);
//	}



    @BeforeEach
    public void setUp() {
        // Initialize the data fetcher and mocks
        merchantDetailsDataFetcher = new MerchantDetailsDataFetcher();
        dgsDataFetchingEnvironment = Mockito.mock(DgsDataFetchingEnvironment.class);
        merchantProductsHandler = Mockito.mock(IRequestHandler.class);

        // Set up the request attributes for the test context
        RequestAttributes requestAttributes = RequestContextHolder.currentRequestAttributes();
        RequestContextHolder.setRequestAttributes(requestAttributes);

        // Inject mocks into the data fetcher
        merchantDetailsDataFetcher.merchantProductsHandler = merchantProductsHandler;
    }
    @Test
    public void getMerchantDetails() {
        MerchantDetailsInput merchantDetailsInput = new MerchantDetailsInput();
        merchantDetailsInput.setMerchantID("9025368145");
        MerchantDetails merchantDetails = MerchantDetails.builder().merchantID("9025368145").bnplStatus("ACTIVE").accountStatus("OPEN").
                mccCode("1236548").build();
        try {
            when(merchantDetailsHandler.handle(merchantDetailsInput)).thenReturn(merchantDetails);
            ObjectMapper mapper = new ObjectMapper();
            mapper.registerModule(new JavaTimeModule());
            merchantDetailsDataFetcher.getMerchantDetails(merchantDetailsInput);
        } catch (Exception ex) {

        }

    }

    @Test
    public void getMerchantDetailsFailure() throws Exception {
        MerchantDetailsInput merchantDetailsInput = new MerchantDetailsInput();
        MerchantDetails merchantDetails = MerchantDetails.builder().businessCountryCode("Test1").build();
        merchantDetailsInput.setMerchantID("187366DB");
        Mockito.when(merchantDetailsHandler.handle(merchantDetailsInput)).thenThrow(new Exception());
//		Mockito.when(merchantDetailsDataFetcher.getMerchantDetails(merchantDetailsInput)).thenReturn(ArgumentMatchers.any());
        RuntimeException bde = new RuntimeException("Test Exception");
        Mockito.when(exceptionHandler.handleException(Mockito.any())).thenThrow(bde);


        assertThrows(RuntimeException.class, () -> merchantDetailsDataFetcher.getMerchantDetails(merchantDetailsInput));

    }

    @Test
    public void resolveShoppingCart() {
        ShoppingCartResponse shoppingCartResponse = new ShoppingCartResponse();
        shoppingCartResponse.setBillingState("State1");
        String actual = merchantDetailsDataFetcher.resolveShoppingCart(null);
        assertEquals(MerchantDetailsConstants.SHOPPING_CART, actual);

    }

    @Test
    public void getShoppingCartMerchantDetail() {
        ShoppingCartResponse shoppingCartResponse = new ShoppingCartResponse();
        String merchantID = "123498716";
        shoppingCartResponse.setBillingState("State1");
        Map<String, Object> values = new HashMap<>();
        values.put(MerchantDetailsConstants.MERCHANT_ID, "123498716");

        CompletableFuture<ShoppingCartResponse> shoppingCartResponseCompletableFuture = merchantDetailsDataFetcher.getShoppingCartMerchantDetail(values, null);
        Assert.assertNotNull(shoppingCartResponse);
    }

    @Test
    public void getShoppingCartMerchantDetails() throws Exception {
        DataFetchingEnvironment dataFetchingEnvironment = this.dataFetchingEnvironment;
        ShoppingCartResponse shoppingCart = new ShoppingCartResponse();
        MerchantDetails merchantDetailsResponse = MerchantDetails.builder().build();
        shoppingCart.setMerchantID("123452356");
        shoppingCart.setBillingState("Billing State");
        Mockito.when(dataFetchingEnvironment.getSource()).thenReturn(shoppingCart);
        Mockito.when(merchantDetailsHandler.handle(ArgumentMatchers.any())).thenReturn(merchantDetailsResponse);

        CompletableFuture<MerchantDetails> actualFeature = merchantDetailsDataFetcher.getShoppingCartMerchantDetails(dataFetchingEnvironment);
    }
//	}

    @Test
    public void getMerchantDetailsFeature() throws Exception {
        DgsDataFetchingEnvironment dgsDataFetchingEnvironment = this.dgsDataFetchingEnvironment;
        MerchantDetails merchantDetails = MerchantDetails.builder().merchantID("123").businessCountryCode("12334").build();
        FeatureConfigurationResponse feature = new FeatureConfigurationResponse();
        List<FeatureConfigurationResponse> featureConfigurationResponseList = new ArrayList<>();
        feature.setConfigurationName("PAGAYA");
        feature.setConfigurationValue("ENABLED");
        featureConfigurationResponseList.add(feature);
        Mockito.when(dgsDataFetchingEnvironment.getSource()).thenReturn(merchantDetails);
        Mockito.when(merchantDetailsFeatureHandler.handle(ArgumentMatchers.any())).thenReturn(featureConfigurationResponseList);

        CompletableFuture<List<FeatureConfigurationResponse>> actualFeature = merchantDetailsDataFetcher.getMerchantDetailsFeature(dgsDataFetchingEnvironment);
    }


    @org.junit.jupiter.api.Test
    public void getMerchantProducts() throws Exception {
        MerchantDetails merchantDetails = MerchantDetails.builder().merchantID("123").businessCountryCode("12334").build();
        List<MerchantProducts> listMerchantProducts = new ArrayList<>();
        MerchantProducts merchantProducts = new MerchantProducts();
        merchantProducts.setMerchantProductGuid(UUID.randomUUID());
        merchantProducts.setProductGuid(UUID.randomUUID());
        merchantProducts.setProductCode("POSLZER018_0001");
        merchantProducts.setTermCount(BigDecimal.valueOf(18));
        merchantProducts.setTermType("months");
        merchantProducts.setMerchantProductEffectiveDate(LocalDateTime.now());
        listMerchantProducts.add(merchantProducts);

        Mockito.when(dgsDataFetchingEnvironment.getSource()).thenReturn(merchantDetails);
        Mockito.when(merchantProductsHandler.handle(ArgumentMatchers.any())).thenReturn(listMerchantProducts);

        CompletableFuture<List<MerchantProducts>> merchantProductsList = merchantDetailsDataFetcher.getMerchantProducts(dgsDataFetchingEnvironment);
        assertNotNull(merchantProductsList);
    }


    @Test
    public void getShoppingCartMerchantDetailsWhenErrorIsPresent() throws Exception {
        DataFetchingEnvironment dataFetchingEnvironment = this.dataFetchingEnvironment;
        ShoppingCartResponse shoppingCart = new ShoppingCartResponse();
        PartialError error = new PartialError();
        error.setApiId("12345");
        shoppingCart.setError(error);
        MerchantDetails merchantDetailsResponse = MerchantDetails.builder().build();
        shoppingCart.setMerchantID("123452356");
        shoppingCart.setBillingState("Billing State");
        Mockito.when(dataFetchingEnvironment.getSource()).thenReturn(shoppingCart);
        assertThrows(GraphQLAPIException.class, () -> merchantDetailsDataFetcher.getShoppingCartMerchantDetails(dataFetchingEnvironment));
    }

    @Test
    public void validateMerchant_ReturnsValidResponse() throws Exception {
        setField(merchantDetailsDataFetcher, "merchantDetailsDisabled", "false");
        ValidateMerchantDetails validateMerchantDetails = new ValidateMerchantDetails();
        validateMerchantDetails.setAccountMid("12345");
        validateMerchantDetails.setApiSource("Converge");
        validateMerchantDetails.setContactFirstName("Test");
        validateMerchantDetails.setContactLastName("Test");
        validateMerchantDetails.setDDANumber("test12345");
        validateMerchantDetails.setProcessingCenterID("testCenter");
        validateMerchantDetails.setSSNorTaxId("testTaxId");

        ValidateMerchantResponse validateMerchantResponse = new ValidateMerchantResponse();
        validateMerchantResponse.setMerchantValid(true);

        Mockito.when(merchantDetailsValidationHandlerHandlerHandler.handle(validateMerchantDetails)).thenReturn(validateMerchantResponse);
        ValidateMerchantResponse validateMerchantResponseActual = merchantDetailsDataFetcher.validateMerchant(validateMerchantDetails);
        Assertions.assertNotNull(validateMerchantResponseActual);
        Assertions.assertTrue(validateMerchantResponseActual.isMerchantValid());
    }

    @Test
    public void validateMerchant_ThrowsUnsupportedOperationException_WhenServiceDisabled() throws Exception {
        setField(merchantDetailsDataFetcher, "merchantDetailsDisabled", "true");
        ValidateMerchantDetails validateMerchantDetails = new ValidateMerchantDetails();
        validateMerchantDetails.setAccountMid("12345");
        validateMerchantDetails.setApiSource("Converge");

        Assertions.assertThrows(UnsupportedOperationException.class,
                () -> merchantDetailsDataFetcher.validateMerchant(validateMerchantDetails));
    }

    @Test
    public void validateMerchant_ThrowsException_WhenValidationFails() throws Exception {
        setField(merchantDetailsDataFetcher, "merchantDetailsDisabled", "false");
        ValidateMerchantDetails validateMerchantDetails = new ValidateMerchantDetails();
        validateMerchantDetails.setAccountMid("12345");
        validateMerchantDetails.setApiSource("Converge");

        Mockito.doThrow(new RuntimeException("Validation failed")).when(merchantDetailsValidator).validate(validateMerchantDetails);
        Assertions.assertThrows(RuntimeException.class,
                () -> merchantDetailsDataFetcher.validateMerchant(validateMerchantDetails));
    }

    @Test
    public void testInviteToApply() throws Exception {
        setField(merchantDetailsDataFetcher, "merchantDetailsDisabled", "false");

        ValidateMerchantDetails validateMerchantDetails = new ValidateMerchantDetails();
        validateMerchantDetails.setAccountMid("12345");
        validateMerchantDetails.setApiSource("Converge");
        validateMerchantDetails.setContactFirstName("Test");
        validateMerchantDetails.setContactLastName("Test");
        validateMerchantDetails.setDDANumber("test12345");
        validateMerchantDetails.setProcessingCenterID("testCenter");
        validateMerchantDetails.setSSNorTaxId("testTaxId");

        ValidateMerchantResponse validateMerchantResponse = new ValidateMerchantResponse();
        validateMerchantResponse.setMerchantValid(true);
        validateMerchantResponse.setToken(UUID.randomUUID().toString());

        InviteToApplyResponse inviteToApplyResponse = new InviteToApplyResponse();
        inviteToApplyResponse.setApplyUrl("http://localhost:8080/applyUrl");

        Mockito.when(inviteToApplyHandler.handle(validateMerchantDetails)).thenReturn(inviteToApplyResponse);
        CompletableFuture<InviteToApplyResponse> inviteToApplyResponse1 = merchantDetailsDataFetcher.inviteToApply(validateMerchantDetails);
        Assertions.assertNotNull(inviteToApplyResponse1);
        Assertions.assertNotNull(inviteToApplyResponse1.get());
        Assertions.assertEquals(inviteToApplyResponse.getApplyUrl(), inviteToApplyResponse1.get().getApplyUrl());
    }

    @Test
    public void testInviteToApply_WhenException() throws Exception {
        setField(merchantDetailsDataFetcher, "merchantDetailsDisabled", "false");
        ValidateMerchantDetails validateMerchantDetails = new ValidateMerchantDetails();
        validateMerchantDetails.setAccountMid("12345");
        validateMerchantDetails.setApiSource("Converge");
        Mockito.when(inviteToApplyHandler.handle(validateMerchantDetails)).thenThrow(Exception.class);
        Assertions.assertThrows(Exception.class,
                () -> merchantDetailsDataFetcher.inviteToApply(validateMerchantDetails));
    }

    @Test
    public void testInviteToApply_WhenMerchantServiceDisabledException() throws Exception {
        setField(merchantDetailsDataFetcher, "merchantDetailsDisabled", "true");
        ValidateMerchantDetails validateMerchantDetails = new ValidateMerchantDetails();
        validateMerchantDetails.setAccountMid("12345");
        validateMerchantDetails.setApiSource("Converge");
        Assertions.assertThrows(UnsupportedOperationException.class,
                () -> merchantDetailsDataFetcher.inviteToApply(validateMerchantDetails));
    }

    @Test
    public void testValidateMerchant_WhenMerchantServiceDisabledException() throws Exception {
        setField(merchantDetailsDataFetcher, "merchantDetailsDisabled", "true");
        ValidateMerchantDetails validateMerchantDetails = new ValidateMerchantDetails();
        validateMerchantDetails.setAccountMid("12345");
        validateMerchantDetails.setApiSource("Converge");
        Assertions.assertThrows(UnsupportedOperationException.class,
                () -> merchantDetailsDataFetcher.validateMerchant(validateMerchantDetails));
    }

    @Test
    public void getShoppingCartMerchantDetailsForGraphqlQlCase() throws Exception {
        ShoppingCartResponse shoppingCart = new ShoppingCartResponse();
        MerchantDetails merchantDetailsResponse = MerchantDetails.builder().build();
        shoppingCart.setMerchantID("123452356");
        shoppingCart.setBillingState("Billing State");
        DataFetchingEnvironment dataFetchingEnvironment = new DataFetchingEnvironment() {
            @Override
            public <T> T getSource() {
                return (T) shoppingCart;
            }

            @Override
            public Map<String, Object> getArguments() {
                return null;
            }

            @Override
            public boolean containsArgument(String name) {
                return false;
            }

            @Override
            public <T> T getArgument(String name) {
                return null;
            }

            @Override
            public <T> T getArgumentOrDefault(String name, T defaultValue) {
                return null;
            }

            @Override
            public <T> T getContext() {
                return null;
            }

            @Override
            public GraphQLContext getGraphQlContext() {
                return null;
            }

            @Override
            public <T> T getLocalContext() {
                return null;
            }

            @Override
            public <T> T getRoot() {
                return null;
            }

            @Override
            public GraphQLFieldDefinition getFieldDefinition() {
                return null;
            }

            @Override
            public List<Field> getFields() {
                return null;
            }

            @Override
            public MergedField getMergedField() {
                return null;
            }

            @Override
            public Field getField() {
                return null;
            }

            @Override
            public GraphQLOutputType getFieldType() {
                return null;
            }

            @Override
            public ExecutionStepInfo getExecutionStepInfo() {
                return null;
            }

            @Override
            public GraphQLType getParentType() {
                return null;
            }

            @Override
            public GraphQLSchema getGraphQLSchema() {
                return null;
            }

            @Override
            public Map<String, FragmentDefinition> getFragmentsByName() {
                return null;
            }

            @Override
            public ExecutionId getExecutionId() {
                return null;
            }

            @Override
            public DataFetchingFieldSelectionSet getSelectionSet() {
                return null;
            }

            @Override
            public QueryDirectives getQueryDirectives() {
                return null;
            }

            @Override
            public <K, V> DataLoader<K, V> getDataLoader(String dataLoaderName) {
                return null;
            }

            @Override
            public DataLoaderRegistry getDataLoaderRegistry() {
                return null;
            }

            @Override
            public CacheControl getCacheControl() {
                return null;
            }

            @Override
            public Locale getLocale() {
                return null;
            }

            @Override
            public OperationDefinition getOperationDefinition() {
                return null;
            }

            @Override
            public Document getDocument() {
                return null;
            }

            @Override
            public Map<String, Object> getVariables() {
                return null;
            }
        };


        Mockito.when(merchantDetailsHandler.handle(ArgumentMatchers.any())).thenThrow(Exception.class);
        RuntimeException exe = new RuntimeException("Test Graphql Exception");
        Mockito.when(exceptionHandler.handleException(Mockito.any())).thenThrow(exe);

        assertThrows(RuntimeException.class, () -> merchantDetailsDataFetcher.getShoppingCartMerchantDetails(dataFetchingEnvironment));
    }
}

