package com.usbank.poslp.merchant.details.service;


import com.fasterxml.jackson.databind.ObjectMapper;
import com.usbank.api.core.aspect.LogExecutionTime;
import com.usbank.api.core.exception.PoslpAPIException;
import com.usbank.api.core.exception.SubsystemUnavailableException;
import com.usbank.api.core.modelservice.IModelService;
import com.usbank.poslp.commons.entities.Merchant;
import com.usbank.poslp.commons.entities.MerchantProduct;
import com.usbank.poslp.merchant.details.advice.MerchantExceptionHandler;
import com.usbank.poslp.merchant.details.constants.CustomErrorCodes;
import com.usbank.poslp.merchant.details.mapper.response.MerchantProductsResponseMapper;
import com.usbank.poslp.merchant.details.model.request.MerchantDetailsInput;
import com.usbank.poslp.merchant.details.model.request.MerchantProducts;
import com.usbank.poslp.merchant.details.repository.MerchantDetailsRepository;
import org.hibernate.exception.JDBCConnectionException;
import org.junit.Before;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.dao.DataAccessResourceFailureException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.CannotCreateTransactionException;


import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.concurrent.CompletableFuture;


import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class MerchantProductsServiceTest {

    @InjectMocks
    MerchantProductsService merchantProductsService;

    @Mock
	private MerchantDetailsRepository merchantRepository;

	@Mock
	private MerchantProductsResponseMapper productsResponseMapper;

	@Mock
	private MerchantExceptionHandler exceptionHandler;

    private MerchantDetailsInput request;
    private Merchant merchant;
    private List<MerchantProduct> productList;
    private List<MerchantProducts> merchantProductsList;

    @Before
    public void setUp() {
        request = new MerchantDetailsInput();
        request.setMerchantID("12345");

        merchant = new Merchant();
        merchant.setMerchantId("12345");
        merchant.setBnplStatus("ACTIVE");

        productList = new ArrayList<>();
        MerchantProduct product = new MerchantProduct();
        productList.add(product);
        merchant.setMerchantProducts(productList);

        merchantProductsList = new ArrayList<>();
        MerchantProducts merchantProduct = new MerchantProducts();
        merchantProductsList.add(merchantProduct);
    }

    @Test
    public void processTestWhenRequestWithProducts() throws Exception {
        when(merchantRepository.findByIdWithProducts(any(String.class))).thenReturn(Optional.of(merchant));
        when(productsResponseMapper.map(any(List.class))).thenReturn(merchantProductsList);

        List<MerchantProducts> result =  merchantProductsService.process(request);

        assertEquals(merchantProductsList, result);
    }

    @Test
    public void processTestWhenMerchantIdNull() {
        MerchantDetailsInput request = new MerchantDetailsInput();
        request.setMerchantID(null);
        PoslpAPIException exe = new PoslpAPIException(CustomErrorCodes.NO_MERCHANT_FOUND.getErrorCode(), CustomErrorCodes.NO_MERCHANT_FOUND.getErrorDescription());

        Mockito.when(exceptionHandler.commonAPIException(any())).thenThrow(exe);
        assertThrows(PoslpAPIException.class, () -> merchantProductsService.process(request));
    }

    @Test
    public void processTestWhenMerchantNotActive() {
        merchant.setBnplStatus("INACTIVE");
        when(merchantRepository.findByIdWithProducts(any(String.class))).thenReturn(Optional.of(merchant));
        PoslpAPIException exe = new PoslpAPIException(CustomErrorCodes.MERCHANT_ID_EXPIRED.getErrorCode(), CustomErrorCodes.MERCHANT_ID_EXPIRED.getErrorDescription());

        Mockito.when(exceptionHandler.commonAPIException(any())).thenThrow(exe);
        assertThrows(PoslpAPIException.class, () -> merchantProductsService.process(request));
    }

    @Test
    public void processTestWhenDatabaseConnectionError() {
        when(merchantRepository.findByIdWithProducts(any(String.class))).thenThrow(new JDBCConnectionException("Database connection error", null));
        SubsystemUnavailableException ex = new SubsystemUnavailableException(CustomErrorCodes.DB_CONNECTION_ERROR.getErrorCode(), CustomErrorCodes.DB_CONNECTION_ERROR.getErrorDescription(), "Database connection error");
        assertThrows(SubsystemUnavailableException.class, () -> merchantProductsService.process(request));
    }

}
