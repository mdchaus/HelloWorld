package com.usbank.poslp.merchant.details.validator;

import com.usbank.api.core.exception.BadRequestException;
import com.usbank.api.core.exception.PoslpAPIException;
import com.usbank.poslp.merchant.details.constants.CustomErrorCodes;
import com.usbank.poslp.merchant.details.model.request.ValidateMerchantDetails;
import com.usbank.poslp.merchant.details.model.response.MerchantDetailsBody;
import com.usbank.poslp.merchant.details.model.response.MerchantDetailsResponse;
import com.usbank.poslp.merchant.details.model.response.SRSApiToken;
import com.usbank.poslp.merchant.details.utils.ApiUtils;
import org.junit.Test;
import org.junit.jupiter.api.Assertions;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

@RunWith(MockitoJUnitRunner.class)
public class MerchantDetailsValidatorTest {

    @Mock
    private ApiUtils apiUtils;

    @Mock
    private ResponseEntity<?> responseEntity;

    @InjectMocks
    private MerchantDetailsValidator merchantDetailsValidator;

    private ValidateMerchantDetails getValidateMerchantDetails() {
        ValidateMerchantDetails validateMerchantDetails = new ValidateMerchantDetails();
        validateMerchantDetails.setAccountMid("12345");
        validateMerchantDetails.setApiSource("Converge");
        validateMerchantDetails.setContactFirstName("Test");
        validateMerchantDetails.setContactLastName("Test");
        validateMerchantDetails.setDDANumber("test12345");
        validateMerchantDetails.setProcessingCenterID("testCenter");
        validateMerchantDetails.setSSNorTaxId("testTaxId");
        return validateMerchantDetails;
    }

    @Test
    public void testValidate_WhenValidateMerchantDetailsIsNull() {
        BadRequestException ex= Assertions.assertThrows(BadRequestException.class,
                () -> merchantDetailsValidator.validate(null));
        Assertions.assertEquals(CustomErrorCodes.VALIDATE_MERCHANT_DETAILS_ERROR.getErrorCode(), ex.getErrorCode());
        Assertions.assertEquals(CustomErrorCodes.VALIDATE_MERCHANT_DETAILS_ERROR.getErrorDescription(), ex.getErrorMessage());
    }

    @Test
    public void testValidate_WhenAccountMidIsNull() {
        ValidateMerchantDetails validateMerchantDetails = getValidateMerchantDetails();
        validateMerchantDetails.setAccountMid(null);
        BadRequestException ex= Assertions.assertThrows(BadRequestException.class,
                () -> merchantDetailsValidator.validate(validateMerchantDetails));
        Assertions.assertEquals(CustomErrorCodes.VALIDATE_MERCHANT_DETAILS_ERROR.getErrorCode(), ex.getErrorCode());
        Assertions.assertEquals(CustomErrorCodes.VALIDATE_MERCHANT_DETAILS_ERROR.getErrorDescription(), ex.getErrorMessage());
    }

    @Test
    public void testValidate_WhenApiSourceIsNull() {
        ValidateMerchantDetails validateMerchantDetails = getValidateMerchantDetails();
        validateMerchantDetails.setApiSource(null);
        BadRequestException ex= Assertions.assertThrows(BadRequestException.class,
                () -> merchantDetailsValidator.validate(validateMerchantDetails));
        Assertions.assertEquals(CustomErrorCodes.VALIDATE_MERCHANT_DETAILS_ERROR.getErrorCode(), ex.getErrorCode());
        Assertions.assertEquals(CustomErrorCodes.VALIDATE_MERCHANT_DETAILS_ERROR.getErrorDescription(), ex.getErrorMessage());
    }

    @Test
    public void testValidate_WhenContactFirstNameIsNull() {
        ValidateMerchantDetails validateMerchantDetails = getValidateMerchantDetails();
        validateMerchantDetails.setContactFirstName(null);
        BadRequestException ex= Assertions.assertThrows(BadRequestException.class,
                () -> merchantDetailsValidator.validate(validateMerchantDetails));
        Assertions.assertEquals(CustomErrorCodes.VALIDATE_MERCHANT_DETAILS_ERROR.getErrorCode(), ex.getErrorCode());
        Assertions.assertEquals(CustomErrorCodes.VALIDATE_MERCHANT_DETAILS_ERROR.getErrorDescription(), ex.getErrorMessage());
    }

    @Test
    public void testValidate_WhenContactLastNameIsNull() {
        ValidateMerchantDetails validateMerchantDetails = getValidateMerchantDetails();
        validateMerchantDetails.setContactLastName(null);
        BadRequestException ex= Assertions.assertThrows(BadRequestException.class,
                () -> merchantDetailsValidator.validate(validateMerchantDetails));
        Assertions.assertEquals(CustomErrorCodes.VALIDATE_MERCHANT_DETAILS_ERROR.getErrorCode(), ex.getErrorCode());
        Assertions.assertEquals(CustomErrorCodes.VALIDATE_MERCHANT_DETAILS_ERROR.getErrorDescription(), ex.getErrorMessage());
    }

    @Test
    public void testValidate_WhenDDANumberIsNull() {
        ValidateMerchantDetails validateMerchantDetails = getValidateMerchantDetails();
        validateMerchantDetails.setDDANumber(null);
        BadRequestException ex= Assertions.assertThrows(BadRequestException.class,
                () -> merchantDetailsValidator.validate(validateMerchantDetails));
        Assertions.assertEquals(CustomErrorCodes.VALIDATE_MERCHANT_DETAILS_ERROR.getErrorCode(), ex.getErrorCode());
        Assertions.assertEquals(CustomErrorCodes.VALIDATE_MERCHANT_DETAILS_ERROR.getErrorDescription(), ex.getErrorMessage());
    }

    @Test
    public void testValidate_WhenProcessingCenterIDIsNull() {
        ValidateMerchantDetails validateMerchantDetails = getValidateMerchantDetails();
        validateMerchantDetails.setProcessingCenterID(null);
        BadRequestException ex= Assertions.assertThrows(BadRequestException.class,
                () -> merchantDetailsValidator.validate(validateMerchantDetails));
        Assertions.assertEquals(CustomErrorCodes.VALIDATE_MERCHANT_DETAILS_ERROR.getErrorCode(), ex.getErrorCode());
        Assertions.assertEquals(CustomErrorCodes.VALIDATE_MERCHANT_DETAILS_ERROR.getErrorDescription(), ex.getErrorMessage());
    }

    @Test
    public void testValidate_WhenSSNorTaxIdIsNull() {
        ValidateMerchantDetails validateMerchantDetails = getValidateMerchantDetails();
        validateMerchantDetails.setSSNorTaxId(null);
        BadRequestException ex= Assertions.assertThrows(BadRequestException.class,
                () -> merchantDetailsValidator.validate(validateMerchantDetails));
        Assertions.assertEquals(CustomErrorCodes.VALIDATE_MERCHANT_DETAILS_ERROR.getErrorCode(), ex.getErrorCode());
        Assertions.assertEquals(CustomErrorCodes.VALIDATE_MERCHANT_DETAILS_ERROR.getErrorDescription(), ex.getErrorMessage());
    }

    @Test
    public void testValidate_WhenApiSourceIsInvalid() {
        ValidateMerchantDetails validateMerchantDetails = getValidateMerchantDetails();
        validateMerchantDetails.setApiSource("BNPLPARTNER");
        BadRequestException ex= Assertions.assertThrows(BadRequestException.class,
                () -> merchantDetailsValidator.validate(validateMerchantDetails));
        Assertions.assertEquals(CustomErrorCodes.VALIDATE_MERCHANT_DETAILS_ERROR.getErrorCode(), ex.getErrorCode());
        Assertions.assertEquals(CustomErrorCodes.VALIDATE_MERCHANT_DETAILS_ERROR.getErrorDescription(), ex.getErrorMessage());
    }

    @Test
    public void testValidate_DDANumberIsInvalid() {
        ValidateMerchantDetails validateMerchantDetails = getValidateMerchantDetails();
        validateMerchantDetails.setDDANumber("123456");
        BadRequestException ex= Assertions.assertThrows(BadRequestException.class,
                () -> merchantDetailsValidator.validate(validateMerchantDetails));
        Assertions.assertEquals(CustomErrorCodes.VALIDATE_MERCHANT_DETAILS_ERROR.getErrorCode(), ex.getErrorCode());
        Assertions.assertEquals(CustomErrorCodes.VALIDATE_MERCHANT_DETAILS_ERROR.getErrorDescription(), ex.getErrorMessage());
    }
    @Test
    public void testValid_DDANumber() {
        ValidateMerchantDetails validateMerchantDetails = getValidateMerchantDetails();
        validateMerchantDetails.setDDANumber("12345");
        Assertions.assertTrue(validateMerchantDetails.getDDANumber().length() == 5);
    }
}
