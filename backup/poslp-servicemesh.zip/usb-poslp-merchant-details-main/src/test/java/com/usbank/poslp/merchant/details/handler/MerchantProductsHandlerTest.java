package com.usbank.poslp.merchant.details.handler;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.usbank.api.core.component.requestcontext.IRequestContext;
import com.usbank.api.core.constant.USBConstants;
import com.usbank.poslp.commons.entities.*;
import com.usbank.poslp.merchant.details.advice.MerchantExceptionHandler;
import com.usbank.poslp.merchant.details.constants.MerchantDetailsConstants;
import com.usbank.poslp.merchant.details.model.request.MerchantDetailsInput;
import com.usbank.poslp.merchant.details.model.request.MerchantProducts;
import com.usbank.poslp.merchant.details.model.response.MerchantDetails;
import com.usbank.poslp.merchant.details.service.MerchantProductsService;
import com.usbank.poslp.merchant.details.validator.MerchantDetailsRequestValidator;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;

import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertNotNull;
import static org.mockito.Mockito.when;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.*;

@RunWith(MockitoJUnitRunner.class)
public class MerchantProductsHandlerTest {

    @InjectMocks
    private MerchantProductsHandler merchantProductsHandler;
    

    @Mock
    private MerchantProductsService merchantProductsService;

    @Mock
    MerchantDetailsRequestValidator merchantRequestValidator;

    @Mock
    private MerchantExceptionHandler exceptionHandler;

    @Mock
    ObjectMapper objectMapper;

    @Mock
    private IRequestContext requestContext;

    @Test
    public void productHandlerTest() throws Exception {
    {
        Map<String, String> map = new HashMap<>();
        map.put(USBConstants.CLIENT_ID, MerchantDetailsConstants.APIGEE);
        when(requestContext.getHttpHeaders()).thenReturn(map);
        Merchant merchant=new Merchant();
        List<MerchantProduct> productList=new ArrayList<>();
        MerchantProduct merchantProduct=new MerchantProduct();
        MerchantProduct merchantProduct1=new MerchantProduct();
        Product product=new Product();
        Product product1=new Product();
        product.setProductCode("BNPL");
        merchantProduct.setProduct(product);
        merchantProduct1.setProduct(product1);
        productList.add(merchantProduct);
        productList.add(merchantProduct1);
        MerchantDetails merchantDetails=MerchantDetails.builder().merchantID("12345677").accountStatus("Active").build();
        merchant.setAccountStatus("ACTIVE");
        merchant.setMerchantDbaName("testDb1");
        merchant.setMerchantProducts(productList);
        Optional<Merchant> merchantDetail = Optional.ofNullable(merchant);
        merchantDetail.get().setBnplStatus("ACTIVE");

        MerchantDetailsInput request=new MerchantDetailsInput();
        request.setMerchantID("887772227999");
        List<ProductBand> productBandList = new ArrayList<ProductBand>();
        List<ProductFicoBand> productFicoBandList = new ArrayList<ProductFicoBand>();

        List<MerchantProducts> listMerchantProducts = new ArrayList<>();
        MerchantProducts merchantProducts = new MerchantProducts();
        merchantProducts.setMerchantProductGuid(UUID.randomUUID());
        merchantProducts.setProductGuid(UUID.randomUUID());
        merchantProducts.setProductCode("POSLZER018_0001");
        merchantProducts.setTermCount(BigDecimal.valueOf(18));
        merchantProducts.setTermType("months");
        merchantProducts.setMerchantProductEffectiveDate(LocalDateTime.now());
        listMerchantProducts.add(merchantProducts);
        Mockito.when(merchantProductsService.process(Mockito.any())).thenReturn(listMerchantProducts);
        assertNotNull(merchantProductsHandler.handle(new MerchantDetailsInput()));
    }
}

    @Test
    public void productHandlerTestForException() throws Exception {
    {
        Merchant merchant=new Merchant();
        List<MerchantProduct> productList=new ArrayList<>();
        MerchantProduct merchantProduct=new MerchantProduct();
        MerchantProduct merchantProduct1=new MerchantProduct();
        Product product=new Product();
        Product product1=new Product();
        product.setProductCode("BNPL");
        merchantProduct.setProduct(product);
        merchantProduct1.setProduct(product1);
        productList.add(merchantProduct);
        productList.add(merchantProduct1);
        MerchantDetails merchantDetails=MerchantDetails.builder().merchantID("12345677").accountStatus("Active").build();
        merchant.setAccountStatus("ACTIVE");
        merchant.setMerchantDbaName("testDb1");
        merchant.setMerchantProducts(productList);
        Optional<Merchant> merchantDetail = Optional.ofNullable(merchant);
        merchantDetail.get().setBnplStatus("ACTIVE");

        MerchantDetailsInput request=new MerchantDetailsInput();
        request.setMerchantID("887772227999");
        List<ProductBand> productBandList = new ArrayList<ProductBand>();
        List<ProductFicoBand> productFicoBandList = new ArrayList<ProductFicoBand>();

        List<MerchantProducts> listMerchantProducts = new ArrayList<>();
        MerchantProducts merchantProducts = new MerchantProducts();
        merchantProducts.setMerchantProductGuid(UUID.randomUUID());
        merchantProducts.setProductGuid(UUID.randomUUID());
        merchantProducts.setProductCode("POSLZER018_0001");
        merchantProducts.setTermCount(BigDecimal.valueOf(18));
        merchantProducts.setTermType("months");
        merchantProducts.setMerchantProductEffectiveDate(LocalDateTime.now());
        listMerchantProducts.add(merchantProducts);
        Mockito.when(merchantProductsService.process(Mockito.any())).thenReturn(listMerchantProducts);
        assertNotNull(merchantProductsHandler.handle(null));
    }
}

    @Test
    public void productHandlerForExceptionWithHeader() throws Exception{
        Map<String, String> map = new HashMap<>();
        map.put(USBConstants.CLIENT_ID, MerchantDetailsConstants.USBWEB);
        when(requestContext.getHttpHeaders()).thenReturn(map);
        Merchant merchant=new Merchant();
        List<MerchantProduct> productList=new ArrayList<>();
        MerchantProduct merchantProduct=new MerchantProduct();
        MerchantProduct merchantProduct1=new MerchantProduct();
        Product product=new Product();
        Product product1=new Product();
        product.setProductCode("BNPL");
        merchantProduct.setProduct(product);
        merchantProduct1.setProduct(product1);
        productList.add(merchantProduct);
        productList.add(merchantProduct1);
        MerchantDetails merchantDetails=MerchantDetails.builder().merchantID("12345677").accountStatus("Active").build();
        merchant.setAccountStatus("ACTIVE");
        merchant.setMerchantDbaName("testDb1");
        merchant.setMerchantProducts(productList);
        Optional<Merchant> merchantDetail = Optional.ofNullable(merchant);
        merchantDetail.get().setBnplStatus("ACTIVE");

        MerchantDetailsInput request=new MerchantDetailsInput();
        request.setMerchantID("887772227999");
        List<ProductBand> productBandList = new ArrayList<ProductBand>();
        List<ProductFicoBand> productFicoBandList = new ArrayList<ProductFicoBand>();

        List<MerchantProducts> listMerchantProducts = new ArrayList<>();
        MerchantProducts merchantProducts = new MerchantProducts();
        merchantProducts.setMerchantProductGuid(UUID.randomUUID());
        merchantProducts.setProductGuid(UUID.randomUUID());
        merchantProducts.setProductCode("POSLZER018_0001");
        merchantProducts.setTermCount(BigDecimal.valueOf(18));
        merchantProducts.setTermType("months");
        merchantProducts.setMerchantProductEffectiveDate(LocalDateTime.now());
        listMerchantProducts.add(merchantProducts);
        Mockito.when(merchantProductsService.process(Mockito.any())).thenReturn(listMerchantProducts);
        assertNotNull(merchantProductsHandler.handle(null));
    }
}
