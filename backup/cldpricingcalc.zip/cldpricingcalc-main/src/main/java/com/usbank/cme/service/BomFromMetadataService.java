package com.usbank.cme.service;


import com.azure.core.http.policy.HttpLogDetailLevel;
import com.azure.core.management.AzureEnvironment;
import com.azure.core.management.Region;
import com.azure.core.management.profile.AzureProfile;
import com.azure.identity.ClientSecretCredential;
import com.azure.identity.ClientSecretCredentialBuilder;
import com.azure.identity.DefaultAzureCredential;
import com.azure.identity.DefaultAzureCredentialBuilder;
import com.azure.resourcemanager.AzureResourceManager;
import com.azure.resourcemanager.compute.models.ComputeResourceType;
import com.azure.resourcemanager.resources.models.GenericResource;
import com.azure.resourcemanager.resources.models.ResourceGroup;
import com.fasterxml.jackson.databind.MapperFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.ObjectWriter;
import com.fasterxml.jackson.databind.PropertyNamingStrategies;
import com.fasterxml.jackson.databind.json.JsonMapper;
import com.usbank.cme.car.Car;
import com.usbank.cme.dto.*;
import com.usbank.cme.resourcelist.Resource;
import com.usbank.cme.resourcemanager.*;
import com.usbank.cme.resourcemanager.ManagedDiskSku;
import lombok.extern.slf4j.Slf4j;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;
import org.springframework.util.Base64Utils;
import org.springframework.util.StringUtils;
import org.springframework.web.reactive.function.client.WebClient;

import javax.net.ssl.KeyManagerFactory;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.security.KeyStore;
import java.util.*;

@Service
@Slf4j
public class BomFromMetadataService {


    @Autowired
    @Qualifier("restapiWebClient")
    private WebClient webClient;

    @Value("${CAR_API_USERNAME}")
    private String carApiUsername;

    @Value("${CAR_API_PASSWORD:errorBecauseUndefined}")
    private String carApiPassword;

    @Value("${CAR_API_REQUEST_URL}")
    private String carApiRequestURL;

    @Value("${AZURE_TENANT_ID}")
    private String spTenantId;


    private Map<String, String> computeSkuMap = new HashMap<>();
    private Map<String, VmSku> vmSkuMap = new HashMap<>();
    private Map<String, SqlDbSku> sqlDbSkuMap = new HashMap<>();
    private Map<String, ManagedDiskSku> diskSkuMap = new HashMap<>();

    public ByteArrayInputStream generateBomFromMetadata(String carId, Boolean isSecondaryRegion, String appContextNames, String devSubscriptions,
                                                        Boolean hasVirtualMachines,
                                                        Boolean hasDatabase,
                                                        // VM
                                                        VMType vmOsType,
                                                        VMMaintenanceType maintenanceType, int noOfLBs,
                                                        int noOfDevVms, VmSkuEnum devVmSku, ManagedDiskSkuEnum devVmOsDiskSku, ManagedDiskSkuEnum devVmDataDiskSku,
                                                        int noOfITVms, VmSkuEnum itVmSku, ManagedDiskSkuEnum itVmOsDiskSku, ManagedDiskSkuEnum itVmDataDiskSku,
                                                        int noOfUATVms, VmSkuEnum uatVmSku, ManagedDiskSkuEnum uatVmOsDiskSku, ManagedDiskSkuEnum uatVmDataDiskSku,
                                                        int noOfPRODVms, VmSkuEnum prodVmSku, ManagedDiskSkuEnum prodVmOsDiskSku, ManagedDiskSkuEnum prodVmDataDiskSku,
                                                        //DB
                                                        DBType dbType,
                                                        SqlDbSkuEnum devDbSku, ManagedDiskSkuEnum devDbDiskSku,
                                                        SqlDbSkuEnum itDbSku, ManagedDiskSkuEnum itDbDiskSku,
                                                        SqlDbSkuEnum uatDbSku, ManagedDiskSkuEnum uatDbDiskSku,
                                                        SqlDbSkuEnum prodDbSku, ManagedDiskSkuEnum prodDbDiskSku
    ) throws IOException, IllegalArgumentException {
        if (carApiPassword == null || carApiPassword.isEmpty() || carApiPassword.equals("errorBecauseUndefined")) {
            log.error("CAR API token is not set.  Please define the CAR_API_PASSWORD environment variable or define the secret in K8s. Exiting...");
            return null;
        }

        BomMetadata bomMetadata = new BomMetadata();


        bomMetadata.setCarId(carId);
        bomMetadata.setSecondaryRegion(isSecondaryRegion);
        bomMetadata.setIsAppUsingStorage(true);
        bomMetadata.setAppContextNames(appContextNames);
        bomMetadata.setDevSubscriptions(devSubscriptions);
        bomMetadata.setItSubscriptions(bomMetadata.getDevSubscriptions().replace("dev", "it"));
        bomMetadata.setUatSubscriptions(bomMetadata.getDevSubscriptions().replace("dev", "uat"));
        bomMetadata.setProdSubscriptions(bomMetadata.getDevSubscriptions().replace("dev", "prod"));

        try {
            populateAzureDetails(bomMetadata, hasVirtualMachines, hasDatabase, dbType);
        } catch (Exception e) {
            e.printStackTrace();
        }

        bomMetadata.setMaintenanceType(maintenanceType.toString());
        if (noOfLBs > 0)
            bomMetadata.setIsLBNeeded(Boolean.TRUE);
        else
            bomMetadata.setIsLBNeeded(Boolean.FALSE);

        ManagedDiskSku osDiskSku;
        ManagedDiskSku dataDiskSku;

        if (noOfDevVms > 0) {

            VM thisVM = new VM();
            thisVM.setEnv(ENV.DEV);
            thisVM.setCount(noOfDevVms);
            thisVM.setSku(devVmSku.name());
            thisVM.setMaintenanceType(maintenanceType);
            thisVM.setType(vmOsType);
            thisVM.setFamily(computeSkuMap.get(devVmSku.name()));

            if (devVmDataDiskSku != ManagedDiskSkuEnum.NONE) {
                dataDiskSku = new ManagedDiskSku(devVmDataDiskSku);
                ManagedDisk disk2 = new ManagedDisk(ManagedDiskType.DATADISK, Integer.valueOf(dataDiskSku.capacity), dataDiskSku.getFormattedSkuName(), dataDiskSku.getFormattedTier(),dataDiskSku.redundancy);
                thisVM.setDataDisk(disk2);
            }
            osDiskSku = new ManagedDiskSku(devVmOsDiskSku);
            ManagedDisk disk1 = new ManagedDisk(ManagedDiskType.OSDISK, Integer.valueOf(osDiskSku.capacity), osDiskSku.getFormattedSkuName(), osDiskSku.getFormattedTier(),osDiskSku.redundancy);
            thisVM.setOsDisk(disk1);

            bomMetadata.getVms().add(thisVM);
        }
        if (noOfITVms > 0) {
 
            VM thisVM = new VM();
            thisVM.setEnv(ENV.IT);
            thisVM.setCount(noOfITVms);
            thisVM.setSku(itVmSku.name());
            thisVM.setMaintenanceType(maintenanceType);
            thisVM.setType(vmOsType);
            thisVM.setFamily(computeSkuMap.get(itVmSku.name()));

            if (itVmDataDiskSku != ManagedDiskSkuEnum.NONE) {
                dataDiskSku = new ManagedDiskSku(itVmDataDiskSku);
                ManagedDisk disk2 = new ManagedDisk(ManagedDiskType.DATADISK, Integer.valueOf(dataDiskSku.capacity), dataDiskSku.getFormattedSkuName(), dataDiskSku.getFormattedTier(),dataDiskSku.redundancy);
                thisVM.setDataDisk(disk2);
            }
            osDiskSku = new ManagedDiskSku(itVmOsDiskSku);
            ManagedDisk disk1 = new ManagedDisk(ManagedDiskType.OSDISK, Integer.valueOf(osDiskSku.capacity), osDiskSku.getFormattedSkuName(), osDiskSku.getFormattedTier(),osDiskSku.redundancy);
            thisVM.setOsDisk(disk1);

            bomMetadata.getVms().add(thisVM);
        }
        if (noOfUATVms > 0) {
 
            VM thisVM = new VM();
            thisVM.setEnv(ENV.UAT);
            thisVM.setCount(noOfUATVms);
            thisVM.setSku(uatVmSku.name());
            thisVM.setMaintenanceType(maintenanceType);
            thisVM.setType(vmOsType);
            thisVM.setFamily(computeSkuMap.get(uatVmSku.name()));

            if (uatVmDataDiskSku != ManagedDiskSkuEnum.NONE) {
                dataDiskSku = new ManagedDiskSku(uatVmDataDiskSku);
                ManagedDisk disk2 = new ManagedDisk(ManagedDiskType.DATADISK, Integer.valueOf(dataDiskSku.capacity), dataDiskSku.getFormattedSkuName(), dataDiskSku.getFormattedTier(),dataDiskSku.redundancy);
                thisVM.setDataDisk(disk2);
            }
            osDiskSku = new ManagedDiskSku(uatVmOsDiskSku);
            ManagedDisk disk1 = new ManagedDisk(ManagedDiskType.OSDISK, Integer.valueOf(osDiskSku.capacity), osDiskSku.getFormattedSkuName(), osDiskSku.getFormattedTier(),osDiskSku.redundancy);
            thisVM.setOsDisk(disk1);

            bomMetadata.getVms().add(thisVM);
        }

        if (noOfPRODVms > 0) {
 
            VM thisVM = new VM();
            thisVM.setEnv(ENV.PROD);
            thisVM.setCount(noOfPRODVms);
            thisVM.setSku(prodVmSku.name());
            thisVM.setMaintenanceType(maintenanceType);
            thisVM.setType(vmOsType);
            thisVM.setFamily(computeSkuMap.get(prodVmSku.name()));

            if (prodVmDataDiskSku != ManagedDiskSkuEnum.NONE) {
                dataDiskSku = new ManagedDiskSku(prodVmDataDiskSku);
                ManagedDisk disk2 = new ManagedDisk(ManagedDiskType.DATADISK, Integer.valueOf(dataDiskSku.capacity), dataDiskSku.getFormattedSkuName(), dataDiskSku.getFormattedTier(),dataDiskSku.redundancy);
                thisVM.setDataDisk(disk2);
            }
            osDiskSku = new ManagedDiskSku(prodVmOsDiskSku);
            ManagedDisk disk1 = new ManagedDisk(ManagedDiskType.OSDISK, Integer.valueOf(osDiskSku.capacity), osDiskSku.getFormattedSkuName(), osDiskSku.getFormattedTier(),osDiskSku.redundancy);
            thisVM.setOsDisk(disk1);

            bomMetadata.getVms().add(thisVM);
        }

        SqlDbSku db;
        ManagedDiskSku dbDisk;

        if (devDbSku != SqlDbSkuEnum.NONE) {
            db = new SqlDbSku(devDbSku);
            dbDisk = new ManagedDiskSku(devDbDiskSku);
            //DB (count, env, sku;   //e.g. GP_Gen5, capacity; // e.g. 4  (vCore or DTU or DWU), diskSizeInGB, dbType,  tier; // e.g.GeneralPurpose, e.g. Gen5)
            bomMetadata.getDbs().add(new DB(1, ENV.DEV, db.name, db.capacity, dbDisk.capacity, dbType, db.tier, db.family));
        }
        if (itDbSku != SqlDbSkuEnum.NONE) {
            db = new SqlDbSku(itDbSku);
            dbDisk = new ManagedDiskSku(itDbDiskSku);
            //bomMetadata.getDbs().add(new DB(1,ENV.IT, db.getFormattedCapacityName(), Integer.toString(itdbVcore), Integer.toString(itdbDiskSizeInGB), dbType));
            bomMetadata.getDbs().add(new DB(1, ENV.IT, db.name, db.capacity, dbDisk.capacity, dbType, db.tier, db.family));
        }
        if (uatDbSku != SqlDbSkuEnum.NONE) {
            db = new SqlDbSku(uatDbSku);
            dbDisk = new ManagedDiskSku(uatDbDiskSku);
            bomMetadata.getDbs().add(new DB(1, ENV.UAT, db.name, db.capacity, dbDisk.capacity, dbType, db.tier, db.family));
        }
        if (prodDbSku != SqlDbSkuEnum.NONE) {
            db = new SqlDbSku(prodDbSku);
            dbDisk = new ManagedDiskSku(prodDbDiskSku);
            bomMetadata.getDbs().add(new DB(1, ENV.PROD, db.name, db.capacity, dbDisk.capacity, dbType, db.tier, db.family));
        }

        ObjectWriter ow = new ObjectMapper().writer().withDefaultPrettyPrinter();
        String json = ow.writeValueAsString(bomMetadata);
        System.out.println(json);

        XSSFWorkbook workbook = new XSSFWorkbook();
        createApplicationSheet(bomMetadata, workbook);
        createTagsSheet(bomMetadata, workbook);
        createResourceGroupSheet(bomMetadata, workbook);
        createUserManagedIdentitySheet(bomMetadata, workbook);
        createPrivateEndpointSheet(bomMetadata, workbook);
        //createKvSheet(bomMetadata, workbook);
        //createVirtualNetworkSheet(bomMetadata, workbook);


        if (bomMetadata.getIsLBNeeded() == Boolean.TRUE)
            createLBSheet(bomMetadata, workbook);
        if (bomMetadata.getVms().size() > 0) {
            createVMSheet(bomMetadata, workbook);
            createVMDiskSheet(bomMetadata, workbook);

        }
        if (bomMetadata.getDbs().size() > 0) {
            createDBSQLSheet(bomMetadata, workbook);
        }

        if (bomMetadata.getStorages().size() > 0) {
            createStorageSheet(bomMetadata, workbook);
        }


        ByteArrayOutputStream out = new ByteArrayOutputStream();
        workbook.write(out);
        return new ByteArrayInputStream(out.toByteArray());

    }


    public void createApplicationSheet(BomMetadata metadata, XSSFWorkbook workbook) {
        XSSFSheet sheet
                = workbook.getSheet("Application");


        HashMap<Integer, Object[]> data
                = new HashMap<Integer, Object[]>();
        int count = 2;

        for (String sub : metadata.getDevSubscriptions().split(",")) {
            if (sheet == null) {
                sheet
                        = workbook.createSheet("Application");
                changeColumnWidth(sheet, 25);
            }
            data.put(2, new Object[]{"Region", "Subscription Name", "Automation Tool", "Description"});
            data.put(++count,
                    new Object[]{"Central US", sub, "Manual", "Dev subscription"});
            data.put(++count,
                    new Object[]{"Central US", sub.replace("dev", "it"), "Manual", "IT subscription"});
            data.put(++count,
                    new Object[]{"Central US", sub.replace("dev", "uat"), "Manual", "UAT Central  subscription"});
            data.put(++count,
                    new Object[]{"Central US", sub.replace("dev", "prod"), "Manual", "Prod Central subscription"});
            if (metadata.getSecondaryRegion() == Boolean.TRUE) {
                data.put(++count,
                        new Object[]{"East US", sub.replace("dev", "uat"), "Manual", "UAT East subscription"});
                data.put(++count,
                        new Object[]{"East US", sub.replace("dev", "prod"), "Manual", "Prod East subscription"});
            }

        }
        putDataIntoCellsSorted(data, sheet);

    }

    public void createTagsSheet(BomMetadata metadata, XSSFWorkbook workbook) {
        XSSFSheet sheet = workbook.getSheet("Tags");

        if (webClient == null)
        {
            webClient = WebClient.builder().baseUrl(carApiRequestURL).defaultHeader("Accept", MediaType.APPLICATION_JSON_VALUE, "Content-Type", MediaType.APPLICATION_JSON_VALUE).build();
            log.error("createTagsSheet webClient to invoke CAR API is null.  Tags sheet will be null.", new Exception("createTagsSheet webClient is null"));
            return;
        }

        
        Car carRes = webClient.get()
            .uri(carApiRequestURL + "?carId=" + metadata.getCarId())
            .header("Authorization", "Basic " + Base64Utils
                    .encodeToString((carApiUsername + ":" + carApiPassword).getBytes(StandardCharsets.UTF_8)))
            .retrieve()
            .toEntity(Car.class).block().getBody();


        HashMap<Integer, Object[]> data
                = new HashMap<Integer, Object[]>();
        int count = 2;
        for (String sub : metadata.getDevSubscriptions().split(",")) {
            if (sheet == null) {
                sheet
                        = workbook.createSheet("Tags");
                changeColumnWidth(sheet, 25);
            }
            data.put(2, new Object[]{"environment", "environment sub-type", "Application Name", "Application ID",
                    "confidentiality", "assignment_group", "car_id", "owner", "maintenance_type", "cost_center", "Department", "Resilience"});
            data.put(++count,
                    new Object[]{"Development", "dev-cus", carRes.getData().get(0).getSoftwareName(), carRes.getData().get(0).getCarId(),
                            "internal", carRes.getData().get(0).getAssigneeGroupLevel3Support(), carRes.getData().get(0).getCarId(), carRes.getData().get(0).getToEmail(), metadata.getMaintenanceType(),
                            carRes.getData().get(0).getToCostCenter(), carRes.getData().get(0).getToCcDescription(), carRes.getData().get(0).getResiliencyTier()});

            data.put(++count,
                    new Object[]{"IT", "it-cus", carRes.getData().get(0).getSoftwareName(), carRes.getData().get(0).getCarId(),
                            "internal", carRes.getData().get(0).getAssigneeGroupLevel3Support(), carRes.getData().get(0).getCarId(), carRes.getData().get(0).getToEmail(), metadata.getMaintenanceType(),
                            carRes.getData().get(0).getToCostCenter(), carRes.getData().get(0).getToCcDescription(), carRes.getData().get(0).getResiliencyTier()});
            data.put(++count,
                    new Object[]{"UAT-primary", "uat-cus", carRes.getData().get(0).getSoftwareName(), carRes.getData().get(0).getCarId(),
                            "internal", carRes.getData().get(0).getAssigneeGroupLevel3Support(), carRes.getData().get(0).getCarId(), carRes.getData().get(0).getToEmail(), metadata.getMaintenanceType(),
                            carRes.getData().get(0).getToCostCenter(), carRes.getData().get(0).getToCcDescription(), carRes.getData().get(0).getResiliencyTier()});
            data.put(++count,
                    new Object[]{"PROD-primary", "prod-cus", carRes.getData().get(0).getSoftwareName(), carRes.getData().get(0).getCarId(),
                            "internal", carRes.getData().get(0).getAssigneeGroupLevel3Support(), carRes.getData().get(0).getCarId(), carRes.getData().get(0).getToEmail(), metadata.getMaintenanceType(),
                            carRes.getData().get(0).getToCostCenter(), carRes.getData().get(0).getToCcDescription(), carRes.getData().get(0).getResiliencyTier()});

            if (metadata.getSecondaryRegion() == Boolean.TRUE) {
                data.put(++count,
                        new Object[]{"UAT-secondary", "uat-eus2", carRes.getData().get(0).getSoftwareName(), carRes.getData().get(0).getCarId(),
                                "internal", carRes.getData().get(0).getAssigneeGroupLevel3Support(), carRes.getData().get(0).getCarId(), carRes.getData().get(0).getToEmail(), metadata.getMaintenanceType(),
                                carRes.getData().get(0).getToCostCenter(), carRes.getData().get(0).getToCcDescription(), carRes.getData().get(0).getResiliencyTier()});
                data.put(++count,
                        new Object[]{"PROD-secondary", "prod-eus2", carRes.getData().get(0).getSoftwareName(), carRes.getData().get(0).getCarId(),
                                "internal", carRes.getData().get(0).getAssigneeGroupLevel3Support(), carRes.getData().get(0).getCarId(), carRes.getData().get(0).getToEmail(), metadata.getMaintenanceType(),
                                carRes.getData().get(0).getToCostCenter(), carRes.getData().get(0).getToCcDescription(), carRes.getData().get(0).getResiliencyTier()});
            }


        }
        putDataIntoCellsSorted(data, sheet);

    }

    public void createResourceGroupSheet(BomMetadata metadata, XSSFWorkbook workbook) {
        XSSFSheet sheet
                = workbook.getSheet("Resource Group");


        HashMap<Integer, Object[]> data
                = new HashMap<Integer, Object[]>();
        int count = 2;

        if (sheet == null) {
            sheet
                    = workbook.createSheet("Resource Group");
            changeColumnWidth(sheet, 25);
        }

        data.put(2, new Object[]{"Environment", "Action", "Friendly Name", "Resource Name", "Location", "maintenance_type"});
        for (String appContext : metadata.getAppContextNames().split(",")) {
            data.put(++count,
                    new Object[]{"Development", "create", "Application Resource Group", "rg-cus-" + appContext + "-dev-01", "Central US", "Pet"});

            data.put(++count,
                    new Object[]{"IT", "create", "Application Resource Group", "rg-cus-" + appContext + "-it-01", "Central US", "Pet"});
            data.put(++count,
                    new Object[]{"UAT-Primary", "create", "Application Resource Group", "rg-cus-" + appContext + "-uat-01", "Central US", "Pet"});
            data.put(++count,
                    new Object[]{"Production-Primary", "create", "Application Resource Group", "rg-cus-" + appContext + "-prod-01", "Central US", "Pet"});
            if (metadata.getSecondaryRegion() == Boolean.TRUE) {
                data.put(++count,
                        new Object[]{"UAT-Secondary", "create", "Application Resource Group", "rg-eus2-" + appContext + "-uat-01", "East US", "Pet"});
                data.put(++count,
                        new Object[]{"Production-Secondary", "create", "Application Resource Group", "rg-eus2-" + appContext + "-prod-01", "East US", "Pet"});
            }
        }

        putDataIntoCellsSorted(data, sheet);

    }

    public void createUserManagedIdentitySheet(BomMetadata metadata, XSSFWorkbook workbook) {
        XSSFSheet sheet
                = workbook.getSheet("Managed Identity");

        List<String> umiTypes = Arrays.asList("adf", "evh", "pgsql", "sa", "sql", "vm");

        HashMap<Integer, Object[]> data
                = new HashMap<Integer, Object[]>();
        int count = 2;

        if (sheet == null) {
            sheet
                    = workbook.createSheet("Managed Identity");
            changeColumnWidth(sheet, 25);
        }
        for (String umitype : umiTypes) {
            for (String appContext : metadata.getAppContextNames().split(",")) {
                data.put(2, new Object[]{"Environment", "Action", "Service Name", "Resource Group Name", "User Managed Identity Name"});
                data.put(++count,
                        new Object[]{"DEV", "Create", "User Managed Identity", "rg-cus-" + appContext + "-dev-01", "umi-cus-" + appContext + "-dev-" + umitype + "-01"});
                data.put(++count,
                        new Object[]{"IT", "Create", "User Managed Identity", "rg-cus-" + appContext + "-it-01", "umi-cus-" + appContext + "-it-" + umitype + "-01"});
                data.put(++count,
                        new Object[]{"UAT-Primary", "Create", "User Managed Identity", "rg-cus-" + appContext + "-uat-01", "umi-cus-" + appContext + "-uat-" + umitype + "-01"});
                data.put(++count,
                        new Object[]{"PROD-Primary", "Create", "User Managed Identity", "rg-cus-" + appContext + "-prod-01", "umi-cus-" + appContext + "-prod-" + umitype + "-01"});
                if (metadata.getSecondaryRegion() == Boolean.TRUE) {
                    data.put(++count,
                            new Object[]{"UAT-Secondary", "Create", "User Managed Identity", "rg-eus2-" + appContext + "-uat-01", "umi-cus-" + appContext + "-uat-" + umitype + "-01"});
                    data.put(++count,
                            new Object[]{"PROD-Secondary", "Create", "User Managed Identity", "rg-eus2-" + appContext + "-prod-01", "umi-cus-" + appContext + "-prod-" + umitype + "-01"});
                }
            }
        }
        putDataIntoCellsSorted(data, sheet);

    }

    public void createPrivateEndpointSheet(BomMetadata metadata, XSSFWorkbook workbook) {
        XSSFSheet sheet
                = workbook.getSheet("PVT Endpoint");

        List<String> peTypes = new ArrayList<>();
        peTypes.add("kv-01");
        List<String> peStorageTypes = Arrays.asList("blob-jadp", "file-jdap", "queue-jadp", "table-jadp");
        if (metadata.getIsAppUsingStorage() == true)
            peTypes.addAll(peStorageTypes);


        HashMap<Integer, Object[]> data
                = new HashMap<Integer, Object[]>();
        int count = 2;

        if (sheet == null) {
            sheet
                    = workbook.createSheet("PVT Endpoint");
            changeColumnWidth(sheet, 25);
        }
        for (String peType : peTypes) {
            for (String appContext : metadata.getAppContextNames().split(",")) {
                data.put(2, new Object[]{"Environment", "Action", "Friendly Name", "Resource Name"});
                data.put(++count,
                        new Object[]{"DEV", "Create", "Private Endpoint", "pe-cus-" + appContext + "-dev-" + peType});
                data.put(++count,
                        new Object[]{"IT", "Create", "Private Endpoint", "pe-cus-" + appContext + "-it-" + peType});
                data.put(++count,
                        new Object[]{"UAT-Primary", "Create", "Private Endpoint", "pe-cus-" + appContext + "-uat-" + peType});
                data.put(++count,
                        new Object[]{"PROD-Primary", "Create", "Private Endpoint", "pe-cus-" + appContext + "-prod-" + peType});
                if (metadata.getSecondaryRegion() == Boolean.TRUE) {
                    data.put(++count,
                            new Object[]{"UAT-Secondary", "Create", "Private Endpoint", "pe-eus2-" + appContext + "-dev-" + peType});
                    data.put(++count,
                            new Object[]{"PROD-Secondary", "Create", "Private Endpoint", "pe-eus2-" + appContext + "-dev-" + peType});
                }
            }
        }

        putDataIntoCellsSorted(data, sheet);

    }

    public void createKvSheet(BomMetadata metadata, XSSFWorkbook workbook) {
        XSSFSheet sheet
                = workbook.getSheet("Key Vault");


        HashMap<Integer, Object[]> data
                = new HashMap<Integer, Object[]>();
        int count = 2;
        data.put(2, new Object[]{"Environment", "Action", "Service Family", "Service Name", "Product Name", "Meter Name", "SKU Name", "UOM", "Friendly Name"});
        for (String sub : metadata.getDevSubscriptions().split(",")) {
            if (sheet == null) {
                sheet
                        = workbook.createSheet("Key Vault");
                changeColumnWidth(sheet, 25);
            }

            data.put(++count,
                    new Object[]{"Development", "Create", "Security", "Key Vault", "Key Vault", "Operations", "Premium", 5, "Key Vault"});
            data.put(++count,
                    new Object[]{"IT", "Create", "Security", "Key Vault", "Key Vault", "Operations", "Premium", 5, "Key Vault"});
            data.put(++count,
                    new Object[]{"UAT-Primary", "Create", "Security", "Key Vault", "Key Vault", "Operations", "Premium", 5, "Key Vault"});
            data.put(++count,
                    new Object[]{"PROD-Primary", "Create", "Security", "Key Vault", "Key Vault", "Operations", "Premium", 5, "Key Vault"});
            if (metadata.getSecondaryRegion() == Boolean.TRUE) {
                data.put(++count,
                        new Object[]{"UAT-Secondary", "Create", "Security", "Key Vault", "Key Vault", "Operations", "Premium", 5, "Key Vault"});
                data.put(++count,
                        new Object[]{"PROD-Secondary", "Create", "Security", "Key Vault", "Key Vault", "Operations", "Premium", 5, "Key Vault"});
            }
        }

        putDataIntoCellsSorted(data, sheet);

    }

    public void createVirtualNetworkSheet(BomMetadata metadata, XSSFWorkbook workbook) {
        XSSFSheet sheet
                = workbook.getSheet("Virtual Network");


        HashMap<Integer, Object[]> data
                = new HashMap<Integer, Object[]>();
        int count = 2;
        data.put(2, new Object[]{"Environment", "Action", "Service Family", "Service Name", "Product Name", "Meter Name", "SKU Name", "UOM", "Friendly Name"});
        for (String sub : metadata.getDevSubscriptions().split(",")) {
            if (sheet == null) {
                sheet
                        = workbook.createSheet("Virtual Network");
                changeColumnWidth(sheet, 25);
            }

            data.put(++count,
                    new Object[]{"Development", "Already Created", "Networking", "Virtual Network", "Virtual Network Private Link", "Standard Private Endpoint", "Standard", 730, sub + " - Virtual Network"});
            data.put(++count,
                    new Object[]{"Development", "Already Created", "Networking", "Virtual Network", "Virtual Network Private Link", "Standard Data Processed - Egress", "Standard", 100, sub + " - Virtual Network"});
            data.put(++count,
                    new Object[]{"Development", "Already Created", "Networking", "Virtual Network", "Virtual Network Private Link", "Standard Data Processed - Ingress", "Standard", 100, sub + " - Virtual Network"});
            data.put(++count, new Object[]{""});

            data.put(++count,
                    new Object[]{"IT", "Already Created", "Networking", "Virtual Network", "Virtual Network Private Link", "Standard Private Endpoint", "Standard", 730, sub.replace("dev", "it") + " - Virtual Network"});
            data.put(++count,
                    new Object[]{"IT", "Already Created", "Networking", "Virtual Network", "Virtual Network Private Link", "Standard Data Processed - Egress", "Standard", 100, sub.replace("dev", "it") + " - Virtual Network"});
            data.put(++count,
                    new Object[]{"IT", "Already Created", "Networking", "Virtual Network", "Virtual Network Private Link", "Standard Data Processed - Ingress", "Standard", 100, sub.replace("dev", "it") + " - Virtual Network"});
            data.put(++count, new Object[]{""});

            data.put(++count,
                    new Object[]{"UAT-Primary", "Already Created", "Networking", "Virtual Network", "Virtual Network Private Link", "Standard Private Endpoint", "Standard", 730, sub.replace("dev", "uat") + " - Virtual Network"});
            data.put(++count,
                    new Object[]{"UAT-Primary", "Already Created", "Networking", "Virtual Network", "Virtual Network Private Link", "Standard Data Processed - Egress", "Standard", 100, sub.replace("dev", "uat") + " - Virtual Network"});
            data.put(++count,
                    new Object[]{"UAT-Primary", "Already Created", "Networking", "Virtual Network", "Virtual Network Private Link", "Standard Data Processed - Ingress", "Standard", 100, sub.replace("dev", "uat") + " - Virtual Network"});


            data.put(++count, new Object[]{""});
            data.put(++count,
                    new Object[]{"PROD-Primary", "Already Created", "Networking", "Virtual Network", "Virtual Network Private Link", "Standard Private Endpoint", "Standard", 730, sub.replace("dev", "prod") + " - Virtual Network"});
            data.put(++count,
                    new Object[]{"PROD-Primary", "Already Created", "Networking", "Virtual Network", "Virtual Network Private Link", "Standard Data Processed - Egress", "Standard", 100, sub.replace("dev", "prod") + " - Virtual Network"});
            data.put(++count,
                    new Object[]{"PROD-Primary", "Already Created", "Networking", "Virtual Network", "Virtual Network Private Link", "Standard Data Processed - Ingress", "Standard", 100, sub.replace("dev", "prod") + " - Virtual Network"});
            data.put(++count, new Object[]{""});

            if (metadata.getSecondaryRegion() == Boolean.TRUE) {
                data.put(++count,
                        new Object[]{"UAT-Secondary", "Already Created", "Networking", "Virtual Network", "Virtual Network Private Link", "Standard Private Endpoint", "Standard", 730, sub.replace("dev", "uat-eus2") + " - Virtual Network"});
                data.put(++count,
                        new Object[]{"UAT-Secondary", "Already Created", "Networking", "Virtual Network", "Virtual Network Private Link", "Standard Data Processed - Egress", "Standard", 100, sub.replace("dev", "uat-eus2") + " - Virtual Network"});
                data.put(++count,
                        new Object[]{"UAT-Secondary", "Already Created", "Networking", "Virtual Network", "Virtual Network Private Link", "Standard Data Processed - Ingress", "Standard", 100, sub.replace("dev", "uat-eus2") + " - Virtual Network"});

                data.put(++count, new Object[]{""});

                data.put(++count,
                        new Object[]{"PROD-Secondary", "Already Created", "Networking", "Virtual Network", "Virtual Network Private Link", "Standard Private Endpoint", "Standard", 730, sub.replace("dev", "prod-eus2") + " - Virtual Network"});
                data.put(++count,
                        new Object[]{"PROD-Secondary", "Already Created", "Networking", "Virtual Network", "Virtual Network Private Link", "Standard Data Processed - Egress", "Standard", 100, sub.replace("dev", "prod-eus2") + " - Virtual Network"});
                data.put(++count,
                        new Object[]{"PROD-Secondary", "Already Created", "Networking", "Virtual Network", "Virtual Network Private Link", "Standard Data Processed - Ingress", "Standard", 100, sub.replace("dev", "prod-eus2") + " - Virtual Network"});
            }
        }

        putDataIntoCellsSorted(data, sheet);

    }

    public void createLBSheet(BomMetadata metadata, XSSFWorkbook workbook) {
        XSSFSheet sheet
                = workbook.getSheet("Load Balancer");


        HashMap<Integer, Object[]> data
                = new HashMap<Integer, Object[]>();
        int count = 2;
        data.put(2, new Object[]{"Environment", "Action", "Service Family", "Service Name", "Product Name", "Meter Name", "SKU Pricing", "UOM", "Load Balancer Name", "Resource Group"});
        if (metadata.getIsLBNeeded().equals(Boolean.TRUE)) {
            if (sheet == null) {
                sheet
                        = workbook.createSheet("Load Balancer");
                changeColumnWidth(sheet, 30);
            }

            data.put(++count,
                    new Object[]{"Development", "Create", "Networking", "Load Balancer", "Load Balancer", "Standard Included LB Rules and Outbound Rules", "Standard", 730, "ilb-cus-" + metadata.getAppContextNames().split(",")[0] + "-dev-001", "rg-cus-" + metadata.getAppContextNames().split(",")[0] + "-dev-01"});
            data.put(++count,
                    new Object[]{"Development", "Create", "Networking", "Load Balancer", "Load Balancer", "Standard Data Processed", "Standard", 1000, "ilb-cus-" + metadata.getAppContextNames().split(",")[0] + "-dev-001", "rg-cus-" + metadata.getAppContextNames().split(",")[0] + "-dev-01"});
            data.put(++count,
                    new Object[]{"IT", "Create", "Networking", "Load Balancer", "Load Balancer", "Standard Included LB Rules and Outbound Rules", "Standard", 730, "ilb-cus-" + metadata.getAppContextNames().split(",")[0] + "-it-001", "rg-cus-" + metadata.getAppContextNames().split(",")[0] + "-it-01"});
            data.put(++count,
                    new Object[]{"IT", "Create", "Networking", "Load Balancer", "Load Balancer", "Standard Data Processed", "Standard", 1000, "ilb-cus-" + metadata.getAppContextNames().split(",")[0] + "-it-001", "rg-cus-" + metadata.getAppContextNames().split(",")[0] + "-it-01"});
            data.put(++count,
                    new Object[]{"UAT-Primary", "Create", "Networking", "Load Balancer", "Load Balancer", "Standard Included LB Rules and Outbound Rules", "Standard", 730, "ilb-cus-" + metadata.getAppContextNames().split(",")[0] + "-uat-001", "rg-cus-" + metadata.getAppContextNames().split(",")[0] + "-uat-01"});
            data.put(++count,
                    new Object[]{"UAT-Primary", "Create", "Networking", "Load Balancer", "Load Balancer", "Standard Data Processed", "Standard", 1000, "ilb-cus-" + metadata.getAppContextNames().split(",")[0] + "-uat-001", "rg-cus-" + metadata.getAppContextNames().split(",")[0] + "-uat-01"});
            data.put(++count,
                    new Object[]{"PROD-Primary", "Create", "Networking", "Load Balancer", "Load Balancer", "Standard Included LB Rules and Outbound Rules", "Standard", 730, "ilb-cus-" + metadata.getAppContextNames().split(",")[0] + "-prod-001", "rg-cus-" + metadata.getAppContextNames().split(",")[0] + "-prod-01"});
            data.put(++count,
                    new Object[]{"PROD-Primary", "Create", "Networking", "Load Balancer", "Load Balancer", "Standard Data Processed", "Standard", 1000, "ilb-cus-" + metadata.getAppContextNames().split(",")[0] + "-prod-001", "rg-cus-" + metadata.getAppContextNames().split(",")[0] + "-prod-01"});
            if (metadata.getSecondaryRegion() == Boolean.TRUE) {
                data.put(++count,
                        new Object[]{"UAT-Secondary", "Create", "Networking", "Load Balancer", "Load Balancer", "Standard Included LB Rules and Outbound Rules", "Standard", 730, "ilb-eus2-" + metadata.getAppContextNames().split(",")[0] + "-uat-001", "rg-eus2-" + metadata.getAppContextNames().split(",")[0] + "-uat-01"});
                data.put(++count,
                        new Object[]{"UAT-Secondary", "Create", "Networking", "Load Balancer", "Load Balancer", "Standard Data Processed", "Standard", 1000, "ilb-cus-" + metadata.getAppContextNames().split(",")[0] + "-uat-001", "rg-cus-" + metadata.getAppContextNames().split(",")[0] + "-uat-01"});
                data.put(++count,
                        new Object[]{"PROD-Secondary", "Create", "Networking", "Load Balancer", "Load Balancer", "Standard Included LB Rules and Outbound Rules", "Standard", 730, "ilb-eus2-" + metadata.getAppContextNames().split(",")[0] + "-prod-001", "rg-eus2-" + metadata.getAppContextNames().split(",")[0] + "-prod-01"});
                data.put(++count,
                        new Object[]{"PROD-Secondary", "Create", "Networking", "Load Balancer", "Load Balancer", "Standard Data Processed", "Standard", 1000, "ilb-eus2-" + metadata.getAppContextNames().split(",")[0] + "-prod-001", "rg-eus2-" + metadata.getAppContextNames().split(",")[0] + "-prod-01"});
            }


            putDataIntoCellsSorted(data, sheet);
        }
    }

    public void createVMSheet(BomMetadata metadata, XSSFWorkbook workbook) {
        HashMap<Integer, Object[]> data
                = new HashMap<Integer, Object[]>();
        XSSFSheet sheet = null;
        int count = 2;
        for (VM vm : metadata.getVms()) {
            sheet
                    = workbook.getSheet("VM-" + vm.getType().name());
            data.put(2, new Object[]{"Environment", "Action", "Service Family", "Service Name", "Product Name", "Meter Name", "SKU Name", "UOM"});

            if (sheet == null) {
                sheet
                        = workbook.createSheet("VM-" + vm.getType().name());
                changeColumnWidth(sheet, 30);
            }
            if (vm.getEnv().name().equals("DEV")) {
                for (int i = 1; i <= vm.getCount(); i++) {
                    data.put(++count,
                            new Object[]{"Development", "Create", "Compute", "Virtual Machines", "Virtual Machines " + Arrays.stream(vm.getSku().split("_")).reduce((first, second) -> second).get() + " Series", vm.getSku().replaceAll("Standard_", "").replace("_", " "), vm.getSku(), 240});
                    data.put(++count, new Object[]{"Development", "Create", "Networking", "Bandwidth", "Bandwidth Inter-Region", "Inter Continent Data Transfer Out - NAM or EU To Any", "Inter Continent", 5});
                    data.put(++count, new Object[]{""});
                }
            }

            if (vm.getEnv().name().equals("IT")) {
                for (int i = 1; i <= vm.getCount(); i++) {
                    data.put(++count,
                            new Object[]{"IT", "Create", "Compute", "Virtual Machines", "Virtual Machines " + Arrays.stream(vm.getSku().split("_")).reduce((first, second) -> second).get() + " Series", vm.getSku().replaceAll("Standard_", "").replace("_", " "), vm.getSku(), 240});
                    data.put(++count, new Object[]{"IT", "Create", "Networking", "Bandwidth", "Bandwidth Inter-Region", "Inter Continent Data Transfer Out - NAM or EU To Any", "Inter Continent", 5});
                    data.put(++count, new Object[]{""});
                }
            }


            if (vm.getEnv().name().equals("UAT")) {
                for (int i = 1; i <= vm.getCount(); i++) {
                    data.put(++count,
                            new Object[]{"UAT-Primary", "Create", "Compute", "Virtual Machines", "Virtual Machines " + Arrays.stream(vm.getSku().split("_")).reduce((first, second) -> second).get() + " Series", vm.getSku().replaceAll("Standard_", "").replace("_", " "), vm.getSku(), 240});
                    data.put(++count, new Object[]{"UAT-Primary", "Create", "Networking", "Bandwidth", "Bandwidth Inter-Region", "Inter Continent Data Transfer Out - NAM or EU To Any", "Inter Continent", 5});
                    data.put(++count, new Object[]{""});
                }
            }

            if (vm.getEnv().name().equals("PROD")) {
                for (int i = 1; i <= vm.getCount(); i++) {
                    data.put(++count,
                            new Object[]{"PROD-Primary", "Create", "Compute", "Virtual Machines", "Virtual Machines " + Arrays.stream(vm.getSku().split("_")).reduce((first, second) -> second).get() + " Series", vm.getSku().replaceAll("Standard_", "").replace("_", " "), vm.getSku(), 730});
                    data.put(++count, new Object[]{"PROD-Primary", "Create", "Networking", "Bandwidth", "Bandwidth Inter-Region", "Inter Continent Data Transfer Out - NAM or EU To Any", "Inter Continent", 5});
                    data.put(++count, new Object[]{""});
                }
            }

            if (metadata.getSecondaryRegion() == Boolean.TRUE && vm.getEnv().name().equals("UAT")) {
                for (int i = 1; i <= vm.getCount(); i++) {
                    data.put(++count,
                            new Object[]{"UAT-Secondary", "Create", "Compute", "Virtual Machines", "Virtual Machines " + Arrays.stream(vm.getSku().split("_")).reduce((first, second) -> second).get() + " Series", vm.getSku().replaceAll("Standard_", "").replace("_", " "), vm.getSku(), 240});
                    data.put(++count, new Object[]{"UAT-Secondary", "Create", "Networking", "Bandwidth", "Bandwidth Inter-Region", "Inter Continent Data Transfer Out - NAM or EU To Any", "Inter Continent", 5});
                    data.put(++count, new Object[]{""});
                }
            }

            if (metadata.getSecondaryRegion() == Boolean.TRUE && vm.getEnv().name().equals("PROD")) {
                for (int i = 1; i <= vm.getCount(); i++) {
                    data.put(++count,
                            new Object[]{"PROD-Secondary", "Create", "Compute", "Virtual Machines", "Virtual Machines " + Arrays.stream(vm.getSku().split("_")).reduce((first, second) -> second).get() + " Series", vm.getSku().replaceAll("Standard_", "").replace("_", " "), vm.getSku(), 730});
                    data.put(++count, new Object[]{"PROD-Secondary", "Create", "Networking", "Bandwidth", "Bandwidth Inter-Region", "Inter Continent Data Transfer Out - NAM or EU To Any", "Inter Continent", 5});
                    data.put(++count, new Object[]{""});
                }
            }

        }

        putDataIntoCellsSorted(data, sheet);

    }

    public void createVMDiskSheet(BomMetadata metadata, XSSFWorkbook workbook) {
        HashMap<Integer, Object[]> data
                = new HashMap<Integer, Object[]>();
        XSSFSheet sheet = null;
        int count = 2;
        for (VM vm : metadata.getVms()) {
            sheet = workbook.getSheet("Managed Disk");
            data.put(2, new Object[]{"Environment", "Action", "Service Family", "Service Name", "Product Name", "Meter Name", "SKU Name", "UOM", "Friendly Name"});

            if (sheet == null) {
                sheet = workbook.createSheet("Managed Disk");
                changeColumnWidth(sheet, 30);
            }

            String env = vm.getEnv().name().toUpperCase();
            String envToPrint;

            if (env.equals("DEV") || env.equals("IT")) {
                envToPrint = env.equals("DEV") ? "Development" : env;
                for (int i = 1; i <= vm.getCount(); i++) {
                    data.put(    ++count, new Object[]{envToPrint, "Create", "Storage", "Storage", vm.getOsDisk().getTier() +  " Managed Disks", vm.getOsDisk().getSku() + " Disk",            vm.getOsDisk().getSku(),      1, vm.getOsDisk().getType().name().toLowerCase()});
                    data.put(    ++count, new Object[]{envToPrint, "Create", "Storage", "Storage", vm.getOsDisk().getTier() +  " Managed Disks", vm.getOsDisk().getSku() + " Disk Operations", vm.getOsDisk().getSku(),  10000, "Storage Transactions"});

                    if (vm.getDataDisk() != null) {
                        data.put(++count, new Object[]{envToPrint, "Create", "Storage", "Storage", vm.getDataDisk().getTier() + " Managed Disks", vm.getDataDisk().getSku() + " Disk",            vm.getDataDisk().getSku(),     1, vm.getDataDisk().getType().name().toLowerCase()});
                        data.put(++count, new Object[]{envToPrint, "Create", "Storage", "Storage", vm.getDataDisk().getTier() + " Managed Disks", vm.getDataDisk().getSku() + " Disk Operations", vm.getDataDisk().getSku(), 10000, "Storage Transactions"});
                    }
                    data.put(++count, new Object[]{""});
                }
            }

            if (env.equals("UAT") || env.equals("PROD")) {
                envToPrint = env + "-Primary";
                for (int i = 1; i <= vm.getCount(); i++) {
                    data.put(    ++count, new Object[]{envToPrint, "Create", "Storage", "Storage", vm.getOsDisk().getTier() +  " Managed Disks", vm.getOsDisk().getSku() + " Disk",            vm.getOsDisk().getSku(),      1, vm.getOsDisk().getType().name().toLowerCase()});
                    data.put(    ++count, new Object[]{envToPrint, "Create", "Storage", "Storage", vm.getOsDisk().getTier() +  " Managed Disks", vm.getOsDisk().getSku() + " Disk Operations", vm.getOsDisk().getSku(),  10000, "Storage Transactions"});

                    if (vm.getDataDisk() != null) {
                        data.put(++count, new Object[]{envToPrint, "Create", "Storage", "Storage", vm.getDataDisk().getTier() + " Managed Disks", vm.getDataDisk().getSku() + " Disk",            vm.getDataDisk().getSku(),     1, vm.getDataDisk().getType().name().toLowerCase()});
                        data.put(++count, new Object[]{envToPrint, "Create", "Storage", "Storage", vm.getDataDisk().getTier() + " Managed Disks", vm.getDataDisk().getSku() + " Disk Operations", vm.getDataDisk().getSku(), 10000, "Storage Transactions"});
                    }
                    data.put(++count, new Object[]{""});
                }

                if (metadata.getSecondaryRegion() == Boolean.TRUE)
                {
                    envToPrint = env + "-Secondary";
                    for (int i = 1; i <= vm.getCount(); i++) {
                        data.put(    ++count, new Object[]{envToPrint, "Create", "Storage", "Storage", vm.getOsDisk().getTier() +  " Managed Disks", vm.getOsDisk().getSku() + " Disk",            vm.getOsDisk().getSku(),      1, vm.getOsDisk().getType().name().toLowerCase()});
                        data.put(    ++count, new Object[]{envToPrint, "Create", "Storage", "Storage", vm.getOsDisk().getTier() +  " Managed Disks", vm.getOsDisk().getSku() + " Disk Operations", vm.getOsDisk().getSku(),  10000, "Storage Transactions"});

                        if (vm.getDataDisk() != null) {
                            data.put(++count, new Object[]{envToPrint, "Create", "Storage", "Storage", vm.getDataDisk().getTier() + " Managed Disks", vm.getDataDisk().getSku() + " Disk",            vm.getDataDisk().getSku(),     1, vm.getDataDisk().getType().name().toLowerCase()});
                            data.put(++count, new Object[]{envToPrint, "Create", "Storage", "Storage", vm.getDataDisk().getTier() + " Managed Disks", vm.getDataDisk().getSku() + " Disk Operations", vm.getDataDisk().getSku(), 10000, "Storage Transactions"});
                        }
                        data.put(++count, new Object[]{""});
                    }


                }
            }

        }
        putDataIntoCellsSorted(data, sheet);
    }

    public void createDBSQLSheet(BomMetadata metadata, XSSFWorkbook workbook) {
        HashMap<Integer, Object[]> data
                = new HashMap<Integer, Object[]>();
        XSSFSheet sheet = null;
        int count = 2;
        for (DB db : metadata.getDbs()) {
            sheet
                    = workbook.getSheet("DB-" + db.getDbType().name());
            data.put(2, new Object[]{"Environment", "Action", "Service Family", "Service Name", "Product Name", "Meter Name", "SKU Name", "UOM", "Friendly Name"});

            if (sheet == null) {
                sheet
                        = workbook.createSheet("DB-" + db.getDbType().name());
                changeColumnWidth(sheet, 30);
            }

            String env = db.getEnv().name().toUpperCase().trim();
            String serviceName = db.getDbType().equals(DBType.SQLMI) ? "SQL Managed Instance" : "SQL Database";
            String family = db.family;
            String meterName = db.getCapacityUnits();
            String tier = db.getFormattedTier();

            String envToPrint;

            if (env.equals("DEV") || env.equals("IT")) {
                envToPrint = env.equals("DEV") ? "Development" : env;

                for (int i = 1; i <= db.getCount(); i++) {
                    data.put(++count, new Object[]{envToPrint, "Create", "Databases", serviceName, serviceName + " Single/Elastic Pool " + tier + " - Compute " + family, meterName,             db.getSku(), 730});
                    data.put(++count, new Object[]{envToPrint, "Create", "Databases", serviceName, serviceName + " Single/Elastic Pool " + tier + " - Storage",           tier + " Data Stored", tier,        db.getDiskSizeInGB()});
                    data.put(++count, new Object[]{""});
                }
            }

            if (env.equals("UAT") || env.equals("PROD")) {
                envToPrint = env + "-Primary";

                for (int i = 1; i <= db.getCount(); i++) {
                    data.put(++count, new Object[]{envToPrint, "Create", "Databases", serviceName, serviceName + " Single/Elastic Pool " + tier + " - Compute " + family, meterName,             db.getSku(), 730});
                    data.put(++count, new Object[]{envToPrint, "Create", "Databases", serviceName, serviceName + " Single/Elastic Pool " + tier + " - Storage",           tier + " Data Stored", tier,        db.getDiskSizeInGB()});
                    data.put(++count, new Object[]{""});
                }

                if (metadata.getSecondaryRegion() == Boolean.TRUE) {
                    envToPrint = env + "-Secondary";

                    for (int i = 1; i <= db.getCount(); i++) {
                        data.put(++count, new Object[]{envToPrint, "Create", "Databases", serviceName, serviceName + " Single/Elastic Pool " + tier + " - Compute " + family, meterName,             db.getSku(), 730});
                        data.put(++count, new Object[]{envToPrint, "Create", "Databases", serviceName, serviceName + " Single/Elastic Pool " + tier + " - Storage",           tier + " Data Stored", tier,        db.getDiskSizeInGB()});
                        data.put(++count, new Object[]{""});
                    }
                }

            }
        }

        putDataIntoCellsSorted(data, sheet);

    }

    public void createStorageSheet(BomMetadata metadata, XSSFWorkbook workbook) {
        HashMap<Integer, Object[]> data
                = new HashMap<Integer, Object[]>();
        XSSFSheet sheet = null;
        int count = 2;
        for (Storage storage : metadata.getStorages()) {
            sheet
                    = workbook.getSheet("SA-Fileshare Blob Table Queue");
            data.put(2, new Object[]{"Environment", "Action", "Service Family", "Service Name", "Product Name", "Meter Name", "SKU Name", "UOM"});

            if (sheet == null) {
                sheet
                        = workbook.createSheet("SA-Fileshare Blob Table Queue");
                changeColumnWidth(sheet, 30);
            }
            String productName = storage.getStorageType().equals(StorageType.Blob) ? "General Block Blob v2" : "Files V2";
            if (storage.getEnv().name().equals("DEV")) {
                for (int i = 1; i <= storage.getCount(); i++) {
                    data.put(++count, new Object[]{"Development", "Create", "Storage", "Storage", productName, storage.getSku() + " Data Stored", storage.getSku(), storage.getSizeInGB()});
                }
            }

            if (storage.getEnv().name().equals("IT")) {
                for (int i = 1; i <= storage.getCount(); i++) {
                    data.put(++count, new Object[]{"IT", "Create", "Storage", "Storage", productName, storage.getSku() + " Data Stored", storage.getSku(), storage.getSizeInGB()});
                }
            }

            if (storage.getEnv().name().equals("UAT")) {
                for (int i = 1; i <= storage.getCount(); i++) {
                    data.put(++count, new Object[]{"UAT-Primary", "Create", "Storage", "Storage", productName, storage.getSku() + " Data Stored", storage.getSku(), storage.getSizeInGB()});
                }
            }

            if (storage.getEnv().name().equals("PROD")) {
                for (int i = 1; i <= storage.getCount(); i++) {
                    data.put(++count, new Object[]{"PROD-Primary", "Create", "Storage", "Storage", productName, storage.getSku() + " Data Stored", storage.getSku(), storage.getSizeInGB()});
                }
            }

        }

        putDataIntoCellsSorted(data, sheet);

    }

    public void changeColumnWidth(XSSFSheet sheet, int width) {
        for (int i = 0; i < 100; i++) {
            sheet.setColumnWidth(i, width * 256);
            sheet.setVerticallyCenter(Boolean.TRUE);
        }
    }

    public static CellStyle createHeaderCellStyle(XSSFSheet sheet) {
        // Create header CellStyle

        CellStyle headerCellStyle = sheet.getWorkbook().createCellStyle();
        // fill foreground color ...
        headerCellStyle.setFillForegroundColor(IndexedColors.BLUE_GREY.getIndex());
        // and solid fill pattern produces solid grey cell fill
        headerCellStyle.setFillPattern(FillPatternType.SOLID_FOREGROUND);
        return headerCellStyle;
    }


    public CellStyle changeCellStyle(XSSFSheet sheet) {
        CellStyle style = sheet.getWorkbook().createCellStyle();
        style.setBorderBottom(BorderStyle.THIN);
        style.setBorderTop(BorderStyle.THIN);
        style.setBorderLeft(BorderStyle.THIN);
        style.setBorderRight(BorderStyle.THIN);
        return style;
    }

    public void putDataIntoCellsSorted(HashMap<Integer, Object[]> data, XSSFSheet sheet) {
        Set<Integer> keyset = data.keySet();
        int rownum = 1;
        for (Integer key : keyset) {
            Row row = sheet.createRow(rownum++);
            Object[] objArr = data.get(key);
            int cellnum = 0;
            for (Object obj : objArr) {
                Cell cell = row.createCell(cellnum++);

                if (obj instanceof String) {
                    cell.setCellStyle(changeCellStyle(sheet));
                    cell.setCellValue((String) obj);
                } else if (obj instanceof Integer) {
                    cell.setCellStyle(changeCellStyle(sheet));
                    cell.setCellValue((Integer) obj);
                }

                if (key == 2)
                    cell.setCellStyle(createHeaderCellStyle(sheet));
            }
        }
    }

    private AzureResourceManager initializeAzureResourceManager(String subscription) {
        DefaultAzureCredential clientSecretCredential = new DefaultAzureCredentialBuilder().tenantId(spTenantId).build();



        AzureProfile profile = new AzureProfile(AzureEnvironment.AZURE);
        HashMap<String, String> subscriptionMap = new HashMap<>();
        AzureResourceManager.configure().withLogLevel(HttpLogDetailLevel.BODY_AND_HEADERS)
                .authenticate(clientSecretCredential, profile)
                .subscriptions().list().stream().forEach(
                s ->
                        subscriptionMap.put(s.displayName(), s.subscriptionId()));
        AzureResourceManager resourceManager = AzureResourceManager.configure().withLogLevel(HttpLogDetailLevel.NONE)
                .authenticate(clientSecretCredential, profile).withSubscription(subscriptionMap.get(subscription));

        resourceManager.computeSkus().
                listByRegionAndResourceType(Region.US_CENTRAL, ComputeResourceType.VIRTUALMACHINES).stream().
                forEach(computeSku ->
                {
                    //log.info("Compute SKU " + computeSku.name());
                    computeSkuMap.put(String.valueOf(computeSku.name()), StringUtils.capitalize(computeSku.innerModel().family().toLowerCase().replace("family", " series").replace("standard", "")));
                });

        return resourceManager;
    }

    private BomMetadata populateAzureDetails(BomMetadata bomMetadata, Boolean hasVms, Boolean hasDb, DBType
            dbType) throws Exception {

        List<String> subscriptions = new ArrayList<>(Arrays.asList(bomMetadata.getDevSubscriptions().split(",")));
        List<GenericResource> resources = new ArrayList<>();
        List<Resource> allResources = new ArrayList<>();
        for (String sub : subscriptions) {
            List<ResourceGroup> resourceGroups = new ArrayList<>();
            AzureResourceManager resourceManager = initializeAzureResourceManager(sub);
            JsonMapper.builder().configure(MapperFeature.ACCEPT_CASE_INSENSITIVE_PROPERTIES, true);
            ObjectMapper objectMapper = new ObjectMapper();
            objectMapper.setPropertyNamingStrategy(PropertyNamingStrategies.SNAKE_CASE);


            //           resourceManager.storageSkus().list().stream().
            //          forEach(storageSku ->
            //                 {
            //                     log.info("Storage SKU " + storageSku.name()+ ", resourceType " + storageSku.resourceType()+ ", kind " + storageSku.storageAccountKind().toString());
            //                 }
            //              );

            AzureSkusForRegion availableSkusInThisRegion = new AzureSkusForRegion(resourceManager);
            diskSkuMap = availableSkusInThisRegion.getDiskSkus();
            if (hasVms)
                vmSkuMap = availableSkusInThisRegion.getVmSkus();
            if (hasDb)
               sqlDbSkuMap.putAll(availableSkusInThisRegion.getSqlDbSkus());

        }

        return bomMetadata;
    }
}
