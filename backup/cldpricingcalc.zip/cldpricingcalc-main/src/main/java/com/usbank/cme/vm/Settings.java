
package com.usbank.cme.vm;

import java.util.LinkedHashMap;
import java.util.Map;
import javax.annotation.Generated;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "authentication",
    "azureResourceId",
    "installedBy",
    "vNextEnabled",
    "commandToExecute",
    "timestamp"
})
@Generated("jsonschema2pojo")
public class Settings {

    @JsonProperty("authentication")
    private Authentication authentication;
    @JsonProperty("azureResourceId")
    private String azureResourceId;
    @JsonProperty("installedBy")
    private String installedBy;
    @JsonProperty("vNextEnabled")
    private String vNextEnabled;
    @JsonProperty("commandToExecute")
    private String commandToExecute;
    @JsonProperty("timestamp")
    private Integer timestamp;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new LinkedHashMap<String, Object>();

    @JsonProperty("authentication")
    public Authentication getAuthentication() {
        return authentication;
    }

    @JsonProperty("authentication")
    public void setAuthentication(Authentication authentication) {
        this.authentication = authentication;
    }

    @JsonProperty("azureResourceId")
    public String getAzureResourceId() {
        return azureResourceId;
    }

    @JsonProperty("azureResourceId")
    public void setAzureResourceId(String azureResourceId) {
        this.azureResourceId = azureResourceId;
    }

    @JsonProperty("installedBy")
    public String getInstalledBy() {
        return installedBy;
    }

    @JsonProperty("installedBy")
    public void setInstalledBy(String installedBy) {
        this.installedBy = installedBy;
    }

    @JsonProperty("vNextEnabled")
    public String getvNextEnabled() {
        return vNextEnabled;
    }

    @JsonProperty("vNextEnabled")
    public void setvNextEnabled(String vNextEnabled) {
        this.vNextEnabled = vNextEnabled;
    }

    @JsonProperty("commandToExecute")
    public String getCommandToExecute() {
        return commandToExecute;
    }

    @JsonProperty("commandToExecute")
    public void setCommandToExecute(String commandToExecute) {
        this.commandToExecute = commandToExecute;
    }

    @JsonProperty("timestamp")
    public Integer getTimestamp() {
        return timestamp;
    }

    @JsonProperty("timestamp")
    public void setTimestamp(Integer timestamp) {
        this.timestamp = timestamp;
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

}
