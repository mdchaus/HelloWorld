package com.usbank.cme.resourcemanager;


public class ManagedDiskSku {


    //need:  (1) service name:  Storage
    //       (2) Product name:   Standard SSD Managed Disks
    //       (3) Meter name:  E6 LRS Disk
    //       (4) SKU name: E6 LRS


    public String skuEnumString;

    private String tier;  // Standard_LRS, StandardSSD, PremiumSSD, PremiumSSDV2, UltraSSD
    private String formattedTier;

    public String getFormattedTier() {
        return formattedTier;
    }

    public String redundancy;  // LRS or ZRS
    public String capacity;
    public String capacityUnits; // GB or maybe TB

    public String getFormattedCapacityName() {
        return capacity + " " + capacityUnits;
    }

    private String diskSkuSize;  // E10, S2, specifyDiskSizeTB

    public String getFormattedSkuName() {
        return diskSkuSize + " " + redundancy;
    }


    final String diskServiceName = "Storage";

    private String sqlServiceName() {
        return this.diskServiceName;
    }

    final String diskProductNameEnd = " Managed Disks";

    public String getFormattedSQLProductName() {
        return formattedTier + diskProductNameEnd;
    }

    private String formattedName;


   public String toString() {
        return formattedName;
    }

    // example: Disk SKU PremiumV2_LRS, tier Premium, sku type PremiumV2_LRS, disk size type P, disk size 65536
    public ManagedDiskSku (String sku, String tier, String diskSkuSize, String diskSize )
    {

        String storageOption = sku.split("_")[0];
        this.redundancy = sku.split("_")[1];
        this.tier = tier;
        this.diskSkuSize = diskSkuSize;
        capacity = diskSize;


        switch (storageOption) {
            case "None":
                break;
            case "Standard":
                formattedTier = "Standard HDD";
                capacityUnits = "GB";
                skuEnumString = "Standard_" + redundancy + "_" + diskSkuSize + "_" + capacity + capacityUnits;
                break;
            case "StandardSSD":
                formattedTier = "Standard SSD";
                capacityUnits = "GB";
                skuEnumString = formattedTier.replace(" ","") + "_" + redundancy + "_" + diskSkuSize + "_" + capacity + capacityUnits;
                break;
            case "Premium":
                formattedTier = "Premium SSD";
                capacityUnits = "GB";
                skuEnumString = formattedTier.replace(" ","") + "_" + redundancy + "_" + diskSkuSize + "_" + capacity + capacityUnits;
                break;
            case "PremiumV2":
                formattedTier = "Premium SSDV2";
                diskSkuSize = "n/a";
                capacity = "specifyDiskSize";
                capacityUnits = "TB";
                skuEnumString = formattedTier.replace(" ","") + "_" + redundancy + "_" + capacity + capacityUnits;
                break;
            case "UltraSSD":
                formattedTier = "Ultra SSD";
                diskSkuSize = "n/a";
                capacity = "specifyDiskSize";
                capacityUnits = "TB";
                skuEnumString = formattedTier.replace(" ","") + "_" + redundancy + "_" + capacity + capacityUnits;
                break;

        }
        formattedName = formattedTier + " " + redundancy + " " + getFormattedCapacityName();

    }

    public ManagedDiskSku(ManagedDiskSkuEnum diskSkuEnum) {

        // ManagedDiskEnum examples:
        //  Standard_LRS_S80_32767GB,
        //  StandardSSD_LRS_E20_512GB,
        //  StandardSSD_ZRS_E3_16GB
        //  PremiumSSD_LRS_P50_4096GB,
        //  PremiumSSD_ZRS_P50_4096GB,
        //  PremiumSSDV2_LRS_specifyDiskSize,
        //  PremiumSSDV2_ZRS_specifyDiskSize,
        //  UltraSSD_LRS_specifyDiskSizeTB
        skuEnumString = diskSkuEnum.toString();
        if (diskSkuEnum == ManagedDiskSkuEnum.NONE)
        {
            tier = "NONE";
            redundancy = "NONE";
            formattedTier = "NONE";
            diskSkuSize = "NONE";
            capacity = "NONE"; // the number in the part e.g.  64GB -> 64
            capacityUnits = "NONE"; // the units
            formattedName = "NONE";
            return;
        }



        String[] parts = skuEnumString.split("_");

        tier = parts[0]; //Standard, StandardSSD, PremiumSSD, PremiumSSDV2, UltraSSD
        redundancy = parts[1]; // LRS, ZRS
        String[] meter;

        switch (tier) {
            case "None":
                break;
            case "Standard":
                formattedTier = "Standard HDD";
                diskSkuSize = parts[2];
                meter = parts[3].split("(?<=[A-Za-z])\\s*(?=\\d)|(?<=\\d)\\s*(?=[A-Za-z])");
                capacity = meter[0];  // the number in the part e.g.  64GB -> 64
                capacityUnits = meter[1]; // the units
                formattedName = formattedTier + " " + redundancy + " " + diskSkuSize + " " + getFormattedCapacityName();
                break;
            case "StandardSSD":
                formattedTier = "Standard SSD";
                diskSkuSize = parts[2];
                meter = parts[3].split("(?<=[A-Za-z])\\s*(?=\\d)|(?<=\\d)\\s*(?=[A-Za-z])");
                capacity = meter[0];  // the number in the part e.g.  64GB -> 64
                capacityUnits = meter[1]; // the units
                formattedName = formattedTier + " " + redundancy + " " + diskSkuSize + " " + getFormattedCapacityName();
                break;
            case "PremiumSSD":
                formattedTier = "Premium SSD";
                diskSkuSize = parts[2];
                meter = parts[3].split("(?<=[A-Za-z])\\s*(?=\\d)|(?<=\\d)\\s*(?=[A-Za-z])");
                capacity = meter[0];  // the number in the part e.g.  64GB -> 64
                capacityUnits = meter[1]; // the units
                formattedName = formattedTier + " " + redundancy + " " + diskSkuSize + " " + getFormattedCapacityName();
                break;
            case "PremiumSSDV2":
                formattedTier = "Premium SSDv2";
                diskSkuSize = "n/a";
                capacity = "specifyDiskSize";
                capacityUnits = "TB";
                formattedName = formattedTier + " " + redundancy + " " + getFormattedCapacityName();
                break;
            case "UltraSSD":
                formattedTier = "Ultra SSD";
                diskSkuSize = "n/a";
                capacity = "specifyDiskSize";
                capacityUnits = "TB";
                formattedName = formattedTier + " " + redundancy + " " + getFormattedCapacityName();
                break;

        }

    }


}
