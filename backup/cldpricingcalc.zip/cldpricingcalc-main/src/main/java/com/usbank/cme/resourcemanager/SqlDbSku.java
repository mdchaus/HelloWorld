package com.usbank.cme.resourcemanager;

import org.apache.commons.text.CaseUtils;


public class SqlDbSku  {

    //need:  (1) service name:  SQL Managed Instance or SQL Database
    //       (2) Product name:   SQL Database Single/Elastic Pool General Purpose - Compute Gen5, SQL Managed Instance Single/Elastic Pool General Purpose - Compute Gen5
    //       (3) Meter name:  always "vCore"
    //       (4) SKU name: 4 vCore

    private String skuEnumString;
    public String family;
    public String name;

    public String tier;
    private String formattedTier;
    public String getFormattedTier() {
        return formattedTier;
    }

    public String capacity;

    private enum CapacityEnum
    {
        vCore,
        DTU,  // database transaction units
        DWU   //  data warehouse units
    }
    private CapacityEnum capacityUnits;
    public String getCapacityUnits()
    {
        return capacityUnits.toString();
    }

    public String getFormattedCapacitySku() {
        return capacity + " " + capacityUnits.toString();
    }


    //DatabaseSku.BUSINESSCRITICAL_BC_GEN5_2
    final String sqlDbServiceName = "SQL Database";
    private String sqlDbServiceName()
    {
        return this.sqlDbServiceName;
    }



    final String sqlDbProductNameStart = sqlDbServiceName + " Single/Elastic Pool ";
    private String formattedSQLProductName;    // e.g. "E4 LRS"
    public String getFormattedSQLProductName() {
        return formattedSQLProductName;
    }

    final String sqlMiDbServiceName = "SQL Managed Instance";
    private String sqlMiServiceName()
    {
        return this.sqlMiDbServiceName;
    }

    final String sqlMiDbProductNameStart = sqlMiDbServiceName + " Single/Elastic Pool ";
    private String formattedSQLMIProductName;    // e.g. "E4 LRS"
    public String getFormattedSQLMIProductName() {
        return formattedSQLMIProductName;
    }




    //  name   /tier          /family/capacity/size
    // GP_Gen5/GeneralPurpose/Gen5   /32      /null   (size is always null)
    public SqlDbSku(String name, String tier, String family, String capacity) {

        this.skuEnumString = "";
        this.name = name.toUpperCase().trim();
        this.tier = tier.toUpperCase().trim();
        this.family = family.toUpperCase().trim();
        this.capacity = capacity.trim();

        // this isn't functional yet
        switch (this.tier) {
            case ("GENERALPURPOSE"):
                capacityUnits = CapacityEnum.vCore;
                break;
            case ("PREMIUM"):
                capacityUnits = CapacityEnum.DTU;
                break;
            case ("BUSINESSCRITICAL"):
                capacityUnits = CapacityEnum.vCore;
                break;
            case ("STANDARD"):
                capacityUnits = CapacityEnum.DTU;
                break;
            case ("DATAWAREHOUSE"):
                capacityUnits = CapacityEnum.DWU;
                break;
            default:
                //throw IllegalArgumentException();
        }

        //formattedProductName
    }
    public SqlDbSku(SqlDbSkuEnum sqlDbSkuEnum)
    {


        this.skuEnumString = sqlDbSkuEnum.toString();
        String[] parts = skuEnumString.split("_");

        String firstPart= parts[0];
        String lastPart = parts[parts.length-1];
        String[] meter = lastPart.split("(?<=[A-Za-z])\\s*(?=\\d)|(?<=\\d)\\s*(?=[A-Za-z])");
        capacity = meter[0];  // the number in the part e.g.  64vCore -> 64

        switch (firstPart)
        {
            case("NONE"):
                capacity = "0";
                family = "NONE";
                name = "NONE";
                capacityUnits = CapacityEnum.vCore;
                tier = "NONE";
                formattedTier = "NONE";
                break;
            case ("GENERALPURPOSE"):
                if (parts[2].equals("S")) {
                    family = CaseUtils.toCamelCase(parts[3],true);
                    name = parts[1] + "_S_" + family;
                }
                else {
                    family = CaseUtils.toCamelCase(parts[2],true);
                    name = parts[1] + "_" + family;

                }
                capacityUnits = CapacityEnum.vCore;
                tier = "GeneralPurpose";
                formattedTier = "General Purpose";
                break;
            case ("PREMIUM"):
                family = CaseUtils.toCamelCase(parts[1],true);
                name = "Premium";
                capacityUnits = CapacityEnum.DTU;
                tier = "Premium";
                formattedTier = "Premium";
                break;
            case ("BUSINESSCRITICAL"):
                family = CaseUtils.toCamelCase(parts[2],true);
                name = parts[1] + "_" + family;
                capacityUnits = CapacityEnum.vCore;
                tier = "BusinessCritical";
                formattedTier = "Business Critical";
                break;
            case ("STANDARD"):
                family = CaseUtils.toCamelCase(parts[1],true);
                name = "Standard";
                capacityUnits = CapacityEnum.DTU;
                tier = "Standard";
                formattedTier = "Standard";
                break;
            case ("DATAWAREHOUSE"):
                family = parts[1]; //DW
                name = "DataWarehouse";
                capacityUnits = CapacityEnum.DWU;
                tier = "DataWarehouse";
                formattedTier = "Data Warehouse";
                break;
            default:
                //throw IllegalArgumentException();
        }

        formattedSQLProductName = sqlDbProductNameStart + formattedTier + " - Compute " + family;
        formattedSQLMIProductName = sqlMiDbProductNameStart + formattedTier + " - Compute " + family;

    }


}
