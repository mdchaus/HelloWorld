
package com.usbank.cme.kv;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import javax.annotation.Generated;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "certificates",
    "keys",
    "secrets",
    "storage"
})
@Generated("jsonschema2pojo")
public class Permissions {

    @JsonProperty("certificates")
    private List<Object> certificates;
    @JsonProperty("keys")
    private List<String> keys;
    @JsonProperty("secrets")
    private List<Object> secrets;
    @JsonProperty("storage")
    private List<Object> storage;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new LinkedHashMap<String, Object>();

    @JsonProperty("certificates")
    public List<Object> getCertificates() {
        return certificates;
    }

    @JsonProperty("certificates")
    public void setCertificates(List<Object> certificates) {
        this.certificates = certificates;
    }

    @JsonProperty("keys")
    public List<String> getKeys() {
        return keys;
    }

    @JsonProperty("keys")
    public void setKeys(List<String> keys) {
        this.keys = keys;
    }

    @JsonProperty("secrets")
    public List<Object> getSecrets() {
        return secrets;
    }

    @JsonProperty("secrets")
    public void setSecrets(List<Object> secrets) {
        this.secrets = secrets;
    }

    @JsonProperty("storage")
    public List<Object> getStorage() {
        return storage;
    }

    @JsonProperty("storage")
    public void setStorage(List<Object> storage) {
        this.storage = storage;
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

}
