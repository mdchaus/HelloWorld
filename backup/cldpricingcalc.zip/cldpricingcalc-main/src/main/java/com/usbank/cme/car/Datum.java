
package com.usbank.cme.car;

import java.util.LinkedHashMap;
import java.util.Map;
import javax.annotation.Generated;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "carId",
    "softwareName",
    "softwareDescription",
    "softwareLifeCycleCode",
    "softwareLifeCycle",
    "slLastChangeDate",
    "acquisitionName",
    "acquisitionInProgress",
    "estimatedAcquisitionIntegrationDate",
    "acquisitionStatus",
    "estimatedProductionDate",
    "estimatedRetirementDate",
    "softwareClassification",
    "supportType",
    "productName",
    "softwareUsage",
    "customerTransferFunds",
    "customerEditPersonalData",
    "customerViewNonPublicPersonalData",
    "customerAdminAccess",
    "resiliencyTier",
    "workstationSoftware",
    "serverSoftware",
    "tprmAssociation",
    "thirdPartyRelationshipID",
    "configurationMgmt",
    "autoSys",
    "webAccessManagement",
    "alias",
    "aliasType",
    "accessProvisioning",
    "accessAdminPreferredId",
    "accessAdminName",
    "inherentRiskRating",
    "inherentRiskScore",
    "informationClassification",
    "personal",
    "confidential",
    "personalInformationClass",
    "officialRecords",
    "retentionCapabilities",
    "purgingCapabilities",
    "externalAccess",
    "accessibility",
    "aiML",
    "encryption",
    "finra",
    "fisma",
    "moneyMovement",
    "pci",
    "pciAssessed",
    "pciII",
    "psd2",
    "socSoxAssessed",
    "soc1",
    "soc2",
    "soxSftl",
    "ads",
    "basel",
    "settlementApplicable",
    "inboundDependency",
    "toRiskOversightPreferredId",
    "toRiskOversightName",
    "toBusinessLine",
    "toBusinessLineDesc",
    "pbloRiskOversightPreferredId",
    "pbloRiskOversightName",
    "pbloBusinessLine",
    "pbloBusinessLineDesc",
    "softwareCertificationRequirement",
    "toPreferredId",
    "toName",
    "toEmail",
    "toCostCenter",
    "toCcDescription",
    "toAssignedDate",
    "toCurrentQtrCertificationStatus",
    "toCertificationDate",
    "toManagerPreferredId",
    "toManagerName",
    "toManagersManagerPreferredId",
    "toManagersManagerName",
    "toLevel5MgrPreferredId",
    "toLevel5MgrName",
    "toLevel4MgrPreferredId",
    "toLevel4MgrName",
    "toLevel3MgrPreferredId",
    "toLevel3MgrName",
    "toLevel2MgrPreferredId",
    "toLevel2MgrName",
    "pbloPreferredId",
    "pbloName",
    "pbloEmail",
    "pbloCostCenter",
    "pbloCcDescription",
    "pbloAssignedDate",
    "pbloCurrentQtrCertificationStatus",
    "pbloCertificationDate",
    "pbloManagerPreferredId",
    "pbloManagerName",
    "pbloManagersManagerPreferredId",
    "pbloManagersManagerName",
    "pbloLevel5MgrPreferredId",
    "pbloLevel5MgrName",
    "pbloLevel4MgrPreferredId",
    "pbloLevel4MgrName",
    "pbloLevel3MgrPreferredId",
    "pbloLevel3MgrName",
    "pbloLevel2MgrPreferredId",
    "pbloLevel2MgrName",
    "sbloPreferredId",
    "sbloEmail",
    "sbloCertificationDate",
    "remediationOwnerPreferredId",
    "remediationOwnerName",
    "remediationOwnerEmail",
    "ascPreferredId",
    "ascName",
    "ascEmail",
    "reliabilityEngineeringLeadPreferredID",
    "reliabilityEngineeringLeadName",
    "reliabilityEngineeringLeadEmail",
    "recordCreationDate",
    "recordLastChangedDate",
    "recordLastChangedByPreferredId",
    "recordLastChangedByName",
    "assigneeGroupLevel2Support",
    "assigneeGroupLevel3Support",
    "inboundDependencies",
    "outboundDependencies"
})
@Generated("jsonschema2pojo")
public class Datum {

    @JsonProperty("carId")
    private String carId;
    @JsonProperty("softwareName")
    private String softwareName;
    @JsonProperty("softwareDescription")
    private String softwareDescription;
    @JsonProperty("softwareLifeCycleCode")
    private String softwareLifeCycleCode;
    @JsonProperty("softwareLifeCycle")
    private String softwareLifeCycle;
    @JsonProperty("slLastChangeDate")
    private String slLastChangeDate;
    @JsonProperty("acquisitionName")
    private Object acquisitionName;
    @JsonProperty("acquisitionInProgress")
    private Object acquisitionInProgress;
    @JsonProperty("estimatedAcquisitionIntegrationDate")
    private Object estimatedAcquisitionIntegrationDate;
    @JsonProperty("acquisitionStatus")
    private Object acquisitionStatus;
    @JsonProperty("estimatedProductionDate")
    private Object estimatedProductionDate;
    @JsonProperty("estimatedRetirementDate")
    private Object estimatedRetirementDate;
    @JsonProperty("softwareClassification")
    private String softwareClassification;
    @JsonProperty("supportType")
    private String supportType;
    @JsonProperty("productName")
    private String productName;
    @JsonProperty("softwareUsage")
    private String softwareUsage;
    @JsonProperty("customerTransferFunds")
    private String customerTransferFunds;
    @JsonProperty("customerEditPersonalData")
    private String customerEditPersonalData;
    @JsonProperty("customerViewNonPublicPersonalData")
    private String customerViewNonPublicPersonalData;
    @JsonProperty("customerAdminAccess")
    private String customerAdminAccess;
    @JsonProperty("resiliencyTier")
    private String resiliencyTier;
    @JsonProperty("workstationSoftware")
    private String workstationSoftware;
    @JsonProperty("serverSoftware")
    private String serverSoftware;
    @JsonProperty("tprmAssociation")
    private String tprmAssociation;
    @JsonProperty("thirdPartyRelationshipID")
    private Object thirdPartyRelationshipID;
    @JsonProperty("configurationMgmt")
    private String configurationMgmt;
    @JsonProperty("autoSys")
    private String autoSys;
    @JsonProperty("webAccessManagement")
    private String webAccessManagement;
    @JsonProperty("alias")
    private Object alias;
    @JsonProperty("aliasType")
    private Object aliasType;
    @JsonProperty("accessProvisioning")
    private String accessProvisioning;
    @JsonProperty("accessAdminPreferredId")
    private Object accessAdminPreferredId;
    @JsonProperty("accessAdminName")
    private Object accessAdminName;
    @JsonProperty("inherentRiskRating")
    private String inherentRiskRating;
    @JsonProperty("inherentRiskScore")
    private String inherentRiskScore;
    @JsonProperty("informationClassification")
    private String informationClassification;
    @JsonProperty("personal")
    private String personal;
    @JsonProperty("confidential")
    private String confidential;
    @JsonProperty("personalInformationClass")
    private String personalInformationClass;
    @JsonProperty("officialRecords")
    private String officialRecords;
    @JsonProperty("retentionCapabilities")
    private String retentionCapabilities;
    @JsonProperty("purgingCapabilities")
    private String purgingCapabilities;
    @JsonProperty("externalAccess")
    private String externalAccess;
    @JsonProperty("accessibility")
    private String accessibility;
    @JsonProperty("aiML")
    private String aiML;
    @JsonProperty("encryption")
    private String encryption;
    @JsonProperty("finra")
    private String finra;
    @JsonProperty("fisma")
    private String fisma;
    @JsonProperty("moneyMovement")
    private String moneyMovement;
    @JsonProperty("pci")
    private String pci;
    @JsonProperty("pciAssessed")
    private String pciAssessed;
    @JsonProperty("pciII")
    private String pciII;
    @JsonProperty("psd2")
    private String psd2;
    @JsonProperty("socSoxAssessed")
    private String socSoxAssessed;
    @JsonProperty("soc1")
    private String soc1;
    @JsonProperty("soc2")
    private String soc2;
    @JsonProperty("soxSftl")
    private String soxSftl;
    @JsonProperty("ads")
    private String ads;
    @JsonProperty("basel")
    private String basel;
    @JsonProperty("settlementApplicable")
    private String settlementApplicable;
    @JsonProperty("inboundDependency")
    private String inboundDependency;
    @JsonProperty("toRiskOversightPreferredId")
    private String toRiskOversightPreferredId;
    @JsonProperty("toRiskOversightName")
    private String toRiskOversightName;
    @JsonProperty("toBusinessLine")
    private String toBusinessLine;
    @JsonProperty("toBusinessLineDesc")
    private String toBusinessLineDesc;
    @JsonProperty("pbloRiskOversightPreferredId")
    private String pbloRiskOversightPreferredId;
    @JsonProperty("pbloRiskOversightName")
    private String pbloRiskOversightName;
    @JsonProperty("pbloBusinessLine")
    private String pbloBusinessLine;
    @JsonProperty("pbloBusinessLineDesc")
    private String pbloBusinessLineDesc;
    @JsonProperty("softwareCertificationRequirement")
    private String softwareCertificationRequirement;
    @JsonProperty("toPreferredId")
    private String toPreferredId;
    @JsonProperty("toName")
    private String toName;
    @JsonProperty("toEmail")
    private String toEmail;
    @JsonProperty("toCostCenter")
    private String toCostCenter;
    @JsonProperty("toCcDescription")
    private String toCcDescription;
    @JsonProperty("toAssignedDate")
    private String toAssignedDate;
    @JsonProperty("toCurrentQtrCertificationStatus")
    private String toCurrentQtrCertificationStatus;
    @JsonProperty("toCertificationDate")
    private String toCertificationDate;
    @JsonProperty("toManagerPreferredId")
    private String toManagerPreferredId;
    @JsonProperty("toManagerName")
    private String toManagerName;
    @JsonProperty("toManagersManagerPreferredId")
    private String toManagersManagerPreferredId;
    @JsonProperty("toManagersManagerName")
    private String toManagersManagerName;
    @JsonProperty("toLevel5MgrPreferredId")
    private String toLevel5MgrPreferredId;
    @JsonProperty("toLevel5MgrName")
    private String toLevel5MgrName;
    @JsonProperty("toLevel4MgrPreferredId")
    private String toLevel4MgrPreferredId;
    @JsonProperty("toLevel4MgrName")
    private String toLevel4MgrName;
    @JsonProperty("toLevel3MgrPreferredId")
    private String toLevel3MgrPreferredId;
    @JsonProperty("toLevel3MgrName")
    private String toLevel3MgrName;
    @JsonProperty("toLevel2MgrPreferredId")
    private String toLevel2MgrPreferredId;
    @JsonProperty("toLevel2MgrName")
    private String toLevel2MgrName;
    @JsonProperty("pbloPreferredId")
    private String pbloPreferredId;
    @JsonProperty("pbloName")
    private String pbloName;
    @JsonProperty("pbloEmail")
    private String pbloEmail;
    @JsonProperty("pbloCostCenter")
    private String pbloCostCenter;
    @JsonProperty("pbloCcDescription")
    private String pbloCcDescription;
    @JsonProperty("pbloAssignedDate")
    private String pbloAssignedDate;
    @JsonProperty("pbloCurrentQtrCertificationStatus")
    private String pbloCurrentQtrCertificationStatus;
    @JsonProperty("pbloCertificationDate")
    private String pbloCertificationDate;
    @JsonProperty("pbloManagerPreferredId")
    private String pbloManagerPreferredId;
    @JsonProperty("pbloManagerName")
    private String pbloManagerName;
    @JsonProperty("pbloManagersManagerPreferredId")
    private String pbloManagersManagerPreferredId;
    @JsonProperty("pbloManagersManagerName")
    private String pbloManagersManagerName;
    @JsonProperty("pbloLevel5MgrPreferredId")
    private String pbloLevel5MgrPreferredId;
    @JsonProperty("pbloLevel5MgrName")
    private String pbloLevel5MgrName;
    @JsonProperty("pbloLevel4MgrPreferredId")
    private String pbloLevel4MgrPreferredId;
    @JsonProperty("pbloLevel4MgrName")
    private String pbloLevel4MgrName;
    @JsonProperty("pbloLevel3MgrPreferredId")
    private String pbloLevel3MgrPreferredId;
    @JsonProperty("pbloLevel3MgrName")
    private String pbloLevel3MgrName;
    @JsonProperty("pbloLevel2MgrPreferredId")
    private String pbloLevel2MgrPreferredId;
    @JsonProperty("pbloLevel2MgrName")
    private String pbloLevel2MgrName;
    @JsonProperty("sbloPreferredId")
    private String sbloPreferredId;
    @JsonProperty("sbloEmail")
    private String sbloEmail;
    @JsonProperty("sbloCertificationDate")
    private String sbloCertificationDate;
    @JsonProperty("remediationOwnerPreferredId")
    private Object remediationOwnerPreferredId;
    @JsonProperty("remediationOwnerName")
    private Object remediationOwnerName;
    @JsonProperty("remediationOwnerEmail")
    private Object remediationOwnerEmail;
    @JsonProperty("ascPreferredId")
    private Object ascPreferredId;
    @JsonProperty("ascName")
    private Object ascName;
    @JsonProperty("ascEmail")
    private Object ascEmail;
    @JsonProperty("reliabilityEngineeringLeadPreferredID")
    private Object reliabilityEngineeringLeadPreferredID;
    @JsonProperty("reliabilityEngineeringLeadName")
    private Object reliabilityEngineeringLeadName;
    @JsonProperty("reliabilityEngineeringLeadEmail")
    private Object reliabilityEngineeringLeadEmail;
    @JsonProperty("recordCreationDate")
    private String recordCreationDate;
    @JsonProperty("recordLastChangedDate")
    private String recordLastChangedDate;
    @JsonProperty("recordLastChangedByPreferredId")
    private String recordLastChangedByPreferredId;
    @JsonProperty("recordLastChangedByName")
    private Object recordLastChangedByName;
    @JsonProperty("assigneeGroupLevel2Support")
    private String assigneeGroupLevel2Support;
    @JsonProperty("assigneeGroupLevel3Support")
    private String assigneeGroupLevel3Support;
    @JsonProperty("inboundDependencies")
    private Object inboundDependencies;
    @JsonProperty("outboundDependencies")
    private Object outboundDependencies;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new LinkedHashMap<String, Object>();

    @JsonProperty("carId")
    public String getCarId() {
        return carId;
    }

    @JsonProperty("carId")
    public void setCarId(String carId) {
        this.carId = carId;
    }

    @JsonProperty("softwareName")
    public String getSoftwareName() {
        return softwareName;
    }

    @JsonProperty("softwareName")
    public void setSoftwareName(String softwareName) {
        this.softwareName = softwareName;
    }

    @JsonProperty("softwareDescription")
    public String getSoftwareDescription() {
        return softwareDescription;
    }

    @JsonProperty("softwareDescription")
    public void setSoftwareDescription(String softwareDescription) {
        this.softwareDescription = softwareDescription;
    }

    @JsonProperty("softwareLifeCycleCode")
    public String getSoftwareLifeCycleCode() {
        return softwareLifeCycleCode;
    }

    @JsonProperty("softwareLifeCycleCode")
    public void setSoftwareLifeCycleCode(String softwareLifeCycleCode) {
        this.softwareLifeCycleCode = softwareLifeCycleCode;
    }

    @JsonProperty("softwareLifeCycle")
    public String getSoftwareLifeCycle() {
        return softwareLifeCycle;
    }

    @JsonProperty("softwareLifeCycle")
    public void setSoftwareLifeCycle(String softwareLifeCycle) {
        this.softwareLifeCycle = softwareLifeCycle;
    }

    @JsonProperty("slLastChangeDate")
    public String getSlLastChangeDate() {
        return slLastChangeDate;
    }

    @JsonProperty("slLastChangeDate")
    public void setSlLastChangeDate(String slLastChangeDate) {
        this.slLastChangeDate = slLastChangeDate;
    }

    @JsonProperty("acquisitionName")
    public Object getAcquisitionName() {
        return acquisitionName;
    }

    @JsonProperty("acquisitionName")
    public void setAcquisitionName(Object acquisitionName) {
        this.acquisitionName = acquisitionName;
    }

    @JsonProperty("acquisitionInProgress")
    public Object getAcquisitionInProgress() {
        return acquisitionInProgress;
    }

    @JsonProperty("acquisitionInProgress")
    public void setAcquisitionInProgress(Object acquisitionInProgress) {
        this.acquisitionInProgress = acquisitionInProgress;
    }

    @JsonProperty("estimatedAcquisitionIntegrationDate")
    public Object getEstimatedAcquisitionIntegrationDate() {
        return estimatedAcquisitionIntegrationDate;
    }

    @JsonProperty("estimatedAcquisitionIntegrationDate")
    public void setEstimatedAcquisitionIntegrationDate(Object estimatedAcquisitionIntegrationDate) {
        this.estimatedAcquisitionIntegrationDate = estimatedAcquisitionIntegrationDate;
    }

    @JsonProperty("acquisitionStatus")
    public Object getAcquisitionStatus() {
        return acquisitionStatus;
    }

    @JsonProperty("acquisitionStatus")
    public void setAcquisitionStatus(Object acquisitionStatus) {
        this.acquisitionStatus = acquisitionStatus;
    }

    @JsonProperty("estimatedProductionDate")
    public Object getEstimatedProductionDate() {
        return estimatedProductionDate;
    }

    @JsonProperty("estimatedProductionDate")
    public void setEstimatedProductionDate(Object estimatedProductionDate) {
        this.estimatedProductionDate = estimatedProductionDate;
    }

    @JsonProperty("estimatedRetirementDate")
    public Object getEstimatedRetirementDate() {
        return estimatedRetirementDate;
    }

    @JsonProperty("estimatedRetirementDate")
    public void setEstimatedRetirementDate(Object estimatedRetirementDate) {
        this.estimatedRetirementDate = estimatedRetirementDate;
    }

    @JsonProperty("softwareClassification")
    public String getSoftwareClassification() {
        return softwareClassification;
    }

    @JsonProperty("softwareClassification")
    public void setSoftwareClassification(String softwareClassification) {
        this.softwareClassification = softwareClassification;
    }

    @JsonProperty("supportType")
    public String getSupportType() {
        return supportType;
    }

    @JsonProperty("supportType")
    public void setSupportType(String supportType) {
        this.supportType = supportType;
    }

    @JsonProperty("productName")
    public String getProductName() {
        return productName;
    }

    @JsonProperty("productName")
    public void setProductName(String productName) {
        this.productName = productName;
    }

    @JsonProperty("softwareUsage")
    public String getSoftwareUsage() {
        return softwareUsage;
    }

    @JsonProperty("softwareUsage")
    public void setSoftwareUsage(String softwareUsage) {
        this.softwareUsage = softwareUsage;
    }

    @JsonProperty("customerTransferFunds")
    public String getCustomerTransferFunds() {
        return customerTransferFunds;
    }

    @JsonProperty("customerTransferFunds")
    public void setCustomerTransferFunds(String customerTransferFunds) {
        this.customerTransferFunds = customerTransferFunds;
    }

    @JsonProperty("customerEditPersonalData")
    public String getCustomerEditPersonalData() {
        return customerEditPersonalData;
    }

    @JsonProperty("customerEditPersonalData")
    public void setCustomerEditPersonalData(String customerEditPersonalData) {
        this.customerEditPersonalData = customerEditPersonalData;
    }

    @JsonProperty("customerViewNonPublicPersonalData")
    public String getCustomerViewNonPublicPersonalData() {
        return customerViewNonPublicPersonalData;
    }

    @JsonProperty("customerViewNonPublicPersonalData")
    public void setCustomerViewNonPublicPersonalData(String customerViewNonPublicPersonalData) {
        this.customerViewNonPublicPersonalData = customerViewNonPublicPersonalData;
    }

    @JsonProperty("customerAdminAccess")
    public String getCustomerAdminAccess() {
        return customerAdminAccess;
    }

    @JsonProperty("customerAdminAccess")
    public void setCustomerAdminAccess(String customerAdminAccess) {
        this.customerAdminAccess = customerAdminAccess;
    }

    @JsonProperty("resiliencyTier")
    public String getResiliencyTier() {
        return resiliencyTier;
    }

    @JsonProperty("resiliencyTier")
    public void setResiliencyTier(String resiliencyTier) {
        this.resiliencyTier = resiliencyTier;
    }

    @JsonProperty("workstationSoftware")
    public String getWorkstationSoftware() {
        return workstationSoftware;
    }

    @JsonProperty("workstationSoftware")
    public void setWorkstationSoftware(String workstationSoftware) {
        this.workstationSoftware = workstationSoftware;
    }

    @JsonProperty("serverSoftware")
    public String getServerSoftware() {
        return serverSoftware;
    }

    @JsonProperty("serverSoftware")
    public void setServerSoftware(String serverSoftware) {
        this.serverSoftware = serverSoftware;
    }

    @JsonProperty("tprmAssociation")
    public String getTprmAssociation() {
        return tprmAssociation;
    }

    @JsonProperty("tprmAssociation")
    public void setTprmAssociation(String tprmAssociation) {
        this.tprmAssociation = tprmAssociation;
    }

    @JsonProperty("thirdPartyRelationshipID")
    public Object getThirdPartyRelationshipID() {
        return thirdPartyRelationshipID;
    }

    @JsonProperty("thirdPartyRelationshipID")
    public void setThirdPartyRelationshipID(Object thirdPartyRelationshipID) {
        this.thirdPartyRelationshipID = thirdPartyRelationshipID;
    }

    @JsonProperty("configurationMgmt")
    public String getConfigurationMgmt() {
        return configurationMgmt;
    }

    @JsonProperty("configurationMgmt")
    public void setConfigurationMgmt(String configurationMgmt) {
        this.configurationMgmt = configurationMgmt;
    }

    @JsonProperty("autoSys")
    public String getAutoSys() {
        return autoSys;
    }

    @JsonProperty("autoSys")
    public void setAutoSys(String autoSys) {
        this.autoSys = autoSys;
    }

    @JsonProperty("webAccessManagement")
    public String getWebAccessManagement() {
        return webAccessManagement;
    }

    @JsonProperty("webAccessManagement")
    public void setWebAccessManagement(String webAccessManagement) {
        this.webAccessManagement = webAccessManagement;
    }

    @JsonProperty("alias")
    public Object getAlias() {
        return alias;
    }

    @JsonProperty("alias")
    public void setAlias(Object alias) {
        this.alias = alias;
    }

    @JsonProperty("aliasType")
    public Object getAliasType() {
        return aliasType;
    }

    @JsonProperty("aliasType")
    public void setAliasType(Object aliasType) {
        this.aliasType = aliasType;
    }

    @JsonProperty("accessProvisioning")
    public String getAccessProvisioning() {
        return accessProvisioning;
    }

    @JsonProperty("accessProvisioning")
    public void setAccessProvisioning(String accessProvisioning) {
        this.accessProvisioning = accessProvisioning;
    }

    @JsonProperty("accessAdminPreferredId")
    public Object getAccessAdminPreferredId() {
        return accessAdminPreferredId;
    }

    @JsonProperty("accessAdminPreferredId")
    public void setAccessAdminPreferredId(Object accessAdminPreferredId) {
        this.accessAdminPreferredId = accessAdminPreferredId;
    }

    @JsonProperty("accessAdminName")
    public Object getAccessAdminName() {
        return accessAdminName;
    }

    @JsonProperty("accessAdminName")
    public void setAccessAdminName(Object accessAdminName) {
        this.accessAdminName = accessAdminName;
    }

    @JsonProperty("inherentRiskRating")
    public String getInherentRiskRating() {
        return inherentRiskRating;
    }

    @JsonProperty("inherentRiskRating")
    public void setInherentRiskRating(String inherentRiskRating) {
        this.inherentRiskRating = inherentRiskRating;
    }

    @JsonProperty("inherentRiskScore")
    public String getInherentRiskScore() {
        return inherentRiskScore;
    }

    @JsonProperty("inherentRiskScore")
    public void setInherentRiskScore(String inherentRiskScore) {
        this.inherentRiskScore = inherentRiskScore;
    }

    @JsonProperty("informationClassification")
    public String getInformationClassification() {
        return informationClassification;
    }

    @JsonProperty("informationClassification")
    public void setInformationClassification(String informationClassification) {
        this.informationClassification = informationClassification;
    }

    @JsonProperty("personal")
    public String getPersonal() {
        return personal;
    }

    @JsonProperty("personal")
    public void setPersonal(String personal) {
        this.personal = personal;
    }

    @JsonProperty("confidential")
    public String getConfidential() {
        return confidential;
    }

    @JsonProperty("confidential")
    public void setConfidential(String confidential) {
        this.confidential = confidential;
    }

    @JsonProperty("personalInformationClass")
    public String getPersonalInformationClass() {
        return personalInformationClass;
    }

    @JsonProperty("personalInformationClass")
    public void setPersonalInformationClass(String personalInformationClass) {
        this.personalInformationClass = personalInformationClass;
    }

    @JsonProperty("officialRecords")
    public String getOfficialRecords() {
        return officialRecords;
    }

    @JsonProperty("officialRecords")
    public void setOfficialRecords(String officialRecords) {
        this.officialRecords = officialRecords;
    }

    @JsonProperty("retentionCapabilities")
    public String getRetentionCapabilities() {
        return retentionCapabilities;
    }

    @JsonProperty("retentionCapabilities")
    public void setRetentionCapabilities(String retentionCapabilities) {
        this.retentionCapabilities = retentionCapabilities;
    }

    @JsonProperty("purgingCapabilities")
    public String getPurgingCapabilities() {
        return purgingCapabilities;
    }

    @JsonProperty("purgingCapabilities")
    public void setPurgingCapabilities(String purgingCapabilities) {
        this.purgingCapabilities = purgingCapabilities;
    }

    @JsonProperty("externalAccess")
    public String getExternalAccess() {
        return externalAccess;
    }

    @JsonProperty("externalAccess")
    public void setExternalAccess(String externalAccess) {
        this.externalAccess = externalAccess;
    }

    @JsonProperty("accessibility")
    public String getAccessibility() {
        return accessibility;
    }

    @JsonProperty("accessibility")
    public void setAccessibility(String accessibility) {
        this.accessibility = accessibility;
    }

    @JsonProperty("aiML")
    public String getAiML() {
        return aiML;
    }

    @JsonProperty("aiML")
    public void setAiML(String aiML) {
        this.aiML = aiML;
    }

    @JsonProperty("encryption")
    public String getEncryption() {
        return encryption;
    }

    @JsonProperty("encryption")
    public void setEncryption(String encryption) {
        this.encryption = encryption;
    }

    @JsonProperty("finra")
    public String getFinra() {
        return finra;
    }

    @JsonProperty("finra")
    public void setFinra(String finra) {
        this.finra = finra;
    }

    @JsonProperty("fisma")
    public String getFisma() {
        return fisma;
    }

    @JsonProperty("fisma")
    public void setFisma(String fisma) {
        this.fisma = fisma;
    }

    @JsonProperty("moneyMovement")
    public String getMoneyMovement() {
        return moneyMovement;
    }

    @JsonProperty("moneyMovement")
    public void setMoneyMovement(String moneyMovement) {
        this.moneyMovement = moneyMovement;
    }

    @JsonProperty("pci")
    public String getPci() {
        return pci;
    }

    @JsonProperty("pci")
    public void setPci(String pci) {
        this.pci = pci;
    }

    @JsonProperty("pciAssessed")
    public String getPciAssessed() {
        return pciAssessed;
    }

    @JsonProperty("pciAssessed")
    public void setPciAssessed(String pciAssessed) {
        this.pciAssessed = pciAssessed;
    }

    @JsonProperty("pciII")
    public String getPciII() {
        return pciII;
    }

    @JsonProperty("pciII")
    public void setPciII(String pciII) {
        this.pciII = pciII;
    }

    @JsonProperty("psd2")
    public String getPsd2() {
        return psd2;
    }

    @JsonProperty("psd2")
    public void setPsd2(String psd2) {
        this.psd2 = psd2;
    }

    @JsonProperty("socSoxAssessed")
    public String getSocSoxAssessed() {
        return socSoxAssessed;
    }

    @JsonProperty("socSoxAssessed")
    public void setSocSoxAssessed(String socSoxAssessed) {
        this.socSoxAssessed = socSoxAssessed;
    }

    @JsonProperty("soc1")
    public String getSoc1() {
        return soc1;
    }

    @JsonProperty("soc1")
    public void setSoc1(String soc1) {
        this.soc1 = soc1;
    }

    @JsonProperty("soc2")
    public String getSoc2() {
        return soc2;
    }

    @JsonProperty("soc2")
    public void setSoc2(String soc2) {
        this.soc2 = soc2;
    }

    @JsonProperty("soxSftl")
    public String getSoxSftl() {
        return soxSftl;
    }

    @JsonProperty("soxSftl")
    public void setSoxSftl(String soxSftl) {
        this.soxSftl = soxSftl;
    }

    @JsonProperty("ads")
    public String getAds() {
        return ads;
    }

    @JsonProperty("ads")
    public void setAds(String ads) {
        this.ads = ads;
    }

    @JsonProperty("basel")
    public String getBasel() {
        return basel;
    }

    @JsonProperty("basel")
    public void setBasel(String basel) {
        this.basel = basel;
    }

    @JsonProperty("settlementApplicable")
    public String getSettlementApplicable() {
        return settlementApplicable;
    }

    @JsonProperty("settlementApplicable")
    public void setSettlementApplicable(String settlementApplicable) {
        this.settlementApplicable = settlementApplicable;
    }

    @JsonProperty("inboundDependency")
    public String getInboundDependency() {
        return inboundDependency;
    }

    @JsonProperty("inboundDependency")
    public void setInboundDependency(String inboundDependency) {
        this.inboundDependency = inboundDependency;
    }

    @JsonProperty("toRiskOversightPreferredId")
    public String getToRiskOversightPreferredId() {
        return toRiskOversightPreferredId;
    }

    @JsonProperty("toRiskOversightPreferredId")
    public void setToRiskOversightPreferredId(String toRiskOversightPreferredId) {
        this.toRiskOversightPreferredId = toRiskOversightPreferredId;
    }

    @JsonProperty("toRiskOversightName")
    public String getToRiskOversightName() {
        return toRiskOversightName;
    }

    @JsonProperty("toRiskOversightName")
    public void setToRiskOversightName(String toRiskOversightName) {
        this.toRiskOversightName = toRiskOversightName;
    }

    @JsonProperty("toBusinessLine")
    public String getToBusinessLine() {
        return toBusinessLine;
    }

    @JsonProperty("toBusinessLine")
    public void setToBusinessLine(String toBusinessLine) {
        this.toBusinessLine = toBusinessLine;
    }

    @JsonProperty("toBusinessLineDesc")
    public String getToBusinessLineDesc() {
        return toBusinessLineDesc;
    }

    @JsonProperty("toBusinessLineDesc")
    public void setToBusinessLineDesc(String toBusinessLineDesc) {
        this.toBusinessLineDesc = toBusinessLineDesc;
    }

    @JsonProperty("pbloRiskOversightPreferredId")
    public String getPbloRiskOversightPreferredId() {
        return pbloRiskOversightPreferredId;
    }

    @JsonProperty("pbloRiskOversightPreferredId")
    public void setPbloRiskOversightPreferredId(String pbloRiskOversightPreferredId) {
        this.pbloRiskOversightPreferredId = pbloRiskOversightPreferredId;
    }

    @JsonProperty("pbloRiskOversightName")
    public String getPbloRiskOversightName() {
        return pbloRiskOversightName;
    }

    @JsonProperty("pbloRiskOversightName")
    public void setPbloRiskOversightName(String pbloRiskOversightName) {
        this.pbloRiskOversightName = pbloRiskOversightName;
    }

    @JsonProperty("pbloBusinessLine")
    public String getPbloBusinessLine() {
        return pbloBusinessLine;
    }

    @JsonProperty("pbloBusinessLine")
    public void setPbloBusinessLine(String pbloBusinessLine) {
        this.pbloBusinessLine = pbloBusinessLine;
    }

    @JsonProperty("pbloBusinessLineDesc")
    public String getPbloBusinessLineDesc() {
        return pbloBusinessLineDesc;
    }

    @JsonProperty("pbloBusinessLineDesc")
    public void setPbloBusinessLineDesc(String pbloBusinessLineDesc) {
        this.pbloBusinessLineDesc = pbloBusinessLineDesc;
    }

    @JsonProperty("softwareCertificationRequirement")
    public String getSoftwareCertificationRequirement() {
        return softwareCertificationRequirement;
    }

    @JsonProperty("softwareCertificationRequirement")
    public void setSoftwareCertificationRequirement(String softwareCertificationRequirement) {
        this.softwareCertificationRequirement = softwareCertificationRequirement;
    }

    @JsonProperty("toPreferredId")
    public String getToPreferredId() {
        return toPreferredId;
    }

    @JsonProperty("toPreferredId")
    public void setToPreferredId(String toPreferredId) {
        this.toPreferredId = toPreferredId;
    }

    @JsonProperty("toName")
    public String getToName() {
        return toName;
    }

    @JsonProperty("toName")
    public void setToName(String toName) {
        this.toName = toName;
    }

    @JsonProperty("toEmail")
    public String getToEmail() {
        return toEmail;
    }

    @JsonProperty("toEmail")
    public void setToEmail(String toEmail) {
        this.toEmail = toEmail;
    }

    @JsonProperty("toCostCenter")
    public String getToCostCenter() {
        return toCostCenter;
    }

    @JsonProperty("toCostCenter")
    public void setToCostCenter(String toCostCenter) {
        this.toCostCenter = toCostCenter;
    }

    @JsonProperty("toCcDescription")
    public String getToCcDescription() {
        return toCcDescription;
    }

    @JsonProperty("toCcDescription")
    public void setToCcDescription(String toCcDescription) {
        this.toCcDescription = toCcDescription;
    }

    @JsonProperty("toAssignedDate")
    public String getToAssignedDate() {
        return toAssignedDate;
    }

    @JsonProperty("toAssignedDate")
    public void setToAssignedDate(String toAssignedDate) {
        this.toAssignedDate = toAssignedDate;
    }

    @JsonProperty("toCurrentQtrCertificationStatus")
    public String getToCurrentQtrCertificationStatus() {
        return toCurrentQtrCertificationStatus;
    }

    @JsonProperty("toCurrentQtrCertificationStatus")
    public void setToCurrentQtrCertificationStatus(String toCurrentQtrCertificationStatus) {
        this.toCurrentQtrCertificationStatus = toCurrentQtrCertificationStatus;
    }

    @JsonProperty("toCertificationDate")
    public String getToCertificationDate() {
        return toCertificationDate;
    }

    @JsonProperty("toCertificationDate")
    public void setToCertificationDate(String toCertificationDate) {
        this.toCertificationDate = toCertificationDate;
    }

    @JsonProperty("toManagerPreferredId")
    public String getToManagerPreferredId() {
        return toManagerPreferredId;
    }

    @JsonProperty("toManagerPreferredId")
    public void setToManagerPreferredId(String toManagerPreferredId) {
        this.toManagerPreferredId = toManagerPreferredId;
    }

    @JsonProperty("toManagerName")
    public String getToManagerName() {
        return toManagerName;
    }

    @JsonProperty("toManagerName")
    public void setToManagerName(String toManagerName) {
        this.toManagerName = toManagerName;
    }

    @JsonProperty("toManagersManagerPreferredId")
    public String getToManagersManagerPreferredId() {
        return toManagersManagerPreferredId;
    }

    @JsonProperty("toManagersManagerPreferredId")
    public void setToManagersManagerPreferredId(String toManagersManagerPreferredId) {
        this.toManagersManagerPreferredId = toManagersManagerPreferredId;
    }

    @JsonProperty("toManagersManagerName")
    public String getToManagersManagerName() {
        return toManagersManagerName;
    }

    @JsonProperty("toManagersManagerName")
    public void setToManagersManagerName(String toManagersManagerName) {
        this.toManagersManagerName = toManagersManagerName;
    }

    @JsonProperty("toLevel5MgrPreferredId")
    public String getToLevel5MgrPreferredId() {
        return toLevel5MgrPreferredId;
    }

    @JsonProperty("toLevel5MgrPreferredId")
    public void setToLevel5MgrPreferredId(String toLevel5MgrPreferredId) {
        this.toLevel5MgrPreferredId = toLevel5MgrPreferredId;
    }

    @JsonProperty("toLevel5MgrName")
    public String getToLevel5MgrName() {
        return toLevel5MgrName;
    }

    @JsonProperty("toLevel5MgrName")
    public void setToLevel5MgrName(String toLevel5MgrName) {
        this.toLevel5MgrName = toLevel5MgrName;
    }

    @JsonProperty("toLevel4MgrPreferredId")
    public String getToLevel4MgrPreferredId() {
        return toLevel4MgrPreferredId;
    }

    @JsonProperty("toLevel4MgrPreferredId")
    public void setToLevel4MgrPreferredId(String toLevel4MgrPreferredId) {
        this.toLevel4MgrPreferredId = toLevel4MgrPreferredId;
    }

    @JsonProperty("toLevel4MgrName")
    public String getToLevel4MgrName() {
        return toLevel4MgrName;
    }

    @JsonProperty("toLevel4MgrName")
    public void setToLevel4MgrName(String toLevel4MgrName) {
        this.toLevel4MgrName = toLevel4MgrName;
    }

    @JsonProperty("toLevel3MgrPreferredId")
    public String getToLevel3MgrPreferredId() {
        return toLevel3MgrPreferredId;
    }

    @JsonProperty("toLevel3MgrPreferredId")
    public void setToLevel3MgrPreferredId(String toLevel3MgrPreferredId) {
        this.toLevel3MgrPreferredId = toLevel3MgrPreferredId;
    }

    @JsonProperty("toLevel3MgrName")
    public String getToLevel3MgrName() {
        return toLevel3MgrName;
    }

    @JsonProperty("toLevel3MgrName")
    public void setToLevel3MgrName(String toLevel3MgrName) {
        this.toLevel3MgrName = toLevel3MgrName;
    }

    @JsonProperty("toLevel2MgrPreferredId")
    public String getToLevel2MgrPreferredId() {
        return toLevel2MgrPreferredId;
    }

    @JsonProperty("toLevel2MgrPreferredId")
    public void setToLevel2MgrPreferredId(String toLevel2MgrPreferredId) {
        this.toLevel2MgrPreferredId = toLevel2MgrPreferredId;
    }

    @JsonProperty("toLevel2MgrName")
    public String getToLevel2MgrName() {
        return toLevel2MgrName;
    }

    @JsonProperty("toLevel2MgrName")
    public void setToLevel2MgrName(String toLevel2MgrName) {
        this.toLevel2MgrName = toLevel2MgrName;
    }

    @JsonProperty("pbloPreferredId")
    public String getPbloPreferredId() {
        return pbloPreferredId;
    }

    @JsonProperty("pbloPreferredId")
    public void setPbloPreferredId(String pbloPreferredId) {
        this.pbloPreferredId = pbloPreferredId;
    }

    @JsonProperty("pbloName")
    public String getPbloName() {
        return pbloName;
    }

    @JsonProperty("pbloName")
    public void setPbloName(String pbloName) {
        this.pbloName = pbloName;
    }

    @JsonProperty("pbloEmail")
    public String getPbloEmail() {
        return pbloEmail;
    }

    @JsonProperty("pbloEmail")
    public void setPbloEmail(String pbloEmail) {
        this.pbloEmail = pbloEmail;
    }

    @JsonProperty("pbloCostCenter")
    public String getPbloCostCenter() {
        return pbloCostCenter;
    }

    @JsonProperty("pbloCostCenter")
    public void setPbloCostCenter(String pbloCostCenter) {
        this.pbloCostCenter = pbloCostCenter;
    }

    @JsonProperty("pbloCcDescription")
    public String getPbloCcDescription() {
        return pbloCcDescription;
    }

    @JsonProperty("pbloCcDescription")
    public void setPbloCcDescription(String pbloCcDescription) {
        this.pbloCcDescription = pbloCcDescription;
    }

    @JsonProperty("pbloAssignedDate")
    public String getPbloAssignedDate() {
        return pbloAssignedDate;
    }

    @JsonProperty("pbloAssignedDate")
    public void setPbloAssignedDate(String pbloAssignedDate) {
        this.pbloAssignedDate = pbloAssignedDate;
    }

    @JsonProperty("pbloCurrentQtrCertificationStatus")
    public String getPbloCurrentQtrCertificationStatus() {
        return pbloCurrentQtrCertificationStatus;
    }

    @JsonProperty("pbloCurrentQtrCertificationStatus")
    public void setPbloCurrentQtrCertificationStatus(String pbloCurrentQtrCertificationStatus) {
        this.pbloCurrentQtrCertificationStatus = pbloCurrentQtrCertificationStatus;
    }

    @JsonProperty("pbloCertificationDate")
    public String getPbloCertificationDate() {
        return pbloCertificationDate;
    }

    @JsonProperty("pbloCertificationDate")
    public void setPbloCertificationDate(String pbloCertificationDate) {
        this.pbloCertificationDate = pbloCertificationDate;
    }

    @JsonProperty("pbloManagerPreferredId")
    public String getPbloManagerPreferredId() {
        return pbloManagerPreferredId;
    }

    @JsonProperty("pbloManagerPreferredId")
    public void setPbloManagerPreferredId(String pbloManagerPreferredId) {
        this.pbloManagerPreferredId = pbloManagerPreferredId;
    }

    @JsonProperty("pbloManagerName")
    public String getPbloManagerName() {
        return pbloManagerName;
    }

    @JsonProperty("pbloManagerName")
    public void setPbloManagerName(String pbloManagerName) {
        this.pbloManagerName = pbloManagerName;
    }

    @JsonProperty("pbloManagersManagerPreferredId")
    public String getPbloManagersManagerPreferredId() {
        return pbloManagersManagerPreferredId;
    }

    @JsonProperty("pbloManagersManagerPreferredId")
    public void setPbloManagersManagerPreferredId(String pbloManagersManagerPreferredId) {
        this.pbloManagersManagerPreferredId = pbloManagersManagerPreferredId;
    }

    @JsonProperty("pbloManagersManagerName")
    public String getPbloManagersManagerName() {
        return pbloManagersManagerName;
    }

    @JsonProperty("pbloManagersManagerName")
    public void setPbloManagersManagerName(String pbloManagersManagerName) {
        this.pbloManagersManagerName = pbloManagersManagerName;
    }

    @JsonProperty("pbloLevel5MgrPreferredId")
    public String getPbloLevel5MgrPreferredId() {
        return pbloLevel5MgrPreferredId;
    }

    @JsonProperty("pbloLevel5MgrPreferredId")
    public void setPbloLevel5MgrPreferredId(String pbloLevel5MgrPreferredId) {
        this.pbloLevel5MgrPreferredId = pbloLevel5MgrPreferredId;
    }

    @JsonProperty("pbloLevel5MgrName")
    public String getPbloLevel5MgrName() {
        return pbloLevel5MgrName;
    }

    @JsonProperty("pbloLevel5MgrName")
    public void setPbloLevel5MgrName(String pbloLevel5MgrName) {
        this.pbloLevel5MgrName = pbloLevel5MgrName;
    }

    @JsonProperty("pbloLevel4MgrPreferredId")
    public String getPbloLevel4MgrPreferredId() {
        return pbloLevel4MgrPreferredId;
    }

    @JsonProperty("pbloLevel4MgrPreferredId")
    public void setPbloLevel4MgrPreferredId(String pbloLevel4MgrPreferredId) {
        this.pbloLevel4MgrPreferredId = pbloLevel4MgrPreferredId;
    }

    @JsonProperty("pbloLevel4MgrName")
    public String getPbloLevel4MgrName() {
        return pbloLevel4MgrName;
    }

    @JsonProperty("pbloLevel4MgrName")
    public void setPbloLevel4MgrName(String pbloLevel4MgrName) {
        this.pbloLevel4MgrName = pbloLevel4MgrName;
    }

    @JsonProperty("pbloLevel3MgrPreferredId")
    public String getPbloLevel3MgrPreferredId() {
        return pbloLevel3MgrPreferredId;
    }

    @JsonProperty("pbloLevel3MgrPreferredId")
    public void setPbloLevel3MgrPreferredId(String pbloLevel3MgrPreferredId) {
        this.pbloLevel3MgrPreferredId = pbloLevel3MgrPreferredId;
    }

    @JsonProperty("pbloLevel3MgrName")
    public String getPbloLevel3MgrName() {
        return pbloLevel3MgrName;
    }

    @JsonProperty("pbloLevel3MgrName")
    public void setPbloLevel3MgrName(String pbloLevel3MgrName) {
        this.pbloLevel3MgrName = pbloLevel3MgrName;
    }

    @JsonProperty("pbloLevel2MgrPreferredId")
    public String getPbloLevel2MgrPreferredId() {
        return pbloLevel2MgrPreferredId;
    }

    @JsonProperty("pbloLevel2MgrPreferredId")
    public void setPbloLevel2MgrPreferredId(String pbloLevel2MgrPreferredId) {
        this.pbloLevel2MgrPreferredId = pbloLevel2MgrPreferredId;
    }

    @JsonProperty("pbloLevel2MgrName")
    public String getPbloLevel2MgrName() {
        return pbloLevel2MgrName;
    }

    @JsonProperty("pbloLevel2MgrName")
    public void setPbloLevel2MgrName(String pbloLevel2MgrName) {
        this.pbloLevel2MgrName = pbloLevel2MgrName;
    }

    @JsonProperty("sbloPreferredId")
    public String getSbloPreferredId() {
        return sbloPreferredId;
    }

    @JsonProperty("sbloPreferredId")
    public void setSbloPreferredId(String sbloPreferredId) {
        this.sbloPreferredId = sbloPreferredId;
    }

    @JsonProperty("sbloEmail")
    public String getSbloEmail() {
        return sbloEmail;
    }

    @JsonProperty("sbloEmail")
    public void setSbloEmail(String sbloEmail) {
        this.sbloEmail = sbloEmail;
    }

    @JsonProperty("sbloCertificationDate")
    public String getSbloCertificationDate() {
        return sbloCertificationDate;
    }

    @JsonProperty("sbloCertificationDate")
    public void setSbloCertificationDate(String sbloCertificationDate) {
        this.sbloCertificationDate = sbloCertificationDate;
    }

    @JsonProperty("remediationOwnerPreferredId")
    public Object getRemediationOwnerPreferredId() {
        return remediationOwnerPreferredId;
    }

    @JsonProperty("remediationOwnerPreferredId")
    public void setRemediationOwnerPreferredId(Object remediationOwnerPreferredId) {
        this.remediationOwnerPreferredId = remediationOwnerPreferredId;
    }

    @JsonProperty("remediationOwnerName")
    public Object getRemediationOwnerName() {
        return remediationOwnerName;
    }

    @JsonProperty("remediationOwnerName")
    public void setRemediationOwnerName(Object remediationOwnerName) {
        this.remediationOwnerName = remediationOwnerName;
    }

    @JsonProperty("remediationOwnerEmail")
    public Object getRemediationOwnerEmail() {
        return remediationOwnerEmail;
    }

    @JsonProperty("remediationOwnerEmail")
    public void setRemediationOwnerEmail(Object remediationOwnerEmail) {
        this.remediationOwnerEmail = remediationOwnerEmail;
    }

    @JsonProperty("ascPreferredId")
    public Object getAscPreferredId() {
        return ascPreferredId;
    }

    @JsonProperty("ascPreferredId")
    public void setAscPreferredId(Object ascPreferredId) {
        this.ascPreferredId = ascPreferredId;
    }

    @JsonProperty("ascName")
    public Object getAscName() {
        return ascName;
    }

    @JsonProperty("ascName")
    public void setAscName(Object ascName) {
        this.ascName = ascName;
    }

    @JsonProperty("ascEmail")
    public Object getAscEmail() {
        return ascEmail;
    }

    @JsonProperty("ascEmail")
    public void setAscEmail(Object ascEmail) {
        this.ascEmail = ascEmail;
    }

    @JsonProperty("reliabilityEngineeringLeadPreferredID")
    public Object getReliabilityEngineeringLeadPreferredID() {
        return reliabilityEngineeringLeadPreferredID;
    }

    @JsonProperty("reliabilityEngineeringLeadPreferredID")
    public void setReliabilityEngineeringLeadPreferredID(Object reliabilityEngineeringLeadPreferredID) {
        this.reliabilityEngineeringLeadPreferredID = reliabilityEngineeringLeadPreferredID;
    }

    @JsonProperty("reliabilityEngineeringLeadName")
    public Object getReliabilityEngineeringLeadName() {
        return reliabilityEngineeringLeadName;
    }

    @JsonProperty("reliabilityEngineeringLeadName")
    public void setReliabilityEngineeringLeadName(Object reliabilityEngineeringLeadName) {
        this.reliabilityEngineeringLeadName = reliabilityEngineeringLeadName;
    }

    @JsonProperty("reliabilityEngineeringLeadEmail")
    public Object getReliabilityEngineeringLeadEmail() {
        return reliabilityEngineeringLeadEmail;
    }

    @JsonProperty("reliabilityEngineeringLeadEmail")
    public void setReliabilityEngineeringLeadEmail(Object reliabilityEngineeringLeadEmail) {
        this.reliabilityEngineeringLeadEmail = reliabilityEngineeringLeadEmail;
    }

    @JsonProperty("recordCreationDate")
    public String getRecordCreationDate() {
        return recordCreationDate;
    }

    @JsonProperty("recordCreationDate")
    public void setRecordCreationDate(String recordCreationDate) {
        this.recordCreationDate = recordCreationDate;
    }

    @JsonProperty("recordLastChangedDate")
    public String getRecordLastChangedDate() {
        return recordLastChangedDate;
    }

    @JsonProperty("recordLastChangedDate")
    public void setRecordLastChangedDate(String recordLastChangedDate) {
        this.recordLastChangedDate = recordLastChangedDate;
    }

    @JsonProperty("recordLastChangedByPreferredId")
    public String getRecordLastChangedByPreferredId() {
        return recordLastChangedByPreferredId;
    }

    @JsonProperty("recordLastChangedByPreferredId")
    public void setRecordLastChangedByPreferredId(String recordLastChangedByPreferredId) {
        this.recordLastChangedByPreferredId = recordLastChangedByPreferredId;
    }

    @JsonProperty("recordLastChangedByName")
    public Object getRecordLastChangedByName() {
        return recordLastChangedByName;
    }

    @JsonProperty("recordLastChangedByName")
    public void setRecordLastChangedByName(Object recordLastChangedByName) {
        this.recordLastChangedByName = recordLastChangedByName;
    }

    @JsonProperty("assigneeGroupLevel2Support")
    public String getAssigneeGroupLevel2Support() {
        return assigneeGroupLevel2Support;
    }

    @JsonProperty("assigneeGroupLevel2Support")
    public void setAssigneeGroupLevel2Support(String assigneeGroupLevel2Support) {
        this.assigneeGroupLevel2Support = assigneeGroupLevel2Support;
    }

    @JsonProperty("assigneeGroupLevel3Support")
    public String getAssigneeGroupLevel3Support() {
        return assigneeGroupLevel3Support;
    }

    @JsonProperty("assigneeGroupLevel3Support")
    public void setAssigneeGroupLevel3Support(String assigneeGroupLevel3Support) {
        this.assigneeGroupLevel3Support = assigneeGroupLevel3Support;
    }

    @JsonProperty("inboundDependencies")
    public Object getInboundDependencies() {
        return inboundDependencies;
    }

    @JsonProperty("inboundDependencies")
    public void setInboundDependencies(Object inboundDependencies) {
        this.inboundDependencies = inboundDependencies;
    }

    @JsonProperty("outboundDependencies")
    public Object getOutboundDependencies() {
        return outboundDependencies;
    }

    @JsonProperty("outboundDependencies")
    public void setOutboundDependencies(Object outboundDependencies) {
        this.outboundDependencies = outboundDependencies;
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

}
