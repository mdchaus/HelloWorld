package com.usbank.cme.utils;

import com.usbank.cme.dto.BomMetadata;
import com.usbank.cme.dto.VM;
import com.usbank.cme.dto.VMType;
import org.apache.poi.ss.util.CellRangeAddress;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import java.util.HashMap;

public class VMUtils {

    public static void createVMSheet(BomMetadata metadata, XSSFWorkbook workbook) {
        HashMap<Integer, Object[]> linuxData = new HashMap<Integer, Object[]>();
        HashMap<Integer, Object[]> winData = new HashMap<Integer, Object[]>();
        XSSFSheet linuxSheet = null;
        XSSFSheet winSheet = null;
        int count = 2;
        for (VM vm : metadata.getVms()) {
            if(vm.getType().equals(VMType.Linux)) {
                linuxSheet = workbook.getSheet("VM-Linux");


                if (linuxSheet == null) {
                    linuxSheet = workbook.createSheet("VM-" + vm.getType().name());
                    ExcelUtils.changeColumnWidth(linuxSheet, 30);
                    linuxSheet.addMergedRegion(CellRangeAddress.valueOf("C1:H1"));
                    ExcelUtils.createHeaderData(linuxData);
                }
                if (vm.getEnv().name().equals("DEV")) {
                    for (int i = 1; i <= vm.getCount(); i++) {
                        linuxData.put(++count, new Object[]{"Development", "Create", "Compute", "Virtual Machines", "Virtual Machines " + vm.getFamily(), vm.getSku().replaceAll("Standard_", "").replace("_", " "), vm.getSku(), 240 });
                        linuxData.put(++count, new Object[]{"Development", "Create", "Networking", "Bandwidth", "Bandwidth Inter-Region", "Inter Continent Data Transfer Out - NAM or EU To Any", "Inter Continent", 5});
                        linuxData.put(++count, new Object[]{""});
                    }
                }

                if (vm.getEnv().name().equals("IT")) {
                    for (int i = 1; i <= vm.getCount(); i++) {
                        linuxData.put(++count, new Object[]{"IT", "Create", "Compute", "Virtual Machines","Virtual Machines " + vm.getFamily(), vm.getSku().replaceAll("Standard_", "").replace("_", " "), vm.getSku(), 240});
                        linuxData.put(++count, new Object[]{"IT", "Create", "Networking", "Bandwidth", "Bandwidth Inter-Region", "Inter Continent Data Transfer Out - NAM or EU To Any", "Inter Continent", 5});
                        linuxData.put(++count, new Object[]{""});
                    }
                }


                if (vm.getEnv().name().equals("UATPRIMARY")) {
                    for (int i = 1; i <= vm.getCount(); i++) {
                        linuxData.put(++count, new Object[]{"UAT-Primary", "Create", "Compute", "Virtual Machines", "Virtual Machines " + vm.getFamily(), vm.getSku().replaceAll("Standard_", "").replace("_", " "), vm.getSku(), 240});
                        linuxData.put(++count, new Object[]{"UAT-Primary", "Create", "Networking", "Bandwidth", "Bandwidth Inter-Region", "Inter Continent Data Transfer Out - NAM or EU To Any", "Inter Continent", 5});
                        linuxData.put(++count, new Object[]{""});
                    }
                }

                if (vm.getEnv().name().equals("PRODPRIMARY")) {
                    for (int i = 1; i <= vm.getCount(); i++) {
                        linuxData.put(++count, new Object[]{"PROD-Primary", "Create", "Compute", "Virtual Machines", "Virtual Machines " + vm.getFamily(), vm.getSku().replaceAll("Standard_", "").replace("_", " "), vm.getSku(), 730});
                        linuxData.put(++count, new Object[]{"PROD-Primary", "Create", "Networking", "Bandwidth", "Bandwidth Inter-Region", "Inter Continent Data Transfer Out - NAM or EU To Any", "Inter Continent", 5});
                        linuxData.put(++count, new Object[]{""});
                    }
                }

                if (vm.getEnv().name().equals("UATSECONDARY")) {
                    for (int i = 1; i <= vm.getCount(); i++) {
                        linuxData.put(++count, new Object[]{"UAT-Secondary", "Create", "Compute", "Virtual Machines", "Virtual Machines " + vm.getFamily(), vm.getSku().replaceAll("Standard_", "").replace("_", " "), vm.getSku(), 240});
                        linuxData.put(++count, new Object[]{"UAT-Secondary", "Create", "Networking", "Bandwidth", "Bandwidth Inter-Region", "Inter Continent Data Transfer Out - NAM or EU To Any", "Inter Continent", 5});
                        linuxData.put(++count, new Object[]{""});
                    }
                }

                if (vm.getEnv().name().equals("PRODSECONDARY")) {
                    for (int i = 1; i <= vm.getCount(); i++) {
                        linuxData.put(++count, new Object[]{"PROD-Secondary", "Create", "Compute", "Virtual Machines", "Virtual Machines " + vm.getFamily(), vm.getSku().replaceAll("Standard_", "").replace("_", " "), vm.getSku(), 730});
                        linuxData.put(++count, new Object[]{"PROD-Secondary", "Create", "Networking", "Bandwidth", "Bandwidth Inter-Region", "Inter Continent Data Transfer Out - NAM or EU To Any", "Inter Continent", 5});
                        linuxData.put(++count, new Object[]{""});
                    }
                }
            }
            else if(vm.getType().equals(VMType.Windows))
            {
                winSheet = workbook.getSheet("VM-Windows");

                if (winSheet == null) {
                    winSheet = workbook.createSheet("VM-Windows");
                    ExcelUtils.changeColumnWidth(winSheet, 30);
                    winSheet.addMergedRegion(CellRangeAddress.valueOf("C1:H1"));
                    ExcelUtils.createHeaderData(winData);
                }
                if (vm.getEnv().name().equals("DEV")) {
                    for (int i = 1; i <= vm.getCount(); i++) {
                        winData.put(++count, new Object[]{"Development", "Create", "Compute", "Virtual Machines", "Virtual Machines " + vm.getFamily(), vm.getSku().replaceAll("Standard_", "").replace("_", " "), vm.getSku(), 240});
                        winData.put(++count, new Object[]{"Development", "Create", "Networking", "Bandwidth", "Bandwidth Inter-Region", "Inter Continent Data Transfer Out - NAM or EU To Any", "Inter Continent", 5});
                        winData.put(++count, new Object[]{""});
                    }
                }

                if (vm.getEnv().name().equals("IT")) {
                    for (int i = 1; i <= vm.getCount(); i++) {
                        winData.put(++count, new Object[]{"IT", "Create", "Compute", "Virtual Machines", "Virtual Machines " + vm.getFamily(), vm.getSku().replaceAll("Standard_", "").replace("_", " "), vm.getSku(), 240});
                        winData.put(++count, new Object[]{"IT", "Create", "Networking", "Bandwidth", "Bandwidth Inter-Region", "Inter Continent Data Transfer Out - NAM or EU To Any", "Inter Continent", 5});
                        winData.put(++count, new Object[]{""});
                    }
                }


                if (vm.getEnv().name().equals("UATPRIMARY")) {
                    for (int i = 1; i <= vm.getCount(); i++) {
                        winData.put(++count, new Object[]{"UAT-Primary", "Create", "Compute", "Virtual Machines", "Virtual Machines " + vm.getFamily(), vm.getSku().replaceAll("Standard_", "").replace("_", " "), vm.getSku(), 240});
                        winData.put(++count, new Object[]{"UAT-Primary", "Create", "Networking", "Bandwidth", "Bandwidth Inter-Region", "Inter Continent Data Transfer Out - NAM or EU To Any", "Inter Continent", 5});
                        winData.put(++count, new Object[]{""});
                    }
                }

                if (vm.getEnv().name().equals("PRODPRIMARY")) {
                    for (int i = 1; i <= vm.getCount(); i++) {
                        winData.put(++count, new Object[]{"PROD-Primary", "Create", "Compute", "Virtual Machines", "Virtual Machines " + vm.getFamily(), vm.getSku().replaceAll("Standard_", "").replace("_", " "), vm.getSku(), 730});
                        winData.put(++count, new Object[]{"PROD-Primary", "Create", "Networking", "Bandwidth", "Bandwidth Inter-Region", "Inter Continent Data Transfer Out - NAM or EU To Any", "Inter Continent", 5});
                        winData.put(++count, new Object[]{""});
                    }
                }

                if (vm.getEnv().name().equals("UATSECONDARY")) {
                    for (int i = 1; i <= vm.getCount(); i++) {
                        winData.put(++count, new Object[]{"UAT-Secondary", "Create", "Compute", "Virtual Machines", "Virtual Machines " + vm.getFamily(), vm.getSku().replaceAll("Standard_", "").replace("_", " "), vm.getSku(), 240});
                        winData.put(++count, new Object[]{"UAT-Secondary", "Create", "Networking", "Bandwidth", "Bandwidth Inter-Region", "Inter Continent Data Transfer Out - NAM or EU To Any", "Inter Continent", 5});
                        winData.put(++count, new Object[]{""});
                    }
                }

                if (vm.getEnv().name().equals("PRODSECONDARY")) {
                    for (int i = 1; i <= vm.getCount(); i++) {
                        winData.put(++count, new Object[]{"PROD-Secondary", "Create", "Compute", "Virtual Machines", "Virtual Machines " + vm.getFamily(), vm.getSku().replaceAll("Standard_", "").replace("_", " "), vm.getSku(), 730});
                        winData.put(++count, new Object[]{"PROD-Secondary", "Create", "Networking", "Bandwidth", "Bandwidth Inter-Region", "Inter Continent Data Transfer Out - NAM or EU To Any", "Inter Continent", 5});
                        winData.put(++count, new Object[]{""});
                    }
                }
            }

        }

        ExcelUtils.putDataIntoCellsSorted(linuxData, linuxSheet);
        ExcelUtils.putDataIntoCellsSorted(winData, winSheet);

    }
}
