
package com.usbank.cme.vm;

import java.util.LinkedHashMap;
import java.util.Map;
import javax.annotation.Generated;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "securityType",
    "uefiSettings"
})
@Generated("jsonschema2pojo")
public class SecurityProfile {

    @JsonProperty("securityType")
    private String securityType;
    @JsonProperty("uefiSettings")
    private UefiSettings uefiSettings;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new LinkedHashMap<String, Object>();

    @JsonProperty("securityType")
    public String getSecurityType() {
        return securityType;
    }

    @JsonProperty("securityType")
    public void setSecurityType(String securityType) {
        this.securityType = securityType;
    }

    @JsonProperty("uefiSettings")
    public UefiSettings getUefiSettings() {
        return uefiSettings;
    }

    @JsonProperty("uefiSettings")
    public void setUefiSettings(UefiSettings uefiSettings) {
        this.uefiSettings = uefiSettings;
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

}
