
package com.usbank.cme.kv;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import javax.annotation.Generated;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "bypass",
    "defaultAction",
    "ipRules",
    "virtualNetworkRules"
})
@Generated("jsonschema2pojo")
public class NetworkAcls {

    @JsonProperty("bypass")
    private String bypass;
    @JsonProperty("defaultAction")
    private String defaultAction;
    @JsonProperty("ipRules")
    private List<IpRule> ipRules;
    @JsonProperty("virtualNetworkRules")
    private List<Object> virtualNetworkRules;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new LinkedHashMap<String, Object>();

    @JsonProperty("bypass")
    public String getBypass() {
        return bypass;
    }

    @JsonProperty("bypass")
    public void setBypass(String bypass) {
        this.bypass = bypass;
    }

    @JsonProperty("defaultAction")
    public String getDefaultAction() {
        return defaultAction;
    }

    @JsonProperty("defaultAction")
    public void setDefaultAction(String defaultAction) {
        this.defaultAction = defaultAction;
    }

    @JsonProperty("ipRules")
    public List<IpRule> getIpRules() {
        return ipRules;
    }

    @JsonProperty("ipRules")
    public void setIpRules(List<IpRule> ipRules) {
        this.ipRules = ipRules;
    }

    @JsonProperty("virtualNetworkRules")
    public List<Object> getVirtualNetworkRules() {
        return virtualNetworkRules;
    }

    @JsonProperty("virtualNetworkRules")
    public void setVirtualNetworkRules(List<Object> virtualNetworkRules) {
        this.virtualNetworkRules = virtualNetworkRules;
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

}
