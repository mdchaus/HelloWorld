
package com.usbank.cme.vm;

import java.util.LinkedHashMap;
import java.util.Map;
import javax.annotation.Generated;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "assessmentMode",
    "enableHotpatching",
    "patchMode"
})
@Generated("jsonschema2pojo")
public class PatchSettings {

    @JsonProperty("assessmentMode")
    private String assessmentMode;
    @JsonProperty("enableHotpatching")
    private Boolean enableHotpatching;
    @JsonProperty("patchMode")
    private String patchMode;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new LinkedHashMap<String, Object>();

    @JsonProperty("assessmentMode")
    public String getAssessmentMode() {
        return assessmentMode;
    }

    @JsonProperty("assessmentMode")
    public void setAssessmentMode(String assessmentMode) {
        this.assessmentMode = assessmentMode;
    }

    @JsonProperty("enableHotpatching")
    public Boolean getEnableHotpatching() {
        return enableHotpatching;
    }

    @JsonProperty("enableHotpatching")
    public void setEnableHotpatching(Boolean enableHotpatching) {
        this.enableHotpatching = enableHotpatching;
    }

    @JsonProperty("patchMode")
    public String getPatchMode() {
        return patchMode;
    }

    @JsonProperty("patchMode")
    public void setPatchMode(String patchMode) {
        this.patchMode = patchMode;
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

}
