package com.usbank.cme.dto;

public enum DBType {

    SQLMI , SQL
}
