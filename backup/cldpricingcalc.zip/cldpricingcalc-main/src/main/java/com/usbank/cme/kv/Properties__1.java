
package com.usbank.cme.kv;

import java.util.LinkedHashMap;
import java.util.Map;
import javax.annotation.Generated;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "privateEndpoint",
    "privateLinkServiceConnectionState",
    "provisioningState"
})
@Generated("jsonschema2pojo")
public class Properties__1 {

    @JsonProperty("privateEndpoint")
    private PrivateEndpoint privateEndpoint;
    @JsonProperty("privateLinkServiceConnectionState")
    private PrivateLinkServiceConnectionState privateLinkServiceConnectionState;
    @JsonProperty("provisioningState")
    private String provisioningState;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new LinkedHashMap<String, Object>();

    @JsonProperty("privateEndpoint")
    public PrivateEndpoint getPrivateEndpoint() {
        return privateEndpoint;
    }

    @JsonProperty("privateEndpoint")
    public void setPrivateEndpoint(PrivateEndpoint privateEndpoint) {
        this.privateEndpoint = privateEndpoint;
    }

    @JsonProperty("privateLinkServiceConnectionState")
    public PrivateLinkServiceConnectionState getPrivateLinkServiceConnectionState() {
        return privateLinkServiceConnectionState;
    }

    @JsonProperty("privateLinkServiceConnectionState")
    public void setPrivateLinkServiceConnectionState(PrivateLinkServiceConnectionState privateLinkServiceConnectionState) {
        this.privateLinkServiceConnectionState = privateLinkServiceConnectionState;
    }

    @JsonProperty("provisioningState")
    public String getProvisioningState() {
        return provisioningState;
    }

    @JsonProperty("provisioningState")
    public void setProvisioningState(String provisioningState) {
        this.provisioningState = provisioningState;
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

}
