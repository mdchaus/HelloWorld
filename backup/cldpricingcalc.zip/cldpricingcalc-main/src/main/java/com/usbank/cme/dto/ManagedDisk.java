package com.usbank.cme.dto;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor

public class ManagedDisk {
    public ManagedDiskType type;
    public int sizeInGB;
    public String sku;
    public String tier;
    public String resiliency;
    public ManagedDisk() {}

}
