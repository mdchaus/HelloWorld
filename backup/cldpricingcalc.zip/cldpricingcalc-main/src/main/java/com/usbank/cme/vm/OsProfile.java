
package com.usbank.cme.vm;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import javax.annotation.Generated;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "adminUsername",
    "allowExtensionOperations",
    "computerName",
    "requireGuestProvisionSignal",
    "secrets",
    "windowsConfiguration"
})
@Generated("jsonschema2pojo")
public class OsProfile {

    @JsonProperty("adminUsername")
    private String adminUsername;
    @JsonProperty("allowExtensionOperations")
    private Boolean allowExtensionOperations;
    @JsonProperty("computerName")
    private String computerName;
    @JsonProperty("requireGuestProvisionSignal")
    private Boolean requireGuestProvisionSignal;
    @JsonProperty("secrets")
    private List<Object> secrets;
    @JsonProperty("windowsConfiguration")
    private WindowsConfiguration windowsConfiguration;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new LinkedHashMap<String, Object>();

    @JsonProperty("adminUsername")
    public String getAdminUsername() {
        return adminUsername;
    }

    @JsonProperty("adminUsername")
    public void setAdminUsername(String adminUsername) {
        this.adminUsername = adminUsername;
    }

    @JsonProperty("allowExtensionOperations")
    public Boolean getAllowExtensionOperations() {
        return allowExtensionOperations;
    }

    @JsonProperty("allowExtensionOperations")
    public void setAllowExtensionOperations(Boolean allowExtensionOperations) {
        this.allowExtensionOperations = allowExtensionOperations;
    }

    @JsonProperty("computerName")
    public String getComputerName() {
        return computerName;
    }

    @JsonProperty("computerName")
    public void setComputerName(String computerName) {
        this.computerName = computerName;
    }

    @JsonProperty("requireGuestProvisionSignal")
    public Boolean getRequireGuestProvisionSignal() {
        return requireGuestProvisionSignal;
    }

    @JsonProperty("requireGuestProvisionSignal")
    public void setRequireGuestProvisionSignal(Boolean requireGuestProvisionSignal) {
        this.requireGuestProvisionSignal = requireGuestProvisionSignal;
    }

    @JsonProperty("secrets")
    public List<Object> getSecrets() {
        return secrets;
    }

    @JsonProperty("secrets")
    public void setSecrets(List<Object> secrets) {
        this.secrets = secrets;
    }

    @JsonProperty("windowsConfiguration")
    public WindowsConfiguration getWindowsConfiguration() {
        return windowsConfiguration;
    }

    @JsonProperty("windowsConfiguration")
    public void setWindowsConfiguration(WindowsConfiguration windowsConfiguration) {
        this.windowsConfiguration = windowsConfiguration;
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

}
