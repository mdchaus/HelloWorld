
package com.usbank.cme.vm;

import java.util.LinkedHashMap;
import java.util.Map;
import javax.annotation.Generated;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "caching",
    "createOption",
    "deleteOption",
    "diskSizeGB",
    "lun",
    "managedDisk",
    "name",
    "toBeDetached",
    "writeAcceleratorEnabled"
})
@Generated("jsonschema2pojo")
public class DataDisk {

    @JsonProperty("caching")
    private String caching;
    @JsonProperty("createOption")
    private String createOption;
    @JsonProperty("deleteOption")
    private String deleteOption;
    @JsonProperty("diskSizeGB")
    private Integer diskSizeGB;
    @JsonProperty("lun")
    private Integer lun;
    @JsonProperty("managedDisk")
    private ManagedDisk managedDisk;
    @JsonProperty("name")
    private String name;
    @JsonProperty("toBeDetached")
    private Boolean toBeDetached;
    @JsonProperty("writeAcceleratorEnabled")
    private Boolean writeAcceleratorEnabled;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new LinkedHashMap<String, Object>();

    @JsonProperty("caching")
    public String getCaching() {
        return caching;
    }

    @JsonProperty("caching")
    public void setCaching(String caching) {
        this.caching = caching;
    }

    @JsonProperty("createOption")
    public String getCreateOption() {
        return createOption;
    }

    @JsonProperty("createOption")
    public void setCreateOption(String createOption) {
        this.createOption = createOption;
    }

    @JsonProperty("deleteOption")
    public String getDeleteOption() {
        return deleteOption;
    }

    @JsonProperty("deleteOption")
    public void setDeleteOption(String deleteOption) {
        this.deleteOption = deleteOption;
    }

    @JsonProperty("diskSizeGB")
    public Integer getDiskSizeGB() {
        return diskSizeGB;
    }

    @JsonProperty("diskSizeGB")
    public void setDiskSizeGB(Integer diskSizeGB) {
        this.diskSizeGB = diskSizeGB;
    }

    @JsonProperty("lun")
    public Integer getLun() {
        return lun;
    }

    @JsonProperty("lun")
    public void setLun(Integer lun) {
        this.lun = lun;
    }

    @JsonProperty("managedDisk")
    public ManagedDisk getManagedDisk() {
        return managedDisk;
    }

    @JsonProperty("managedDisk")
    public void setManagedDisk(ManagedDisk managedDisk) {
        this.managedDisk = managedDisk;
    }

    @JsonProperty("name")
    public String getName() {
        return name;
    }

    @JsonProperty("name")
    public void setName(String name) {
        this.name = name;
    }

    @JsonProperty("toBeDetached")
    public Boolean getToBeDetached() {
        return toBeDetached;
    }

    @JsonProperty("toBeDetached")
    public void setToBeDetached(Boolean toBeDetached) {
        this.toBeDetached = toBeDetached;
    }

    @JsonProperty("writeAcceleratorEnabled")
    public Boolean getWriteAcceleratorEnabled() {
        return writeAcceleratorEnabled;
    }

    @JsonProperty("writeAcceleratorEnabled")
    public void setWriteAcceleratorEnabled(Boolean writeAcceleratorEnabled) {
        this.writeAcceleratorEnabled = writeAcceleratorEnabled;
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

}
