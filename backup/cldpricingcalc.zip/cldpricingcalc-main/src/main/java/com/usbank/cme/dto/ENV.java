package com.usbank.cme.dto;

public enum ENV {
    DEV,
    IT,
    UAT,
    PROD
}
