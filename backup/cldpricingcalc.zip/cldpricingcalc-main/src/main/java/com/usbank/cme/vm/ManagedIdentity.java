
package com.usbank.cme.vm;

import java.util.LinkedHashMap;
import java.util.Map;
import javax.annotation.Generated;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "identifier-name",
    "identifier-value"
})
@Generated("jsonschema2pojo")
public class ManagedIdentity {

    @JsonProperty("identifier-name")
    private String identifierName;
    @JsonProperty("identifier-value")
    private String identifierValue;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new LinkedHashMap<String, Object>();

    @JsonProperty("identifier-name")
    public String getIdentifierName() {
        return identifierName;
    }

    @JsonProperty("identifier-name")
    public void setIdentifierName(String identifierName) {
        this.identifierName = identifierName;
    }

    @JsonProperty("identifier-value")
    public String getIdentifierValue() {
        return identifierValue;
    }

    @JsonProperty("identifier-value")
    public void setIdentifierValue(String identifierValue) {
        this.identifierValue = identifierValue;
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

}
