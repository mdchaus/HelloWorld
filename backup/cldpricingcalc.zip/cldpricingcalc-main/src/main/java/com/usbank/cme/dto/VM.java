package com.usbank.cme.dto;

import lombok.Data;

@Data

public class VM {

    ENV env;
    String sku;
    String family;
    Integer count;
    ManagedDisk osDisk;
    ManagedDisk dataDisk;
    VMMaintenanceType maintenanceType;
    VMType type;
}
