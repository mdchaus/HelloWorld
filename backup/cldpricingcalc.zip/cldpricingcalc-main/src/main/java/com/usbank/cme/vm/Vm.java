
package com.usbank.cme.vm;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import javax.annotation.Generated;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "extendedLocation",
    "id",
    "identity",
    "kind",
    "location",
    "managedBy",
    "name",
    "plan",
    "properties",
    "resourceGroup",
    "resources",
    "sku",
    "tags",
    "type"
})
@Generated("jsonschema2pojo")
public class Vm {

    @JsonProperty("extendedLocation")
    private Object extendedLocation;
    @JsonProperty("id")
    private String id;
    @JsonProperty("identity")
    private Identity identity;
    @JsonProperty("kind")
    private Object kind;
    @JsonProperty("location")
    private String location;
    @JsonProperty("managedBy")
    private Object managedBy;
    @JsonProperty("name")
    private String name;
    @JsonProperty("plan")
    private Object plan;
    @JsonProperty("properties")
    private Properties properties;
    @JsonProperty("resourceGroup")
    private String resourceGroup;
    @JsonProperty("resources")
    private List<Resource> resources;
    @JsonProperty("sku")
    private Object sku;
    @JsonProperty("tags")
    private Tags__1 tags;
    @JsonProperty("type")
    private String type;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new LinkedHashMap<String, Object>();

    @JsonProperty("extendedLocation")
    public Object getExtendedLocation() {
        return extendedLocation;
    }

    @JsonProperty("extendedLocation")
    public void setExtendedLocation(Object extendedLocation) {
        this.extendedLocation = extendedLocation;
    }

    @JsonProperty("id")
    public String getId() {
        return id;
    }

    @JsonProperty("id")
    public void setId(String id) {
        this.id = id;
    }

    @JsonProperty("identity")
    public Identity getIdentity() {
        return identity;
    }

    @JsonProperty("identity")
    public void setIdentity(Identity identity) {
        this.identity = identity;
    }

    @JsonProperty("kind")
    public Object getKind() {
        return kind;
    }

    @JsonProperty("kind")
    public void setKind(Object kind) {
        this.kind = kind;
    }

    @JsonProperty("location")
    public String getLocation() {
        return location;
    }

    @JsonProperty("location")
    public void setLocation(String location) {
        this.location = location;
    }

    @JsonProperty("managedBy")
    public Object getManagedBy() {
        return managedBy;
    }

    @JsonProperty("managedBy")
    public void setManagedBy(Object managedBy) {
        this.managedBy = managedBy;
    }

    @JsonProperty("name")
    public String getName() {
        return name;
    }

    @JsonProperty("name")
    public void setName(String name) {
        this.name = name;
    }

    @JsonProperty("plan")
    public Object getPlan() {
        return plan;
    }

    @JsonProperty("plan")
    public void setPlan(Object plan) {
        this.plan = plan;
    }

    @JsonProperty("properties")
    public Properties getProperties() {
        return properties;
    }

    @JsonProperty("properties")
    public void setProperties(Properties properties) {
        this.properties = properties;
    }

    @JsonProperty("resourceGroup")
    public String getResourceGroup() {
        return resourceGroup;
    }

    @JsonProperty("resourceGroup")
    public void setResourceGroup(String resourceGroup) {
        this.resourceGroup = resourceGroup;
    }

    @JsonProperty("resources")
    public List<Resource> getResources() {
        return resources;
    }

    @JsonProperty("resources")
    public void setResources(List<Resource> resources) {
        this.resources = resources;
    }

    @JsonProperty("sku")
    public Object getSku() {
        return sku;
    }

    @JsonProperty("sku")
    public void setSku(Object sku) {
        this.sku = sku;
    }

    @JsonProperty("tags")
    public Tags__1 getTags() {
        return tags;
    }

    @JsonProperty("tags")
    public void setTags(Tags__1 tags) {
        this.tags = tags;
    }

    @JsonProperty("type")
    public String getType() {
        return type;
    }

    @JsonProperty("type")
    public void setType(String type) {
        this.type = type;
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

}
