package com.usbank.cme.utils;

import com.usbank.cme.dto.BomMetadata;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import java.util.HashMap;
import java.util.Map;

public class UmiUtils {

    public static void createUserManagedIdentitySheet(BomMetadata metadata, XSSFWorkbook workbook) {
        XSSFSheet sheet = workbook.getSheet("Managed Identity");



        HashMap<Integer, Object[]> data = new HashMap<Integer, Object[]>();
        int count = 2;

        for (Map.Entry<String, String> umi : metadata.getUmis().entrySet()) {

            if (sheet == null) {
                sheet = workbook.createSheet("Managed Identity");
                ExcelUtils.changeColumnWidth(sheet, 25);
            }
            data.put(1, new Object[]{""});
            data.put(2, new Object[]{"Environment", "Action", "Service Name", "Resource Group Name", "User Managed Identity Name"});
            data.put(++count, new Object[]{"DEV", "Create", "User Managed Identity",umi.getValue(), umi.getKey()});
            data.put(++count, new Object[]{"IT", "Create", "User Managed Identity", umi.getValue().replace("dev" , "it"), umi.getKey().replace("dev" , "it")});
            data.put(++count, new Object[]{"UAT-Primary", "Create", "User Managed Identity", umi.getValue().replace("dev" , "uat") , umi.getKey().replace("dev" , "uat")});
            data.put(++count, new Object[]{"PROD-Primary", "Create", "User Managed Identity", umi.getValue().replace("dev" , "prod"), umi.getKey().replace("dev" , "prod")});
            if (metadata.getSecondaryRegion() == Boolean.TRUE) {
                data.put(++count, new Object[]{"UAT-Secondary", "Create", "User Managed Identity", umi.getValue().replace("dev" , "uat").replace("cus" , "eus2"), umi.getKey().replace("dev" , "uat").replace("cus" , "eus2")});
                data.put(++count, new Object[]{"PROD-Secondary", "Create", "User Managed Identity", umi.getValue().replace("dev" , "prod").replace("cus" , "eus2"), umi.getKey().replace("dev" , "prod").replace("cus" , "eus2")});
            }
        }

        ExcelUtils.putDataIntoCellsSorted(data, sheet);

    }
}
