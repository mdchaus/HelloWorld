package com.usbank.cme.utils;

import com.usbank.cme.dto.BomMetadata;
import com.usbank.cme.dto.VM;
import org.apache.poi.ss.util.CellRangeAddress;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import java.util.HashMap;

public class VmDiskUtils {

    public static void createVMDiskSheet(BomMetadata metadata, XSSFWorkbook workbook) {
        HashMap<Integer, Object[]> data = new HashMap<Integer, Object[]>();
        XSSFSheet sheet = null;
        int count = 2;
        for (VM vm : metadata.getVms()) {
            sheet = workbook.getSheet("Managed Disk");



        if (sheet == null) {
            sheet = workbook.createSheet("Managed Disk");
            ExcelUtils.changeColumnWidth(sheet, 30);
            sheet.addMergedRegion(CellRangeAddress.valueOf("C1:H1"));
            ExcelUtils.createHeaderDataWithFriendlyCol(data);
        }

        String env = vm.getEnv().name().toUpperCase();
        String envToPrint;
        if (env.equals("DEV"))
            envToPrint = "Development";
        else if (env.equals("IT"))
            envToPrint = "IT";
        else if (env.equals("UATPRIMARY"))
            envToPrint = "UAT-Primary";
        else if (env.equals("UATSECONDARY"))
            envToPrint = "UAT-Primary";
        else if (env.equals("PRODPRIMARY"))
            envToPrint = "UAT-Primary";
        else if (env.equals("PRODSECONDARY"))
            envToPrint = "UAT-Primary";
        else
            envToPrint = env;


        for (int i = 1; i <= vm.getCount(); i++) {
            data.put(++count, new Object[]{envToPrint, "Create", "Storage", "Storage", vm.getOsDisk().getTier() + " Managed Disks", vm.getOsDisk().getSku() + " Disk", vm.getOsDisk().getSku(), 1, vm.getOsDisk().getType().name().toLowerCase()});
            data.put(++count, new Object[]{envToPrint, "Create", "Storage", "Storage", vm.getOsDisk().getTier() + " Managed Disks", vm.getOsDisk().getSku() + " Disk Operations", vm.getOsDisk().getSku(), 10000, "Storage Transactions"});

            if (vm.getDataDisk() != null) {
                data.put(++count, new Object[]{envToPrint, "Create", "Storage", "Storage", vm.getDataDisk().getTier() + " Managed Disks", vm.getDataDisk().getSku() + " Disk", vm.getDataDisk().getSku(), 1, vm.getDataDisk().getType().name().toLowerCase()});
                data.put(++count, new Object[]{envToPrint, "Create", "Storage", "Storage", vm.getDataDisk().getTier() + " Managed Disks", vm.getDataDisk().getSku() + " Disk Operations", vm.getDataDisk().getSku(), 10000, "Storage Transactions"});
            }
            data.put(++count, new Object[]{""});
          }
        }

        ExcelUtils.putDataIntoCellsSorted(data, sheet);

    }
}
