package com.usbank.cme.utils;

import com.usbank.cme.dto.BomMetadata;
import com.usbank.cme.dto.Storage;
import com.usbank.cme.dto.StorageType;
import org.apache.poi.ss.util.CellRangeAddress;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import java.util.HashMap;

public class StorageUtils {

    public static void createStorageSheet(BomMetadata metadata, XSSFWorkbook workbook) {
        HashMap<Integer, Object[]> data = new HashMap<Integer, Object[]>();
        XSSFSheet sheet = null;
        int count = 2;
        for (Storage storage : metadata.getStorages()) {
            sheet = workbook.getSheet("SA-Fileshare Blob Table Queue");
            if (sheet == null) {
                sheet = workbook.createSheet("SA-Fileshare Blob Table Queue");
                sheet.addMergedRegion(CellRangeAddress.valueOf("C1:H1"));
                ExcelUtils.changeColumnWidth(sheet, 30);
                ExcelUtils.createHeaderData(data);
            }
            String productName = storage.getStorageType().equals(StorageType.Blob) ? "General Block Blob v2" : "Files v2";
            if (storage.getEnv().name().equals("DEV")) {
                for (int i = 1; i <= storage.getCount(); i++) {
                    data.put(++count, new Object[]{"Development", "Create", "Storage", "Storage", productName,"Hot LRS Data Stored", "Hot LRS", storage.getSizeInGB()});
                }
            }

            if (storage.getEnv().name().equals("IT")) {
                for (int i = 1; i <= storage.getCount(); i++) {
                    data.put(++count, new Object[]{"IT", "Create", "Storage", "Storage", productName, "Hot LRS Data Stored", "Hot LRS", storage.getSizeInGB()});
                }
            }

            if (storage.getEnv().name().equals("UATPRIMARY")) {
                for (int i = 1; i <= storage.getCount(); i++) {
                    data.put(++count, new Object[]{"UAT-Primary", "Create", "Storage", "Storage", productName, "Hot LRS Data Stored", "Hot LRS", storage.getSizeInGB()});
                }
            }

            if (storage.getEnv().name().equals("PRODPRIMARY")) {
                for (int i = 1; i <= storage.getCount(); i++) {
                    data.put(++count, new Object[]{"PROD-Primary", "Create", "Storage", "Storage", productName, "Hot LRS Data Stored", "Hot LRS", storage.getSizeInGB()});
                }
            }

        }

        ExcelUtils.putDataIntoCellsSorted(data, sheet);

    }
}
