
package com.usbank.cme.kv;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import javax.annotation.Generated;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "accessPolicies",
    "enablePurgeProtection",
    "enableRbacAuthorization",
    "enableSoftDelete",
    "enabledForDeployment",
    "enabledForDiskEncryption",
    "enabledForTemplateDeployment",
    "networkAcls",
    "privateEndpointConnections",
    "provisioningState",
    "publicNetworkAccess",
    "sku",
    "tenantId",
    "vaultUri"
})
@Generated("jsonschema2pojo")
public class Properties {

    @JsonProperty("accessPolicies")
    private List<AccessPolicy> accessPolicies;
    @JsonProperty("enablePurgeProtection")
    private Boolean enablePurgeProtection;
    @JsonProperty("enableRbacAuthorization")
    private Boolean enableRbacAuthorization;
    @JsonProperty("enableSoftDelete")
    private Boolean enableSoftDelete;
    @JsonProperty("enabledForDeployment")
    private Boolean enabledForDeployment;
    @JsonProperty("enabledForDiskEncryption")
    private Boolean enabledForDiskEncryption;
    @JsonProperty("enabledForTemplateDeployment")
    private Boolean enabledForTemplateDeployment;
    @JsonProperty("networkAcls")
    private NetworkAcls networkAcls;
    @JsonProperty("privateEndpointConnections")
    private List<PrivateEndpointConnection> privateEndpointConnections;
    @JsonProperty("provisioningState")
    private String provisioningState;
    @JsonProperty("publicNetworkAccess")
    private String publicNetworkAccess;
    @JsonProperty("sku")
    private Sku sku;
    @JsonProperty("tenantId")
    private String tenantId;
    @JsonProperty("vaultUri")
    private String vaultUri;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new LinkedHashMap<String, Object>();

    @JsonProperty("accessPolicies")
    public List<AccessPolicy> getAccessPolicies() {
        return accessPolicies;
    }

    @JsonProperty("accessPolicies")
    public void setAccessPolicies(List<AccessPolicy> accessPolicies) {
        this.accessPolicies = accessPolicies;
    }

    @JsonProperty("enablePurgeProtection")
    public Boolean getEnablePurgeProtection() {
        return enablePurgeProtection;
    }

    @JsonProperty("enablePurgeProtection")
    public void setEnablePurgeProtection(Boolean enablePurgeProtection) {
        this.enablePurgeProtection = enablePurgeProtection;
    }

    @JsonProperty("enableRbacAuthorization")
    public Boolean getEnableRbacAuthorization() {
        return enableRbacAuthorization;
    }

    @JsonProperty("enableRbacAuthorization")
    public void setEnableRbacAuthorization(Boolean enableRbacAuthorization) {
        this.enableRbacAuthorization = enableRbacAuthorization;
    }

    @JsonProperty("enableSoftDelete")
    public Boolean getEnableSoftDelete() {
        return enableSoftDelete;
    }

    @JsonProperty("enableSoftDelete")
    public void setEnableSoftDelete(Boolean enableSoftDelete) {
        this.enableSoftDelete = enableSoftDelete;
    }

    @JsonProperty("enabledForDeployment")
    public Boolean getEnabledForDeployment() {
        return enabledForDeployment;
    }

    @JsonProperty("enabledForDeployment")
    public void setEnabledForDeployment(Boolean enabledForDeployment) {
        this.enabledForDeployment = enabledForDeployment;
    }

    @JsonProperty("enabledForDiskEncryption")
    public Boolean getEnabledForDiskEncryption() {
        return enabledForDiskEncryption;
    }

    @JsonProperty("enabledForDiskEncryption")
    public void setEnabledForDiskEncryption(Boolean enabledForDiskEncryption) {
        this.enabledForDiskEncryption = enabledForDiskEncryption;
    }

    @JsonProperty("enabledForTemplateDeployment")
    public Boolean getEnabledForTemplateDeployment() {
        return enabledForTemplateDeployment;
    }

    @JsonProperty("enabledForTemplateDeployment")
    public void setEnabledForTemplateDeployment(Boolean enabledForTemplateDeployment) {
        this.enabledForTemplateDeployment = enabledForTemplateDeployment;
    }

    @JsonProperty("networkAcls")
    public NetworkAcls getNetworkAcls() {
        return networkAcls;
    }

    @JsonProperty("networkAcls")
    public void setNetworkAcls(NetworkAcls networkAcls) {
        this.networkAcls = networkAcls;
    }

    @JsonProperty("privateEndpointConnections")
    public List<PrivateEndpointConnection> getPrivateEndpointConnections() {
        return privateEndpointConnections;
    }

    @JsonProperty("privateEndpointConnections")
    public void setPrivateEndpointConnections(List<PrivateEndpointConnection> privateEndpointConnections) {
        this.privateEndpointConnections = privateEndpointConnections;
    }

    @JsonProperty("provisioningState")
    public String getProvisioningState() {
        return provisioningState;
    }

    @JsonProperty("provisioningState")
    public void setProvisioningState(String provisioningState) {
        this.provisioningState = provisioningState;
    }

    @JsonProperty("publicNetworkAccess")
    public String getPublicNetworkAccess() {
        return publicNetworkAccess;
    }

    @JsonProperty("publicNetworkAccess")
    public void setPublicNetworkAccess(String publicNetworkAccess) {
        this.publicNetworkAccess = publicNetworkAccess;
    }

    @JsonProperty("sku")
    public Sku getSku() {
        return sku;
    }

    @JsonProperty("sku")
    public void setSku(Sku sku) {
        this.sku = sku;
    }

    @JsonProperty("tenantId")
    public String getTenantId() {
        return tenantId;
    }

    @JsonProperty("tenantId")
    public void setTenantId(String tenantId) {
        this.tenantId = tenantId;
    }

    @JsonProperty("vaultUri")
    public String getVaultUri() {
        return vaultUri;
    }

    @JsonProperty("vaultUri")
    public void setVaultUri(String vaultUri) {
        this.vaultUri = vaultUri;
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

}
