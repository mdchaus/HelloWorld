package com.usbank.cme.dto;


import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class LB {

    String env;
    int count;
}
