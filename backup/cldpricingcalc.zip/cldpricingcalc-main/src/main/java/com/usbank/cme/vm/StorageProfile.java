
package com.usbank.cme.vm;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import javax.annotation.Generated;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "dataDisks",
    "diskControllerType",
    "imageReference",
    "osDisk"
})
@Generated("jsonschema2pojo")
public class StorageProfile {

    @JsonProperty("dataDisks")
    private List<DataDisk> dataDisks;
    @JsonProperty("diskControllerType")
    private String diskControllerType;
    @JsonProperty("imageReference")
    private ImageReference imageReference;
    @JsonProperty("osDisk")
    private OsDisk osDisk;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new LinkedHashMap<String, Object>();

    @JsonProperty("dataDisks")
    public List<DataDisk> getDataDisks() {
        return dataDisks;
    }

    @JsonProperty("dataDisks")
    public void setDataDisks(List<DataDisk> dataDisks) {
        this.dataDisks = dataDisks;
    }

    @JsonProperty("diskControllerType")
    public String getDiskControllerType() {
        return diskControllerType;
    }

    @JsonProperty("diskControllerType")
    public void setDiskControllerType(String diskControllerType) {
        this.diskControllerType = diskControllerType;
    }

    @JsonProperty("imageReference")
    public ImageReference getImageReference() {
        return imageReference;
    }

    @JsonProperty("imageReference")
    public void setImageReference(ImageReference imageReference) {
        this.imageReference = imageReference;
    }

    @JsonProperty("osDisk")
    public OsDisk getOsDisk() {
        return osDisk;
    }

    @JsonProperty("osDisk")
    public void setOsDisk(OsDisk osDisk) {
        this.osDisk = osDisk;
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

}
