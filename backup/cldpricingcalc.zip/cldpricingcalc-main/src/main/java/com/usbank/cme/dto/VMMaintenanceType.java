package com.usbank.cme.dto;

public enum VMMaintenanceType {
    PET,
    CATTLE
}
