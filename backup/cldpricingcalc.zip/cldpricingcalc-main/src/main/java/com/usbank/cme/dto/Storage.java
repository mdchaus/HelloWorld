package com.usbank.cme.dto;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class Storage {

    public int count;
    public ENV env;
    public String sku;
    public int sizeInGB;
    public StorageType storageType;

    public Storage(){}

}
