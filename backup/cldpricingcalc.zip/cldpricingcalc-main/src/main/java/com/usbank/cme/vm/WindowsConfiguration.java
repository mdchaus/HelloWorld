
package com.usbank.cme.vm;

import java.util.LinkedHashMap;
import java.util.Map;
import javax.annotation.Generated;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "enableAutomaticUpdates",
    "enableVMAgentPlatformUpdates",
    "patchSettings",
    "provisionVMAgent",
    "winRM"
})
@Generated("jsonschema2pojo")
public class WindowsConfiguration {

    @JsonProperty("enableAutomaticUpdates")
    private Boolean enableAutomaticUpdates;
    @JsonProperty("enableVMAgentPlatformUpdates")
    private Boolean enableVMAgentPlatformUpdates;
    @JsonProperty("patchSettings")
    private PatchSettings patchSettings;
    @JsonProperty("provisionVMAgent")
    private Boolean provisionVMAgent;
    @JsonProperty("winRM")
    private WinRM winRM;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new LinkedHashMap<String, Object>();

    @JsonProperty("enableAutomaticUpdates")
    public Boolean getEnableAutomaticUpdates() {
        return enableAutomaticUpdates;
    }

    @JsonProperty("enableAutomaticUpdates")
    public void setEnableAutomaticUpdates(Boolean enableAutomaticUpdates) {
        this.enableAutomaticUpdates = enableAutomaticUpdates;
    }

    @JsonProperty("enableVMAgentPlatformUpdates")
    public Boolean getEnableVMAgentPlatformUpdates() {
        return enableVMAgentPlatformUpdates;
    }

    @JsonProperty("enableVMAgentPlatformUpdates")
    public void setEnableVMAgentPlatformUpdates(Boolean enableVMAgentPlatformUpdates) {
        this.enableVMAgentPlatformUpdates = enableVMAgentPlatformUpdates;
    }

    @JsonProperty("patchSettings")
    public PatchSettings getPatchSettings() {
        return patchSettings;
    }

    @JsonProperty("patchSettings")
    public void setPatchSettings(PatchSettings patchSettings) {
        this.patchSettings = patchSettings;
    }

    @JsonProperty("provisionVMAgent")
    public Boolean getProvisionVMAgent() {
        return provisionVMAgent;
    }

    @JsonProperty("provisionVMAgent")
    public void setProvisionVMAgent(Boolean provisionVMAgent) {
        this.provisionVMAgent = provisionVMAgent;
    }

    @JsonProperty("winRM")
    public WinRM getWinRM() {
        return winRM;
    }

    @JsonProperty("winRM")
    public void setWinRM(WinRM winRM) {
        this.winRM = winRM;
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

}
