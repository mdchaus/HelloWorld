
package com.usbank.cme.vm;

import java.util.LinkedHashMap;
import java.util.Map;
import javax.annotation.Generated;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "caching",
    "createOption",
    "deleteOption",
    "diskSizeGB",
    "managedDisk",
    "name",
    "osType",
    "writeAcceleratorEnabled"
})
@Generated("jsonschema2pojo")
public class OsDisk {

    @JsonProperty("caching")
    private String caching;
    @JsonProperty("createOption")
    private String createOption;
    @JsonProperty("deleteOption")
    private String deleteOption;
    @JsonProperty("diskSizeGB")
    private Integer diskSizeGB;
    @JsonProperty("managedDisk")
    private ManagedDisk__1 managedDisk;
    @JsonProperty("name")
    private String name;
    @JsonProperty("osType")
    private String osType;
    @JsonProperty("writeAcceleratorEnabled")
    private Boolean writeAcceleratorEnabled;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new LinkedHashMap<String, Object>();

    @JsonProperty("caching")
    public String getCaching() {
        return caching;
    }

    @JsonProperty("caching")
    public void setCaching(String caching) {
        this.caching = caching;
    }

    @JsonProperty("createOption")
    public String getCreateOption() {
        return createOption;
    }

    @JsonProperty("createOption")
    public void setCreateOption(String createOption) {
        this.createOption = createOption;
    }

    @JsonProperty("deleteOption")
    public String getDeleteOption() {
        return deleteOption;
    }

    @JsonProperty("deleteOption")
    public void setDeleteOption(String deleteOption) {
        this.deleteOption = deleteOption;
    }

    @JsonProperty("diskSizeGB")
    public Integer getDiskSizeGB() {
        return diskSizeGB;
    }

    @JsonProperty("diskSizeGB")
    public void setDiskSizeGB(Integer diskSizeGB) {
        this.diskSizeGB = diskSizeGB;
    }

    @JsonProperty("managedDisk")
    public ManagedDisk__1 getManagedDisk() {
        return managedDisk;
    }

    @JsonProperty("managedDisk")
    public void setManagedDisk(ManagedDisk__1 managedDisk) {
        this.managedDisk = managedDisk;
    }

    @JsonProperty("name")
    public String getName() {
        return name;
    }

    @JsonProperty("name")
    public void setName(String name) {
        this.name = name;
    }

    @JsonProperty("osType")
    public String getOsType() {
        return osType;
    }

    @JsonProperty("osType")
    public void setOsType(String osType) {
        this.osType = osType;
    }

    @JsonProperty("writeAcceleratorEnabled")
    public Boolean getWriteAcceleratorEnabled() {
        return writeAcceleratorEnabled;
    }

    @JsonProperty("writeAcceleratorEnabled")
    public void setWriteAcceleratorEnabled(Boolean writeAcceleratorEnabled) {
        this.writeAcceleratorEnabled = writeAcceleratorEnabled;
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

}
