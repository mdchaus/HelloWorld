package com.usbank.cme.resourcelist;


import lombok.Data;

@Data
public class Sku {

    String capacity;
    String family;
    String model;
    String name;
    String size;
    String tier;
}
