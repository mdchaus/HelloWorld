package com.usbank.cme.utils;

import com.usbank.cme.dto.BomMetadata;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import java.util.HashMap;

public class KVUtils {

    public static void createKvSheet(BomMetadata metadata, XSSFWorkbook workbook) {
        XSSFSheet sheet = workbook.getSheet("Key Vault");


        HashMap<Integer, Object[]> data = new HashMap<Integer, Object[]>();
        int count = 2;

        for (String sub : metadata.getDevSubscriptions().split(",")) {
            if (sheet == null) {
                sheet = workbook.createSheet("Key Vault");
                ExcelUtils.changeColumnWidth(sheet, 25);
                data.put(1, new Object[]{""});
                data.put(2, new Object[]{"Environment", "Action", "Service Family", "Service Name", "Product Name", "Meter Name", "SKU Name", "UOM", "Friendly Name"});
            }

            data.put(++count, new Object[]{"Development", "Create", "Security", "Key Vault", "Key Vault", "Operations", "Premium", 5, "Key Vault"});
            data.put(++count, new Object[]{"IT", "Create", "Security", "Key Vault", "Key Vault", "Operations", "Premium", 5, "Key Vault"});
            data.put(++count, new Object[]{"UAT-Primary", "Create", "Security", "Key Vault", "Key Vault", "Operations", "Premium", 5, "Key Vault"});
            data.put(++count, new Object[]{"PROD-Primary", "Create", "Security", "Key Vault", "Key Vault", "Operations", "Premium", 5, "Key Vault"});
            if (metadata.getSecondaryRegion() == Boolean.TRUE) {
                data.put(++count, new Object[]{"UAT-Secondary", "Create", "Security", "Key Vault", "Key Vault", "Operations", "Premium", 5, "Key Vault"});
                data.put(++count, new Object[]{"PROD-Secondary", "Create", "Security", "Key Vault", "Key Vault", "Operations", "Premium", 5, "Key Vault"});
            }
        }

        ExcelUtils.putDataIntoCellsSorted(data, sheet);

    }

}
