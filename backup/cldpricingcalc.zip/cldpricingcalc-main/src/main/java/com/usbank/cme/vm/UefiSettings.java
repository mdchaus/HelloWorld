
package com.usbank.cme.vm;

import java.util.LinkedHashMap;
import java.util.Map;
import javax.annotation.Generated;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "secureBootEnabled",
    "vTpmEnabled"
})
@Generated("jsonschema2pojo")
public class UefiSettings {

    @JsonProperty("secureBootEnabled")
    private Boolean secureBootEnabled;
    @JsonProperty("vTpmEnabled")
    private Boolean vTpmEnabled;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new LinkedHashMap<String, Object>();

    @JsonProperty("secureBootEnabled")
    public Boolean getSecureBootEnabled() {
        return secureBootEnabled;
    }

    @JsonProperty("secureBootEnabled")
    public void setSecureBootEnabled(Boolean secureBootEnabled) {
        this.secureBootEnabled = secureBootEnabled;
    }

    @JsonProperty("vTpmEnabled")
    public Boolean getvTpmEnabled() {
        return vTpmEnabled;
    }

    @JsonProperty("vTpmEnabled")
    public void setvTpmEnabled(Boolean vTpmEnabled) {
        this.vTpmEnabled = vTpmEnabled;
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

}
