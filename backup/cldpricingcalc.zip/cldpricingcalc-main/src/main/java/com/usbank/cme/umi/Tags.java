
package com.usbank.cme.umi;

import java.util.LinkedHashMap;
import java.util.Map;
import javax.annotation.Generated;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "Name",
    "assignment_group",
    "car_id",
    "confidentiality",
    "cost_center",
    "deployment_id",
    "environment",
    "maintenance_type",
    "owner",
    "tf_creator",
    "tf_origin",
    "tf_owner"
})
@Generated("jsonschema2pojo")
public class Tags {

    @JsonProperty("Name")
    private String name;
    @JsonProperty("assignment_group")
    private String assignmentGroup;
    @JsonProperty("car_id")
    private String carId;
    @JsonProperty("confidentiality")
    private String confidentiality;
    @JsonProperty("cost_center")
    private String costCenter;
    @JsonProperty("deployment_id")
    private String deploymentId;
    @JsonProperty("environment")
    private String environment;
    @JsonProperty("maintenance_type")
    private String maintenanceType;
    @JsonProperty("owner")
    private String owner;
    @JsonProperty("tf_creator")
    private String tfCreator;
    @JsonProperty("tf_origin")
    private String tfOrigin;
    @JsonProperty("tf_owner")
    private String tfOwner;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new LinkedHashMap<String, Object>();

    @JsonProperty("Name")
    public String getName() {
        return name;
    }

    @JsonProperty("Name")
    public void setName(String name) {
        this.name = name;
    }

    @JsonProperty("assignment_group")
    public String getAssignmentGroup() {
        return assignmentGroup;
    }

    @JsonProperty("assignment_group")
    public void setAssignmentGroup(String assignmentGroup) {
        this.assignmentGroup = assignmentGroup;
    }

    @JsonProperty("car_id")
    public String getCarId() {
        return carId;
    }

    @JsonProperty("car_id")
    public void setCarId(String carId) {
        this.carId = carId;
    }

    @JsonProperty("confidentiality")
    public String getConfidentiality() {
        return confidentiality;
    }

    @JsonProperty("confidentiality")
    public void setConfidentiality(String confidentiality) {
        this.confidentiality = confidentiality;
    }

    @JsonProperty("cost_center")
    public String getCostCenter() {
        return costCenter;
    }

    @JsonProperty("cost_center")
    public void setCostCenter(String costCenter) {
        this.costCenter = costCenter;
    }

    @JsonProperty("deployment_id")
    public String getDeploymentId() {
        return deploymentId;
    }

    @JsonProperty("deployment_id")
    public void setDeploymentId(String deploymentId) {
        this.deploymentId = deploymentId;
    }

    @JsonProperty("environment")
    public String getEnvironment() {
        return environment;
    }

    @JsonProperty("environment")
    public void setEnvironment(String environment) {
        this.environment = environment;
    }

    @JsonProperty("maintenance_type")
    public String getMaintenanceType() {
        return maintenanceType;
    }

    @JsonProperty("maintenance_type")
    public void setMaintenanceType(String maintenanceType) {
        this.maintenanceType = maintenanceType;
    }

    @JsonProperty("owner")
    public String getOwner() {
        return owner;
    }

    @JsonProperty("owner")
    public void setOwner(String owner) {
        this.owner = owner;
    }

    @JsonProperty("tf_creator")
    public String getTfCreator() {
        return tfCreator;
    }

    @JsonProperty("tf_creator")
    public void setTfCreator(String tfCreator) {
        this.tfCreator = tfCreator;
    }

    @JsonProperty("tf_origin")
    public String getTfOrigin() {
        return tfOrigin;
    }

    @JsonProperty("tf_origin")
    public void setTfOrigin(String tfOrigin) {
        this.tfOrigin = tfOrigin;
    }

    @JsonProperty("tf_owner")
    public String getTfOwner() {
        return tfOwner;
    }

    @JsonProperty("tf_owner")
    public void setTfOwner(String tfOwner) {
        this.tfOwner = tfOwner;
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

}
