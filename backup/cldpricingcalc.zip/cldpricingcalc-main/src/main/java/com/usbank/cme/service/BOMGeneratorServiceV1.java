package com.usbank.cme.service;

import com.azure.core.http.policy.HttpLogDetailLevel;
import com.azure.core.management.AzureEnvironment;
import com.azure.core.management.Region;
import com.azure.core.management.profile.AzureProfile;
import com.azure.identity.ClientSecretCredential;
import com.azure.identity.ClientSecretCredentialBuilder;
import com.azure.identity.DefaultAzureCredential;
import com.azure.identity.DefaultAzureCredentialBuilder;
import com.azure.resourcemanager.AzureResourceManager;
import com.azure.resourcemanager.compute.models.ComputeResourceType;
import com.azure.resourcemanager.compute.models.OperatingSystemTypes;
import com.azure.resourcemanager.compute.models.VirtualMachine;
import com.azure.resourcemanager.compute.models.VirtualMachineDataDisk;
import com.azure.resourcemanager.resources.models.GenericResource;
import com.azure.resourcemanager.resources.models.ResourceGroup;
import com.fasterxml.jackson.databind.*;
import com.fasterxml.jackson.databind.json.JsonMapper;
import com.usbank.cme.car.Car;
import com.usbank.cme.dto.*;
import com.usbank.cme.exception.NoDataFoundException;
import com.usbank.cme.resourcemanager.AzureSkusForRegion;
import com.usbank.cme.resourcemanager.ManagedDiskSku;
import com.usbank.cme.utils.*;
import io.netty.handler.ssl.SslContext;
import io.netty.handler.ssl.SslContextBuilder;
import io.netty.handler.ssl.util.InsecureTrustManagerFactory;
import lombok.extern.slf4j.Slf4j;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.MediaType;
import org.springframework.http.client.reactive.ReactorClientHttpConnector;
import org.springframework.stereotype.Service;
import org.springframework.util.Base64Utils;
import org.springframework.util.StringUtils;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.netty.http.client.HttpClient;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.*;
import java.util.stream.Collectors;

@Slf4j
@Service
public class BOMGeneratorServiceV1 {


    @Autowired
    @Qualifier("restapiWebClient")
    private WebClient webClient;

    @Value("${CAR_API_USERNAME}")
    private String carApiUsername;

    @Value("${CAR_API_PASSWORD:errorBecauseUndefined}")
    private String carApiPassword;

    @Value("${CAR_API_REQUEST_URL}")
    private String carApiRequestURL;

    @Value("${AZURE_TENANT_ID}")
    private String spTenantId;

    private Map<String, String> computeSkuMap = new HashMap<>();
    private Map<String, ManagedDiskSku> diskSkuMap = new HashMap<>();

    public ByteArrayInputStream generateBomFromAzure(String carId, String subscriptions, Boolean isSecRegion) throws Exception {
        if (carApiPassword == null || carApiPassword.isEmpty() || carApiPassword.equals("errorBecauseUndefined")) {
            log.error("CAR API token is not set.  Please define the CAR_API_PASSWORD environment variable or define the secret in K8s. Exiting...");
            return null;
        }

        BomMetadata metadata = new BomMetadata();
        metadata.setDevSubscriptions(subscriptions);
        metadata.setCarId(carId);
        loadDataFromDev(metadata);
        metadata.setSecondaryRegion(isSecRegion);
        metadata.setItSubscriptions(metadata.getDevSubscriptions().replace("dev", "it"));
        metadata.setUatSubscriptions(metadata.getDevSubscriptions().replace("dev", "uat"));
        metadata.setProdSubscriptions(metadata.getDevSubscriptions().replace("dev", "prod"));

        ObjectWriter ow = new ObjectMapper().writer().withDefaultPrettyPrinter();
        String json = ow.writeValueAsString(metadata);
        System.out.println(json);
        XSSFWorkbook workbook = new XSSFWorkbook();
        ApplicationSheetUtils.createApplicationSheet(metadata, workbook);
        //createTagsSheet(metadata, workbook);
        ResourceGroupUtils.createResourceGroupSheet(metadata, workbook);
        UmiUtils.createUserManagedIdentitySheet(metadata, workbook);
        if (metadata.getPeTypes().size() > 0) PeUtils.createPrivateEndpointSheet(metadata, workbook);
        if (metadata.getLbs().size() > 0) LBUtils.createLBSheet(metadata, workbook);
        if (metadata.getVms().size() > 0) {
            VMUtils.createVMSheet(metadata, workbook);
            VmDiskUtils.createVMDiskSheet(metadata, workbook);
        }
        if (metadata.getDbs().size() > 0) DBUtils.createDBSQLSheet(metadata, workbook);
        if (metadata.getStorages().size() > 0) StorageUtils.createStorageSheet(metadata, workbook);

        //createNSGSheet(metadata, workbook);
        ADFUtils.createADFSheet(metadata, workbook);
        NoMappingUtils.createNoMappingSheet(metadata, workbook);
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        workbook.write(out);
        return new ByteArrayInputStream(out.toByteArray());

    }

    private BomMetadata loadDataFromDev(BomMetadata bomMetadata) throws Exception {

        List<String> subscriptions = new ArrayList<>(Arrays.asList(bomMetadata.getDevSubscriptions().split(",")));
        List<GenericResource> resources = new ArrayList<>();
        for (String sub : subscriptions) {
            List<ResourceGroup> resourceGroups = new ArrayList<>();
            AzureResourceManager resourceManager = initializeAzureResourceManager(sub);
            JsonMapper.builder().configure(MapperFeature.ACCEPT_CASE_INSENSITIVE_PROPERTIES, true);
            ObjectMapper objectMapper = new ObjectMapper();
            objectMapper.setPropertyNamingStrategy(PropertyNamingStrategies.SNAKE_CASE);
            resourceManager.resourceGroups().listByTag("car_id", bomMetadata.getCarId()).stream().forEach(rg ->
                    {
                        System.out.println(rg.name());
                        resourceGroups.add(rg);
                        try {
                            addDevVmDataToMetaData(bomMetadata, resourceManager, rg.name());
                        } catch (IOException e) {
                            throw new RuntimeException(e);
                        }
                    }
            );
            resourceGroups.stream().forEach(rg ->
                    resourceManager.genericResources().listByResourceGroup(rg.name()).forEach(r -> resources.add(r)));
        }
        if (resources.isEmpty())
            throw new NoDataFoundException("No resource found for this app in given resource group");
        for (GenericResource resource : resources) {
            bomMetadata.getRgs().add(resource.resourceGroupName().toLowerCase());
            if (resource.type().equals("Microsoft.Compute/virtualMachines")) {
            } else if (resource.type().equals("Microsoft.Storage/storageAccounts")) {
                bomMetadata.setIsAppUsingStorage(Boolean.TRUE);
                bomMetadata.getStorages().add(new Storage(1, ENV.DEV, resource.sku().name(), 0, StorageType.Files));
            } else if (resource.type().equals("Microsoft.Network/privateEndpoints"))
                bomMetadata.getPeTypes().add(resource.name());
            else if (resource.type().equals("Microsoft.Network/loadBalancers"))
                bomMetadata.getLbs().put(resource.name(), resource.resourceGroupName());
            else if (resource.type().equals("Microsoft.ManagedIdentity/userAssignedIdentities"))
                bomMetadata.getUmis().put(resource.name(), resource.resourceGroupName());
            else if (resource.type().equals("Microsoft.Network/networkSecurityGroups"))
                bomMetadata.getNsgs().put(resource.name(), resource.resourceGroupName());
            else if (resource.type().equals("Microsoft.Sql/managedInstances")) {
                bomMetadata.getDbs().add(new DB(1, ENV.DEV, resource.sku().name(), resource.sku().capacity().toString() , "10", DBType.SQLMI, resource.sku().tier(), resource.sku().family()));
            }
            else if (resource.type().equals("Microsoft.Sql/servers/databases") && !resource.sku().name().equals("System"))
                bomMetadata.getDbs().add(new DB(1, ENV.DEV, resource.sku().name(), resource.sku().capacity().toString(), "10", DBType.SQL, resource.sku().tier(), resource.sku().family()));
            else if (resource.type().equals("Microsoft.DataFactory/factories"))
                bomMetadata.getAdfs().put(resource.name(), resource.resourceGroupName());
            else {
                bomMetadata.getNoMappings().put(resource.name(), resource.resourceGroupName());
            }
        }
        return bomMetadata;
    }

    private void addDevVmDataToMetaData(BomMetadata bomMetadata, AzureResourceManager resourceManager, String resourceGroupName) throws IOException {
        JsonMapper.builder().configure(MapperFeature.ACCEPT_CASE_INSENSITIVE_PROPERTIES, true);
        ObjectMapper objectMapper = new ObjectMapper();
        objectMapper.setPropertyNamingStrategy(PropertyNamingStrategies.SNAKE_CASE);
        List<VirtualMachine> virtualMachines = new ArrayList<>();
        resourceManager.virtualMachines().listByResourceGroup(resourceGroupName).forEach(
                vm -> virtualMachines.add(vm)
        );
        virtualMachines.forEach(
                vm ->
                {
                    VM vmDto = new VM();
                    vmDto.setEnv(vm.tags().get("environment").toLowerCase().equals("it") ? ENV.IT : ENV.DEV);
                    vmDto.setCount(1);
                    vmDto.setSku(vm.size().toString());
                    vmDto.setMaintenanceType(vm.tags().get("maintenance_type").equals("cattle") ? VMMaintenanceType.CATTLE : VMMaintenanceType.PET);
                    vmDto.setType(vm.osType().equals(OperatingSystemTypes.WINDOWS) ? VMType.Windows : VMType.Linux);
                    vmDto.setFamily(computeSkuMap.get(vm.size().toString()));

                    if (vm.dataDisks().size() > 0) {
                        int index = 0;
                        if (vm.dataDisks().get(index) == null) {
                            index = 1;
                        }


                        //  Data disks
                        VirtualMachineDataDisk vmDataDisk = vm.dataDisks().get(index);
                        if (vmDataDisk != null) {

                            String sku = vmDataDisk.storageAccountType().toString();
                            int diskSizeInt = vmDataDisk.size();
                            String diskSizeStr = Integer.toString(diskSizeInt);

                            Set<String> keySet = diskSkuMap.keySet()
                                    .stream()
                                    .filter(s -> s.startsWith(sku))
                                    .filter(s -> s.contains(diskSizeStr))
                                    .collect(Collectors.toSet());

                            ManagedDiskSku foundDiskSku = null;
                            Boolean found = false;
                            for (String key : keySet)
                            {
                                foundDiskSku = diskSkuMap.get(key);
                                if (foundDiskSku != null && foundDiskSku.capacity.equals(diskSizeStr))
                                {
                                    // found it
                                    found = true;
                                    break;
                                }
                            }
                            if (!found)
                            {
                                log.info("**** ERROR: cannot find in diskSkuMap, looking for sku '" + sku + "' and size '" + diskSizeStr + "'");
                            }
                            else
                            {
                                 vmDto.setDataDisk(new ManagedDisk(ManagedDiskType.DATADISK, diskSizeInt, foundDiskSku.getFormattedSkuName(), foundDiskSku.getFormattedTier(), foundDiskSku.redundancy));
                            }
                        }
                    }

                    //  OS disks
                    String sku = vm.osDiskStorageAccountType().toString();
                    int diskSizeInt = vm.osDiskSize();
                    String diskSizeStr = Integer.toString(diskSizeInt);

                    Set<String> keySet = diskSkuMap.keySet()
                            .stream()
                            .filter(s -> s.startsWith(sku))
                            .filter(s -> s.contains(diskSizeStr))
                            .collect(Collectors.toSet());

                    ManagedDiskSku foundDiskSku = null;
                    Boolean found = false;
                    for (String key : keySet)
                    {
                        foundDiskSku = diskSkuMap.get(key);
                        if (foundDiskSku != null && foundDiskSku.capacity.equals(diskSizeStr))
                        {
                            // found it
                            found = true;
                            break;
                        }
                    }
                    if (!found)
                    {
                        log.info("**** ERROR: cannot find in diskSkuMap, looking for sku '" + sku + "' and size '" + diskSizeStr + "'");
                    }
                    else {

                        vmDto.setOsDisk(new ManagedDisk(ManagedDiskType.OSDISK, diskSizeInt, foundDiskSku.getFormattedSkuName(), foundDiskSku.getFormattedTier(), foundDiskSku.redundancy));
                    }
                    bomMetadata.getVms().add(vmDto);
                    bomMetadata.setMaintenanceType(vm.tags().get("maintenance_type"));
                }
        );
    }


    public void createTagsSheet(BomMetadata metadata, XSSFWorkbook workbook) {
        XSSFSheet sheet = workbook.getSheet("Tags");

        // for unit testing with TestAzureSDK, uncomment these


        if (webClient == null)
        {
            log.error("createTagsSheet webClient to invoke CAR API is null.  Tags sheet will be null.", new Exception("createTagsSheet webClient is null"));
            return;
        }

        Car carRes = webClient.get()
                .uri(carApiRequestURL + "?carId=" + metadata.getCarId())
                .header("Authorization", "Basic " + Base64Utils
                        .encodeToString((carApiUsername + ":" + carApiPassword).getBytes(StandardCharsets.UTF_8)))
                .retrieve()
                .toEntity(Car.class).block().getBody();


        HashMap<Integer, Object[]> data = new HashMap<Integer, Object[]>();
        int count = 2;
        for (String sub : metadata.getDevSubscriptions().split(",")) {
            if (sheet == null) {
                sheet = workbook.createSheet("Tags");
                ExcelUtils.changeColumnWidth(sheet, 25);
            }
            data.put(1, new Object[]{""});
            data.put(2, new Object[]{"environment", "environment sub-type", "Application Name", "Application ID", "confidentiality", "assignment_group", "car_id", "owner", "maintenance_type", "cost_center", "Department", "Resilience"});
            data.put(++count, new Object[]{"dev", "dev-cus", carRes.getData().get(0).getSoftwareName(), carRes.getData().get(0).getCarId(), "internal", carRes.getData().get(0).getAssigneeGroupLevel3Support(), carRes.getData().get(0).getCarId(), carRes.getData().get(0).getToEmail(), metadata.getMaintenanceType(), carRes.getData().get(0).getToCostCenter(), carRes.getData().get(0).getToCcDescription(), carRes.getData().get(0).getResiliencyTier()});

            data.put(++count, new Object[]{"it", "it-cus", carRes.getData().get(0).getSoftwareName(), carRes.getData().get(0).getCarId(), "internal", carRes.getData().get(0).getAssigneeGroupLevel3Support(), carRes.getData().get(0).getCarId(), carRes.getData().get(0).getToEmail(), metadata.getMaintenanceType(), carRes.getData().get(0).getToCostCenter(), carRes.getData().get(0).getToCcDescription(), carRes.getData().get(0).getResiliencyTier()});
            data.put(++count, new Object[]{"uat-primary", "uat-cus", carRes.getData().get(0).getSoftwareName(), carRes.getData().get(0).getCarId(), "internal", carRes.getData().get(0).getAssigneeGroupLevel3Support(), carRes.getData().get(0).getCarId(), carRes.getData().get(0).getToEmail(), metadata.getMaintenanceType(), carRes.getData().get(0).getToCostCenter(), carRes.getData().get(0).getToCcDescription(), carRes.getData().get(0).getResiliencyTier()});
            data.put(++count, new Object[]{"prod-primary", "prod-cus", carRes.getData().get(0).getSoftwareName(), carRes.getData().get(0).getCarId(), "internal", carRes.getData().get(0).getAssigneeGroupLevel3Support(), carRes.getData().get(0).getCarId(), carRes.getData().get(0).getToEmail(), metadata.getMaintenanceType(), carRes.getData().get(0).getToCostCenter(), carRes.getData().get(0).getToCcDescription(), carRes.getData().get(0).getResiliencyTier()});

            if (metadata.getSecondaryRegion() == Boolean.TRUE) {
                data.put(++count, new Object[]{"uat-secondary", "uat-eus2", carRes.getData().get(0).getSoftwareName(), carRes.getData().get(0).getCarId(), "internal", carRes.getData().get(0).getAssigneeGroupLevel3Support(), carRes.getData().get(0).getCarId(), carRes.getData().get(0).getToEmail(), metadata.getMaintenanceType(), carRes.getData().get(0).getToCostCenter(), carRes.getData().get(0).getToCcDescription(), carRes.getData().get(0).getResiliencyTier()});
                data.put(++count, new Object[]{"prod-secondary", "prod-eus2", carRes.getData().get(0).getSoftwareName(), carRes.getData().get(0).getCarId(), "internal", carRes.getData().get(0).getAssigneeGroupLevel3Support(), carRes.getData().get(0).getCarId(), carRes.getData().get(0).getToEmail(), metadata.getMaintenanceType(), carRes.getData().get(0).getToCostCenter(), carRes.getData().get(0).getToCcDescription(), carRes.getData().get(0).getResiliencyTier()});
            }
        }
        ExcelUtils.putDataIntoCellsSorted(data, sheet);

    }

    public AzureResourceManager initializeAzureResourceManager(String subscription) {



        DefaultAzureCredential clientSecretCredential = new DefaultAzureCredentialBuilder().tenantId(spTenantId).build();

        AzureProfile profile = new AzureProfile(AzureEnvironment.AZURE);
        HashMap<String, String> subscriptionMap = new HashMap<>();
        AzureResourceManager.configure().withLogLevel(HttpLogDetailLevel.BODY_AND_HEADERS)
                .authenticate(clientSecretCredential, profile)
                .subscriptions().list().stream().forEach(
                        s ->
                                subscriptionMap.put(s.displayName(), s.subscriptionId()));
        AzureResourceManager resourceManager = AzureResourceManager.configure().withLogLevel(HttpLogDetailLevel.NONE)
                .authenticate(clientSecretCredential, profile).withSubscription(subscriptionMap.get(subscription));


        AzureSkusForRegion skus = new AzureSkusForRegion(resourceManager);

        diskSkuMap = skus.getDiskSkus();

        resourceManager.computeSkus().
                listByRegionAndResourceType(Region.US_CENTRAL, ComputeResourceType.VIRTUALMACHINES).stream().
                forEach(computeSku ->
                {
                    log.info("Compute SKU " + computeSku.name());
                    computeSkuMap.put(String.valueOf(computeSku.name()), StringUtils.capitalize(computeSku.innerModel().family().toLowerCase().replace("family", " series").replace("standard", "")));
                });

        return resourceManager;
    }

}
