package com.usbank.cme.resourcemanager;

public class VmSku {


    //need:  (1) service name:  Virtual Machines
    //       (2) Product name:   Virtual Machines v5 Services
    //       (3) Meter name:  D2as v5
    //       (4) SKU name: Standard_D2as_v5
    // family:  D2a5 series

    public String sku;  //e.g. Standard_D2as_v5

    public String family;

    public String size;
    public String tier;

    public String getvCpus() {
        return vCpus;
    }

    public String getMemoryGB() {
        return memoryGB;
    }

    private String vCpus;
    private String memoryGB;

    public VmSku(String sku, String tier, String size, String family, String vCPUs, String memoryGB)
    {

        this.sku = sku;
        this.tier = tier;
        this.size = size;
        this.family = family;
        this.vCpus = vCPUs;
        this.memoryGB = memoryGB;
    }


}
