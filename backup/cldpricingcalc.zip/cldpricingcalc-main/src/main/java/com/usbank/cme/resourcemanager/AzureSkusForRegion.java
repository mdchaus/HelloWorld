package com.usbank.cme.resourcemanager;

import com.azure.core.management.Region;
import com.azure.resourcemanager.AzureResourceManager;
import com.azure.resourcemanager.compute.models.ComputeResourceType;
import com.azure.resourcemanager.compute.models.ResourceSkuCapabilities;
import com.azure.resourcemanager.compute.models.ResourceSkuRestrictions;
//import com.azure.resourcemanager.sql.models.DatabaseSku;
import com.usbank.cme.dto.DBType;
//import com.usbank.cme.resourcelist.Sku;

//import com.usbank.cme.dto.DBType;
import lombok.extern.slf4j.Slf4j;

import java.util.*;

@Slf4j
public class AzureSkusForRegion {

    private AzureResourceManager resourceManager;

    private Map<String, VmSku> computeSkuMap = new HashMap<>();
    private Map<String, SqlDbSku> databaseSkuMap = new HashMap<>();
    private Map<String, ManagedDiskSku> diskSkuMap = new HashMap<>();


    public AzureSkusForRegion(AzureResourceManager resourceManager) {
        this.resourceManager = resourceManager;
    }

    public Map<String, ManagedDiskSku> getDiskSkus() {
        resourceManager.computeSkus().listByRegionAndResourceType(Region.US_CENTRAL, ComputeResourceType.DISKS).forEach
                (
                        diskSku ->
                        {
                            try {
                                if (diskSku.innerModel().capabilities() != null) {

                                    ListIterator<ResourceSkuCapabilities> capabilitiesIterator = diskSku.innerModel().capabilities().listIterator();

                                    Boolean found = false;
                                    String diskSize = "0";
                                    while (capabilitiesIterator.hasNext() && found == false) {
                                        ResourceSkuCapabilities capability = capabilitiesIterator.next();
                                        if (capability.name().equals("MaxSizeGiB")) {
                                            found = true;
                                            diskSize = capability.value();
                                        }
                                    }

                                    ManagedDiskSku managedDiskSku = new ManagedDiskSku(diskSku.name().toString(), diskSku.tier().toString(), diskSku.innerModel().size(), diskSize);

                                    String managedDiskSkuEnumStr =  managedDiskSku.skuEnumString;    // e.g. PREMIUM_P1_125dtu
                                     // example: Disk SKU PremiumV2_LRS, tier Premium, sku type PremiumV2_LRS, disk size type P, disk size 65536
                                    log.info("Disk SKU enum str " + managedDiskSkuEnumStr + ", SKU " + diskSku.name() + ", tier " + diskSku.tier().toString() + ", sku type " + diskSku.diskSkuType().toString() + ", disk size type " + diskSku.innerModel().size().toString() + ", disk size " + diskSize);

                                    diskSkuMap.put(managedDiskSkuEnumStr, managedDiskSku);
                                }
                            } catch (Exception e) {
                                e.printStackTrace();
                                log.info("exception on Disk SKU " + diskSku.name() + ", tier " + diskSku.tier().toString() + ", sku type " + diskSku.diskSkuType().toString());
                            }
                            //", capacity max " + diskSku.capacity().maximum().toString());
                        }
                );

        return diskSkuMap;
    }

    public Map<String, VmSku> getVmSkus() {

        resourceManager.computeSkus().
                listByRegionAndResourceType(Region.US_CENTRAL, ComputeResourceType.VIRTUALMACHINES).stream().
                forEach(computeSku ->
                {
                    log.info("Compute SKU " + computeSku.name());

                    // see if VM SKU has location restriction
                    Boolean available = true;
                    for (ResourceSkuRestrictions restriction : computeSku.innerModel().restrictions()) {
                        if (restriction.type().toString() == "Location" && restriction.reasonCode().toString() == "NotAvailableForSubscription") {
                            available = false;
                            break;
                        }
                    }
                    if (available) {
                        //    public VmSku(String name, String tier, String size, String family, int vCPUs, int memoryGB)
                        String vCPUs = "unknown";
                        try {
                            vCPUs = computeSku.innerModel().capabilities().stream().filter(it -> "vCPUs".equals(it.name())).findFirst().get().value();
                        } catch (Exception e) {
                            System.out.println("Exception on '" + computeSku.name() + ":" + "vCPUs");
                            e.printStackTrace();
                        }
                        String memoryGB = "unknown";
                        try {
                            memoryGB = computeSku.innerModel().capabilities().stream().filter(it -> "MemoryGB".equals(it.name())).findFirst().get().value();
                        } catch (Exception e) {
                            System.out.println("Exception on '" + computeSku.name() + ":" + "MemoryGB");
                            e.printStackTrace();
                        }
                        // String vCPUsPerCore = "1";
                        // try {
                        //     vCPUsPerCore = computeSku.innerModel().capabilities().stream().filter(it -> "vCPUsPerCore".equals(it.name())).findFirst().get().value();
                        // } catch (Exception e) {
                        //     System.out.println("Exception on '" + computeSku.name() + ":" + "vCPUsPerCore");
                        //     e.printStackTrace();
                        // }
                        computeSkuMap.put(String.valueOf(computeSku.name()), new VmSku(computeSku.name().toString(), computeSku.innerModel().tier().toString(), computeSku.innerModel().size().toString(), computeSku.innerModel().family().toString(), vCPUs, memoryGB));  //StringUtils.capitalize(computeSku.innerModel().family().toLowerCase().replace("family", " series").replace("standard", "")));
                    }
                });
        return computeSkuMap;
    }

    public Map<String, SqlDbSku> getSqlDbSkus() {
        // SQL

        // Set<String> supportedTiers = new HashSet<String>()
        // {{
        //     add("BusinessCritical");
        //     add("DataWarehouse");
        //     add("GeneralPurpose");    // excluded:  Free, Basic,
        //     add("Premium");
        //     add("Standard");
        // }};
        // Set<String> supportedEditions = new HashSet<String>()
        // {{
        //     //add("12.0");// 12.0 == SQL Server 2014
        //     add("13.0");// 13.0 == SQL Server 2016
        //     add("14.0");// 14.0 == SQL Server 2017
        //     add("15.0");// 15.0 == SQL Server 2019
        //     add("16.0 ");// 16.0 == SQL Server 2022
        // }};


        // List<DatabaseSku> databaseSkus = DatabaseSku.getAll().stream().filter(thissku -> supportedTiers.contains(thissku.toSku().tier().toString())).collect(Collectors.toCollection(LinkedList::new));
        // for (DatabaseSku dbSku : databaseSkus)
        // {
        //     String reformattedName = dbSku.toString();
        //     Sku mySku = dbSku.toSku();
        //     //DatabaseSku.BUSINESSCRITICAL_BC_GEN5_4

        //     // name/tier/family/capacity/size
        //     // databaseSkuMap.put(reformattedName, new SqlDbSku(reformattedName,mySku.tier().toString(), mySku.family()));
        // }
        //List<DatabaseSku> databaseSkuSorted = databaseSkus.sort(Comparator.comparing()mySku-> mySku.toString() );

    //    resourceManager.sqlServers().getCapabilitiesByRegion(Region.US_CENTRAL).supportedCapabilitiesByServerVersion().forEach(
    //            (s, serverVersionCapability) ->
    //            {
    //                serverVersionCapability.supportedEditions().forEach(
    //                        version ->
    //                        {

    //                            String versionName = version.name().toString();
    //                            String status = version.status().toString();
    //                            String name = version.name();
    //                            //String family = version.family;
    //                            //String tier = version.
    //                            if (status.equals("Available") && supportedEditions.contains(versionName)) {
    //                                 log.info("SQL version name: " + versionName);
    //                                //DatabaseSku dbSku = new DatabaseSku(name, tier, family, capacity, size);
    //                                //dbSku.toString();
    //                             }
    //                        }
    //                );
    //            }
    //    );




    //     resourceManager.sqlServers().manager().serviceClient().getCapabilities().listByLocation(Region.US_CENTRAL.toString()).supportedServerVersions().
    //             forEach(sqlVersion ->
    //             {
    //                 sqlVersion.supportedEditions().forEach(edition ->
    //                         {
    //                             log.info("SQL SKU " + edition.name());
    //                             String status = edition.status().toString();
    //                             String editionName = edition.name().toString();
    //                             if (status.equals("Available") && supportedEditions.contains(editionName)) {
    //                                 DBType dbType = DBType.SQL;
    //                                 String version = sqlVersion.name().toString();
    //                                 String sku = edition.supportedServiceLevelObjectives().get(0).sku().name().toString();
    //                                 String tier = edition.supportedServiceLevelObjectives().get(0).sku().tier().toString();
    //                                 String baseProduct = "SQL Database Single";

    //                                 //String name, String tier, String family, String capacity)
    //                                 //databaseSkuMap.put(sku,new SqlDbSku(sku, baseProduct, tier)); // version,

    //                             }

    //                         }
    //                 );
    //                 sqlVersion.supportedElasticPoolEditions().forEach(edition ->
    //                         {
    //                             log.info("SQL (Elastic) SKU " + edition.name());
    //                             String status = edition.status().toString();
    //                             String editionName = edition.name().toString();
    //                             if (status.equals("Available") && supportedEditions.contains(editionName)) {
    //                                 DBType dbType = DBType.SQL;
    //                                 //edition.supportedElasticPoolPerformanceLevels().
    //                                 //String sku = edition.supportedServiceLevelObjectives().get(0).sku().name().toString();
    //                                 //String tier = edition.supportedServiceLevelObjectives().get(0).sku().tier().toString();
    //                                 String baseProduct = "SQL Database Elastic Pool";


    //                                 //databaseSkuMap.put("xxx", new SqlDbSku());

    //                             }

    //                         }
    //                 );
    //             });

    //     resourceManager.sqlServers().manager().serviceClient().getCapabilities().listByLocation(Region.US_CENTRAL.toString()).supportedManagedInstanceVersions().
    //             forEach(sqlMiVersion ->
    //             {
    //                 sqlMiVersion.supportedEditions().forEach(edition ->
    //                         {
    //                             log.info("SQL MI SKU " + edition.name());
    //                             String status = edition.status().toString();
    //                             String editionName = edition.name().toString();
    //                             if (status.equals("Available") && supportedEditions.contains(editionName)) {
    //                                 DBType dbType = DBType.SQLMI;
    //                                 //String sku = edition.supportedServiceLevelObjectives().get(0).sku().name().toString();
    //                                 //String tier = edition.supportedServiceLevelObjectives().get(0).sku().tier().toString();
    //                                 String baseProduct = "SQL Managed Instance Single";


    //                                 //databaseSkuMap.put("xxx", new SqlDbSku());

    //                             }

    //                         }
    //                 );
    //                 sqlMiVersion.supportedInstancePoolEditions().forEach(edition ->
    //                         {
    //                             log.info("SQL MI (Pool) SKU " + edition.name());
    //                             String status = edition.status().toString();
    //                             String editionName = edition.name().toString();
    //                             if (status.equals("Available") && supportedEditions.contains(editionName)) {
    //                                 DBType dbType = DBType.SQLMI;
    //                                 //edition.supportedElasticPoolPerformanceLevels().
    //                                 //String sku = edition.supportedServiceLevelObjectives().get(0).sku().name().toString();
    //                                 //String tier = edition.supportedServiceLevelObjectives().get(0).sku().tier().toString();
    //                                 String baseProduct = "SQL Managed Instance Elastic Pool";


    //                                 //databaseSkuMap.put("xxx", new SqlDbSku());

    //                             }
    //                         }
    //                 );
    //             });

        return databaseSkuMap;
    }


}
