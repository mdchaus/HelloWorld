package com.usbank.cme.dto;

public enum VMType {
    Linux, Windows
}
