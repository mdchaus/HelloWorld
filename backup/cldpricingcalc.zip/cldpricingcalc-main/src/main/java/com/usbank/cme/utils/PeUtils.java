package com.usbank.cme.utils;

import com.usbank.cme.dto.BomMetadata;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import java.util.HashMap;
import java.util.List;

public class PeUtils {

    public static void createPrivateEndpointSheet(BomMetadata metadata, XSSFWorkbook workbook) {
        XSSFSheet sheet = workbook.getSheet("PVT Endpoint");
        HashMap<Integer, Object[]> data = new HashMap<Integer, Object[]>();

        int count = 2;
        List<String> peTypes = metadata.getPeTypes();



        for (String peType : peTypes) {
            if (sheet == null) {
                sheet = workbook.createSheet("PVT Endpoint");
                ExcelUtils.changeColumnWidth(sheet, 25);
                data.put(1, new Object[]{""});
                data.put(2, new Object[]{"Environment", "Action", "Friendly Name", "Resource Name"});
            }

            data.put(++count, new Object[]{"DEV", "Create", "Private Endpoint", peType});
            data.put(++count, new Object[]{"IT", "Create", "Private Endpoint", peType.replace("dev", "it")});
            data.put(++count, new Object[]{"UAT-Primary", "Create", "Private Endpoint", peType.replace("dev", "uat")});
            data.put(++count, new Object[]{"PROD-Primary", "Create", "Private Endpoint", peType.replace("dev", "prod")});
            if (metadata.getSecondaryRegion() == Boolean.TRUE) {
                data.put(++count, new Object[]{"UAT-Secondary", "Create", "Private Endpoint", peType.replace("dev", "uat").replace("cus" , "eus2")});
                data.put(++count, new Object[]{"PROD-Secondary", "Create", "Private Endpoint", peType.replace("dev", "prod").replace("cus" , "eus2")});
            }
        }
        ExcelUtils.putDataIntoCellsSorted(data, sheet);
    }
}
