package com.usbank.cme.utils;

import com.usbank.cme.dto.BomMetadata;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import java.util.HashMap;
import java.util.Map;

public class NSGUtils {

    public static void createNSGSheet(BomMetadata metadata, XSSFWorkbook workbook) {
        XSSFSheet sheet = workbook.getSheet("NSG");

        HashMap<Integer, Object[]> data = new HashMap<Integer, Object[]>();
        int count = 2;

        if (sheet == null) {
            sheet = workbook.createSheet("NSG");
            ExcelUtils.changeColumnWidth(sheet, 25);
            data.put(0, new Object[]{"Environment", "Action", "Service Name", "Resource Group Name", "NSG Name"});
            data.put(2, new Object[]{"Environment", "Action", "Service Name", "Resource Group Name", "NSG Name"});
        }

        for (Map.Entry<String, String> nsg : metadata.getNsgs().entrySet()) {
            data.put(0, new Object[]{"Environment", "Action", "Service Name", "Resource Group Name", "NSG Name"});
            data.put(2, new Object[]{"Environment", "Action", "Service Name", "Resource Group Name", "NSG Name"});
            data.put(++count, new Object[]{"DEV", "Create", "Network Security Groups",nsg.getValue(), nsg.getKey()});
            data.put(++count, new Object[]{"IT", "Create", "Network Security Groups", nsg.getValue().replace("dev" , "it"), nsg.getKey().replace("dev" , "it")});
            data.put(++count, new Object[]{"UAT-Primary", "Create", "Network Security Groups", nsg.getValue().replace("dev" , "uat") , nsg.getKey().replace("dev" , "uat")});
            data.put(++count, new Object[]{"PROD-Primary", "Create", "Network Security Groups", nsg.getValue().replace("dev" , "prod"), nsg.getKey().replace("dev" , "prod")});
            if (metadata.getSecondaryRegion() == Boolean.TRUE) {
                data.put(++count, new Object[]{"UAT-Secondary", "Create", "Network Security Groups", nsg.getValue().replace("dev" , "uat").replace("cus" , "eus2"), nsg.getKey().replace("dev" , "uat").replace("cus" , "eus2")});
                data.put(++count, new Object[]{"PROD-Secondary", "Create", "Network Security Groups", nsg.getValue().replace("dev" , "prod").replace("cus" , "eus2"), nsg.getKey().replace("dev" , "prod").replace("cus" , "eus2")});
            }
        }
        ExcelUtils.putDataIntoCellsSorted(data, sheet);

    }
}
