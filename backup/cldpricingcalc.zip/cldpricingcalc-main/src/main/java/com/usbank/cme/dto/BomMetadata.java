package com.usbank.cme.dto;


import lombok.Data;

import java.util.*;

@Data
public class BomMetadata {

    public String CarId;
    public String appContextNames;
    public Boolean secondaryRegion;
    public String devSubscriptions ;
    public String itSubscriptions ;
    public String uatSubscriptions ;
    public String prodSubscriptions;
    public List<VM> vms= new ArrayList<>();
    public List<DB> dbs = new ArrayList<>();
    public List<Storage> storages = new ArrayList<>();
    public Boolean isLBNeeded;
    public String maintenanceType;
    public Boolean isAppUsingStorage;
    List<String> peTypes = new ArrayList<>();
    HashSet<String> rgs = new HashSet<>();
    Map<String, String> umis = new HashMap<>();
    Map<String, String> nsgs = new HashMap<>();
    Map<String, String> adfs = new HashMap<>();
    Map<String, String> noMappings = new HashMap<>();
    Map<String, String> lbs = new HashMap<>();
}
