package com.usbank.cme;

import com.usbank.cme.kv.Kv;
import com.usbank.cme.nsg.DefaultSecurityRule;
import com.usbank.cme.nsg.Nsg;
import com.usbank.cme.resourcelist.Resource;
import com.usbank.cme.umi.Umi;
import com.fasterxml.jackson.databind.MapperFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.PropertyNamingStrategies;
import com.fasterxml.jackson.databind.json.JsonMapper;

import lombok.extern.slf4j.Slf4j;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import com.usbank.cme.pe.PrivateEndpoint;

import java.io.*;
import java.util.*;
import java.util.stream.Collectors;
@Slf4j
public class BomGenerator {
    static int carId=3707;
    static String[] subscriptions = {"apps-dev-002"};

    public static void main(String[] args) throws IOException {
        List<Resource> allResources = new ArrayList<>();
        for(String sub: subscriptions) {
            runPowerShellCommand("az account set --subscription " + sub);
            JsonMapper.builder().configure(MapperFeature.ACCEPT_CASE_INSENSITIVE_PROPERTIES, true);
            ObjectMapper objectMapper = new ObjectMapper();
            objectMapper.setPropertyNamingStrategy(PropertyNamingStrategies.SNAKE_CASE);
            List<Resource> resources = objectMapper.readValue(runPowerShellCommand("az resource list --tag car_id=" + carId),
                    objectMapper.getTypeFactory().constructCollectionType(List.class, Resource.class));
            allResources.addAll(resources);
        }
        List<Resource> kvResources =  new ArrayList<>();
        List<Resource> umiResources = new ArrayList<>();
        List<Resource> peResources = new ArrayList<>();
        List<Resource> nsgResources = new ArrayList<>();
        List<Resource> vmResources = new ArrayList<>();
        XSSFWorkbook workbook = new XSSFWorkbook();
        for(Resource resource:allResources)
        {
            if(resource.getType().equals("Microsoft.KeyVault/vaults"))
                kvResources.add(resource);

            else if(resource.getType().equals("Microsoft.ManagedIdentity/userAssignedIdentities"))
                umiResources.add(resource);

            else if(resource.getType().equals("Microsoft.Network/privateEndpoints"))
                peResources.add(resource);

            else if(resource.getType().equals("Microsoft.Network/networkSecurityGroups"))
                nsgResources.add(resource);

            else if(resource.getType().equals("Microsoft.Compute/virtualMachines"))
                vmResources.add(resource);

        }
        generateKvSheet(kvResources , workbook);
        generateUmiSheet(umiResources,workbook);
        generatePeSheet(peResources, workbook);
        generateNsgSheet(nsgResources, workbook);



        try {
            FileOutputStream out = new FileOutputStream(
                    new File("bom-"+carId+".xlsx"));
            workbook.write(out);
            out.close();
            System.out.println("xlsx written successfully on disk");
        }
        catch (Exception e) {
            e.printStackTrace();
        }
    }
    public static void generateKvSheet(List<Resource> resources, XSSFWorkbook workbook) throws IOException {
        JsonMapper.builder().configure(MapperFeature.ACCEPT_CASE_INSENSITIVE_PROPERTIES, true);
        ObjectMapper objectMapper = new ObjectMapper();
        objectMapper.setPropertyNamingStrategy(PropertyNamingStrategies.SNAKE_CASE);
    Map<String, Object[]> data
                = new TreeMap<String, Object[]>();
        // Creating a blank Excel sheet
        XSSFSheet sheet
                = workbook.getSheet("Key Vault");

        for(Resource resource:resources) {
            Kv keyvault = objectMapper.readValue(runPowerShellCommand("az resource show --id " +  resource.getId()), Kv.class);
            System.out.println(keyvault.getProperties().getSku().getName());

            if (sheet == null) {
                sheet
                        = workbook.createSheet("Key Vault");
            }
            data.put("1", new Object[]{"Environment", "Action", "Service Family", "Service Name", "Product Name", "Meter Name", "SKU Name", "Friendly Name", "Resource Group Name", "Resource Name", "Enabled For Deployment", "Enabled For Disk Encryption",
                    "Enabled_For Template Deployment", "Soft Delete Retention Days", "Purge Protection Enabled", "Secret", "Network ACLS - Bypass", "Network ACLS - Default Action", "Prefix", "Suffix", "Allowed IP Ranges", "Permitted Virtual Network Subnet IDs"});
            data.put(keyvault.getName(),
                    new Object[]{keyvault.getTags().getEnvironment(), "create", "Security", "Key Vault", "Key Vault", "Operations", keyvault.getProperties().getSku().getName(), "Key Vault", keyvault.getResourceGroup(), keyvault.getName(),
                            keyvault.getProperties().getEnabledForDeployment(), keyvault.getProperties().getEnabledForDiskEncryption(), keyvault.getProperties().getEnabledForTemplateDeployment(), "7 Days",
                            keyvault.getProperties().getEnablePurgeProtection(), "",
                            keyvault.getProperties().getNetworkAcls().getBypass(), keyvault.getProperties().getNetworkAcls().getDefaultAction(), "", "", keyvault.getProperties().getNetworkAcls().getIpRules().get(0), ""});

            data.put(keyvault.getName()+"-it",
                    new Object[]{"it", "create", "Security", "Key Vault", "Key Vault", "Operations", keyvault.getProperties().getSku().getName(), "Key Vault", keyvault.getResourceGroup().replace("dev" , "it"), keyvault.getName().replace("dev" , "it"),
                            keyvault.getProperties().getEnabledForDeployment(), keyvault.getProperties().getEnabledForDiskEncryption(), keyvault.getProperties().getEnabledForTemplateDeployment(), "7 Days",
                            keyvault.getProperties().getEnablePurgeProtection(), "",
                            keyvault.getProperties().getNetworkAcls().getBypass(), keyvault.getProperties().getNetworkAcls().getDefaultAction(), "", "", keyvault.getProperties().getNetworkAcls().getIpRules().get(0), ""});
            data.put(keyvault.getName()+"-uat",
                    new Object[]{"uat", "create", "Security", "Key Vault", "Key Vault", "Operations", keyvault.getProperties().getSku().getName(), "Key Vault", keyvault.getResourceGroup().replace("dev" , "uat"), keyvault.getName().replace("dev" , "uat"),
                            keyvault.getProperties().getEnabledForDeployment(), keyvault.getProperties().getEnabledForDiskEncryption(), keyvault.getProperties().getEnabledForTemplateDeployment(), "7 Days",
                            keyvault.getProperties().getEnablePurgeProtection(), "",
                            keyvault.getProperties().getNetworkAcls().getBypass(), keyvault.getProperties().getNetworkAcls().getDefaultAction(), "", "", keyvault.getProperties().getNetworkAcls().getIpRules().get(0), ""});
            data.put(keyvault.getName()+"-zprod",
                    new Object[]{"prod", "create", "Security", "Key Vault", "Key Vault", "Operations", keyvault.getProperties().getSku().getName(), "Key Vault", keyvault.getResourceGroup().replace("dev" , "prod"), keyvault.getName().replace("dev" , "prod"),
                            keyvault.getProperties().getEnabledForDeployment(), keyvault.getProperties().getEnabledForDiskEncryption(), keyvault.getProperties().getEnabledForTemplateDeployment(), "7 Days",
                            keyvault.getProperties().getEnablePurgeProtection(), "",
                            keyvault.getProperties().getNetworkAcls().getBypass(), keyvault.getProperties().getNetworkAcls().getDefaultAction(), "", "", keyvault.getProperties().getNetworkAcls().getIpRules().get(0), ""});

        }
        Set<String> keyset = data.keySet();
        int rownum = 0;
        for (String key : keyset) {
            Row row = sheet.createRow(rownum++);
            Object[] objArr = data.get(key);
            int cellnum = 0;
            for (Object obj : objArr) {
                Cell cell = row.createCell(cellnum++);
                if (obj instanceof String)
                    cell.setCellValue((String)obj);
                else if (obj instanceof Integer)
                    cell.setCellValue((Integer)obj);
            }
        }
    }
    public static void generateUmiSheet(List<Resource> resources, XSSFWorkbook workbook) throws IOException {
        JsonMapper.builder().configure(MapperFeature.ACCEPT_CASE_INSENSITIVE_PROPERTIES, true);
        ObjectMapper objectMapper = new ObjectMapper();
        objectMapper.setPropertyNamingStrategy(PropertyNamingStrategies.SNAKE_CASE);
   Map<String, Object[]> data
                = new TreeMap<String, Object[]>();

        XSSFSheet sheet
                = workbook.getSheet("Managed Identity");
        for(Resource resource:resources) {
            Umi umi = objectMapper.readValue(runPowerShellCommand("az resource show --id " +  resource.getId()), Umi.class);
            System.out.println(umi.getProperties().getTenantId());

            if (sheet == null) {
                sheet
                        = workbook.createSheet("Managed Identity");
            }
            data.put("1", new Object[]{"Environment","Action","Service Name","Resource Group Name", "User Managed Identity Name","Identity Type","VM Name","umi additional tags"});
            data.put(umi.getName(),
                    new Object[]{umi.getTags().getEnvironment(), "create", "User Managed Identity", umi.getResourceGroup(), umi.getName(),
                            umi.getType(), "",""});
            data.put(umi.getName()+"-it",
                    new Object[]{"it", "create", "User Managed Identity", umi.getResourceGroup().replace("dev" ,"it"), umi.getName().replace("dev" ,"it"),
                            umi.getType(), "",""});
            data.put(umi.getName()+"-uat",
                    new Object[]{"uat", "create", "User Managed Identity", umi.getResourceGroup().replace("dev" ,"uat"), umi.getName().replace("dev" ,"uat"),
                            umi.getType(), "",""});
            data.put(umi.getName()+"-zprod",
                    new Object[]{"prod", "create", "User Managed Identity", umi.getResourceGroup().replace("dev" ,"prod"), umi.getName().replace("dev" ,"prod"),
                            umi.getType(), "",""});

        }
        Set<String> keyset = data.keySet();
        int rownum = 0;
        for (String key : keyset) {
            Row row = sheet.createRow(rownum++);
            Object[] objArr = data.get(key);
            int cellnum = 0;
            for (Object obj : objArr) {
                Cell cell = row.createCell(cellnum++);
                if (obj instanceof String)
                    cell.setCellValue((String)obj);
                else if (obj instanceof Integer)
                    cell.setCellValue((Integer)obj);
            }
        }
    }
    public static void generatePeSheet(List<Resource> resources, XSSFWorkbook workbook) throws IOException {
        JsonMapper.builder().configure(MapperFeature.ACCEPT_CASE_INSENSITIVE_PROPERTIES, true);
        ObjectMapper objectMapper = new ObjectMapper();
        objectMapper.setPropertyNamingStrategy(PropertyNamingStrategies.SNAKE_CASE);
   Map<String, Object[]> data
                = new TreeMap<String, Object[]>();
        XSSFSheet sheet
                = workbook.getSheet("Pvt Endpoint");
        for(Resource resource:resources) {
            PrivateEndpoint pe = objectMapper.readValue(runPowerShellCommand("az resource show --id " +  resource.getId()), PrivateEndpoint.class);
            System.out.println(pe.getResourceGroup());

            if (sheet == null) {
                sheet
                        = workbook.createSheet("Pvt Endpoint");
            }
            data.put("1", new Object[]{"Environment","Action","Friendly Name","Resource Name","Subnet ID", "Group IDs" ,"Approval Required", "Approval Message"	, "DNS Zone Names" ,"DNS Zone Group Name" ,"Private Connection Address ID",	"Resource Group Name"});
            data.put(pe.getName(),
                    new Object[]{pe.getTags().getEnvironment(), "create" , "Private Endpoint" , pe.getName() , pe.getProperties().getSubnet().getId() , pe.getProperties().getPrivateLinkServiceConnections().get(0).getProperties().getGroupIds() ,
                            pe.getProperties().getPrivateLinkServiceConnections().get(0).getProperties().getPrivateLinkServiceConnectionState().getActionsRequired() ,
                            pe.getProperties().getPrivateLinkServiceConnections().get(0).getProperties().getPrivateLinkServiceConnectionState().getDescription() ,"" , "" ,  pe.getProperties().getSubnet().getId() , pe.getProperties().getPrivateLinkServiceConnections().get(0).getId() , pe.getResourceGroup()});
            data.put(pe.getName()+"-it",
                    new Object[]{"it", "create" , "Private Endpoint" , pe.getName().replace("dev" ,"it") , pe.getProperties().getSubnet().getId().replace("dev" ,"it") , pe.getProperties().getPrivateLinkServiceConnections().get(0).getProperties().getGroupIds() ,
                            pe.getProperties().getPrivateLinkServiceConnections().get(0).getProperties().getPrivateLinkServiceConnectionState().getActionsRequired() ,
                            pe.getProperties().getPrivateLinkServiceConnections().get(0).getProperties().getPrivateLinkServiceConnectionState().getDescription() ,"" , "" ,
                            pe.getProperties().getSubnet().getId() , pe.getProperties().getPrivateLinkServiceConnections().get(0).getId().replace("dev" ,"it") , pe.getResourceGroup().replace("dev" ,"it")});
            data.put(pe.getName()+"-uat",
                    new Object[]{"uat", "create" , "Private Endpoint" , pe.getName().replace("dev" ,"uat") , pe.getProperties().getSubnet().getId().replace("dev" ,"uat") , pe.getProperties().getPrivateLinkServiceConnections().get(0).getProperties().getGroupIds() ,
                            pe.getProperties().getPrivateLinkServiceConnections().get(0).getProperties().getPrivateLinkServiceConnectionState().getActionsRequired() ,
                            pe.getProperties().getPrivateLinkServiceConnections().get(0).getProperties().getPrivateLinkServiceConnectionState().getDescription() ,"" , "" ,
                            pe.getProperties().getSubnet().getId() , pe.getProperties().getPrivateLinkServiceConnections().get(0).getId().replace("dev" ,"uat") , pe.getResourceGroup().replace("dev" ,"it")});
            data.put(pe.getName()+"-zprod",
                    new Object[]{"prod", "create" , "Private Endpoint" , pe.getName().replace("dev" ,"prod") , pe.getProperties().getSubnet().getId().replace("dev" ,"prod") , pe.getProperties().getPrivateLinkServiceConnections().get(0).getProperties().getGroupIds() ,
                            pe.getProperties().getPrivateLinkServiceConnections().get(0).getProperties().getPrivateLinkServiceConnectionState().getActionsRequired() ,
                            pe.getProperties().getPrivateLinkServiceConnections().get(0).getProperties().getPrivateLinkServiceConnectionState().getDescription() ,"" , "" ,
                            pe.getProperties().getSubnet().getId() , pe.getProperties().getPrivateLinkServiceConnections().get(0).getId().replace("dev" ,"prod") , pe.getResourceGroup().replace("dev" ,"prod")});

        }
        Set<String> keyset = data.keySet();
        int rownum = 0;
        for (String key : keyset) {
            Row row = sheet.createRow(rownum++);
            Object[] objArr = data.get(key);
            int cellnum = 0;
            for (Object obj : objArr) {
                Cell cell = row.createCell(cellnum++);
                if (obj instanceof String)
                    cell.setCellValue((String)obj);
                else if (obj instanceof Integer)
                    cell.setCellValue((Integer)obj);
            }
        }

    }

    public static void generateNsgSheet(List<Resource> resources, XSSFWorkbook workbook) throws IOException {
        JsonMapper.builder().configure(MapperFeature.ACCEPT_CASE_INSENSITIVE_PROPERTIES, true);
        ObjectMapper objectMapper = new ObjectMapper();
        objectMapper.setPropertyNamingStrategy(PropertyNamingStrategies.SNAKE_CASE);
    Map<String, Object[]> data
                = new TreeMap<String, Object[]>();

        XSSFSheet sheet
                = workbook.getSheet("NSG");
        for(Resource resource:resources) {
            Nsg nsg = objectMapper.readValue(runPowerShellCommand("az resource show --id " +  resource.getId()), Nsg.class);
            System.out.println(nsg.getProperties().getResourceGuid());

            if (sheet == null) {
                sheet
                        = workbook.createSheet("NSG");
            }
            data.put("1", new Object[]{"Environment","Action","NSG Name","Resource Name","Resource Group Name","Subnet Name",
                    "Virtual Network Name","Virtual Network RG Name","Direction","Priority","Access",
                    "Protocol",	"Source Port Range","Destination Port Ranges","Source Address",
                    "Destination Address","Description",	"Source ASG IDs","Destination ASG IDs",	"Additional NSG Tags"});
            for(DefaultSecurityRule rule: nsg.getProperties().getDefaultSecurityRules())
                    data.put(nsg.getName(),
                                new Object[]{nsg.getTags().getEnvironment(), "create", nsg.getName() , rule.getName() , rule.getResourceGroup() ,  nsg.getProperties().getSubnets().get(0).getId() ,
                                        "Vnet"  , rule.getResourceGroup() , rule.getProperties().getDirection() , rule.getProperties().getPriority(),rule.getProperties().getAccess(),
                                        rule.getProperties().getProtocol(),rule.getProperties().getSourcePortRange() , rule.getProperties().getDestinationPortRange(),rule.getProperties().getSourceAddressPrefix(),
                                        rule.getProperties().getDestinationAddressPrefix(), rule.getProperties().getDescription()});


        }
        Set<String> keyset = data.keySet();
        int rownum = 0;
        for (String key : keyset) {
            Row row = sheet.createRow(rownum++);
            Object[] objArr = data.get(key);
            int cellnum = 0;
            for (Object obj : objArr) {
                Cell cell = row.createCell(cellnum++);
                if (obj instanceof String)
                    cell.setCellValue((String)obj);
                else if (obj instanceof Integer)
                    cell.setCellValue((Integer)obj);
            }
        }
    }


    public static String  runPowerShellCommand(String command) throws IOException {
        BufferedReader stdout = null;
        try {
        String fcommand = "powershell.exe " + command;
            System.out.println(fcommand);
        // Executing the command
        Process powerShellProcess = Runtime.getRuntime().exec(fcommand);
        // Getting the results
        powerShellProcess.getOutputStream().close();
         stdout = new BufferedReader(new InputStreamReader(
                powerShellProcess.getInputStream()));
            String output = stdout.lines().collect(Collectors.joining());
            log.info("Output : " + output );
        return output;
    } catch (IOException e) {
            throw new RuntimeException(e);
        } finally {
        stdout.close();
    }
    }
}
