package com.usbank.cme.dto;


//import lombok.AllArgsConstructor;
import lombok.Data;

@Data
public class DB {
    public int count;
    public ENV env; // DEV | IT | UAT | PROD
    public String sku;   //e.g. GP_Gen5
    public String capacity; // e.g. 4  (vCore or DTU or DWU)
    public String diskSizeInGB;
    public DBType dbType; // SQL | SQLMI
    public String tier; // e.g. GeneralPurpose
    public String family; // e.g. Gen5


    private String capacityUnits;


    public String getMeterUnits()
    {
        return capacityUnits;
    }
    public String formattedSkuName()
    {
        return capacity + " " + capacityUnits;
    }

    private String formattedTier;
    public String getFormattedTier()
    {
        return formattedTier;
    }

    public DB(int count, ENV env, String sku, String capacity, String diskSizeInGB, DBType dbType, String tier, String family)
    {
        this.count = count;
        this.env = env;
        this.sku = sku;
        this.capacity = capacity;
        this.diskSizeInGB = diskSizeInGB;
        this.dbType = dbType;
        this.tier = tier;
        this.family = family;
        initializeDB();
    }

    private void initializeDB() {
        switch (tier.toUpperCase().replace(" ", "")) {
            case ("GENERALPURPOSE"):
                capacityUnits = "vCore";
                formattedTier = "General Purpose";
                break;
            case ("PREMIUM"):
                capacityUnits = "DTU";
                formattedTier = "Premium";
                break;
            case ("BUSINESSCRITICAL"):
                capacityUnits = "vCore";
                formattedTier = "Business Critical";
                break;
            case ("STANDARD"):
                capacityUnits = "DTU";
                formattedTier = "Standard";
                break;
            case ("DATAWAREHOUSE"):
                capacityUnits = "DWU";
                formattedTier = "Data Warehouse";
                break;
            default:
                capacityUnits = "vCore";
                formattedTier = tier;
        }
    }
}
