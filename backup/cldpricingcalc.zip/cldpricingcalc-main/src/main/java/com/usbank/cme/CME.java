package com.usbank.cme;


import io.swagger.v3.oas.annotations.ExternalDocumentation;
import io.swagger.v3.oas.annotations.OpenAPIDefinition;
import io.swagger.v3.oas.annotations.info.Info;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.jdbc.DataSourceAutoConfiguration;
import org.springframework.boot.autoconfigure.jdbc.DataSourceTransactionManagerAutoConfiguration;
import org.springframework.boot.autoconfigure.orm.jpa.HibernateJpaAutoConfiguration;


@SpringBootApplication(exclude = {
		DataSourceAutoConfiguration.class,
		DataSourceTransactionManagerAutoConfiguration.class,
		HibernateJpaAutoConfiguration.class})

@OpenAPIDefinition(info = @Info(title = "Cloud Migration Engineering Tools", version = "1.0", description = "Cloud Migration Engineering Tools") ,externalDocs = @ExternalDocumentation(description = "Splunk URL" ,url = "https://elosusbaws.splunkcloud.com/en-US/app/search/search?q=search%20index%3D%22it_k8s_azure%22%20k8s.cluster.name%3D%22aks-cus-gen-dev-001%22%20%22k8s.namespace.name%22%3D%22azurebatchservices-dev-001%22%20%22container.image.name%22%3D%22regcusnonprod001.azurecr.io%2Fazurebatchservices%2Fcmetools%22&display.page.search.mode=smart&dispatch.sample_ratio=1&workload_pool=standard_perf&earliest=-15m&latest=now&display.events.type=raw&sid=1709611694.57571_CF2AD2BE-81CD-4FAB-B3C2-BF10F848065D" ))
public class CME {

	public static void main(String[] args) {
		SpringApplication.run(CME.class, args);
	}

}
