package com.usbank.cme.dto;

public enum ManagedDiskType {
    OSDISK,
    DATADISK
}
