package com.usbank.cme.utils;

import com.usbank.cme.dto.BomMetadata;
import org.apache.poi.ss.util.CellRangeAddress;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import java.util.HashMap;
import java.util.Map;

public class LBUtils {

    public static void createLBSheet(BomMetadata metadata, XSSFWorkbook workbook) {
        XSSFSheet sheet = workbook.getSheet("Load Balancer");


        HashMap<Integer, Object[]> data = new HashMap<Integer, Object[]>();
        int count = 2;

        for (Map.Entry<String, String> lb : metadata.getLbs().entrySet()) {
            if (sheet == null) {
                sheet = workbook.createSheet("Load Balancer");
                sheet.addMergedRegion(CellRangeAddress.valueOf("C1:H1"));
                ExcelUtils.changeColumnWidth(sheet, 30);
                ExcelUtils.createHeaderDataLoadBalancer(data);
            }
            data.put(++count,
                    new Object[]{"Development", "Create", "Networking", "Load Balancer", "Load Balancer", "Standard Included LB Rules and Outbound Rules", "Standard", 730, lb.getKey(), lb.getValue()});
            data.put(++count,
                    new Object[]{"Development", "Create", "Networking", "Load Balancer", "Load Balancer", "Standard Data Processed", "Standard", 1000, lb.getKey(), lb.getValue()});
        }
        ExcelUtils.putDataIntoCellsSorted(data, sheet);
    }


}
