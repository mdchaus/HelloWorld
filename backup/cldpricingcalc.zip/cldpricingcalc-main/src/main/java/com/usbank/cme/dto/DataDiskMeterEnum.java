package com.usbank.cme.dto;

import java.util.HashMap;
import java.util.Map;

public enum DataDiskMeterEnum {

    E1(4, "E1"),
    E2(8 , "E2" ),
    E3(16, "E3" ),
    E4(32, "E4" ),
    E6(64, "E6" ),
    E10(128, "E10"),
    E15(256, "E15"),
    E20(512, "E20"),
    E30(1024 ,"E30"),
    E40(2048 , "E40" ),
    E50(4096 , "E50"),
    E60(8192 , "E60" ),
    E70(16384, "E70" ),
    E80(32767 , "E80" );

    private static Map<Integer, DataDiskMeterEnum> valueToTextMapping;
    private final Integer value;
    private final String text;
    private DataDiskMeterEnum(Integer value, String text){
        this.value = value;
        this.text = text;
    }

    public static DataDiskMeterEnum getDiskMeter(Integer i){
        if(valueToTextMapping == null){
            initMapping();
        }
        return valueToTextMapping.get(i);
    }

    private static void initMapping(){
        valueToTextMapping = new HashMap<>();
        for(DataDiskMeterEnum s : values()){
            valueToTextMapping.put(s.value, s);
        }
    }

    public Integer getValue(){
        return value;
    }

    public String getText(){
        return text;
    }
}

