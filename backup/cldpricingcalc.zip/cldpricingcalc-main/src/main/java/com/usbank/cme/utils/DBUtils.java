package com.usbank.cme.utils;

import com.usbank.cme.dto.BomMetadata;
import com.usbank.cme.dto.DB;
import com.usbank.cme.dto.DBType;
import org.apache.poi.ss.util.CellRangeAddress;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import java.util.HashMap;

public class DBUtils {

    public static void createDBSQLSheet(BomMetadata metadata, XSSFWorkbook workbook) {
        HashMap<Integer, Object[]> data = new HashMap<Integer, Object[]>();
        XSSFSheet sheet = null;
        int count = 2;
        for (DB db : metadata.getDbs()) {
            sheet = workbook.getSheet("DB-" + db.getDbType().name());

            if (sheet == null) {
                sheet = workbook.createSheet("DB-" + db.getDbType().name());
                ExcelUtils.changeColumnWidth(sheet, 30);
                ExcelUtils.createHeaderData(data);
                sheet.addMergedRegion(CellRangeAddress.valueOf("C1:H1"));
            }

            String env = db.getEnv().name().toUpperCase().trim();
            String serviceName = db.getDbType().equals(DBType.SQLMI) ? "SQL Managed Instance" : "SQL Database";
            String productNameCompute =    serviceName + " Single/Elastic Pool " + db.getFormattedTier() + " - Compute " + db.family;
            String productNameStorage =    serviceName + " Single/Elastic Pool " + db.getFormattedTier() + " - Storage";
            String serviceNamePITRStorageExtension =  db.getDbType().equals(DBType.SQLMI) ? " PITR Backup Storage" : " Single/Elastic Pool PITR Backup Storage" ;
            String meterName = db.getCapacityUnits();
            String tier = db.getFormattedTier();
            String envToPrint;


            if (env.equals("DEV"))
                envToPrint = "Development";
            else if (env.equals("IT"))
                envToPrint = "IT";
            else if (env.equals("UATPRIMARY"))
                envToPrint = "UAT-primary";
            else if (env.equals("UATSECONDARY"))
                envToPrint = "UAT-secondary";
            else if (env.equals("PRODPRIMARY"))
                envToPrint = "PROD-primary";
            else if (env.equals("PRODSECONDARY"))
                envToPrint = "PROD-Secondary";
            else
                envToPrint = env;

            for (int i = 1; i <= db.getCount(); i++) {

                data.put(++count, new Object[]{envToPrint, "Create", "Databases", serviceName, productNameCompute, meterName,             db.getSku(), 730});
                data.put(++count, new Object[]{envToPrint, "Create", "Databases", serviceName, productNameStorage, tier + " Data Stored", tier,        db.getDiskSizeInGB()});
                data.put(++count, new Object[]{envToPrint, "Create", "Databases", serviceName, serviceName + serviceNamePITRStorageExtension, "LRS Data Stored", "Backup LRS", 1});
                data.put(++count, new Object[]{envToPrint, "Create", "Databases", serviceName, serviceName + " - LTR Backup Storage", "Backup LRS Data Stored", "Backup LRS", 5});
                data.put(++count, new Object[]{""});
            }

        }
        ExcelUtils.putDataIntoCellsSorted(data, sheet);

    }



}
