package com.usbank.cme.controller;


import com.usbank.cme.dto.*;
import com.usbank.cme.service.BOMGeneratorServiceV1;
import com.usbank.cme.service.BomFromMetadataService;
import com.usbank.cme.utils.Base58Decode;
import com.usbank.cme.utils.Base64Decode;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.InputStreamResource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.io.IOException;
import java.util.concurrent.ExecutionException;

import com.usbank.cme.resourcemanager.ManagedDiskSkuEnum;
import com.usbank.cme.resourcemanager.SqlDbSkuEnum;
import com.usbank.cme.resourcemanager.VmSkuEnum;

@org.springframework.web.bind.annotation.RestController
@RequestMapping("/")
@Slf4j
public class RestController {

    @Autowired
    private BOMGeneratorServiceV1 bomGeneratorService;

    @Autowired
    private BomFromMetadataService bomFromMetadataService;


    @PostMapping(value = "/generateBOM")
    public ResponseEntity<?> createBom(@RequestParam String carId, @RequestParam String subscriptions, @RequestParam Boolean isSecondaryRegion) throws Exception {

        String filename = "bom-" + carId + ".xlsx";
        InputStreamResource file = new InputStreamResource(bomGeneratorService.generateBomFromAzure(carId, subscriptions, isSecondaryRegion));
        log.info("Returning the file to browser now");
        return ResponseEntity.ok()
                .header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=" + filename)
                .contentType(MediaType.parseMediaType("application/vnd.ms-excel"))
                .body(file);

    }

    @PostMapping(value = "/base58decode")
    public ResponseEntity<?> base58decode(@RequestParam String base58EncodedString) throws Exception {
        return ResponseEntity.ok().body(Base58Decode.decode(base58EncodedString));

    }

    @PostMapping(value = "/base64decode")
    public ResponseEntity<?> base64Decode(@RequestParam String base64EncodedString) throws Exception {
        return ResponseEntity.ok().body(Base64Decode.decode(base64EncodedString));

    }


    @PostMapping("/generateBOMFromMetadata")
    public ResponseEntity<?> generateFromMetadata(@RequestParam String carId, @RequestParam Boolean isSecondaryRegion,
                                                  @RequestParam String appContextNames, @RequestParam String devSubscriptions,
                                                  @RequestParam(defaultValue = "false") Boolean hasVirtualMachines,
                                                  @RequestParam(defaultValue = "false") Boolean hasDatabase,

                                                  // VMs section
                                                  @RequestParam VMType osType,
                                                  @RequestParam VMMaintenanceType maintenanceType,
                                                  @RequestParam(defaultValue = "0") int noOfLBs,

                                                  @RequestParam(defaultValue = "0") int noOfDevVms, @RequestParam(name = "dev vm sku", defaultValue = "NONE", required = false) VmSkuEnum devVmSku, @RequestParam(name = "dev vm os disk sku", defaultValue = "NONE", required = false) ManagedDiskSkuEnum devVmOsDiskSku, @RequestParam(name = "dev vm data disk sku", defaultValue = "NONE", required = false) ManagedDiskSkuEnum devVmDataDiskSku,
                                                  @RequestParam(defaultValue = "0") int noOfItVms, @RequestParam(name = "it vm sku", defaultValue = "NONE", required = false) VmSkuEnum itVmSku, @RequestParam(name = "it vm os disk sku", defaultValue = "NONE", required = false) ManagedDiskSkuEnum itVmOsDiskSku, @RequestParam(name = "it vm data disk sku", defaultValue = "NONE", required = false) ManagedDiskSkuEnum itVmDataDiskSku,
                                                  @RequestParam(defaultValue = "0") int noOfUatVms, @RequestParam(name = "uat vm sku", defaultValue = "NONE", required = false) VmSkuEnum uatVmSku, @RequestParam(name = "uat vm os disk sku", defaultValue = "NONE", required = false) ManagedDiskSkuEnum uatVmOsDiskSku, @RequestParam(name = "uat vm data disk sku", defaultValue = "NONE", required = false) ManagedDiskSkuEnum uatVmDataDiskSku,
                                                  @RequestParam(defaultValue = "0") int noOfProdVms, @RequestParam(name = "prod vm sku", defaultValue = "NONE", required = false) VmSkuEnum prodVmSku, @RequestParam(name = "prod vm os disk sku", defaultValue = "NONE", required = false) ManagedDiskSkuEnum prodVmOsDiskSku, @RequestParam(name = "prod vm data disk sku", defaultValue = "NONE", required = false) ManagedDiskSkuEnum prodVmDataDiskSku,

                                                  // DB section
                                                  @RequestParam(defaultValue = "SQL") DBType dBType,
                                                  @RequestParam(name = "dev db sku", defaultValue = "NONE", required = false) SqlDbSkuEnum devDbSku, @RequestParam(name = "dev db disk sku", defaultValue = "NONE", required = false) ManagedDiskSkuEnum devDbDiskSku,
                                                  @RequestParam(name = "it db sku", defaultValue = "NONE", required = false) SqlDbSkuEnum itDbSku, @RequestParam(name = "it db disk sku", defaultValue = "NONE", required = false) ManagedDiskSkuEnum itDbDiskSku,
                                                  @RequestParam(name = "uat db sku", defaultValue = "NONE", required = false) SqlDbSkuEnum uatDbSku, @RequestParam(name = "uat db disk sku", defaultValue = "NONE", required = false) ManagedDiskSkuEnum uatDbDiskSku,
                                                  @RequestParam(name = "prod db sku", defaultValue = "NONE", required = false) SqlDbSkuEnum prodDbSku, @RequestParam(name = "prod db disk sku", defaultValue = "NONE", required = false) ManagedDiskSkuEnum prodDbDiskSku
    )
            throws IOException, ExecutionException, InterruptedException {


        Boolean paramsOk = true;

        String errorStr = "";


        if (!paramsOk) {
            return ResponseEntity.badRequest().body(errorStr);
        } else {
            String filename = "bom-" + carId + ".xlsx";

            InputStreamResource file = new InputStreamResource(bomFromMetadataService.generateBomFromMetadata(
                    carId,
                    isSecondaryRegion,
                    appContextNames,
                    devSubscriptions,
                    hasVirtualMachines,
                    hasDatabase,
                    osType,
                    maintenanceType,
                    noOfLBs,

                    noOfDevVms,
                    devVmSku,
                    devVmOsDiskSku,
                    devVmDataDiskSku,

                    noOfItVms,
                    itVmSku,
                    itVmOsDiskSku,
                    itVmDataDiskSku,

                    noOfUatVms,
                    uatVmSku,
                    uatVmOsDiskSku,
                    uatVmDataDiskSku,

                    noOfProdVms,
                    prodVmSku,
                    prodVmOsDiskSku,
                    prodVmDataDiskSku,

                    dBType,

                    devDbSku,
                    devDbDiskSku,

                    itDbSku,
                    itDbDiskSku,

                    uatDbSku,
                    uatDbDiskSku,

                    prodDbSku,
                    prodDbDiskSku)
            );

            log.info("Returning the file to browser now");
            return ResponseEntity.ok()
                    .header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=" + filename)
                    .contentType(MediaType.parseMediaType("application/vnd.ms-excel"))
                    .body(file);

        }
    }


}
