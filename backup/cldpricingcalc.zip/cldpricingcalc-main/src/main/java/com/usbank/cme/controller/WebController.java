package com.usbank.cme.controller;

import com.usbank.cme.dto.BomRequestDto;
import com.usbank.cme.service.BOMGeneratorServiceV1;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.InputStreamResource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;


@Controller
@RequestMapping("/web")
public class WebController {

    @Autowired
    BOMGeneratorServiceV1 bomGeneratorService;

    @GetMapping("/index")
    public String displayDashboard(Model model) {
        model.addAttribute("bomRequest", new BomRequestDto());
        return "main";
    }

    @PostMapping(value="/generateBOM" )
    public ResponseEntity<?> createBom( Model model ,BomRequestDto bomRequestDto ) throws Exception {
        model.addAttribute("bomRequest", bomRequestDto);
        String filename = "bom-"+bomRequestDto.getCarId()+".xlsx";
        InputStreamResource file = new InputStreamResource(bomGeneratorService.generateBomFromAzure(bomRequestDto.getCarId(),bomRequestDto.getSubscriptions() , bomRequestDto.getSecondaryRegion()));
        return ResponseEntity.ok()
                .header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=" + filename)
                .contentType(MediaType.parseMediaType("application/vnd.ms-excel"))
                .body(file);
    }
}
