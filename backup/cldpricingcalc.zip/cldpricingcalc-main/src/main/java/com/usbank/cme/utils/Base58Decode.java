package com.usbank.cme.utils;

import java.math.BigInteger;
import java.nio.charset.StandardCharsets;

public class Base58Decode {

        private static final String ALPHABET = "123456789ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz";


    public static String decode(String input) {
        BigInteger bi = BigInteger.ZERO;
        for (char c : input.toCharArray()) {
            bi = bi.multiply(BigInteger.valueOf(58));
            int index = ALPHABET.indexOf(c);
            if (index == -1) {
                throw new IllegalArgumentException("Invalid character in Base58 string: " + c);
            }
            bi = bi.add(BigInteger.valueOf(index));
        }

        byte[] bytes = bi.toByteArray();
        if (bytes[0] == 0) {
            byte[] tmp = new byte[bytes.length - 1];
            System.arraycopy(bytes, 1, tmp, 0, tmp.length);
            bytes = tmp;
        }

        return new String(bytes, StandardCharsets.UTF_8);
    }
}
