package com.usbank.cme.utils;

import com.usbank.cme.dto.BomMetadata;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import java.util.HashMap;

public class ResourceGroupUtils {

    public static void createResourceGroupSheet(BomMetadata metadata, XSSFWorkbook workbook) {
        XSSFSheet sheet = workbook.getSheet("Resource Group");


        HashMap<Integer, Object[]> data = new HashMap<Integer, Object[]>();
        int count = 2;

        if (sheet == null) {
            sheet = workbook.createSheet("Resource Group");
            ExcelUtils.changeColumnWidth(sheet, 25);
            data.put(1, new Object[]{""});
            data.put(2, new Object[]{"Environment", "Action", "Friendly Name", "Resource Name", "Location", "maintenance_type"});
        }

        for (String rg: metadata.getRgs()) {
            data.put(++count, new Object[]{"Development", "create", "Application Resource Group", rg, "Central US", "Pet"});

            data.put(++count, new Object[]{"IT", "create", "Application Resource Group",rg.replace("dev" , "it"), "Central US", "Pet"});
            data.put(++count, new Object[]{"UAT-Primary", "create", "Application Resource Group", rg.replace("dev" , "uat"), "Central US", "Pet"});
            data.put(++count, new Object[]{"Production-Primary", "create", "Application Resource Group", rg.replace("dev" , "prod"), "Central US", "Pet"});
            if (metadata.getSecondaryRegion() == Boolean.TRUE) {
                data.put(++count, new Object[]{"UAT-Secondary", "create", "Application Resource Group", rg.replace("dev" , "uat").replace("cus" , "eus2"), "East US", "Pet"});
                data.put(++count, new Object[]{"Production-Secondary", "create", "Application Resource Group", rg.replace("dev" , "prod").replace("cus" , "eus2"), "East US", "Pet"});
            }
        }
        ExcelUtils.putDataIntoCellsSorted(data, sheet);
    }
}
