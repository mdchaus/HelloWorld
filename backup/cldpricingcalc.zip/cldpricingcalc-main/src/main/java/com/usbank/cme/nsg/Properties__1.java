
package com.usbank.cme.nsg;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import javax.annotation.Generated;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "access",
    "description",
    "destinationAddressPrefix",
    "destinationAddressPrefixes",
    "destinationPortRange",
    "destinationPortRanges",
    "direction",
    "priority",
    "protocol",
    "provisioningState",
    "sourceAddressPrefix",
    "sourceAddressPrefixes",
    "sourcePortRange",
    "sourcePortRanges"
})
@Generated("jsonschema2pojo")
public class Properties__1 {

    @JsonProperty("access")
    private String access;
    @JsonProperty("description")
    private String description;
    @JsonProperty("destinationAddressPrefix")
    private String destinationAddressPrefix;
    @JsonProperty("destinationAddressPrefixes")
    private List<Object> destinationAddressPrefixes;
    @JsonProperty("destinationPortRange")
    private String destinationPortRange;
    @JsonProperty("destinationPortRanges")
    private List<Object> destinationPortRanges;
    @JsonProperty("direction")
    private String direction;
    @JsonProperty("priority")
    private Integer priority;
    @JsonProperty("protocol")
    private String protocol;
    @JsonProperty("provisioningState")
    private String provisioningState;
    @JsonProperty("sourceAddressPrefix")
    private String sourceAddressPrefix;
    @JsonProperty("sourceAddressPrefixes")
    private List<Object> sourceAddressPrefixes;
    @JsonProperty("sourcePortRange")
    private String sourcePortRange;
    @JsonProperty("sourcePortRanges")
    private List<Object> sourcePortRanges;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new LinkedHashMap<String, Object>();

    @JsonProperty("access")
    public String getAccess() {
        return access;
    }

    @JsonProperty("access")
    public void setAccess(String access) {
        this.access = access;
    }

    @JsonProperty("description")
    public String getDescription() {
        return description;
    }

    @JsonProperty("description")
    public void setDescription(String description) {
        this.description = description;
    }

    @JsonProperty("destinationAddressPrefix")
    public String getDestinationAddressPrefix() {
        return destinationAddressPrefix;
    }

    @JsonProperty("destinationAddressPrefix")
    public void setDestinationAddressPrefix(String destinationAddressPrefix) {
        this.destinationAddressPrefix = destinationAddressPrefix;
    }

    @JsonProperty("destinationAddressPrefixes")
    public List<Object> getDestinationAddressPrefixes() {
        return destinationAddressPrefixes;
    }

    @JsonProperty("destinationAddressPrefixes")
    public void setDestinationAddressPrefixes(List<Object> destinationAddressPrefixes) {
        this.destinationAddressPrefixes = destinationAddressPrefixes;
    }

    @JsonProperty("destinationPortRange")
    public String getDestinationPortRange() {
        return destinationPortRange;
    }

    @JsonProperty("destinationPortRange")
    public void setDestinationPortRange(String destinationPortRange) {
        this.destinationPortRange = destinationPortRange;
    }

    @JsonProperty("destinationPortRanges")
    public List<Object> getDestinationPortRanges() {
        return destinationPortRanges;
    }

    @JsonProperty("destinationPortRanges")
    public void setDestinationPortRanges(List<Object> destinationPortRanges) {
        this.destinationPortRanges = destinationPortRanges;
    }

    @JsonProperty("direction")
    public String getDirection() {
        return direction;
    }

    @JsonProperty("direction")
    public void setDirection(String direction) {
        this.direction = direction;
    }

    @JsonProperty("priority")
    public Integer getPriority() {
        return priority;
    }

    @JsonProperty("priority")
    public void setPriority(Integer priority) {
        this.priority = priority;
    }

    @JsonProperty("protocol")
    public String getProtocol() {
        return protocol;
    }

    @JsonProperty("protocol")
    public void setProtocol(String protocol) {
        this.protocol = protocol;
    }

    @JsonProperty("provisioningState")
    public String getProvisioningState() {
        return provisioningState;
    }

    @JsonProperty("provisioningState")
    public void setProvisioningState(String provisioningState) {
        this.provisioningState = provisioningState;
    }

    @JsonProperty("sourceAddressPrefix")
    public String getSourceAddressPrefix() {
        return sourceAddressPrefix;
    }

    @JsonProperty("sourceAddressPrefix")
    public void setSourceAddressPrefix(String sourceAddressPrefix) {
        this.sourceAddressPrefix = sourceAddressPrefix;
    }

    @JsonProperty("sourceAddressPrefixes")
    public List<Object> getSourceAddressPrefixes() {
        return sourceAddressPrefixes;
    }

    @JsonProperty("sourceAddressPrefixes")
    public void setSourceAddressPrefixes(List<Object> sourceAddressPrefixes) {
        this.sourceAddressPrefixes = sourceAddressPrefixes;
    }

    @JsonProperty("sourcePortRange")
    public String getSourcePortRange() {
        return sourcePortRange;
    }

    @JsonProperty("sourcePortRange")
    public void setSourcePortRange(String sourcePortRange) {
        this.sourcePortRange = sourcePortRange;
    }

    @JsonProperty("sourcePortRanges")
    public List<Object> getSourcePortRanges() {
        return sourcePortRanges;
    }

    @JsonProperty("sourcePortRanges")
    public void setSourcePortRanges(List<Object> sourcePortRanges) {
        this.sourcePortRanges = sourcePortRanges;
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

}
