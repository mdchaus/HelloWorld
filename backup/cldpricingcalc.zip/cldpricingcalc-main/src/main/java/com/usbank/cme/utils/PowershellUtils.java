package com.usbank.cme.utils;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.stream.Collectors;

public class PowershellUtils {

    public static String runPowerShellCommand(String command) throws IOException {
        BufferedReader stdout = null;
        try {
            String fcommand = "powershell.exe " + command;
            System.out.println(fcommand);
            // Executing the command
            Process powerShellProcess = Runtime.getRuntime().exec(fcommand);
            // Getting the results
            powerShellProcess.getOutputStream().close();
            stdout = new BufferedReader(new InputStreamReader(powerShellProcess.getInputStream()));
            String output = stdout.lines().collect(Collectors.joining());
            return output;
        } catch (IOException e) {
            throw new RuntimeException(e);
        } finally {
            stdout.close();
        }
    }
}
