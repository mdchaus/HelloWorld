package com.usbank.cme.service;

import com.azure.core.credential.TokenRequestContext;
import com.azure.core.http.policy.HttpLogDetailLevel;
import com.azure.core.management.AzureEnvironment;
import com.azure.core.management.Region;
import com.azure.core.management.profile.AzureProfile;
import com.azure.identity.ClientSecretCredential;
import com.azure.identity.ClientSecretCredentialBuilder;
import com.azure.identity.DefaultAzureCredential;
import com.azure.identity.DefaultAzureCredentialBuilder;
import com.azure.resourcemanager.AzureResourceManager;
import com.azure.resourcemanager.compute.models.ComputeResourceType;
import com.azure.security.keyvault.secrets.SecretClient;
import com.azure.security.keyvault.secrets.SecretClientBuilder;
import com.azure.security.keyvault.secrets.models.KeyVaultSecret;
import com.usbank.cme.dto.DBType;
import com.usbank.cme.dto.VMMaintenanceType;
import com.usbank.cme.dto.VMType;
import com.usbank.cme.resourcemanager.*;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.io.FileUtils;
import org.springframework.core.io.InputStreamResource;
import org.springframework.util.StringUtils;

import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;


@Slf4j
public class TestAzureSDK {

    private static final boolean runSkuTest = false;
    private static final boolean runBOMGeneratorServiceV1 = false;
    private static final boolean runBomFromMetadataService_1023 = false;
    private static final boolean runBomFromMetadataService_5378 = true;

    public static void main(String[] args) {

        //        String spsecret= "Tq38Q~NbZoAj4fscRxi1606-aDAmqpHnavQwvdg1";
//
//        ClientSecretCredential clientSecretCredential = new ClientSecretCredentialBuilder()
//                .clientId("2380d24c-c272-4469-89ec-82f6fdf17803")
//                .clientSecret(spsecret)
//                .tenantId("eef95730-77bf-4663-a55d-1ddff9335b5b")
//                .build();
//
//
//        AzureProfile profile = new AzureProfile(AzureEnvironment.AZURE);
//        HashMap<String,String> subscriptionMap= new HashMap<>();
//        List<ResourceGroup> resourceGroups = new ArrayList<>();
//        List<GenericResource> resources = new ArrayList<>();
//
//
//        AzureResourceManager.configure().withLogLevel(HttpLogDetailLevel.BODY_AND_HEADERS)
//                .authenticate(clientSecretCredential, profile)
//                .subscriptions().list().stream().forEach(
//                        s ->
//                            subscriptionMap.put(s.displayName() , s.subscriptionId()));
//       AzureResourceManager resourceManager =  AzureResourceManager.configure().withLogLevel(HttpLogDetailLevel.NONE)
//               .authenticate(clientSecretCredential, profile).withSubscription(subscriptionMap.get("apps-dev-001"));


        String spTenantId = "eef95730-77bf-4663-a55d-1ddff9335b5b";
        //ClientSecretCredential clientSecretCredential = new ClientSecretCredentialBuilder().clientId(spClientId).clientSecret(spSecret).tenantId(spTenantId).build();
        DefaultAzureCredential clientSecretCredential = new DefaultAzureCredentialBuilder().tenantId(spTenantId).build();

        AzureProfile profile = new AzureProfile(AzureEnvironment.AZURE);
        HashMap<String, String> subscriptionMap = new HashMap<>();
        AzureResourceManager.configure().withLogLevel(HttpLogDetailLevel.NONE)
                .authenticate(clientSecretCredential, profile)
                .subscriptions().list().stream().forEach(
                        s ->
                                subscriptionMap.put(s.displayName(), s.subscriptionId()));

        AzureResourceManager resourceManager = AzureResourceManager.configure().withLogLevel(HttpLogDetailLevel.NONE)
                .authenticate(clientSecretCredential, profile).withSubscription(subscriptionMap.get("apps-poc-001"));

        SecretClient secretClient = new SecretClientBuilder()
                .vaultUrl("https://kv-cus-abp03-dev-01.vault.azure.net/")
                .credential(clientSecretCredential)
                .buildClient();
        String token = clientSecretCredential
                .getToken(new TokenRequestContext()
                        .addScopes("https://redis.azure.com/.default")).block().getToken();
        System.out.println("token with redis scope " + token);

        AzureSkusForRegion skus = new AzureSkusForRegion(resourceManager);
        Map<String, String> computeSkuMap = new HashMap<>();
        System.out.println("Value of the storage key " + resourceManager.vaults().getByResourceGroup("rg-cus-abp03-dev-01" , "kv-cus-abp03-dev-01").secrets().getByName("sasgnc1lpoc01dabp0301-key").getValue());
        System.out.println("Value of the storage key " + resourceManager.vaults().getByResourceGroup("rg-cus-abp03-dev-01" , "kv-cus-abp03-dev-01").secrets().getByName("sasgnc1lpoc01dabp0301-key").attributes().getExpiresOn());
        String newKey=resourceManager.storageAccounts().getByResourceGroup("rg-cus-abp03-dev-01"  , "sasgnc1lpoc01dabp0301" ).regenerateKey("key1").get(0).value();
        System.out.println("New Storage Key "  +  newKey);
        //System.out.println("Update the KeyVault with the new key" +  resourceManager.vaults().getByResourceGroup("rg-cus-abp03-dev-01" , "kv-cus-abp03-dev-01").secretClient().setSecret(new KeyVaultSecret("sasgnc1lpoc01dabp0301-key" , newKey)));
        System.out.println("Update the KeyVault with the new key" + secretClient.setSecret(new KeyVaultSecret("sasgnc1lpoc01dabp0301-key" , newKey)));

    }
}



