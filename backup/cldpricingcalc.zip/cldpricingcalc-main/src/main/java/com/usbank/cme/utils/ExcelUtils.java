package com.usbank.cme.utils;

import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFSheet;

import java.util.HashMap;
import java.util.Set;

public class ExcelUtils {

    public static void changeColumnWidth(XSSFSheet sheet, int width) {
        for (int i = 0; i < 100; i++) {
            sheet.setColumnWidth(i, width * 256);
            sheet.setVerticallyCenter(Boolean.TRUE);
        }
    }

    public static void createHeaderDataLoadBalancer(HashMap<Integer, Object[]> data)
    {
        data.put(1, new Object[]{"","","Azure Pricing Information"});
        data.put(2, new Object[]{"Environment", "Action", "Service Family", "Service Name", "Product Name", "Meter Name", "SKU Name", "UOM", "Resource Name","Resource Group"});
    }
    public static void createHeaderDataWithFriendlyCol(HashMap<Integer, Object[]> data)
    {
        data.put(1, new Object[]{"","","Azure Pricing Information"});
        data.put(2, new Object[]{"Environment", "Action", "Service Family", "Service Name", "Product Name", "Meter Name", "SKU Name", "UOM", "Friendly Name"});
    }

    public static void createHeaderData(HashMap<Integer, Object[]> data)
    {
        data.put(1, new Object[]{"","","Azure Pricing Information"});
        data.put(2, new Object[]{"Environment", "Action", "Service Family", "Service Name", "Product Name", "Meter Name", "SKU Name", "UOM"});
    }


    public static CellStyle createHeaderCellStyle(XSSFSheet sheet) {
        // Create header CellStyle

        CellStyle headerCellStyle = sheet.getWorkbook().createCellStyle();
        // fill foreground color ...
        headerCellStyle.setFillForegroundColor(IndexedColors.BLUE_GREY.getIndex());
        // and solid fill pattern produces solid grey cell fill
        headerCellStyle.setFillPattern(FillPatternType.SOLID_FOREGROUND);
        return headerCellStyle;
    }


    public static CellStyle changeCellStyle(XSSFSheet sheet) {
        CellStyle style = sheet.getWorkbook().createCellStyle();
        style.setBorderBottom(BorderStyle.THIN);
        style.setBorderTop(BorderStyle.THIN);
        style.setBorderLeft(BorderStyle.THIN);
        style.setBorderRight(BorderStyle.THIN);
        return style;
    }

    public static void putDataIntoCellsSorted(HashMap<Integer, Object[]> data, XSSFSheet sheet) {
        Set<Integer> keyset = data.keySet();
        int rownum = 0;
        for (Integer key : keyset) {
            Row row = sheet.createRow(rownum++);
            Object[] objArr = data.get(key);
            int cellnum = 0;
            for (Object obj : objArr) {
                Cell cell = row.createCell(cellnum++);

                if (obj instanceof String) {
                    cell.setCellStyle(changeCellStyle(sheet));
                    cell.setCellValue((String) obj);
                } else if (obj instanceof Integer) {
                    cell.setCellStyle(changeCellStyle(sheet));
                    cell.setCellValue((Integer) obj);
                }

                if (key == 2) cell.setCellStyle(createHeaderCellStyle(sheet));
            }
        }
    }
}
