
package com.usbank.cme.vm;

import java.util.LinkedHashMap;
import java.util.Map;
import javax.annotation.Generated;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "autoUpgradeMinorVersion",
    "enableAutomaticUpgrade",
    "provisioningState",
    "publisher",
    "settings",
    "type",
    "typeHandlerVersion"
})
@Generated("jsonschema2pojo")
public class Properties__2 {

    @JsonProperty("autoUpgradeMinorVersion")
    private Boolean autoUpgradeMinorVersion;
    @JsonProperty("enableAutomaticUpgrade")
    private Boolean enableAutomaticUpgrade;
    @JsonProperty("provisioningState")
    private String provisioningState;
    @JsonProperty("publisher")
    private String publisher;
    @JsonProperty("settings")
    private Settings settings;
    @JsonProperty("type")
    private String type;
    @JsonProperty("typeHandlerVersion")
    private String typeHandlerVersion;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new LinkedHashMap<String, Object>();

    @JsonProperty("autoUpgradeMinorVersion")
    public Boolean getAutoUpgradeMinorVersion() {
        return autoUpgradeMinorVersion;
    }

    @JsonProperty("autoUpgradeMinorVersion")
    public void setAutoUpgradeMinorVersion(Boolean autoUpgradeMinorVersion) {
        this.autoUpgradeMinorVersion = autoUpgradeMinorVersion;
    }

    @JsonProperty("enableAutomaticUpgrade")
    public Boolean getEnableAutomaticUpgrade() {
        return enableAutomaticUpgrade;
    }

    @JsonProperty("enableAutomaticUpgrade")
    public void setEnableAutomaticUpgrade(Boolean enableAutomaticUpgrade) {
        this.enableAutomaticUpgrade = enableAutomaticUpgrade;
    }

    @JsonProperty("provisioningState")
    public String getProvisioningState() {
        return provisioningState;
    }

    @JsonProperty("provisioningState")
    public void setProvisioningState(String provisioningState) {
        this.provisioningState = provisioningState;
    }

    @JsonProperty("publisher")
    public String getPublisher() {
        return publisher;
    }

    @JsonProperty("publisher")
    public void setPublisher(String publisher) {
        this.publisher = publisher;
    }

    @JsonProperty("settings")
    public Settings getSettings() {
        return settings;
    }

    @JsonProperty("settings")
    public void setSettings(Settings settings) {
        this.settings = settings;
    }

    @JsonProperty("type")
    public String getType() {
        return type;
    }

    @JsonProperty("type")
    public void setType(String type) {
        this.type = type;
    }

    @JsonProperty("typeHandlerVersion")
    public String getTypeHandlerVersion() {
        return typeHandlerVersion;
    }

    @JsonProperty("typeHandlerVersion")
    public void setTypeHandlerVersion(String typeHandlerVersion) {
        this.typeHandlerVersion = typeHandlerVersion;
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

}
