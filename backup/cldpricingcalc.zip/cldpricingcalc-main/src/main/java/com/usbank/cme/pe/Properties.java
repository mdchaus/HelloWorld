
package com.usbank.cme.pe;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import javax.annotation.Generated;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "customDnsConfigs",
    "customNetworkInterfaceName",
    "ipConfigurations",
    "manualPrivateLinkServiceConnections",
    "networkInterfaces",
    "privateLinkServiceConnections",
    "provisioningState",
    "resourceGuid",
    "subnet"
})
@Generated("jsonschema2pojo")
public class Properties {

    @JsonProperty("customDnsConfigs")
    private List<Object> customDnsConfigs;
    @JsonProperty("customNetworkInterfaceName")
    private String customNetworkInterfaceName;
    @JsonProperty("ipConfigurations")
    private List<Object> ipConfigurations;
    @JsonProperty("manualPrivateLinkServiceConnections")
    private List<Object> manualPrivateLinkServiceConnections;
    @JsonProperty("networkInterfaces")
    private List<NetworkInterface> networkInterfaces;
    @JsonProperty("privateLinkServiceConnections")
    private List<PrivateLinkServiceConnection> privateLinkServiceConnections;
    @JsonProperty("provisioningState")
    private String provisioningState;
    @JsonProperty("resourceGuid")
    private String resourceGuid;
    @JsonProperty("subnet")
    private Subnet subnet;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new LinkedHashMap<String, Object>();

    @JsonProperty("customDnsConfigs")
    public List<Object> getCustomDnsConfigs() {
        return customDnsConfigs;
    }

    @JsonProperty("customDnsConfigs")
    public void setCustomDnsConfigs(List<Object> customDnsConfigs) {
        this.customDnsConfigs = customDnsConfigs;
    }

    @JsonProperty("customNetworkInterfaceName")
    public String getCustomNetworkInterfaceName() {
        return customNetworkInterfaceName;
    }

    @JsonProperty("customNetworkInterfaceName")
    public void setCustomNetworkInterfaceName(String customNetworkInterfaceName) {
        this.customNetworkInterfaceName = customNetworkInterfaceName;
    }

    @JsonProperty("ipConfigurations")
    public List<Object> getIpConfigurations() {
        return ipConfigurations;
    }

    @JsonProperty("ipConfigurations")
    public void setIpConfigurations(List<Object> ipConfigurations) {
        this.ipConfigurations = ipConfigurations;
    }

    @JsonProperty("manualPrivateLinkServiceConnections")
    public List<Object> getManualPrivateLinkServiceConnections() {
        return manualPrivateLinkServiceConnections;
    }

    @JsonProperty("manualPrivateLinkServiceConnections")
    public void setManualPrivateLinkServiceConnections(List<Object> manualPrivateLinkServiceConnections) {
        this.manualPrivateLinkServiceConnections = manualPrivateLinkServiceConnections;
    }

    @JsonProperty("networkInterfaces")
    public List<NetworkInterface> getNetworkInterfaces() {
        return networkInterfaces;
    }

    @JsonProperty("networkInterfaces")
    public void setNetworkInterfaces(List<NetworkInterface> networkInterfaces) {
        this.networkInterfaces = networkInterfaces;
    }

    @JsonProperty("privateLinkServiceConnections")
    public List<PrivateLinkServiceConnection> getPrivateLinkServiceConnections() {
        return privateLinkServiceConnections;
    }

    @JsonProperty("privateLinkServiceConnections")
    public void setPrivateLinkServiceConnections(List<PrivateLinkServiceConnection> privateLinkServiceConnections) {
        this.privateLinkServiceConnections = privateLinkServiceConnections;
    }

    @JsonProperty("provisioningState")
    public String getProvisioningState() {
        return provisioningState;
    }

    @JsonProperty("provisioningState")
    public void setProvisioningState(String provisioningState) {
        this.provisioningState = provisioningState;
    }

    @JsonProperty("resourceGuid")
    public String getResourceGuid() {
        return resourceGuid;
    }

    @JsonProperty("resourceGuid")
    public void setResourceGuid(String resourceGuid) {
        this.resourceGuid = resourceGuid;
    }

    @JsonProperty("subnet")
    public Subnet getSubnet() {
        return subnet;
    }

    @JsonProperty("subnet")
    public void setSubnet(Subnet subnet) {
        this.subnet = subnet;
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

}
