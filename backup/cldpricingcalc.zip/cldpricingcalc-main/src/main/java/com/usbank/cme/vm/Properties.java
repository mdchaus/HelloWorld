
package com.usbank.cme.vm;

import java.util.LinkedHashMap;
import java.util.Map;
import javax.annotation.Generated;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "diagnosticsProfile",
    "extensionsTimeBudget",
    "hardwareProfile",
    "licenseType",
    "networkProfile",
    "osProfile",
    "priority",
    "provisioningState",
    "securityProfile",
    "storageProfile",
    "timeCreated",
    "vmId"
})
@Generated("jsonschema2pojo")
public class Properties {

    @JsonProperty("diagnosticsProfile")
    private DiagnosticsProfile diagnosticsProfile;
    @JsonProperty("extensionsTimeBudget")
    private String extensionsTimeBudget;
    @JsonProperty("hardwareProfile")
    private HardwareProfile hardwareProfile;
    @JsonProperty("licenseType")
    private String licenseType;
    @JsonProperty("networkProfile")
    private NetworkProfile networkProfile;
    @JsonProperty("osProfile")
    private OsProfile osProfile;
    @JsonProperty("priority")
    private String priority;
    @JsonProperty("provisioningState")
    private String provisioningState;
    @JsonProperty("securityProfile")
    private SecurityProfile securityProfile;
    @JsonProperty("storageProfile")
    private StorageProfile storageProfile;
    @JsonProperty("timeCreated")
    private String timeCreated;
    @JsonProperty("vmId")
    private String vmId;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new LinkedHashMap<String, Object>();

    @JsonProperty("diagnosticsProfile")
    public DiagnosticsProfile getDiagnosticsProfile() {
        return diagnosticsProfile;
    }

    @JsonProperty("diagnosticsProfile")
    public void setDiagnosticsProfile(DiagnosticsProfile diagnosticsProfile) {
        this.diagnosticsProfile = diagnosticsProfile;
    }

    @JsonProperty("extensionsTimeBudget")
    public String getExtensionsTimeBudget() {
        return extensionsTimeBudget;
    }

    @JsonProperty("extensionsTimeBudget")
    public void setExtensionsTimeBudget(String extensionsTimeBudget) {
        this.extensionsTimeBudget = extensionsTimeBudget;
    }

    @JsonProperty("hardwareProfile")
    public HardwareProfile getHardwareProfile() {
        return hardwareProfile;
    }

    @JsonProperty("hardwareProfile")
    public void setHardwareProfile(HardwareProfile hardwareProfile) {
        this.hardwareProfile = hardwareProfile;
    }

    @JsonProperty("licenseType")
    public String getLicenseType() {
        return licenseType;
    }

    @JsonProperty("licenseType")
    public void setLicenseType(String licenseType) {
        this.licenseType = licenseType;
    }

    @JsonProperty("networkProfile")
    public NetworkProfile getNetworkProfile() {
        return networkProfile;
    }

    @JsonProperty("networkProfile")
    public void setNetworkProfile(NetworkProfile networkProfile) {
        this.networkProfile = networkProfile;
    }

    @JsonProperty("osProfile")
    public OsProfile getOsProfile() {
        return osProfile;
    }

    @JsonProperty("osProfile")
    public void setOsProfile(OsProfile osProfile) {
        this.osProfile = osProfile;
    }

    @JsonProperty("priority")
    public String getPriority() {
        return priority;
    }

    @JsonProperty("priority")
    public void setPriority(String priority) {
        this.priority = priority;
    }

    @JsonProperty("provisioningState")
    public String getProvisioningState() {
        return provisioningState;
    }

    @JsonProperty("provisioningState")
    public void setProvisioningState(String provisioningState) {
        this.provisioningState = provisioningState;
    }

    @JsonProperty("securityProfile")
    public SecurityProfile getSecurityProfile() {
        return securityProfile;
    }

    @JsonProperty("securityProfile")
    public void setSecurityProfile(SecurityProfile securityProfile) {
        this.securityProfile = securityProfile;
    }

    @JsonProperty("storageProfile")
    public StorageProfile getStorageProfile() {
        return storageProfile;
    }

    @JsonProperty("storageProfile")
    public void setStorageProfile(StorageProfile storageProfile) {
        this.storageProfile = storageProfile;
    }

    @JsonProperty("timeCreated")
    public String getTimeCreated() {
        return timeCreated;
    }

    @JsonProperty("timeCreated")
    public void setTimeCreated(String timeCreated) {
        this.timeCreated = timeCreated;
    }

    @JsonProperty("vmId")
    public String getVmId() {
        return vmId;
    }

    @JsonProperty("vmId")
    public void setVmId(String vmId) {
        this.vmId = vmId;
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

}
