package com.usbank.cme.dto;

import lombok.Data;

import java.util.ArrayList;
import java.util.List;

@Data
public class BomRequestDto {

    String carId;
    String subscriptions;
    String appContextName;
    Boolean secondaryRegion;
    List<VM> vms = new ArrayList<>();
    List<DB> dbs =  new ArrayList<>();
    List<LB> lbs = new ArrayList<>();
}
