
package com.usbank.cme.pe;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import javax.annotation.Generated;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "groupIds",
    "privateLinkServiceConnectionState",
    "privateLinkServiceId",
    "provisioningState"
})
@Generated("jsonschema2pojo")
public class Properties__1 {

    @JsonProperty("groupIds")
    private List<String> groupIds;
    @JsonProperty("privateLinkServiceConnectionState")
    private PrivateLinkServiceConnectionState privateLinkServiceConnectionState;
    @JsonProperty("privateLinkServiceId")
    private String privateLinkServiceId;
    @JsonProperty("provisioningState")
    private String provisioningState;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new LinkedHashMap<String, Object>();

    @JsonProperty("groupIds")
    public List<String> getGroupIds() {
        return groupIds;
    }

    @JsonProperty("groupIds")
    public void setGroupIds(List<String> groupIds) {
        this.groupIds = groupIds;
    }

    @JsonProperty("privateLinkServiceConnectionState")
    public PrivateLinkServiceConnectionState getPrivateLinkServiceConnectionState() {
        return privateLinkServiceConnectionState;
    }

    @JsonProperty("privateLinkServiceConnectionState")
    public void setPrivateLinkServiceConnectionState(PrivateLinkServiceConnectionState privateLinkServiceConnectionState) {
        this.privateLinkServiceConnectionState = privateLinkServiceConnectionState;
    }

    @JsonProperty("privateLinkServiceId")
    public String getPrivateLinkServiceId() {
        return privateLinkServiceId;
    }

    @JsonProperty("privateLinkServiceId")
    public void setPrivateLinkServiceId(String privateLinkServiceId) {
        this.privateLinkServiceId = privateLinkServiceId;
    }

    @JsonProperty("provisioningState")
    public String getProvisioningState() {
        return provisioningState;
    }

    @JsonProperty("provisioningState")
    public void setProvisioningState(String provisioningState) {
        this.provisioningState = provisioningState;
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

}
