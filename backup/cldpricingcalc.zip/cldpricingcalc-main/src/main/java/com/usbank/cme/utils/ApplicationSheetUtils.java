package com.usbank.cme.utils;

import com.usbank.cme.dto.BomMetadata;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import java.util.HashMap;

public class ApplicationSheetUtils {

    public static void createApplicationSheet(BomMetadata metadata, XSSFWorkbook workbook) {
        XSSFSheet sheet = workbook.getSheet("Application");


        HashMap<Integer, Object[]> data = new HashMap<Integer, Object[]>();
        int count = 2;

        for (String sub : metadata.getDevSubscriptions().split(",")) {
            if (sheet == null) {
                sheet = workbook.createSheet("Application");
                ExcelUtils.changeColumnWidth(sheet, 25);
            }
            data.put(1, new Object[]{""});
            data.put(2, new Object[]{"Region", "Subscription Name", "Automation Tool", "Description"});
            data.put(++count, new Object[]{"Central US", sub, "Manual", "Dev subscription"});
            data.put(++count, new Object[]{"Central US", sub.replace("dev", "it"), "Manual", "IT subscription"});
            data.put(++count, new Object[]{"Central US", sub.replace("dev", "uat"), "Manual", "UAT Central  subscription"});
            data.put(++count, new Object[]{"Central US", sub.replace("dev", "prod"), "Manual", "Prod Central subscription"});
            if (metadata.getSecondaryRegion() == Boolean.TRUE) {
                data.put(++count, new Object[]{"East US", sub.replace("dev", "uat"), "Manual", "UAT East subscription"});
                data.put(++count, new Object[]{"East US", sub.replace("dev", "prod"), "Manual", "Prod East subscription"});
            }

        }
        ExcelUtils.putDataIntoCellsSorted(data, sheet);
    }
}
