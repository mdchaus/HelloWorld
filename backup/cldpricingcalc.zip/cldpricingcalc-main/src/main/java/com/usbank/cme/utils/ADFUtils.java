package com.usbank.cme.utils;

import com.usbank.cme.dto.BomMetadata;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import java.util.HashMap;
import java.util.Map;

public class ADFUtils {

    public static void createADFSheet(BomMetadata metadata, XSSFWorkbook workbook) {
        XSSFSheet sheet = workbook.getSheet("Azure Data Factory");
        HashMap<Integer, Object[]> data = new HashMap<Integer, Object[]>();
        int count = 2;
        for (Map.Entry<String, String> adf : metadata.getAdfs().entrySet()) {
            if (sheet == null) {
                sheet = workbook.createSheet("Azure Data Factory");
                ExcelUtils.changeColumnWidth(sheet, 25);
            }

            data.put(2, new Object[]{"Environment", "Action", "Service Name", "Resource Group Name", "Name"});
            data.put(++count, new Object[]{"DEV", "Create", "Azure Data Factory",adf.getValue(), adf.getKey()});
            /*data.put(++count, new Object[]{"IT", "Create", "Azure Data Factory", adf.getValue().replace("dev" , "it"), adf.getKey().replace("dev" , "it")});
            data.put(++count, new Object[]{"UAT-Primary", "Create", "Azure Data Factory", adf.getValue().replace("dev" , "uat") , adf.getKey().replace("dev" , "uat")});
            data.put(++count, new Object[]{"PROD-Primary", "Create", "Azure Data Factory", adf.getValue().replace("dev" , "prod"), adf.getKey().replace("dev" , "prod")});
            if (metadata.getSecondaryRegion() == Boolean.TRUE) {
                data.put(++count, new Object[]{"UAT-Secondary", "Create", "Azure Data Factory", adf.getValue().replace("dev" , "uat").replace("cus" , "eus2"), adf.getKey().replace("dev" , "uat").replace("cus" , "eus2")});
                data.put(++count, new Object[]{"PROD-Secondary", "Create", "Azure Data Factory", adf.getValue().replace("dev" , "prod").replace("cus" , "eus2"), adf.getKey().replace("dev" , "prod").replace("cus" , "eus2")});
            }*/
        }
        ExcelUtils.putDataIntoCellsSorted(data, sheet);
    }
}
