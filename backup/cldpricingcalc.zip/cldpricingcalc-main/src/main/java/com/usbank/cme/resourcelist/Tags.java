
package com.usbank.cme.resourcelist;

import java.util.LinkedHashMap;
import java.util.Map;
import javax.annotation.Generated;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "Name",
    "applicationUid",
    "assignment_group",
    "blueprintName",
    "car_id",
    "componentUid",
    "confidentiality",
    "cost_center",
    "dconf",
    "deployment_id",
    "environment",
    "maintenance_type",
    "module_version",
    "owner",
    "tf_creator",
    "tf_origin",
    "tf_owner",
    "tfstatefile",
    "usbcloudPlatformVersion",
    "usbcloudPlatformVersionPinned"
})
@Generated("jsonschema2pojo")
public class Tags {

    @JsonProperty("Name")
    private String name;
    @JsonProperty("applicationUid")
    private String applicationUid;
    @JsonProperty("assignment_group")
    private String assignmentGroup;
    @JsonProperty("blueprintName")
    private String blueprintName;
    @JsonProperty("car_id")
    private String carId;
    @JsonProperty("componentUid")
    private String componentUid;
    @JsonProperty("confidentiality")
    private String confidentiality;
    @JsonProperty("cost_center")
    private String costCenter;
    @JsonProperty("dconf")
    private String dconf;
    @JsonProperty("deployment_id")
    private String deploymentId;
    @JsonProperty("environment")
    private String environment;
    @JsonProperty("maintenance_type")
    private String maintenanceType;
    @JsonProperty("module_version")
    private String moduleVersion;
    @JsonProperty("owner")
    private String owner;
    @JsonProperty("tf_creator")
    private String tfCreator;
    @JsonProperty("tf_origin")
    private String tfOrigin;
    @JsonProperty("tf_owner")
    private String tfOwner;
    @JsonProperty("tfstatefile")
    private String tfstatefile;
    @JsonProperty("usbcloudPlatformVersion")
    private String usbcloudPlatformVersion;
    @JsonProperty("usbcloudPlatformVersionPinned")
    private String usbcloudPlatformVersionPinned;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new LinkedHashMap<String, Object>();

    @JsonProperty("Name")
    public String getName() {
        return name;
    }

    @JsonProperty("Name")
    public void setName(String name) {
        this.name = name;
    }

    @JsonProperty("applicationUid")
    public String getApplicationUid() {
        return applicationUid;
    }

    @JsonProperty("applicationUid")
    public void setApplicationUid(String applicationUid) {
        this.applicationUid = applicationUid;
    }

    @JsonProperty("assignment_group")
    public String getAssignmentGroup() {
        return assignmentGroup;
    }

    @JsonProperty("assignment_group")
    public void setAssignmentGroup(String assignmentGroup) {
        this.assignmentGroup = assignmentGroup;
    }

    @JsonProperty("blueprintName")
    public String getBlueprintName() {
        return blueprintName;
    }

    @JsonProperty("blueprintName")
    public void setBlueprintName(String blueprintName) {
        this.blueprintName = blueprintName;
    }

    @JsonProperty("car_id")
    public String getCarId() {
        return carId;
    }

    @JsonProperty("car_id")
    public void setCarId(String carId) {
        this.carId = carId;
    }

    @JsonProperty("componentUid")
    public String getComponentUid() {
        return componentUid;
    }

    @JsonProperty("componentUid")
    public void setComponentUid(String componentUid) {
        this.componentUid = componentUid;
    }

    @JsonProperty("confidentiality")
    public String getConfidentiality() {
        return confidentiality;
    }

    @JsonProperty("confidentiality")
    public void setConfidentiality(String confidentiality) {
        this.confidentiality = confidentiality;
    }

    @JsonProperty("cost_center")
    public String getCostCenter() {
        return costCenter;
    }

    @JsonProperty("cost_center")
    public void setCostCenter(String costCenter) {
        this.costCenter = costCenter;
    }

    @JsonProperty("dconf")
    public String getDconf() {
        return dconf;
    }

    @JsonProperty("dconf")
    public void setDconf(String dconf) {
        this.dconf = dconf;
    }

    @JsonProperty("deployment_id")
    public String getDeploymentId() {
        return deploymentId;
    }

    @JsonProperty("deployment_id")
    public void setDeploymentId(String deploymentId) {
        this.deploymentId = deploymentId;
    }

    @JsonProperty("environment")
    public String getEnvironment() {
        return environment;
    }

    @JsonProperty("environment")
    public void setEnvironment(String environment) {
        this.environment = environment;
    }

    @JsonProperty("maintenance_type")
    public String getMaintenanceType() {
        return maintenanceType;
    }

    @JsonProperty("maintenance_type")
    public void setMaintenanceType(String maintenanceType) {
        this.maintenanceType = maintenanceType;
    }

    @JsonProperty("module_version")
    public String getModuleVersion() {
        return moduleVersion;
    }

    @JsonProperty("module_version")
    public void setModuleVersion(String moduleVersion) {
        this.moduleVersion = moduleVersion;
    }

    @JsonProperty("owner")
    public String getOwner() {
        return owner;
    }

    @JsonProperty("owner")
    public void setOwner(String owner) {
        this.owner = owner;
    }

    @JsonProperty("tf_creator")
    public String getTfCreator() {
        return tfCreator;
    }

    @JsonProperty("tf_creator")
    public void setTfCreator(String tfCreator) {
        this.tfCreator = tfCreator;
    }

    @JsonProperty("tf_origin")
    public String getTfOrigin() {
        return tfOrigin;
    }

    @JsonProperty("tf_origin")
    public void setTfOrigin(String tfOrigin) {
        this.tfOrigin = tfOrigin;
    }

    @JsonProperty("tf_owner")
    public String getTfOwner() {
        return tfOwner;
    }

    @JsonProperty("tf_owner")
    public void setTfOwner(String tfOwner) {
        this.tfOwner = tfOwner;
    }

    @JsonProperty("tfstatefile")
    public String getTfstatefile() {
        return tfstatefile;
    }

    @JsonProperty("tfstatefile")
    public void setTfstatefile(String tfstatefile) {
        this.tfstatefile = tfstatefile;
    }

    @JsonProperty("usbcloudPlatformVersion")
    public String getUsbcloudPlatformVersion() {
        return usbcloudPlatformVersion;
    }

    @JsonProperty("usbcloudPlatformVersion")
    public void setUsbcloudPlatformVersion(String usbcloudPlatformVersion) {
        this.usbcloudPlatformVersion = usbcloudPlatformVersion;
    }

    @JsonProperty("usbcloudPlatformVersionPinned")
    public String getUsbcloudPlatformVersionPinned() {
        return usbcloudPlatformVersionPinned;
    }

    @JsonProperty("usbcloudPlatformVersionPinned")
    public void setUsbcloudPlatformVersionPinned(String usbcloudPlatformVersionPinned) {
        this.usbcloudPlatformVersionPinned = usbcloudPlatformVersionPinned;
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

}
