package com.usbank.cme.utils;

import com.usbank.cme.dto.BomMetadata;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import java.util.HashMap;
import java.util.Map;

public class NoMappingUtils {

    public static void createNoMappingSheet(BomMetadata metadata, XSSFWorkbook workbook) {
        HashMap<Integer, Object[]> data = new HashMap<Integer, Object[]>();
        XSSFSheet sheet = null;
        int count = 2;
        for (Map.Entry<String, String> nm : metadata.getNoMappings().entrySet())
        {
            sheet = workbook.getSheet("NoMapping");
            data.put(2, new Object[]{"Environment", "Action", "Service Family", "Service Name", "Product Name", "Resource Group"});

            if (sheet == null) {
                sheet = workbook.createSheet("NoMapping");
                ExcelUtils.changeColumnWidth(sheet, 30);
            }
            data.put(++count, new Object[]{"Development", "Create", "", "", nm.getKey(), nm.getValue()});
        }
        ExcelUtils.putDataIntoCellsSorted(data, sheet);
    }
}
