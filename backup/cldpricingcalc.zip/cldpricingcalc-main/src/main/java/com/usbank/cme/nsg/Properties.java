
package com.usbank.cme.nsg;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import javax.annotation.Generated;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "defaultSecurityRules",
    "flowLogs",
    "provisioningState",
    "resourceGuid",
    "securityRules",
    "subnets"
})
@Generated("jsonschema2pojo")
public class Properties {

    @JsonProperty("defaultSecurityRules")
    private List<DefaultSecurityRule> defaultSecurityRules;
    @JsonProperty("flowLogs")
    private List<FlowLog> flowLogs;
    @JsonProperty("provisioningState")
    private String provisioningState;
    @JsonProperty("resourceGuid")
    private String resourceGuid;
    @JsonProperty("securityRules")
    private List<Object> securityRules;
    @JsonProperty("subnets")
    private List<Subnet> subnets;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new LinkedHashMap<String, Object>();

    @JsonProperty("defaultSecurityRules")
    public List<DefaultSecurityRule> getDefaultSecurityRules() {
        return defaultSecurityRules;
    }

    @JsonProperty("defaultSecurityRules")
    public void setDefaultSecurityRules(List<DefaultSecurityRule> defaultSecurityRules) {
        this.defaultSecurityRules = defaultSecurityRules;
    }

    @JsonProperty("flowLogs")
    public List<FlowLog> getFlowLogs() {
        return flowLogs;
    }

    @JsonProperty("flowLogs")
    public void setFlowLogs(List<FlowLog> flowLogs) {
        this.flowLogs = flowLogs;
    }

    @JsonProperty("provisioningState")
    public String getProvisioningState() {
        return provisioningState;
    }

    @JsonProperty("provisioningState")
    public void setProvisioningState(String provisioningState) {
        this.provisioningState = provisioningState;
    }

    @JsonProperty("resourceGuid")
    public String getResourceGuid() {
        return resourceGuid;
    }

    @JsonProperty("resourceGuid")
    public void setResourceGuid(String resourceGuid) {
        this.resourceGuid = resourceGuid;
    }

    @JsonProperty("securityRules")
    public List<Object> getSecurityRules() {
        return securityRules;
    }

    @JsonProperty("securityRules")
    public void setSecurityRules(List<Object> securityRules) {
        this.securityRules = securityRules;
    }

    @JsonProperty("subnets")
    public List<Subnet> getSubnets() {
        return subnets;
    }

    @JsonProperty("subnets")
    public void setSubnets(List<Subnet> subnets) {
        this.subnets = subnets;
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

}
