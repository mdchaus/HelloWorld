package com.usbank.cme.dto;

public enum StorageType {

    Files , Blob
}
