# fabric-devops
A sample project which uses GitHub actions, Python and the Fabric REST API to demonstrate deploying solutions.
