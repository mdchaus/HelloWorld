﻿# ADO Project used to demonstrate workspace export/import with Fabric REST API 

This is a demo readme file.